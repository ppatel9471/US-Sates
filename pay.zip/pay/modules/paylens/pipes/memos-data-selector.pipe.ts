import { Pipe, PipeTransform } from '@angular/core';

import { PayStatementsUI } from '../../pay-statements-shared/models/pay-statement-ui';

@Pipe({ name: 'memosDataSelector', pure: true })
export class MemosDataSelectorPipe implements PipeTransform {
  public transform(memos: PayStatementsUI.Memos, useYTD: boolean): PayStatementsUI.Memos {
    return {
      otherMemos: this.filterMemos(memos?.otherMemos, useYTD),
      taxableBenefits: this.filterMemos(memos?.taxableBenefits, useYTD)
    };
  }

  private filterMemos(memos: PayStatementsUI.Memo[], useYTD: boolean): PayStatementsUI.Memo[] {
    return memos?.filter((memo: PayStatementsUI.Memo) => (useYTD ? memo?.amountYTD : memo?.amount));
  }
}
