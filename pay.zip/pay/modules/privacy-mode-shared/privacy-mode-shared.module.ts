import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ToggleSwitchModule } from '@synerg/components/toggle-switch';

import { MyAdpCommonModule } from '@myadp/common';

import { PrivacyModeToggleComponent } from './privacy-mode-toggle/privacy-mode-toggle.component';

@NgModule({
  imports: [CommonModule, MyAdpCommonModule, ToggleSwitchModule],
  declarations: [PrivacyModeToggleComponent],
  exports: [PrivacyModeToggleComponent]
})
export class PrivacyModeSharedModule {}
