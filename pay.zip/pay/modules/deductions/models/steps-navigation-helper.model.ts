import { WorkflowUI } from '../../shared/models/workflow-ui.model';
import { STEPS } from './steps.enum';

export { STEPS } from './steps.enum';

// TODO: could likely be shared typings between DD

export interface ProgressProperties {
  hidden?: boolean;
  disabled?: boolean;
}

export type StepNavigationActions = WorkflowUI.ChangeType | 'root';

export interface StepStateProps {
  prev?: ProgressProperties;
  next?: ProgressProperties;
  cancel?: ProgressProperties;
  isEditing?: boolean;
  showProgress?: boolean;
  showHeader?: boolean;
  hideNavigation?: boolean;
  isLastStep?: boolean;
  isFirstStep?: boolean;
  isSubmitStep?: boolean;
}

export interface StepNavigationDetails {
  stepComponent: STEPS;
  tag?: StepNavigationActions;
  stepProps?: StepStateProps;
  current?: number;
  outOf?: number;
}
