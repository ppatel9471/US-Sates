import { CurrencyPipe } from '@angular/common';
import { waitForAsync } from '@angular/core/testing';
import { of } from 'rxjs';
import { Shallow } from 'shallow-render';

import { LanguageService } from '@myadp/common';
import { WorkerTaxStatementsDTO } from '@myadp/dto';

import { PrivacyModeStore } from '../../../privacy-mode-shared/store/privacy-mode.store';
import { CurrencyFormatComponent } from '../../../shared/components/currency-format/currency-format.component';
import { DownloadPdfDirective } from '../../../shared/directives/download-pdf.directive';
import { ValueFormatterService } from '../../../shared/services/value-formatter.service';
import { TaxStatementsType } from '../../models/tax-statements.model';
import { TaxStatementsTileModule } from '../../tax-statements-tile.module';
import { TaxStatementsDetailComponent } from './tax-statements-detail.component';

describe('TaxStatementsDetailComponent', () => {
  let shallow: Shallow<TaxStatementsDetailComponent>;
  let mockStatement: WorkerTaxStatementsDTO.WorkerTaxStatement = {
    statementName: '2013 W-2',
    employerName: 'AUTOMATIC DATA PROCESSING',
    form: {
      code: 'W-2'
    },
    statementYear: {
      year: '2013'
    },
    summaryAmount: {
      amountValue: 20130,
      currencyCode: 'USD'
    },
    statementImageUri: {
      href: 'mockPDF.pdf'
    }
  };
  beforeEach(
    waitForAsync(() => {
      shallow = new Shallow(TaxStatementsDetailComponent, TaxStatementsTileModule)
        .provide(ValueFormatterService)
        .provide(CurrencyPipe)
        .provide(LanguageService)
        .mock(LanguageService, {
          get: (key) => key
        })
        .mock(PrivacyModeStore, {
          showMaskedValue$: of(false)
        })
        .dontMock(ValueFormatterService)
        .dontMock(CurrencyPipe)
        .dontMock(CurrencyFormatComponent);
    })
  );
  it('should generate an aria label', async () => {
    const { instance } = await shallow
      .mock(LanguageService, {
        get: (key) => key
      })
      .render({
        bind: {
          statement: mockStatement
        }
      });

    expect(instance.ariaLabelForViewStatement).toBe('myadp-pay.PAY_VIEW_STATEMENT_ARIA');
  });

  it('should use AudioEye when viewing W2 forms', async () => {
    const { findDirective, instance } = await shallow.render({
      bind: {
        statement: {
          statementName: '2013 W-2',
          form: {
            code: 'W2'
          },
          statementYear: {
            year: '2013'
          },
          summaryAmount: {
            amountValue: 20130,
            currencyCode: 'USD'
          },
          statementImageUri: {
            href: 'mockPDF.pdf'
          }
        }
      }
    });

    expect(instance.useAudioEye).toBeTrue();
    expect(findDirective(DownloadPdfDirective).useAudioEye).toBeTrue();
  });

  it('should use AudioEye when viewing W-2 forms', async () => {
    const { findDirective, instance } = await shallow.render({
      bind: {
        statement: {
          statementName: '2013 W-2',
          form: {
            code: 'W-2'
          },
          statementYear: {
            year: '2013'
          },
          summaryAmount: {
            amountValue: 20130,
            currencyCode: 'USD'
          },
          statementImageUri: {
            href: 'mockPDF.pdf'
          }
        }
      }
    });

    expect(instance.useAudioEye).toBeTrue();
    expect(findDirective(DownloadPdfDirective).useAudioEye).toBeTrue();
  });

  it('should not use AudioEye when viewing other tax statement forms', async () => {
    const { findDirective, instance } = await shallow.render({
      bind: {
        statement: {
          statementName: '2014 1099-R',
          form: {
            code: '1099-R'
          },
          statementYear: {
            year: '2014'
          },
          summaryAmount: {
            amountValue: 10300,
            currencyCode: 'USD'
          },
          statementImageUri: {
            href: 'mockPDF.pdf'
          }
        }
      }
    });

    expect(instance.useAudioEye).toBeFalse();
    expect(findDirective(DownloadPdfDirective).useAudioEye).toBeFalse();
  });

  describe('form code', () => {
    it('should show form code', async () => {
      const { find } = await shallow.render({
        bind: {
          statement: mockStatement
        }
      });
      expect(find('div[data-e2e="form-code"]')).toHaveFound(1);
    });

    it('should hide form code', async () => {
      mockStatement.form = undefined;
      const { find } = await shallow.render({
        bind: {
          statement: mockStatement
        }
      });
      expect(find('div[data-e2e="form-code"]')).toHaveFound(0);
    });
  });

  describe('employer name', () => {
    it('should show employer name', async () => {
      const { find } = await shallow.render({
        bind: {
          statement: mockStatement
        }
      });
      expect(find('div[data-e2e="employer-name"]')).toHaveFound(1);
    });

    it('should hide employer name when form is 1099-MISC', async () => {
      mockStatement.form = { code: TaxStatementsType.MISCELLANEOUS };
      const { find } = await shallow.render({
        bind: {
          statement: mockStatement
        }
      });
      expect(find('div[data-e2e="employer-name"]')).toHaveFound(0);
    });

    it('should hide employer name when form is 1099', async () => {
      mockStatement.form = { code: TaxStatementsType.SELFEMPLOYMENT };
      const { find } = await shallow.render({
        bind: {
          statement: mockStatement
        }
      });
      expect(find('div[data-e2e="employer-name"]')).toHaveFound(0);
    });

    it('should hide employer name when form is 1099-R', async () => {
      mockStatement.form = { code: TaxStatementsType.RETIREMENT };
      const { find } = await shallow.render({
        bind: {
          statement: mockStatement
        }
      });
      expect(find('div[data-e2e="employer-name"]')).toHaveFound(0);
    });

    it('should hide employer name when there is no employer name', async () => {
      mockStatement = {
        statementName: '2013 W-2',
        form: {
          code: 'W-2'
        },
        statementYear: {
          year: '2013'
        },
        summaryAmount: {
          amountValue: 20130,
          currencyCode: 'USD'
        },
        statementImageUri: {
          href: 'mockPDF.pdf'
        }
      };
      const { find } = await shallow.render({
        bind: {
          statement: mockStatement
        }
      });
      expect(find('div[data-e2e="employer-name"]')).toHaveFound(0);
    });
  });
});
