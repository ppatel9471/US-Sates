import { formatDate } from '@angular/common';
import { Inject, Injectable, LOCALE_ID } from '@angular/core';
import * as moment from 'moment';
import { combineLatest, Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import {
  Address,
  PayrollWorkerWorkAssignment,
  WorkAssignment,
  Worker,
  WorkerName
} from '@myadp/dto';
import { BaseStore } from '@myadp/pay-shared';

import {
  EMPTY_WORKER_INFO_STORE,
  WorkerInfoStoreSlice,
  WorkerInfoStoreState
} from '../models/worker-info-state.model';
import { WorkerInfo, WorkerSsn } from '../models/worker-info.model';

@Injectable({
  providedIn: 'root'
})
export class WorkerInfoStore extends BaseStore<WorkerInfoStoreState> {
  constructor(@Inject(LOCALE_ID) private locale: string) {
    super(EMPTY_WORKER_INFO_STORE);
  }

  public worker$(): Observable<Worker> {
    return this.getData$(WorkerInfoStoreSlice.WORKER, undefined, null);
  }

  public workLocation$(): Observable<Address> {
    return this.getData$(WorkerInfoStoreSlice.WORKER_WORK_ASSIGNMENTS, undefined, null).pipe(
      map((workAssignments: WorkAssignment[] | PayrollWorkerWorkAssignment) => {
        return (
          (workAssignments as WorkAssignment[])?.[0]?.assignedWorkLocations?.[0]?.address ||
          (workAssignments as PayrollWorkerWorkAssignment)?.assignedWorkLocations?.[0]?.address
        );
      })
    );
  }

  public workerIsLoading$(): Observable<boolean> {
    return this.isSliceLoading$(WorkerInfoStoreSlice.WORKER);
  }

  public ssnValidateError$(): Observable<boolean> {
    return this.getData$(WorkerInfoStoreSlice.WORKER_SSN, 'isValid', null);
  }

  public ssnValidateReason$(): Observable<string> {
    return this.getData$(WorkerInfoStoreSlice.WORKER_SSN, 'validateReason', null);
  }

  public workerError$(): Observable<boolean> {
    return this.hasError$(WorkerInfoStoreSlice.WORKER, 'loadWorkerError');
  }

  public workerInfo$(): Observable<WorkerInfo> {
    return this.getData$(WorkerInfoStoreSlice.WORKER_INFO, undefined, null);
  }

  public workerSsn$(): Observable<WorkerSsn> {
    return this.getData$(WorkerInfoStoreSlice.WORKER_SSN, undefined, null);
  }

  public formattedSsn$(): Observable<string> {
    return this.getData$(WorkerInfoStoreSlice.WORKER_SSN, 'formattedSSN', null);
  }

  public workerSsnIsLoading$(): Observable<boolean> {
    return this.isSliceLoading$(WorkerInfoStoreSlice.WORKER_SSN);
  }

  public workerSsnError$(): Observable<boolean> {
    return this.hasError$(WorkerInfoStoreSlice.WORKER_SSN, 'loadWorkerSsnError');
  }

  public workerBirthDate$(): Observable<string> {
    return this.getData$(WorkerInfoStoreSlice.WORKER_BIRTHDATE, undefined, null);
  }

  public workerFormattedBirthDate$(): Observable<string> {
    return this.workerBirthDate$().pipe(
      map((birthDate) => formatDate(birthDate, 'longDate', this.locale))
    );
  }

  public workerBirthDateIsLoading$(): Observable<boolean> {
    return this.isSliceLoading$(WorkerInfoStoreSlice.WORKER_BIRTHDATE);
  }

  public workerBirthDateError$(): Observable<boolean> {
    return this.hasError$(WorkerInfoStoreSlice.WORKER_BIRTHDATE, 'loadWorkerBirthDateError');
  }

  public workerSsnOrBirthDateIsLoading$(): Observable<boolean> {
    return this.isSliceLoading$(
      WorkerInfoStoreSlice.WORKER_SSN,
      WorkerInfoStoreSlice.WORKER_BIRTHDATE
    );
  }

  public workerSsnOrBirthDateIsLoadingOrHasError$(): Observable<boolean> {
    // disable next button when unmaskSsn or unmaskBirthDate is loading or unmaskSsn has error
    return combineLatest([
      this.getData$(WorkerInfoStoreSlice.WORKER_SSN, 'isValid').pipe(map((isValid) => !isValid)),
      this.hasError$(WorkerInfoStoreSlice.WORKER_SSN, 'loadWorkerSsnError'),
      this.isSliceLoading$(WorkerInfoStoreSlice.WORKER_SSN, WorkerInfoStoreSlice.WORKER_BIRTHDATE)
    ]).pipe(
      map(
        ([validateError, workerSsnError, workerSsnOrBirthdateLoading]) =>
          validateError || workerSsnError || workerSsnOrBirthdateLoading
      )
    );
  }

  public legalName$(): Observable<WorkerName> {
    return this.getData$(WorkerInfoStoreSlice.WORKER_INFO, 'legalName', null);
  }

  public birthDate$(): Observable<string> {
    return this.getData$(WorkerInfoStoreSlice.WORKER_INFO, 'birthDate', null);
  }

  public getBirthDate(): string {
    return this.getData(WorkerInfoStoreSlice.WORKER_BIRTHDATE, undefined, null);
  }

  public defaultPhone(): string {
    const { mobiles, landlines } =
      this.getData(WorkerInfoStoreSlice.WORKER, 'person')?.communication ?? {};
    const phones = [].concat(mobiles, landlines).filter((n) => n); // filter out nulls

    return phones.length ? phones[0].formattedNumber : '';
  }

  public employmentDate(): string {
    return (
      (this.getData(WorkerInfoStoreSlice.WORKER, 'workerDates')?.rehireDate ?? null) ||
      (this.getData(WorkerInfoStoreSlice.WORKER, 'workerDates')?.originalHireDate ?? null)
    );
  }

  public determineEmploymentDate(formEmploymentDate: string): string {
    let employmentDate = formEmploymentDate || this.employmentDate();

    if (employmentDate && moment(employmentDate, moment.ISO_8601, true).isValid()) {
      employmentDate = moment(employmentDate, moment.ISO_8601, true).format('MM/DD/YYYY');
    }
    return employmentDate;
  }
}
