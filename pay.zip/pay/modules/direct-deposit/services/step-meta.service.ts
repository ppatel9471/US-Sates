import { Injectable } from '@angular/core';

import { PayDistributionStore } from '../../pay-distributions-shared/store/pay-distribution.store';
import { buildAccountDetailsStepMeta } from '../components/steps/account-details/form-control/account-details-form.utils';
import { buildDepositAmountStepMeta } from '../components/steps/deposit-amount/form-control/deposit-amount-form.utils';
import { StepMeta } from '../models/step-meta.model';
import { DirectDepositStore } from '../store/direct-deposit.store';
import { StepsStore } from '../store/steps/steps.store';
import { BaseStepService } from './base-step.service';

@Injectable({
  providedIn: 'root'
})
export class StepMetaService extends BaseStepService {
  constructor(
    protected stepsStore: StepsStore,
    private directDepositStore: DirectDepositStore,
    private payDistributionStore: PayDistributionStore
  ) {
    super(stepsStore);
  }

  public getStepMeta(): StepMeta {
    return !this.isEditing ? this.getMeta(this.currentStep) : this.getEditStepMeta();
  }

  private getEditStepMeta(): StepMeta {
    return {
      ...this.getMeta('ACCOUNT_DETAILS'),
      ...this.getMeta('DEPOSIT_AMOUNT')
    };
  }

  private getMeta(stepName: string): StepMeta {
    const payDistributionMeta = this.payDistributionStore.payDistributionMetaSnapshot;
    const accountDetails = buildAccountDetailsStepMeta(
      payDistributionMeta,
      this.isEditing,
      this.directDepositStore.isAvsddm
    );

    if (!this.directDepositStore.hasStaticAccountTypes) {
      accountDetails.accountTypes = this.directDepositStore.getAvailableAccountTypes(
        accountDetails.accountTypes
      );
    }

    if (this.directDepositStore.isCanadian) {
      accountDetails.banks =
        this.payDistributionStore.payDistributionMetaSnapshot?.banks?.map((bank) => ({
          value: bank.codeValue,
          label: `${bank.shortName} - ${bank.codeValue}`
        })) || [];
    }

    return {
      ACCOUNT_DETAILS: () => accountDetails,
      DEPOSIT_AMOUNT: () =>
        buildDepositAmountStepMeta(
          this.directDepositStore.getDDAccountsSnapshot(),
          payDistributionMeta,
          this.formData
        )
    }[stepName]();
  }
}
