import { AccountType, ValidationStatusType } from './deposit-account.model';

export enum AccountDetailsControls {
  VALIDATION_STATUS = 'validationStatus',
  ACCOUNT_TYPE_CODE = 'accountTypeCode',
  ACCOUNT_NAME = 'accountName',
  ACCOUNT_NUMBER = 'accountNumber',
  ACCOUNT_CONFIRM = 'accountConfirm',
  ROUTING_NUMBER = 'routingNumber',
  ROUTING_CONFIRM = 'routingConfirm',
  TERMS = 'terms',
  TRANSIT_NUMBER = 'transitNumber',
  TRANSIT_CONFIRM = 'transitConfirm',
  INSTITUTION = 'institution'
}

export interface AccountDetailsForm {
  [AccountDetailsControls.VALIDATION_STATUS]?: ValidationStatusType;
  [AccountDetailsControls.ACCOUNT_TYPE_CODE]?: AccountType;
  [AccountDetailsControls.ACCOUNT_NAME]?: string;
  [AccountDetailsControls.ACCOUNT_NUMBER]?: string;
  [AccountDetailsControls.ACCOUNT_CONFIRM]?: string;
  [AccountDetailsControls.ROUTING_NUMBER]?: string;
  [AccountDetailsControls.ROUTING_CONFIRM]?: string;
  [AccountDetailsControls.TERMS]?: boolean;
  [AccountDetailsControls.INSTITUTION]?: AccountType;
  [AccountDetailsControls.TRANSIT_CONFIRM]?: string;
  [AccountDetailsControls.TRANSIT_NUMBER]?: string;
}
