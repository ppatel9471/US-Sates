import { Component, ElementRef, HostBinding, Input, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { DomSanitizer, SafeUrl } from '@angular/platform-browser';
import { PaginatorLabels } from '@synerg/components/paginator';
import { slideinAnimation } from '@synerg/components/slidein';
import { saveAs } from 'file-saver';
import { Subscription } from 'rxjs';

import { ExternalWindowService } from '@myadp/common';

import { DownloadPdfDirective } from '../../directives/download-pdf.directive';
import { PdfStatement, StatementBehaviorSubject, StatementType } from '../../models/pdf-viewer.model';
import { DownloadPdfService } from '../../services/download-pdf.service';

@Component({
  selector: 'pdf-viewer-slidein',
  templateUrl: 'pdf-viewer-slidein.component.html',
  styleUrls: ['./pdf-viewer-slidein.component.scss'],
  animations: [slideinAnimation]
})
export class PdfViewerSlideinComponent implements OnInit, OnDestroy {
  @ViewChild('pdfViewer')
  public pdfViewer: ElementRef;
  @ViewChild(DownloadPdfDirective)
  public downloadPdfDirective: DownloadPdfDirective;
  @HostBinding('@slideinTransition') slideinTransition = 'slidein';
  @Input() statements: Array<PdfStatement>;
  @Input() type: string;
  public accessibilityEnabled: boolean;
  public stepUpEnabled: boolean;
  public loading: boolean;
  public errorMessage: string;

  public showPdfViewerSlidein: boolean = false;
  public finalUrl: SafeUrl;
  public previousStatementUrl: string;
  public nextStatementUrl: string;

  public downloadError: boolean;
  public pdfBlob: Blob;
  public pdfUrl: string;

  public currentStatementIndex: number;
  public filteredStatements: Array<PdfStatement>;
  public currentStatement: PdfStatement;
  public title: string;
  public statementType = StatementType;
  public pdfSlideinDataSubscription: Subscription;
  public pageNumber: number;
  public selectedStatementUrl: string;

  // to hide paginator label
  public paginatorLabel: Partial<PaginatorLabels> = { pageSize: '' };

  constructor(
    private downloadPdfService: DownloadPdfService,
    private domSanitizer: DomSanitizer,
    private externalWindowService: ExternalWindowService
  ) {}

  public ngOnInit() {
    this.pdfSlideinDataSubscription = this.downloadPdfService.pdfSlideinData$.subscribe(
      (statement: StatementBehaviorSubject) => {
        if (!!statement && this.type === statement.type) {
          this.statements = statement.singleStatement
            ? [statement.singleStatement]
            : this.statements;
          this.filteredStatements = this.statements
            ? this.statements.filter((pdf: PdfStatement) => !!pdf?.uri)
            : [];
          this.setShowPdfViewerSlidein(true);

          this.getCurrentStatementByUrl(statement.uri);

          this.title = this.currentStatement?.title;
          this.pdfUrl = statement.finalUrl;
          this.finalUrl = this.domSanitizer.bypassSecurityTrustResourceUrl(this.pdfUrl);
          this.stepUpEnabled = statement.stepUpEnabled;
          this.accessibilityEnabled = statement.useAudioEye;
        }
      }
    );
  }

  public setShowPdfViewerSlidein(show: boolean): void {
    this.showPdfViewerSlidein = show;
  }

  public download() {
    this.loading = true;
    this.downloadError = false;
    this.downloadPdfService
      .getPdf(this.pdfUrl)
      .toPromise()
      .then((response: ArrayBuffer) => {
        this.pdfBlob = new Blob([new Uint8Array(response)], { type: 'application/pdf' });
        saveAs(this.pdfBlob, `${this.title}.pdf`);
      })
      .catch(() => {
        this.downloadError = true;
        this.errorMessage = this.getErrorMessage();
      })
      .finally(() => (this.loading = false));
  }

  public print() {
    const iframe = this.pdfViewer?.nativeElement;

    if (iframe != null) {
      try {
        iframe.contentWindow.document.execCommand('print', false, null);
      } catch (e) {
        try {
          iframe.contentWindow.focus();
          iframe.contentWindow.print();
        } catch (error) {
          // old version of firefox does not allow user to print pdf
          this.externalWindowService.open({
            uri: this.pdfUrl
          });
        }
      }
    }
  }

  public getCurrentStatementByUrl(url: string) {
    this.currentStatementIndex = this.filteredStatements.findIndex(
      (statement) => statement?.uri === url
    );
    this.currentStatement = this.filteredStatements[this.currentStatementIndex];

    this.previousStatementUrl = this.getStatementUrl(this.currentStatementIndex - 1);
    this.nextStatementUrl = this.getStatementUrl(this.currentStatementIndex + 1);
  }

  public close() {
    this.setShowPdfViewerSlidein(false);
    this.downloadPdfService.pdfSlideinData$.next(null);
    this.pdfBlob = undefined;
    this.pdfUrl = undefined;
    this.currentStatement = undefined;
    this.downloadError = false;
  }

  public onPageChange(event: number) {
    this.selectedStatementUrl = this.getStatementUrl(event - 1);
    // only call download when new statement is not current statement
    if (this.selectedStatementUrl !== this.currentStatement.uri) {
      this.downloadPdfDirective.download(this.selectedStatementUrl);
    }
  }

  public ngOnDestroy() {
    this.pdfSlideinDataSubscription.unsubscribe();
  }

  private getStatementUrl(index: number): string {
    return this.filteredStatements[index]?.uri;
  }

  private getErrorMessage(): string {
    const errorMessage = {
      [StatementType.PAY_STATEMENT]: 'myadp-pay.PDF_SLIDEIN_PAY_STATEMENT_DOWNLOAD_ERROR',
      [StatementType.TAX_STATEMENT]: 'myadp-pay.PDF_SLIDEIN_TAX_STATEMENT_DOWNLOAD_ERROR'
    };
    return errorMessage[this.type] || 'myadp-pay.PDF_SLIDEIN_TAX_WITHHOLDING_DOWNLOAD_ERROR';
  }
}
