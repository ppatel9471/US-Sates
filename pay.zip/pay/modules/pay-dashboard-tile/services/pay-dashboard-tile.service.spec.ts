import { fakeAsync, flush, TestBed } from '@angular/core/testing';
import { Mock } from 'ts-mockery';

import { BaseHttpClient } from '@myadp/common';
import { Amount } from '@myadp/dto';
import { FindSffoService, PAY_SFFO } from '@myadp/pay-shared';

import { PAY_CATEGORY_CONSTANTS } from '../models/pay-category-constants';

import {
  MOCK_DONUT_CONFIG,
  MOCK_PAY_STATEMENTS_RESPONSE
} from '../mocks/mock-data';
import { PayDashboardTileStoreSlice } from '../models/pay-dashboard-tile-state';
import { PayStatementsDTO } from '../models/pay-statement.model';
import { PayDashboardTileService } from './pay-dashboard-tile.service';

describe('PayDashboardTileService', () => {
  const sffo = {
    sffo: { sffo: PAY_SFFO.PAY_STATEMENTS_READ.sffo },
    href: 'foo'
  };

  let baseHttpClient: BaseHttpClient;
  let payService: PayDashboardTileService;
  let findSffoService: FindSffoService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        PayDashboardTileService,
        {
          provide: FindSffoService,
          useValue: Mock.of<FindSffoService>({
            findSffo: () => sffo
          })
        },
        {
          provide: BaseHttpClient,
          useValue: Mock.of<BaseHttpClient>({
            get: () => Promise.resolve<PayStatementsDTO>(MOCK_PAY_STATEMENTS_RESPONSE)
          })
        }
      ]
    });

    baseHttpClient = TestBed.inject(BaseHttpClient);
    payService = TestBed.inject(PayDashboardTileService);
    findSffoService = TestBed.inject(FindSffoService);
  });

  describe('load statements', () => {
    it('should load pay statements', fakeAsync(() => {
      Mock.extend(baseHttpClient).with({
        get: () => Promise.resolve<PayStatementsDTO>(MOCK_PAY_STATEMENTS_RESPONSE)
      });
      payService.loadPayStatements();
      flush();

      expect(payService.stateValue[PayDashboardTileStoreSlice.PAY_STATEMENTS]).toEqual({
        data: {
          payStatements: MOCK_PAY_STATEMENTS_RESPONSE
        },
        loading: false,
        error: {}
      });
      expect(payService.payStatements).toEqual(MOCK_PAY_STATEMENTS_RESPONSE);
      expect(payService.payStatementsError).toEqual(false);
    }));

    it('should return set payStatementsError to true', fakeAsync(() => {
      Mock.extend(findSffoService).with({
        findSffo: () => {
          return {
            sffo: undefined,
            href: undefined
          };
        }
      });

      payService.loadPayStatements();
      flush();
      expect(payService.stateValue[PayDashboardTileStoreSlice.PAY_STATEMENTS]).toEqual({
        data: {
          payStatements: null
        },
        loading: false,
        error: { payStatementsError: true }
      });

      expect(payService.payStatements).toEqual(null);
      expect(payService.payStatementsError).toEqual(true);
    }));
  });

  describe('getPayStatements', () => {
    it('should get pay statements', (done: DoneFn) => {
      Mock.extend(baseHttpClient).with({
        get: () => Promise.resolve<PayStatementsDTO>(MOCK_PAY_STATEMENTS_RESPONSE)
      });

      payService.getPayStatements().then((response) => {
        expect(response).toEqual(MOCK_PAY_STATEMENTS_RESPONSE);
        done();
      });
    });

    it('should get payStatementsIsLoading', (done: DoneFn) => {
      payService.update(PayDashboardTileStoreSlice.PAY_STATEMENTS, {
        loading: true
      });
      payService.payStatementsIsLoading$().subscribe((loading) => {
        expect(loading).toBeTruthy();
        done();
      });
    });

    it('should return error if sffo not found', (done: DoneFn) => {
      Mock.extend(findSffoService).with({
        findSffo: () => {
          return {
            sffo: undefined,
            href: undefined
          };
        }
      });

      payService.getPayStatements().catch((error) => {
        expect(error).toEqual('Pay Permission not found!');
        done();
      });
    });
  });

  describe('getPayDonutData', () => {
    it('should build pay donutConfig', () => {
      const gross: Amount = {
        amountValue: 1000,
        currencyCode: 'USD'
      };
      const net: Amount = {
        amountValue: 600,
        currencyCode: 'USD'
      };
      const donutConfig = payService.getPayDonutData(gross, net);
      expect(donutConfig).toEqual(MOCK_DONUT_CONFIG);
    });

    it('should build pay donutConfig with missing gross', () => {
      const gross: Amount = {
        amountValue: null,
        currencyCode: null
      };
      const net: Amount = {
        amountValue: 600,
        currencyCode: 'USD'
      };
      const donutConfig = payService.getPayDonutData(gross, net);
      expect(donutConfig).toEqual([PAY_CATEGORY_CONSTANTS.disabled]);
    });

    it('should build pay donutConfig with missing net', () => {
      const gross: Amount= {
        amountValue: 1000,
        currencyCode: 'USD'
      };
      const net: Amount = {
        amountValue: null,
        currencyCode: null
      };
      const donutConfig = payService.getPayDonutData(gross, net);
      expect(donutConfig).toEqual([PAY_CATEGORY_CONSTANTS.disabled]);
    });

  });
});
