import { ChangeDetectionStrategy, Component, Input, OnInit } from '@angular/core';
import { Observable } from 'rxjs';

import { PrivacyModeStore } from '../../../privacy-mode-shared/store/privacy-mode.store';

@Component({
  selector: 'pay-number-format',
  templateUrl: './number-format.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class NumberFormatComponent implements OnInit {
  @Input() public value: number;
  @Input() public hasPrivacyMode?: boolean = false;
  public privacyMode$: Observable<boolean>;

  constructor(private privacyModeStore: PrivacyModeStore) {}

  public ngOnInit() {
    this.privacyMode$ = this.privacyModeStore.showMaskedValue$;
  }
}
