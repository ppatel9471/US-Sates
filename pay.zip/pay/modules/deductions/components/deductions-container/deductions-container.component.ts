import { Component, Input, OnInit, ViewChild, ViewContainerRef } from '@angular/core';

import { StepsStoreActions } from '../../store/steps/steps.store';

@Component({
  selector: 'vded-deductions-container',
  templateUrl: './deductions-container.component.html'
})
export class DeductionsContainerComponent implements OnInit {
  @Input() tileMode: boolean = true;
  @ViewChild('stepContainer', { static: true, read: ViewContainerRef })
  public stepContainer: ViewContainerRef;

  constructor(private stepsStoreActions: StepsStoreActions) {}

  public ngOnInit() {
    this.stepsStoreActions.init(this.stepContainer);
  }
}
