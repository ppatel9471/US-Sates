import { CurrencyPipe } from '@angular/common';
import { TestBed } from '@angular/core/testing';
import { Mock } from 'ts-mockery';

import { LanguageService } from '@myadp/common';

import { PayStatementsUI } from '../../pay-statements-shared/models/pay-statement-ui';
import { ValueFormatterService } from '../../shared/services/value-formatter.service';
import { PayDonutDataSelectorPipe } from './pay-donut-data-selector.pipe';

describe('PayDonutDataSelectorPipe', () => {
  let pipe: PayDonutDataSelectorPipe;
  const mockDonutData: PayStatementsUI.PayDonutItem[] = [
    {
      id: 'taxes',
      key: 'myadp-pay.PAY_TAXES',
      amount: { amountValue: -392.97, currencyCode: 'USD' },
      value: 392.97,
      color: 'accent-3'
    },
    {
      id: 'benefits',
      key: 'myadp-pay.PAY_BENEFITS',
      amount: { amountValue: -137, currencyCode: 'USD' },
      value: 137,
      color: 'primary-light'
    },
    {
      id: 'takeHome',
      key: 'myadp-pay.PAY_TAKE_HOME',
      amount: { amountValue: 1021.96, currencyCode: 'USD' },
      value: 1021.96,
      color: 'accent-1'
    }
  ];

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [PayDonutDataSelectorPipe],
      providers: [
        CurrencyPipe,
        ValueFormatterService,
        {
          provide: LanguageService,
          useValue: Mock.of<LanguageService>({ get: (key) => key })
        }
      ]
    });
    pipe = new PayDonutDataSelectorPipe(
      TestBed.inject(LanguageService),
      TestBed.inject(ValueFormatterService)
    );
  });

  it('should return formatted donut data', () => {
    expect(pipe.transform(mockDonutData, false)).toEqual([
      {
        key: 'myadp-pay.PAY_TAXES',
        formatted: '-$392.97',
        value: 392.97,
        color: 'accent-3'
      },
      {
        key: 'myadp-pay.PAY_BENEFITS',
        formatted: '-$137.00',
        value: 137,
        color: 'primary-light'
      },
      {
        key: 'myadp-pay.PAY_TAKE_HOME',
        formatted: '$1,021.96',
        value: 1021.96,
        color: 'accent-1'
      }
    ]);
  });

  it('should return formatted donut data when hiding pay amounts', () => {
    expect(pipe.transform(mockDonutData, true)).toEqual([
      {
        key: 'myadp-pay.PAY_TAXES',
        formatted: '$X,XXX.XX',
        value: 392.97,
        color: 'accent-3'
      },
      {
        key: 'myadp-pay.PAY_BENEFITS',
        formatted: '$X,XXX.XX',
        value: 137,
        color: 'primary-light'
      },
      {
        key: 'myadp-pay.PAY_TAKE_HOME',
        formatted: '$X,XXX.XX',
        value: 1021.96,
        color: 'accent-1'
      }
    ]);
  });
});
