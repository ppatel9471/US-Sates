import { Pipe, PipeTransform } from '@angular/core';

@Pipe({ name: 'maskNumber' })
export class MaskNumberPipe implements PipeTransform {
  public transform(number: string): string {
    const starsToAdd = number?.length < 6 ? number?.length - (number?.length - 2) : 0;
    const showDigits = number?.length < 6 ? number?.length - 2 : 4;
    const mask = 'X'.repeat(5 + starsToAdd);

    return mask + number?.substr(number?.length - showDigits);
  }
}
