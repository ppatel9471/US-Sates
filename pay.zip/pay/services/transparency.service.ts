import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ClientService, UserIdentityService } from '@myadp/common';
import { PaymentCalculationAnalysis } from '../models/payment-calculation-analysis.model';


@Injectable({
  providedIn: 'root'
})
export class TransparencyService {

  constructor(
    private httpClient: HttpClient,
    private userIdentityService: UserIdentityService,
    private clientService: ClientService
  ) { }

  public async hasTransparency(): Promise<boolean> {
    const client = await this.clientService.getClient();
    return this.clientService.hasProductCode(client, 'PI');
  }

  public async getPaymentCalculationAnalysis(documentId: string): Promise<PaymentCalculationAnalysis> {

    const aoid = await this.userIdentityService.getAoid();
    const URI = `/api/pi-api-gateway/transparency/v0/associates/${aoid}/pay-statement-documents/${documentId}/payment-calculation-analysis`;
    return this.httpClient.get<PaymentCalculationAnalysis>(URI).toPromise();

  }

}
