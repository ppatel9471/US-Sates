import { TestBed } from '@angular/core/testing';
import { Mock } from 'ts-mockery';
import { COUNTRY_CONFIG, COUNTRY } from '../../pay-distributions-shared/models/country';

import { DistributionOptions } from '../../pay-distributions-shared/models/pay-distributions-ui';
import { AccountDetailsControls } from '../models/account-details-form.model';
import { DepositAmountControls } from '../models/deposit-amount-form.model';
import { StepMeta } from '../models/step-meta.model';
import { StepsStore } from '../store/steps/steps.store';
import { BaseStepService } from './base-step.service';
import { StepFormGroupService } from './step-form-group.service';
import { WiselyAccountService } from './wisely-account.service';

describe('StepFormGroupService', () => {
  let stepFormGroupService: StepFormGroupService;
  let stepsStore: StepsStore;
  let wiselyAccountService: WiselyAccountService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        BaseStepService,
        {
          provide: StepsStore,
          useValue: Mock.of<StepsStore>({
            isEditing: false,
            currentStepName: 'ACCOUNT_DETAILS',
            country: COUNTRY_CONFIG[COUNTRY.US],
            editingAccount: { currentData: {}, pendingData: {} }
          })
        },
        {
          provide: WiselyAccountService,
          useValue: Mock.of<WiselyAccountService>({
            shouldShowTerms: () => true
          })
        }
      ]
    });

    stepFormGroupService = TestBed.inject(StepFormGroupService);
    stepsStore = TestBed.inject(StepsStore);
    wiselyAccountService = TestBed.inject(WiselyAccountService);
  });

  it('should get FormGroup for ACCOUNT_DETAILS', async () => {
    const mockStepMeta: StepMeta = {
      accountTypes: [
        {
          label: 'Savings2',
          value: '102',
          longName: 'Savings2',
          shortName: 'SAV2'
        },
        {
          label: 'Deduction3',
          value: '103',
          longName: 'Deduction3',
          shortName: 'DED3'
        }
      ],
      displayConfirm: true,
      accountNameEnabled: false,
      accountNameMaxLength: undefined
    };

    const formGroup = stepFormGroupService.getStepForm(mockStepMeta);

    expect(formGroup.value).toEqual({
      ACCOUNT_DETAILS: {
        [AccountDetailsControls.ACCOUNT_TYPE_CODE]: {
          label: 'Savings2',
          value: '102',
          longName: 'Savings2',
          shortName: 'SAV2'
        },
        [AccountDetailsControls.ACCOUNT_NAME]: null,
        [AccountDetailsControls.ROUTING_NUMBER]: null,
        [AccountDetailsControls.ROUTING_CONFIRM]: null,
        [AccountDetailsControls.ACCOUNT_NUMBER]: null,
        [AccountDetailsControls.ACCOUNT_CONFIRM]: null,
        [AccountDetailsControls.TERMS]: false
      }
    });

    expect(formGroup.controls['ACCOUNT_DETAILS'].updateOn).toBe('blur');
  });

  it('should get FormGroup for DEPOSIT_AMOUNT', () => {
    Mock.extend(stepsStore).with({
      currentStepName: 'DEPOSIT_AMOUNT'
    });
    const mockStepMeta: StepMeta = {
      defaultDepositType: DistributionOptions.REMAINING
    };

    const formGroup = stepFormGroupService.getStepForm(mockStepMeta);

    expect(formGroup.value).toEqual({
      DEPOSIT_AMOUNT: {
        [DepositAmountControls.AMOUNT_TYPE]: DistributionOptions.REMAINING,
        [DepositAmountControls.PERCENTAGE_AMOUNT]: null,
        [DepositAmountControls.FLAT_AMOUNT]: null
      }
    });

    expect(formGroup.controls['DEPOSIT_AMOUNT'].updateOn).toBe('change');
  });

  it('should get combined FormGroup when editing', () => {
    const mockStepMeta: StepMeta = {
      accountTypes: [
        {
          value: '102',
          longName: 'Savings2',
          shortName: 'SAV2'
        },
        {
          value: '104',
          longName: 'Savings',
          shortName: 'SAV4'
        },
        {
          value: '103',
          longName: 'Deduction3',
          shortName: 'DED3'
        }
      ],
      displayConfirm: false,
      accountNameEnabled: true,
      accountNameMaxLength: 15,
      defaultDepositType: DistributionOptions.PERCENTAGE,
      showPercentageType: true
    };
    Mock.extend(stepsStore).with({
      isEditing: true,
      stepFormDetails: {
        id: 'SAV4Savings104',
        accountName: 'My Savings',
        codeValueData: {
          longName: 'Savings',
          shortName: 'SAV4',
          accountCode: '104'
        },
        accountTypeCode: {
          label: 'Savings',
          value: '104',
          longName: 'Savings',
          shortName: 'SAV4'
        },
        distributionType: DistributionOptions.PERCENTAGE,
        percentageAmount: '21',
        flatAmount: null,
        accountNumber: '123456',
        routingNumber: '061092387'
      }
    });

    const formGroup = stepFormGroupService.getStepForm(mockStepMeta);

    expect(formGroup.getRawValue()).toEqual({
      ACCOUNT_DETAILS: {
        [AccountDetailsControls.ACCOUNT_TYPE_CODE]: {
          label: 'Savings',
          value: '104',
          longName: 'Savings',
          shortName: 'SAV4'
        },
        [AccountDetailsControls.ACCOUNT_NAME]: 'My Savings',
        [AccountDetailsControls.ROUTING_NUMBER]: '061092387',
        [AccountDetailsControls.ROUTING_CONFIRM]: '061092387',
        [AccountDetailsControls.ACCOUNT_NUMBER]: '123456',
        [AccountDetailsControls.ACCOUNT_CONFIRM]: '123456',
        [AccountDetailsControls.TERMS]: false
      },
      DEPOSIT_AMOUNT: {
        [DepositAmountControls.AMOUNT_TYPE]: DistributionOptions.PERCENTAGE,
        [DepositAmountControls.PERCENTAGE_AMOUNT]: '21',
        [DepositAmountControls.FLAT_AMOUNT]: null
      }
    });

    expect(formGroup.controls['ACCOUNT_DETAILS'].updateOn).toBe('change');
    expect(formGroup.controls['DEPOSIT_AMOUNT'].updateOn).toBe('change');
  });

  it('should include terms validator adding wisely', async () => {
    const mockStepMeta: StepMeta = {
      accountTypes: [
        {
          value: '102',
          longName: 'Savings2',
          shortName: 'SAV2'
        },
        {
          value: '104',
          longName: 'Savings',
          shortName: 'SAV4'
        },
        {
          value: '103',
          longName: 'Deduction3',
          shortName: 'DED3'
        }
      ],
      displayConfirm: false,
      accountNameEnabled: true,
      accountNameMaxLength: 15,
      defaultDepositType: DistributionOptions.PERCENTAGE,
      showPercentageType: true
    };

    Mock.extend(stepsStore).with({
      isEditing: false,
      stepsStoreData: {
        step: { current: 2 },
        showTerms: true
      },
      currentStepName: 'DEPOSIT_AMOUNT',
      stepFormDetails: {
        id: 'SAV4Savings104',
        accountName: 'My Savings',
        codeValueData: {
          longName: 'Savings',
          shortName: 'SAV4',
          accountCode: '104'
        },
        accountTypeCode: {
          label: 'Savings',
          value: '104',
          longName: 'Savings',
          shortName: 'SAV4'
        },
        distributionType: DistributionOptions.PERCENTAGE,
        percentageAmount: '21',
        flatAmount: null,
        accountNumber: '123456',
        routingNumber: '061092387'
      }
    });

    const formGroup = stepFormGroupService.getStepForm(mockStepMeta);

    expect(formGroup.getRawValue()).toEqual({
      DEPOSIT_AMOUNT: {
        [DepositAmountControls.AMOUNT_TYPE]: DistributionOptions.PERCENTAGE,
        [DepositAmountControls.PERCENTAGE_AMOUNT]: '21',
        [DepositAmountControls.FLAT_AMOUNT]: null,
        [DepositAmountControls.TERMS]: false
      }
    });
  });

  it('should not include the terms when adding wisely pay', () => {
    const mockStepMeta: StepMeta = {
      accountTypes: [
        {
          value: '102',
          longName: 'Savings2',
          shortName: 'SAV2'
        },
        {
          value: '104',
          longName: 'Savings',
          shortName: 'SAV4'
        },
        {
          value: '103',
          longName: 'Deduction3',
          shortName: 'DED3'
        }
      ],
      displayConfirm: false,
      accountNameEnabled: true,
      accountNameMaxLength: 15,
      defaultDepositType: DistributionOptions.PERCENTAGE,
      showPercentageType: true
    };

    Mock.extend(wiselyAccountService).with({ shouldShowTerms: () => false });

    Mock.extend(stepsStore).with({
      isEditing: false,
      stepsStoreData: {
        step: { current: 2 },
        showTerms: true
      },
      currentStepName: 'DEPOSIT_AMOUNT',
      stepFormDetails: {
        id: 'SAV4Savings104',
        accountName: 'My Savings',
        codeValueData: {
          longName: 'Savings',
          shortName: 'SAV4',
          accountCode: '104'
        },
        accountTypeCode: {
          label: 'Savings',
          value: '104',
          longName: 'Savings',
          shortName: 'SAV4'
        },
        distributionType: DistributionOptions.PERCENTAGE,
        percentageAmount: '21',
        flatAmount: null,
        accountNumber: '123456',
        routingNumber: '061092387'
      }
    });

    const formGroup = stepFormGroupService.getStepForm(mockStepMeta);

    expect(formGroup.getRawValue()).toEqual({
      DEPOSIT_AMOUNT: {
        [DepositAmountControls.AMOUNT_TYPE]: DistributionOptions.PERCENTAGE,
        [DepositAmountControls.PERCENTAGE_AMOUNT]: '21',
        [DepositAmountControls.FLAT_AMOUNT]: null
      }
    });
  });

  it('should get combined FormGroup with disabled validators when editing avsddm', () => {
    const mockStepMeta: StepMeta = {
      accountTypes: [
        {
          value: '102',
          longName: 'Savings2',
          shortName: 'SAV2'
        }
      ],
      displayConfirm: false,
      accountNameEnabled: true,
      disableRoutingAndAccountValidations: true,
      accountNameMaxLength: 15,
      defaultDepositType: DistributionOptions.PERCENTAGE,
      showPercentageType: true
    };
    Mock.extend(stepsStore).with({
      isEditing: true,
      stepFormDetails: {
        id: 'SAV4Savings104',
        accountName: 'My Savings',
        codeValueData: {
          longName: 'Savings',
          shortName: 'SAV4',
          accountCode: '104'
        },
        accountTypeCode: {
          label: 'Savings',
          value: '104',
          longName: 'Savings',
          shortName: 'SAV4'
        },
        distributionType: DistributionOptions.PERCENTAGE,
        percentageAmount: '21',
        flatAmount: null,
        accountNumber: '123456',
        routingNumber: '061092387'
      }
    });

    const formGroup = stepFormGroupService.getStepForm(mockStepMeta);

    expect(
      formGroup.get('ACCOUNT_DETAILS').get(AccountDetailsControls.ROUTING_NUMBER).validator
    ).toBeNull();
    expect(
      formGroup.get('ACCOUNT_DETAILS').get(AccountDetailsControls.ACCOUNT_NUMBER).validator
    ).toBeNull();
  });

  it('should get the Canadian version of the account details form', () => {
    Mock.extend(stepsStore).with({ country: COUNTRY_CONFIG[COUNTRY.CA] });

    const mockStepMeta: StepMeta = {
      accountTypes: [
        {
          value: '102',
          longName: 'Savings2',
          shortName: 'SAV2'
        },
        {
          value: '104',
          longName: 'Savings',
          shortName: 'SAV4'
        },
        {
          value: '103',
          longName: 'Deduction3',
          shortName: 'DED3'
        }
      ],
      banks: [{ value: '999', shortName: 'Test ' }],
      displayConfirm: false,
      accountNameEnabled: true,
      accountNameMaxLength: 15,
      defaultDepositType: DistributionOptions.PERCENTAGE,
      showPercentageType: true
    };
    Mock.extend(stepsStore).with({
      isEditing: false,
      stepFormDetails: {
        id: 'SAV4Savings104',
        accountName: 'My Savings',
        codeValueData: {
          longName: 'Savings',
          shortName: 'SAV4',
          accountCode: '104'
        },
        institution: '999',
        transitNumber: '061092387',
        accountTypeCode: {
          label: 'Savings',
          value: '104',
          longName: 'Savings',
          shortName: 'SAV4'
        },
        distributionType: DistributionOptions.PERCENTAGE,
        percentageAmount: '21',
        flatAmount: null,
        accountNumber: '123456'
      }
    });

    const formGroup = stepFormGroupService.getStepForm(mockStepMeta);

    expect(formGroup.get('ACCOUNT_DETAILS').get(AccountDetailsControls.TRANSIT_NUMBER).value).toBe(
      '061092387'
    );
    expect(formGroup.get('ACCOUNT_DETAILS').get(AccountDetailsControls.INSTITUTION).value).toEqual({
      value: '999',
      shortName: 'Test '
    });
  });

  it('should get the Canadian version when editing a Canadian account', () => {
    Mock.extend(stepsStore).with({ country: COUNTRY_CONFIG[COUNTRY.CA] });

    const mockStepMeta: StepMeta = {
      accountTypes: [
        {
          value: '102',
          longName: 'Savings2',
          shortName: 'SAV2'
        },
        {
          value: '104',
          longName: 'Savings',
          shortName: 'SAV4'
        },
        {
          value: '103',
          longName: 'Deduction3',
          shortName: 'DED3'
        }
      ],
      banks: [{ value: '999', shortName: 'Test ' }],
      displayConfirm: false,
      accountNameEnabled: true,
      accountNameMaxLength: 15,
      defaultDepositType: DistributionOptions.PERCENTAGE,
      showPercentageType: true
    };
    Mock.extend(stepsStore).with({
      isEditing: true,
      stepFormDetails: {
        id: 'SAV4Savings104',
        accountName: 'My Savings',
        codeValueData: {
          longName: 'Savings',
          shortName: 'SAV4',
          accountCode: '104'
        },
        institution: '999',
        transitNumber: '061092387',
        accountTypeCode: {
          label: 'Savings',
          value: '104',
          longName: 'Savings',
          shortName: 'SAV4'
        },
        distributionType: DistributionOptions.PERCENTAGE,
        percentageAmount: '21',
        flatAmount: null,
        accountNumber: '123456'
      }
    });

    const formGroup = stepFormGroupService.getStepForm(mockStepMeta);

    expect(formGroup.get('ACCOUNT_DETAILS').get(AccountDetailsControls.TRANSIT_NUMBER).value).toBe(
      '061092387'
    );
    expect(formGroup.get('ACCOUNT_DETAILS').get(AccountDetailsControls.INSTITUTION).value).toEqual({
      value: '999',
      shortName: 'Test '
    });
  });
});
