import { Component, Input } from '@angular/core';

import { ExternalWindowService } from '@myadp/common';

@Component({
  selector: 'external-link',
  styleUrls: ['./external-link.component.scss'],
  templateUrl: './external-link.component.html'
})
export class ExternalLinkComponent {
  @Input() public uri: string;
  @Input() public linkText: string;
  @Input() public icon?: string;
  @Input() public mediumSize?: boolean;
  @Input() public class?: string;

  constructor(private externalWindowService: ExternalWindowService) {}

  public open(): void {
    this.externalWindowService.open({ uri: this.uri });
  }
}
