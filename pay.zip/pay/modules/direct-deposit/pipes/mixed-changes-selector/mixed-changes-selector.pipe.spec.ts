import { TestBed } from '@angular/core/testing';

import { DistributionOptions } from '../../../pay-distributions-shared/models/pay-distributions-ui';
import { DirectDepositAccount } from '../../models/direct-deposit-account.model';
import { MixedChangesSelectorPipe } from './mixed-changes-selector.pipe';

// add, edit, and delete
const accounts: DirectDepositAccount[] = [
  {
    isReadOnly: false,
    isWisely: false,
    isDailyPay: false,
    currentData: null,
    pendingData: {
      distributionType: DistributionOptions.FLAT,
      percentageAmount: null,
      flatAmount: { amountValue: 14.69, currencyCode: 'USD' }
    },
    pendingEvent: null
  },
  {
    isReadOnly: false,
    isWisely: false,
    isDailyPay: false,
    currentData: {
      distributionType: DistributionOptions.PERCENTAGE,
      percentageAmount: 13,
      flatAmount: null
    },
    pendingData: {
      distributionType: DistributionOptions.PERCENTAGE,
      percentageAmount: 31,
      flatAmount: null
    },
    pendingEvent: null
  },
  {
    isReadOnly: false,
    isWisely: false,
    isDailyPay: false,
    currentData: {
      distributionType: DistributionOptions.REMAINING,
      percentageAmount: null,
      flatAmount: null
    },
    pendingData: null,
    pendingEvent: null
  }
];

describe('MixedChangesSelectorPipe', () => {
  let pipe: MixedChangesSelectorPipe;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [MixedChangesSelectorPipe]
    });

    pipe = new MixedChangesSelectorPipe();
  });

  it('should return an array of mixed changes', () => {
    expect(
      pipe.transform({
        add: [accounts[0]],
        edit: [accounts[1]],
        delete: [accounts[2]]
      })
    ).toEqual([
      { account: accounts[0], changeMsg: 'myadp-pay.DD_DONE_ADDED_CHANGE' },
      { account: accounts[1], changeMsg: 'myadp-pay.DD_DONE_EDITED_CHANGE' },
      { account: accounts[2], changeMsg: 'myadp-pay.DD_DONE_DELETED_CHANGE' }
    ]);
  });
});
