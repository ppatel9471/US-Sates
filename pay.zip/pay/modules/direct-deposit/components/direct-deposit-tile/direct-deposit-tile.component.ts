import { COUNTRY } from './../../../pay-distributions-shared/models/country';
import { Component, OnInit, Input, Optional } from '@angular/core';
import { Observable } from 'rxjs';

import { TileService } from '@synerg/components/tile';
import { QueryParamsService } from '@myadp/common';
import { PAY_DEEP_LINKS, StoreState } from '@myadp/pay-shared';
import { StepsStoreActions } from '../../store/steps/steps.store';
import { DirectDepositStore, DirectDepositStoreState } from '../../store/direct-deposit.store';

@Component({
  selector: 'direct-deposit-tile',
  templateUrl: './direct-deposit-tile.component.html',
  styleUrls: ['./direct-deposit-tile.scss', '../shared/direct-deposit.scss']
})
export class DirectDepositTileComponent implements OnInit {
  @Input() defaultOpenSlidein: boolean = false;
  public state$: Observable<StoreState<DirectDepositStoreState>>;
  public unmaskError: boolean = false;
  public showSlidein: boolean = false;
  public countries = COUNTRY;

  constructor(
    @Optional() private tileService: TileService,
    private stepsStoreActions: StepsStoreActions,
    private directDepositStore: DirectDepositStore,
    private queryParamsService: QueryParamsService
  ) {}

  public ngOnInit(): void {
    this.tileService?.setIsLoading(false);
    this.state$ = this.directDepositStore?.state$;

    // First GET happens here
    this.stepsStoreActions.loadAccounts({ getMeta: true, getMasked: true });

    this.autoOpenSlideinCheck();
  }

  public openSlidein(): void {
    this.showSlidein = true;
    this.unmaskError = false;
    this.stepsStoreActions.openSlidein();
  }

  public onError(hasError: boolean): void {
    this.unmaskError = hasError;

    if (hasError) {
      this.stepsStoreActions.closeSlidein();
    }
  }

  public onSlideinClose(): void {
    this.showSlidein = false;
    this.stepsStoreActions.closeSlidein();
    this.stepsStoreActions.loadAccounts({ getMeta: true, getMasked: true });
  }

  public autoOpenSlideinCheck(): void {
    const autoOpenDirectDepositDeprecated =
      this.queryParamsService.getParameterValue('openDirectDeposit') === 'true';
    const autoOpenDirectDepositSlidein =
      this.queryParamsService.getParameterValue('open') === PAY_DEEP_LINKS.DirectDeposit;
    if (
      autoOpenDirectDepositDeprecated ||
      autoOpenDirectDepositSlidein ||
      this.defaultOpenSlidein
    ) {
      this.showSlidein = true;
      this.stepsStoreActions.openSlidein();
    }
  }
}
