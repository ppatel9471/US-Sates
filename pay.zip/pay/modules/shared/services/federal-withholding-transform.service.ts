import { Injectable } from '@angular/core';
import { findIndex, forEach, get, isArray, isEmpty, isUndefined } from 'lodash';

import { LanguageService } from '@myadp/common';

import { SummaryItem, WithholdingItem, WithholdingType } from '../../../models/formatted-tax-withholding.model';
import { FEDERAL } from '../../../models/states.model';
import { AdditionalTaxAmount, CodeType, PendingEvent } from '../../../models/tax-withholding.model';
import {
  UsFederalIncomeTaxWithholdingElection,
  UsFederalTaxWithholdingElections
} from '../../../models/us-federal-tax-withholding-election.model';
import { ValueFormatterService, ValueFormatterType } from './value-formatter.service';
import { WithholdingFormatterService } from './withholding-formatter.service';

@Injectable({
  providedIn: 'root'
})
export class FederalWithholdingTransformService {
  constructor(
    private withholdingFormatterService: WithholdingFormatterService,
    private languageService: LanguageService,
    private valueFormatterService: ValueFormatterService
  ) {}

  public getWithholdingItems(withholdingData: UsFederalTaxWithholdingElections): WithholdingItem[] {
    const withholding = this.getCurrentWithholding(withholdingData);
    const pendingWithholding = this.getPendingWithholding(withholdingData);
    const pendingEvents = this.getPendingEvents(withholdingData);
    const payrollGroupCode = this.getPayrollGroupCode(withholdingData);
    const payrollRegionCode = this.getPayrollRegionCode(withholdingData);
    const withholdingItems = this.getWithholdingItem(
      withholding,
      pendingWithholding,
      pendingEvents,
      payrollGroupCode,
      payrollRegionCode
    );

    return [withholdingItems];
  }

  private getWithholdingItem(
    withholding: UsFederalIncomeTaxWithholdingElection,
    pendingWithholding: UsFederalIncomeTaxWithholdingElection,
    pendingEvents: PendingEvent,
    payrollGroupCode: CodeType,
    payrollRegionCode: CodeType
  ): WithholdingItem {
    const attachments = this.withholdingFormatterService.getAttachments(withholding);
    const currentSummaryItems = this.getSummaryItems(withholding);
    const effectiveDate = this.valueFormatterService.format(
      get(withholding, 'taxWithholdingStatus.effectiveDate'),
      ValueFormatterType.Date
    );
    const pendingSummaryItems = this.getSummaryItems(pendingWithholding);

    if (pendingSummaryItems.length > 0) {
      this.pushLegalNameDifferentSummaryItem(
        currentSummaryItems,
        pendingSummaryItems,
        withholding,
        pendingWithholding
      );
      this.withholdingFormatterService.formatPendingItems(currentSummaryItems, pendingSummaryItems);
    }
    const isLocked = this.isFederalLocked(withholding);

    return {
      type: WithholdingType.FEDERAL,
      state: FEDERAL,
      title: this.languageService.get('myadp-pay.FEDERAL'),
      payrollGroupCode: payrollGroupCode,
      payrollRegionCode: payrollRegionCode,
      rawData: withholding,
      effectiveDate: effectiveDate,
      summaryItems: currentSummaryItems,
      pendingSummaryItems: pendingSummaryItems.length ? pendingSummaryItems : undefined,
      pendingEvents: pendingEvents,
      isLocked,
      lockedOutMessage: isLocked ? this.isFederalLockedOut(withholding) : undefined,
      attachments: attachments,
      isCompleted: this.isCompleted(withholding, pendingWithholding)
    };
  }

  private isCompleted(
    withholding: UsFederalIncomeTaxWithholdingElection,
    pendingWithholding: UsFederalIncomeTaxWithholdingElection
  ): boolean {
    const isCompleted: boolean = get(withholding, 'eSignature.signatureIndicator');
    const hasPendingData: boolean = !isEmpty(pendingWithholding);
    const hasCurrentData: boolean = !isEmpty(withholding);

    if (!isUndefined(isCompleted)) {
      return hasPendingData || (hasCurrentData && isCompleted);
    } else {
      /*
       * Everyone using v2 should support eSignature indicator
       */
      return hasCurrentData || hasPendingData;
    }
  }

  private getPayrollGroupCode(withholdingData: UsFederalTaxWithholdingElections): CodeType {
    return get(withholdingData, 'usFederalTaxWithholdingElections[0].payrollGroupCode');
  }

  private getPayrollRegionCode(withholdingData: UsFederalTaxWithholdingElections): CodeType {
    return get(withholdingData, 'usFederalTaxWithholdingElections[0].payrollRegionCode');
  }

  private getCurrentWithholding(
    withholdingData: UsFederalTaxWithholdingElections
  ): UsFederalIncomeTaxWithholdingElection {
    return get(
      withholdingData,
      'usFederalTaxWithholdingElections[0].usFederalIncomeTaxWithholdingElection'
    );
  }

  private getPendingWithholding(
    withholdingData: UsFederalTaxWithholdingElections
  ): UsFederalIncomeTaxWithholdingElection {
    return get(
      withholdingData,
      'usFederalTaxWithholdingElections[0].workflowData.pendingData.' +
        'usFederalTaxWithholdingElections[0].usFederalIncomeTaxWithholdingElection'
    );
  }

  private getPendingEvents(withholdingData: UsFederalTaxWithholdingElections): PendingEvent {
    return get(withholdingData, 'usFederalTaxWithholdingElections[0].workflowData.pendingEvents');
  }

  private getSummaryItems(withholding: UsFederalIncomeTaxWithholdingElection): SummaryItem[] {
    const summaryItems: SummaryItem[] = [];

    this.withholdingFormatterService.summaryItemHelper(
      summaryItems,
      withholding,
      'taxFilingStatusCode.longName',
      'FILING_STATUS'
    );

    if (get(withholding, 'nonResidentAlienIndicator') === true) {
      this.withholdingFormatterService.summaryItemHelper(
        summaryItems,
        withholding,
        'nonResidentAlienIndicator',
        'NONRESIDENT_ALIEN',
        ValueFormatterType.Boolean
      );
    }

    const exemptSummaryItem = this.withholdingFormatterService.isExempt(withholding);
    if (exemptSummaryItem) {
      summaryItems.push(exemptSummaryItem);
    }

    // higher tax rate
    const higherTaxRate = this.withholdingFormatterService.getAdditionalStatutoryInputs(
      'USE_HIGHER_TAX_RATE',
      withholding
    );
    if (higherTaxRate === 'true') {
      summaryItems.push({
        displayName: `TWM_SHARED_SUMMARY_HIGHER_TAX_RATE_HEADING`,
        displayValue: this.languageService.get('common.YES')
      });
    }

    const headings = ['TAX_CREDITS_TOTAL_AMOUNT', 'OTHER_INCOME', 'ITEMIZED_DEDUCTIONS'];
    forEach(headings, (heading: string) => {
      const value = this.withholdingFormatterService.getAdditionalStatutoryInputs(
        heading,
        withholding
      );
      if (value) {
        summaryItems.push({
          displayName: `TWM_FED_${heading}_HEADING`,
          displayValue: this.valueFormatterService.format(
            { amountValue: value },
            ValueFormatterType.Currency
          )
        });
      }
    });

    // fed 2019
    if (get(withholding, 'taxWithholdingAllowanceQuantity') >= 0) {
      this.withholdingFormatterService.summaryItemHelper(
        summaryItems,
        withholding,
        'taxWithholdingAllowanceQuantity',
        'TOTAL_ALLOWANCES'
      );
    }

    const additionalAmount: AdditionalTaxAmount = get(withholding, 'additionalTaxAmount');
    const additionalPercent: number = get(withholding, 'additionalTaxPercentage');
    if (
      this.withholdingFormatterService.showAdditionalTaxAmount(additionalAmount, additionalPercent)
    ) {
      this.withholdingFormatterService.summaryItemHelper(
        summaryItems,
        withholding,
        'additionalTaxAmount',
        'ADDITIONAL_WITHHOLDING_AMOUNT',
        ValueFormatterType.Currency
      );
    }

    if (
      this.withholdingFormatterService.showAdditionalTaxPercentage(
        additionalAmount,
        additionalPercent
      )
    ) {
      this.withholdingFormatterService.summaryItemHelper(
        summaryItems,
        withholding,
        'additionalTaxPercentage',
        'ADDITIONAL_PERCENT_WITHHELD',
        ValueFormatterType.Percentage
      );
    }

    return summaryItems;
  }

  private pushLegalNameDifferentSummaryItem(
    currentSummaryItems: SummaryItem[],
    pendingSummaryItems: SummaryItem[],
    currentElections: UsFederalIncomeTaxWithholdingElection,
    pendingElections: UsFederalIncomeTaxWithholdingElection
  ) {
    const currentLegalName = this.getLegalNameDifferentSummaryItem(currentElections);
    const pendingLegalName = this.getLegalNameDifferentSummaryItem(pendingElections);

    if (currentLegalName.displayValue !== pendingLegalName.displayValue) {
      currentSummaryItems.push(currentLegalName);
      pendingSummaryItems.push(pendingLegalName);
    }
  }

  private getLegalNameDifferentSummaryItem(
    elections: UsFederalIncomeTaxWithholdingElection
  ): SummaryItem {
    const key =
      elections && elections.legalNameDiffersFromSSCardIndicator ? 'common.YES' : 'common.NO';

    return {
      displayName: 'TWM_FED_SUMMARY_LAST_NAME_HEADING',
      displayValue: this.languageService.get(key)
    };
  }

  private isFederalLocked(elections: UsFederalIncomeTaxWithholdingElection): boolean {
    if (!isArray(get(elections, 'actions'))) {
      return false;
    }
    return (
      findIndex(
        elections.actions,
        (action) => action.operationID === 'worker.usFederal.taxWithholding.election.read'
      ) !== -1
    );
  }

  private isFederalLockedOut(withholding: UsFederalIncomeTaxWithholdingElection = {}): string {
    const action = withholding.actions.find(
      (withholdingAction) => !!withholdingAction.attestation?.messageTxt
    );
    return action?.attestation?.messageTxt;
  }
}
