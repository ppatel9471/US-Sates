export type CardLayout = 'advertisement' | 'status' | 'text' | 'add';

export enum WiselyTypes {
  WISELY_DIRECT = 'WISELY_DIRECT',
  WISELY_PAY = 'WISELY_PAY'
}

export interface WiselyAccount {
  isActivated: boolean;
  routingNumber?: string;
  accountNumber?: string;
  status?: WiselyAccountStatus;
  isWiselyDirect?: boolean;
  wiselyErrorMessage?: string;
}

export enum WiselyAccountStatus {
  UNENROLLED = 'UNENROLLED',
  INACTIVE = 'INACTIVE',
  LOST = 'LOST',
  CANCELED = 'CANCELED',
  STOLEN = 'STOLEN',
  UNCREATED = 'UNCREATED',
  MAX = 'MAX',
  SELFENROLL = 'SELFENROLL',
  DONOTSHOW = 'DONOTSHOW',
  CLOSED = 'CLOSED',
  OFAC = 'OFAC',
  LOCKED = 'LOCKED',
  DECEASED = 'DECEASED',
  LIMITED = 'LIMITED',
  EXPIRED = 'EXPIRED',
  DISABLED = 'DISABLED',
  IDLE = 'IDLE'
}

export interface WiselyEnrollmentContent {
  headline?: string;
  offers?: string[];
  callToActionText?: string;
  errorText?: string;
  size?: 'large' | 'small' | 'smaller';
  cardLayout: CardLayout;
  href?: string;
  icon?: string;
  status: WiselyAccountStatus;
  disclaimers?: string[];
}

export const WiselyEnrollmentContentMap = (wiselyType: WiselyTypes) =>
  <Record<WiselyAccountStatus, WiselyEnrollmentContent>>{
    [WiselyAccountStatus.SELFENROLL]: {
      headline:
        wiselyType === WiselyTypes.WISELY_PAY
          ? 'myadp-pay.DD_WISELY_HEADLINE_SELFENROLL_PAY'
          : 'myadp-pay.DD_WISELY_HEADLINE_SELFENROLL',
      offers: [
        'myadp-pay.DD_WISELY_UNENROLLED_CONTENT_A',
        'myadp-pay.DD_WISELY_UNENROLLED_CONTENT_B',
        'myadp-pay.DD_WISELY_UNENROLLED_CONTENT_C'
      ],
      callToActionText: 'myadp-pay.DD_WISELY_ENROLL_NOW',
      size: 'large',
      cardLayout: 'advertisement',
      status: WiselyAccountStatus.SELFENROLL,
      disclaimers:
        wiselyType === WiselyTypes.WISELY_PAY
          ? ['myadp-pay.DD_WISELY_DISCLAIMER_A', 'myadp-pay.DD_WISELY_DISCLAIMER_B']
          : ['myadp-pay.DD_WISELY_DISCLAIMER_A']
    },
    [WiselyAccountStatus.UNENROLLED]: {
      headline: 'myadp-pay.DD_WISELY_HEADLINE_UNENROLLED',
      size: 'large',
      cardLayout: 'advertisement',
      href: 'https://info.mywisely.com/',
      status: WiselyAccountStatus.UNENROLLED
    },
    [WiselyAccountStatus.INACTIVE]: {
      headline: 'myadp-pay.DD_WISELY_HEADLINE_INACTIVE',
      offers: [
        wiselyType === WiselyTypes.WISELY_PAY
          ? 'myadp-pay.DD_WISELY_INACTIVE_CONTENT_A_PAY'
          : 'myadp-pay.DD_WISELY_INACTIVE_CONTENT_A',
        'myadp-pay.DD_WISELY_INACTIVE_CONTENT_B'
      ],
      callToActionText: 'myadp-pay.DD_WISELY_ACTIVATE',
      size: 'large',
      cardLayout: 'advertisement',
      href: 'https://www.activatewisely.com',
      status: WiselyAccountStatus.INACTIVE,
      disclaimers:
        wiselyType === WiselyTypes.WISELY_PAY
          ? ['myadp-pay.DD_WISELY_DISCLAIMER_A', 'myadp-pay.DD_WISELY_DISCLAIMER_B']
          : ['myadp-pay.DD_WISELY_DISCLAIMER_A']
    },
    [WiselyAccountStatus.LOST]: {
      headline: 'myadp-pay.DD_WISELY_LOST',
      errorText: `myadp-pay.DD_${wiselyType}_ERROR_REPLACE`,
      size: 'smaller',
      cardLayout: 'status',
      status: WiselyAccountStatus.LOST
    },
    [WiselyAccountStatus.CANCELED]: {
      headline: 'myadp-pay.DD_WISELY_CANCELED',
      errorText: `myadp-pay.DD_${wiselyType}_ERROR_NEW`,
      size: 'smaller',
      cardLayout: 'status',
      status: WiselyAccountStatus.CANCELED
    },
    [WiselyAccountStatus.STOLEN]: {
      headline: 'myadp-pay.DD_WISELY_STOLEN',
      errorText: `myadp-pay.DD_${wiselyType}_ERROR_REPLACE`,
      size: 'smaller',
      cardLayout: 'status',
      status: WiselyAccountStatus.STOLEN
    },
    [WiselyAccountStatus.UNCREATED]: {
      cardLayout: 'add',
      icon: 'credit-card',
      headline: '',
      status: WiselyAccountStatus.UNCREATED
    },
    [WiselyAccountStatus.MAX]: {
      status: WiselyAccountStatus.MAX,
      cardLayout: 'text'
    }
  };

export const wiselyErrorAlertMap = (wiselyType: WiselyTypes) =>
  <Record<string, string>>{
    [WiselyAccountStatus.LOST]: `myadp-pay.DD_${wiselyType}_ALERT_LOST`,
    [WiselyAccountStatus.CANCELED]: `myadp-pay.DD_${wiselyType}_ALERT_CANCELED`,
    [WiselyAccountStatus.STOLEN]: `myadp-pay.DD_${wiselyType}_ALERT_STOLEN`,
    [WiselyAccountStatus.CLOSED]: `myadp-pay.DD_${wiselyType}_ALERT_CLOSED`,
    [WiselyAccountStatus.DISABLED]: `myadp-pay.DD_${wiselyType}_ALERT_DISABLED`,
    [WiselyAccountStatus.LOCKED]: `myadp-pay.DD_${wiselyType}_ALERT_LOCKED`,
    [WiselyAccountStatus.LIMITED]: `myadp-pay.DD_${wiselyType}_ALERT_LIMITED`,
    [WiselyAccountStatus.DECEASED]: `myadp-pay.DD_${wiselyType}_ALERT_DECEASED`,
    [WiselyAccountStatus.OFAC]: `myadp-pay.DD_${wiselyType}_ALERT_OFAC`,
    [WiselyAccountStatus.IDLE]: `myadp-pay.DD_${wiselyType}_ALERT_IDLE`
  };
