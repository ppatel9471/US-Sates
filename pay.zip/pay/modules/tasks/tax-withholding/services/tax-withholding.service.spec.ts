import { HttpRequest } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';

import { Mock } from 'ts-mockery';
import * as moment from 'moment';
import { Notification } from '@myadp/thingstodo-shared';

import { mockClockAfterEach, mockClockBeforeEach } from '@myadp/pay-shared/testing/spec-util.spec';
import { WithholdingItem } from '../../../../models/formatted-tax-withholding.model';
import { FederalWithholdingTransformService } from '../../../shared/services/federal-withholding-transform.service';
import { StateWithholdingTransformService } from '../../../shared/services/state-withholding-transform.service';
import { TaxWithholdingService } from './tax-withholding.service';

describe('TaxWithholdingService', () => {
  let service: TaxWithholdingService;
  let httpMock: HttpTestingController;
  let federalWithholdingTransformService: FederalWithholdingTransformService;
  let stateWithholdingTransformService: StateWithholdingTransformService;
  let effectiveDate: string;
  const federalUrl =
    '/payroll/v2/workers/MOCKAOID/us-federal-tax-withholding-elections?remoteid=1234&';
  const stateUrl = '/payroll/v2/workers/MOCKAOID/us-state-tax-withholding-elections?remoteid=1234&';

  const mockTransformService = {
    getWithholdingItems: (): WithholdingItem[] => {
      return [];
    }
  };
  const mockNotification: Notification = Mock.of<Notification>({
    taskName: '',
    uri: '/v1_0/O/A/notification/2217737177/Task',
    remoteId: 1234,
    relatedAssociateRef: {
      name: 'MOCKNAME',
      aoid: 'MOCKAOID'
    },
    readIndicator: false,
    receiptDate: '',
    status: 'pending',
    actionTaken: '',
    loading: false
  });

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        TaxWithholdingService,
        { provide: FederalWithholdingTransformService, useValue: mockTransformService },
        { provide: StateWithholdingTransformService, useValue: mockTransformService }
      ]
    });

    mockClockBeforeEach();
    effectiveDate = moment().format('YYYY-MM-DD');

    service = TestBed.inject(TaxWithholdingService);
    httpMock = TestBed.inject(HttpTestingController);
    federalWithholdingTransformService = TestBed.inject(FederalWithholdingTransformService);
    stateWithholdingTransformService = TestBed.inject(StateWithholdingTransformService);
  });

  afterEach(() => {
    mockClockAfterEach();
  });

  describe('get withholding tasks', () => {
    it('should call federal', (done: DoneFn) => {
      spyOn(federalWithholdingTransformService, 'getWithholdingItems').and.callThrough();
      mockNotification.eventNameCode = 'worker.usFederal.taxWithholding.election.change';
      mockNotification.notificationType = {
        code: 'task',
        labelName: 'Task'
      };
      const url = federalUrl + `effectiveDate=${effectiveDate}&taskid=2217737177`;

      service.getWithholding(mockNotification).subscribe(() => {
        expect(federalWithholdingTransformService.getWithholdingItems).toHaveBeenCalled();
        done();
      });

      httpMock
        .expectOne((req: HttpRequest<any>) => {
          return req.url === url && req.headers.get('workflowId') === '1234';
        })
        .flush({ usFederalTaxWithholdingElections: {} });
    });

    it('should call state', (done: DoneFn) => {
      spyOn(stateWithholdingTransformService, 'getWithholdingItems').and.callThrough();
      mockNotification.eventNameCode = 'worker.usState.taxWithholding.election.change';
      mockNotification.notificationType = {
        code: 'task',
        labelName: 'Task'
      };
      const url = stateUrl + `effectiveDate=${effectiveDate}&taskid=2217737177`;

      service.getWithholding(mockNotification).subscribe(() => {
        expect(stateWithholdingTransformService.getWithholdingItems).toHaveBeenCalled();
        done();
      });

      httpMock
        .expectOne((req: HttpRequest<any>) => {
          return req.url === url && req.headers.get('workflowId') === '1234';
        })
        .flush({ usStateTaxWithholdingElections: {} });
    });
  });

  describe('get withholding notifications', () => {
    it('should call federal', (done: DoneFn) => {
      spyOn(federalWithholdingTransformService, 'getWithholdingItems').and.callThrough();
      mockNotification.eventNameCode = 'worker.usFederal.taxWithholding.election.change';
      mockNotification.notificationType = {
        code: 'notification',
        labelName: 'Notification'
      };
      const url = federalUrl + `effectiveDate=${effectiveDate}&notificationid=2217737177`;

      service.getWithholding(mockNotification).subscribe(() => {
        expect(federalWithholdingTransformService.getWithholdingItems).toHaveBeenCalled();
        done();
      });

      httpMock.expectOne(url).flush({ usFederalTaxWithholdingElections: {} });
    });

    it('should call state', (done: DoneFn) => {
      spyOn(stateWithholdingTransformService, 'getWithholdingItems').and.callThrough();
      mockNotification.eventNameCode = 'worker.usState.taxWithholding.election.change';
      mockNotification.notificationType = {
        code: 'notification',
        labelName: 'Notification'
      };
      const url = stateUrl + `effectiveDate=${effectiveDate}&notificationid=2217737177`;

      service.getWithholding(mockNotification).subscribe(() => {
        expect(stateWithholdingTransformService.getWithholdingItems).toHaveBeenCalled();
        done();
      });

      httpMock.expectOne(url).flush({ usStateTaxWithholdingElections: {} });
    });
  });
});
