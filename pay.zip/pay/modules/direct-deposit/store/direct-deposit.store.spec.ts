import { TestBed } from '@angular/core/testing';
import { filter } from 'rxjs/operators';

import { SORS } from '@myadp/common';
import { MOCK_TRANSFORMED_DIRECT_DEPOSIT_ACCOUNTS } from '@specHelpers/pay/direct-deposit/direct-deposit';

import { DistributionOptions } from '../../pay-distributions-shared/models/pay-distributions-ui';
import { AccountType, ValidationStatus } from '../models/deposit-account.model';
import { DirectDepositAccount } from '../models/direct-deposit-account.model';
import { FormDetails } from '../models/form-details.model';
import { WiselyTypes } from '../models/wisely.model';
import { DirectDepositStore, DirectDepositStoreSlice } from './direct-deposit.store';

import { COUNTRY, COUNTRY_CONFIG } from './../../pay-distributions-shared/models/country';

describe('DirectDepositStore', () => {
  let directDepositStore: DirectDepositStore;
  const accounts: DirectDepositAccount[] = [
    {
      currentData: null,
      pendingData: {
        precedence: '1',
        accountTypeName: 'Checking 1',
        accountNumber: 'X123456P7',
        routingNumber: '021000021',
        distributionType: DistributionOptions.FLAT,
        flatAmount: { amountValue: 123, currencyCode: 'USD' },
        codeValueData: {
          shortName: 'ckg1',
          longName: 'Checking 1',
          accountCode: 'C'
        }
      }
    },
    {
      currentData: {
        precedence: '2',
        accountTypeName: 'Checking 2',
        accountNumber: '123-45678',
        routingNumber: '021000021',
        distributionType: DistributionOptions.PERCENTAGE,
        percentageAmount: 25,
        codeValueData: {
          shortName: 'ckg2',
          longName: 'Checking 2',
          accountCode: 'C2'
        }
      }
    },
    {
      currentData: {
        precedence: '3',
        accountName: 'My Account Name',
        accountTypeName: 'Checking 3',
        accountNumber: '12345',
        routingNumber: '021000021',
        distributionType: DistributionOptions.REMAINING,
        codeValueData: {
          shortName: 'ckg3',
          longName: 'Checking 3',
          accountCode: 'C3'
        }
      }
    }
  ];

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: []
    });

    directDepositStore = TestBed.inject(DirectDepositStore);
  });

  it('should create the direct deposit store with an initial state', () => {
    const initialState: Record<string, object> = {
      [DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS]: {
        data: null,
        loading: false,
        error: {}
      },
      [DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS_INITIAL]: {
        data: null
      },
      [DirectDepositStoreSlice.MODIFIED_ACCOUNTS]: {
        data: null
      },
      [DirectDepositStoreSlice.DIRECT_DEPOSIT_CONFIG]: {
        data: undefined,
        loading: false,
        error: {}
      },
      [DirectDepositStoreSlice.FORM_DETAILS]: {
        data: undefined
      },
      [DirectDepositStoreSlice.PERMISSIONS]: {
        data: undefined,
        loading: false,
        error: {}
      },
      [DirectDepositStoreSlice.ACCOUNT_VERIFICATION]: {
        data: undefined,
        loading: false,
        error: {}
      },
      [DirectDepositStoreSlice.DIRECT_DEPOSIT_COUNTRY]: {
        data: null
      }
    };

    expect(directDepositStore).toBeTruthy();
    expect(directDepositStore.stateValue).toEqual(initialState);
  });

  it('should get the form details based on step', () => {
    directDepositStore.update(DirectDepositStoreSlice.FORM_DETAILS, {
      data: {
        terms: false
      }
    });
    const formData: FormDetails = directDepositStore.formDetails;

    expect(formData).toEqual({
      terms: false
    });
  });

  it('should be loading', (done) => {
    directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS, {
      loading: true
    });

    directDepositStore.isLoading$.subscribe((isLoading) => {
      expect(isLoading).toBe(true);
      done();
    });
  });

  it('should not be loading', (done) => {
    directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS, {
      loading: false
    });

    directDepositStore.isLoading$.subscribe((isLoading) => {
      expect(isLoading).toBe(false);
      done();
    });
  });

  describe('getDDAccountsSnapshot', () => {
    const mockData: DirectDepositAccount[] = [
      MOCK_TRANSFORMED_DIRECT_DEPOSIT_ACCOUNTS[0], // no change
      {
        // cancelled edit/delete
        currentData: MOCK_TRANSFORMED_DIRECT_DEPOSIT_ACCOUNTS[1].currentData,
        pendingData: null,
        pendingEvent: { changeType: null }
      },
      {
        // cancelled add
        currentData: null,
        pendingData: null,
        pendingEvent: { changeType: null }
      },
      // deleted pending account
      { currentData: null, pendingData: null, pendingEvent: { changeType: 'pruned' } }
    ];

    it('should filter deleted accounts by default from the accountsSnapshot', () => {
      directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS, {
        data: mockData
      });

      expect(directDepositStore.getDDAccountsSnapshot()).toEqual([
        mockData[0],
        mockData[1],
        mockData[2]
      ]);
    });

    it('should return deleted accounts from the accountsSnapshot', () => {
      directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS, {
        data: mockData
      });

      expect(directDepositStore.getDDAccountsSnapshot({ filterDeleted: false })).toEqual(mockData);
    });
  });

  it('should update verification status when subscribed to', (done) => {
    directDepositStore.update(DirectDepositStoreSlice.FORM_DETAILS, {
      data: {
        validationStatus: ValidationStatus.SUCCESS
      }
    });

    directDepositStore.currentWorkingVerificationStatus$
      .pipe(filter((status: ValidationStatus) => status === ValidationStatus.SUCCESS))
      .subscribe((status: ValidationStatus) => {
        expect(status).toEqual(ValidationStatus.SUCCESS);
        done();
      });
  });

  it('should get verification status', () => {
    directDepositStore.update(DirectDepositStoreSlice.ACCOUNT_VERIFICATION, {
      data: {
        '123': { status: ValidationStatus.SUCCESS }
      }
    });
    expect(directDepositStore.getValidationStatus('123')).toEqual({
      status: ValidationStatus.SUCCESS
    });
  });

  describe('hasPermission', () => {
    it('should return true if sffo is in store', () => {
      directDepositStore.update(DirectDepositStoreSlice.PERMISSIONS, {
        data: {
          [WiselyTypes.WISELY_DIRECT]: true
        }
      });

      expect(directDepositStore.hasPermission(WiselyTypes.WISELY_DIRECT)).toBeTrue();
      expect(directDepositStore.hasPermission('GIACT')).toBeFalse();
    });
  });

  describe('hasPostError', () => {
    it('should return POST error', (done) => {
      directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS, {
        error: {
          ddAccountsPostError: true
        }
      });

      directDepositStore.hasPostError$.subscribe((error) => {
        expect(error).toBeTrue();
        done();
      });
    });

    it('should not return POST error', (done) => {
      directDepositStore.hasPostError$.subscribe((error) => {
        expect(error).toBeFalse();
        done();
      });
    });
  });

  describe('hasStaticAccounts', () => {
    it('should return true for RUN', () => {
      directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_CONFIG, {
        data: { sorProvider: SORS.US.RUN }
      });
      expect(directDepositStore.isRun).toBeTrue();
      expect(directDepositStore.hasStaticAccountTypes).toBeTrue();
      expect(directDepositStore.isWFN).toBeFalse();
      expect(directDepositStore.isAvsddm).toBeFalse();
      expect(directDepositStore.isEnterprise).toBeFalse();
      expect(directDepositStore.isEnterprisePortal).toBeFalse();
      expect(directDepositStore.isPRWC).toBeFalse();
      expect(directDepositStore.usesNonCompliantSchema).toBeFalse();
    });

    it('should return true for WFN', () => {
      directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_CONFIG, {
        data: { sorProvider: SORS.US.WFN }
      });
      expect(directDepositStore.isRun).toBeFalse();
      expect(directDepositStore.hasStaticAccountTypes).toBeFalse();
      expect(directDepositStore.isWFN).toBeTrue();
      expect(directDepositStore.isAvsddm).toBeFalse();
      expect(directDepositStore.isEnterprise).toBeFalse();
      expect(directDepositStore.isEnterprisePortal).toBeFalse();
      expect(directDepositStore.isPRWC).toBeFalse();
      expect(directDepositStore.usesNonCompliantSchema).toBeFalse();
    });

    it('should return true for AVSDDM', () => {
      directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_CONFIG, {
        data: { sorProvider: SORS.US.AVSDDM }
      });
      expect(directDepositStore.isRun).toBeFalse();
      expect(directDepositStore.hasStaticAccountTypes).toBeTrue();
      expect(directDepositStore.isWFN).toBeFalse();
      expect(directDepositStore.isAvsddm).toBeTrue();
      expect(directDepositStore.isEnterprise).toBeFalse();
      expect(directDepositStore.isEnterprisePortal).toBeFalse();
      expect(directDepositStore.isPRWC).toBeFalse();
      expect(directDepositStore.usesNonCompliantSchema).toBeFalse();
    });

    it('should return true for ENTERPRISE', () => {
      directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_CONFIG, {
        data: { sorProvider: SORS.US.ENTERPRISE }
      });
      expect(directDepositStore.isRun).toBeFalse();
      expect(directDepositStore.hasStaticAccountTypes).toBeFalse();
      expect(directDepositStore.isWFN).toBeFalse();
      expect(directDepositStore.isAvsddm).toBeFalse();
      expect(directDepositStore.isEnterprise).toBeTrue();
      expect(directDepositStore.isEnterprisePortal).toBeFalse();
      expect(directDepositStore.isPRWC).toBeFalse();
      expect(directDepositStore.usesNonCompliantSchema).toBeTrue();
    });

    it('should return true for EnterprisePortal', () => {
      directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_CONFIG, {
        data: { sorProvider: SORS.US.ENTERPRISE_PORTAL }
      });
      expect(directDepositStore.isRun).toBeFalse();
      expect(directDepositStore.hasStaticAccountTypes).toBeFalse();
      expect(directDepositStore.isWFN).toBeFalse();
      expect(directDepositStore.isAvsddm).toBeFalse();
      expect(directDepositStore.isEnterprise).toBeFalse();
      expect(directDepositStore.isEnterprisePortal).toBeTrue();
      expect(directDepositStore.isPRWC).toBeFalse();
      expect(directDepositStore.usesNonCompliantSchema).toBeFalse();
    });

    it('should return true for PRWC', () => {
      directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_CONFIG, {
        data: { sorProvider: SORS.US.PRWC }
      });
      expect(directDepositStore.isRun).toBeFalse();
      expect(directDepositStore.hasStaticAccountTypes).toBeTrue();
      expect(directDepositStore.isWFN).toBeFalse();
      expect(directDepositStore.isAvsddm).toBeFalse();
      expect(directDepositStore.isEnterprise).toBeFalse();
      expect(directDepositStore.isEnterprisePortal).toBeFalse();
      expect(directDepositStore.isPRWC).toBeTrue();
      expect(directDepositStore.usesNonCompliantSchema).toBeFalse();
    });
  });

  it('should detect changes in the account snapshots', () => {
    directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS, {
      data: MOCK_TRANSFORMED_DIRECT_DEPOSIT_ACCOUNTS
    });

    directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS_INITIAL, {
      data: MOCK_TRANSFORMED_DIRECT_DEPOSIT_ACCOUNTS
    });

    expect(directDepositStore.hasChanges()).toBeFalse();

    directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS, {
      data: []
    });

    expect(directDepositStore.hasChanges()).toBeTrue();
  });

  describe('getAvailableAccountTypes()', () => {
    it('should filter out used accounts', () => {
      directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS, {
        data: [accounts[0], accounts[1]]
      });

      const accountTypes: AccountType[] = [
        { shortName: 'ck1', value: 'C' },
        { shortName: 'ck2', value: 'C2' },
        { shortName: 'ck3', value: 'C3' }
      ];

      const availableAccountTypes = directDepositStore.getAvailableAccountTypes(accountTypes);
      expect(availableAccountTypes).toEqual([{ shortName: 'ck3', value: 'C3' }]);
    });
  });

  describe('countries', () => {
    it('should determine whether or not the deposits are from the United States', () => {
      directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_COUNTRY, {
        data: COUNTRY_CONFIG[COUNTRY.US]
      });

      expect(directDepositStore.isCanadian).toBeFalse();
      expect(directDepositStore.isFromCountry(COUNTRY.US)).toBeTrue();
      expect(directDepositStore.directDepositCountry).toEqual(COUNTRY_CONFIG[COUNTRY.US]);
    });

    it('should determine whether or not the deposits are from Canada', () => {
      directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_COUNTRY, {
        data: COUNTRY_CONFIG[COUNTRY.CA]
      });

      expect(directDepositStore.isCanadian).toBeTrue();
      expect(directDepositStore.isFromCountry(COUNTRY.CA)).toBeTrue();
      expect(directDepositStore.directDepositCountry).toEqual(COUNTRY_CONFIG[COUNTRY.CA]);
    });
  });
});
