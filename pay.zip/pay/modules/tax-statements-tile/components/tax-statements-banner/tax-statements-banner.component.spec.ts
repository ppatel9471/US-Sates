import { CurrencyPipe } from '@angular/common';
import { Shallow } from 'shallow-render';

import { LanguageService } from '@myadp/common';

import { TaxStatementsTileModule } from '../../tax-statements-tile.module';
import { ValueFormatterService } from '../../../shared/services/value-formatter.service';
import { TaxStatementsBannerComponent } from './tax-statements-banner.component';
import { getButton } from '@myadp/pay-shared/testing/spec-util.spec';

describe('TaxStatementsBannerComponent', () => {
  let shallow: Shallow<TaxStatementsBannerComponent>;

  beforeEach(() => {
    shallow = new Shallow(TaxStatementsBannerComponent, TaxStatementsTileModule)
      .provide(LanguageService)
      .provide(CurrencyPipe)
      .provide(ValueFormatterService)
      .mock(LanguageService, { get: (key: string) => key })
      .dontMock(CurrencyPipe)
      .dontMock(ValueFormatterService);
  });

  describe('tax statements banner', () => {
    it('should find tax prep vendor banner alert', async () => {
      const { find } = await shallow.render();
      expect(find('adp-alert[data-e2e="import-banner"]')).toHaveFound(1);
    });

    it('should find tax prep vendor learn more button link', async () => {
      const { find } = await shallow.render();
      expect(getButton(find, 'import-banner-button')).toHaveFound(1);
    });

    it('should open modal when learn more button is clicked', async () => {
      const { instance, find, fixture } = await shallow.render();
      instance.openModal();
      fixture.detectChanges();
      expect(find('adp-modal')).toHaveFound(1);
    });

    it('should close modal when close button is clicked', async () => {
      const { instance, find, fixture } = await shallow.render();
      instance.openModal();
      fixture.detectChanges();
      instance.closeModal();
      fixture.detectChanges();
      expect(find('adp-modal')).toHaveFound(0);
    });
  });
});
