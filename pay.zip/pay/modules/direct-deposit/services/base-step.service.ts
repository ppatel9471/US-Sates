import { Injectable } from '@angular/core';

import { FormDetails } from '../models/form-details.model';
import { StepsStore } from '../store/steps/steps.store';

@Injectable({
  providedIn: 'root'
})
export class BaseStepService {
  constructor(protected stepsStore: StepsStore) {}

  protected get isEditing(): boolean {
    return this.stepsStore.isEditing;
  }

  protected get formData(): FormDetails {
    return this.stepsStore.stepFormDetails;
  }

  protected get currentStep(): string {
    return this.stepsStore.currentStepName;
  }

  protected get showTerms(): boolean {
    return this.stepsStore?.stepsStoreData?.showTerms;
  }
}
