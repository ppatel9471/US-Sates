import { TestBed } from '@angular/core/testing';
import { Mock } from 'ts-mockery';

import { DistributionOptions } from '../../pay-distributions-shared/models/pay-distributions-ui';
import { FormDetails } from '../models/form-details.model';
import { StepsStore } from '../store/steps/steps.store';
import { BaseStepService } from './base-step.service';

class SomeStepService extends BaseStepService {
  public getIsEditing(): boolean {
    return this.isEditing;
  }

  public getFormData(): FormDetails {
    return this.formData;
  }

  public getCurrentStep(): string {
    return this.currentStep;
  }
}

describe('BaseStepService', () => {
  let someStepService: SomeStepService;
  let stepsStore: StepsStore;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        {
          provide: StepsStore,
          useValue: Mock.of<StepsStore>({
            isEditing: false,
            stepFormDetails: null,
            currentStepName: 'ACCOUNT_DETAILS'
          })
        }
      ]
    });

    stepsStore = TestBed.inject(StepsStore);
    someStepService = new SomeStepService(stepsStore);
  });

  describe('isEditing', () => {
    it('should return false when not editing', () => {
      expect(someStepService.getIsEditing()).toBeFalsy();
    });

    it('should return true when editing', () => {
      Mock.extend(stepsStore).with({
        isEditing: true
      });

      expect(someStepService.getIsEditing()).toBeTruthy();
    });
  });

  describe('formData', () => {
    it('should return stepFormDetails', () => {
      Mock.extend(stepsStore).with({
        stepFormDetails: {
          id: '1',
          codeValueData: {
            longName: 'Savings',
            shortName: 'SAV3',
            accountCode: '103'
          },
          accountTypeCode: {
            label: 'Savings',
            longName: 'Savings',
            shortName: 'SAV3',
            value: '103'
          },
          distributionType: DistributionOptions.REMAINING,
          percentageAmount: null,
          flatAmount: null,
          accountNumber: '123456',
          routingNumber: '061092387'
        }
      });

      expect(someStepService.getFormData()).toEqual({
        id: '1',
        codeValueData: {
          longName: 'Savings',
          shortName: 'SAV3',
          accountCode: '103'
        },
        accountTypeCode: {
          label: 'Savings',
          longName: 'Savings',
          shortName: 'SAV3',
          value: '103'
        },
        distributionType: DistributionOptions.REMAINING,
        percentageAmount: null,
        flatAmount: null,
        accountNumber: '123456',
        routingNumber: '061092387'
      });
    });
  });

  describe('currentStep', () => {
    it('should return "ACCOUNT_DETAILS"', () => {
      expect(someStepService.getCurrentStep()).toEqual('ACCOUNT_DETAILS');
    });
  });
});
