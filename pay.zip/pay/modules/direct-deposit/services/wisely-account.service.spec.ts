import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { flush, TestBed, fakeAsync } from '@angular/core/testing';

import { of } from 'rxjs';
import { Mock } from 'ts-mockery';

import { FilteredUserProfileService, UserIdentityService } from '@myadp/common';

import { WiselyAccountService } from './wisely-account.service';
import { PayDistributionStore } from '../../pay-distributions-shared/store/pay-distribution.store';

import { DirectDepositStore, DirectDepositStoreSlice } from '../store/direct-deposit.store';
import { WiselyAccountStatus, WiselyTypes } from '../models/wisely.model';

const mockCardHolders = {
  cardholders: [
    {
      workerID: {
        idValue: '32659'
      },
      personName: {
        givenName: 'Same',
        middleName: '',
        familyName1: 'Shaik'
      },
      cardholderAccount: {
        routingTransitID: {
          idValue: '071922476'
        },
        accountNumber: '8100000063521237'
      },
      cards: [
        {
          primaryIndicator: true,
          secondaryIndicator: false,
          pinSet: true,
          portability: 'active',
          cardNetwork: 'Visa',
          minTxnDate: '',
          pendingReplacement: false,
          pendingUpgrade: false,
          locked: false,
          cardAliasID: '2374917',
          cardNumber: '7536',
          expirationDate: '2025-01-31',
          cardStatusCode: {
            codeValue: 'stolen',
            shortName: 'Card Status',
            effectiveDate: '2021-01-20'
          },
          accountNumber: '8100000063521237'
        }
      ]
    }
  ]
};

describe('WiselyAccountService', () => {
  let wiselyAccountService: WiselyAccountService;
  let httpClient: HttpTestingController;
  let mock: any;
  let userProfileService: FilteredUserProfileService;
  let payDistributionStore: PayDistributionStore;
  let directDepositStore: DirectDepositStore;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        {
          provide: UserIdentityService,
          useValue: Mock.of<UserIdentityService>({
            getAoid: () => Promise.resolve('1234')
          })
        },
        {
          provide: FilteredUserProfileService,
          useValue: Mock.of<FilteredUserProfileService>({
            hasD2E: of(false)
          })
        },
        {
          provide: PayDistributionStore,
          useValue: Mock.of<PayDistributionStore>({
            payDistributions$: Mock.noop(),
            payDistributionMeta$: Mock.noop(),
            hasChangePermission$: Mock.noop()
          })
        }
      ]
    });

    wiselyAccountService = TestBed.inject(WiselyAccountService);
    httpClient = TestBed.inject(HttpTestingController);
    userProfileService = TestBed.inject(FilteredUserProfileService);
    directDepositStore = TestBed.inject(DirectDepositStore);
    payDistributionStore = TestBed.inject(PayDistributionStore);

    mock = JSON.parse(JSON.stringify(mockCardHolders));

    directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS, {
      data: [
        {
          isWisely: false,
          currentData: null,
          pendingData: {
            precedence: '1',
            accountTypeName: 'Checking 1',
            accountNumber: 'X123456P7',
            routingNumber: '021000021',
            flatAmount: { amountValue: 123, currencyCode: 'USD' },
            codeValueData: {
              shortName: 'ckg1',
              longName: 'Checking 1',
              accountCode: 'C'
            }
          }
        }
      ]
    });
  });

  it('should return whether or not a user has wisely permission', () => {
    Mock.extend(directDepositStore).with({
      hasPermission: (type: WiselyTypes) => type === WiselyTypes.WISELY_DIRECT
    });

    expect(wiselyAccountService.hasWisely()).toBeTrue();

    Mock.extend(directDepositStore).with({
      hasPermission: (type: WiselyTypes) => type !== WiselyTypes.WISELY_DIRECT
    });

    Mock.extend(payDistributionStore).with({
      payDistributionMetaSnapshot: {
        accountTypeList: [
          {
            codeValue: 'WIS'
          },
          {
            codeValue: 'foo'
          },
          {
            codeValue: 'bar'
          }
        ]
      }
    });

    expect(wiselyAccountService.hasWisely()).toBeTrue();

    Mock.extend(directDepositStore).with({
      hasPermission: () => false
    });

    expect(wiselyAccountService.hasWisely()).toBeFalse();
  });

  it('should return to show terms and condition if the user is a wisely direct user', () => {
    Mock.extend(directDepositStore).with({
      hasPermission: (type: WiselyTypes) => type === WiselyTypes.WISELY_DIRECT
    });

    expect(wiselyAccountService.shouldShowTerms()).toBeTrue();
  });

  it('should return to show terms and condition if the user is a wisely pay user', () => {
    Mock.extend(directDepositStore).with({
      hasPermission: (type: WiselyTypes) => type === WiselyTypes.WISELY_PAY
    });

    expect(wiselyAccountService.shouldShowTerms()).toBeTrue();
  });

  it('should flatten an account list', () => {
    Mock.extend(payDistributionStore).with({
      payDistributionMetaSnapshot: {
        accountTypeList: [
          {
            codeValue: 'WIS'
          },
          {
            codeValue: 'foo'
          },
          {
            codeValue: 'bar'
          }
        ]
      }
    });

    expect(wiselyAccountService.flattenAccountTypeCodeList()).toEqual(['WIS', 'foo', 'bar']);
  });

  it('should flatten an account list if the list is mysteriously erroneous', () => {
    Mock.extend(payDistributionStore).with({
      payDistributionMetaSnapshot: {
        accountTypeList: undefined
      }
    });

    expect(wiselyAccountService.flattenAccountTypeCodeList()).toEqual([]);
  });

  it('should use cache if it exists', fakeAsync(async () => {
    Mock.extend(userProfileService).with({
      hasD2E: of(true)
    });

    const wiselyCall = wiselyAccountService.getWiselyAccount();
    flush();
    const apiCall = httpClient.expectOne('/payroll/v1/paycard/cardholders/1234');

    apiCall.flush({}, { status: 500, statusText: 'nt' });

    const wiselyAccount = await wiselyCall;

    expect(wiselyAccount.status).toEqual(WiselyAccountStatus.DONOTSHOW);

    const secondWiselyCall = wiselyAccountService.getWiselyAccount();
    flush();
    httpClient.expectNone('/payroll/v1/paycard/cardholders/1234');

    const secondWiselyResult = await secondWiselyCall;

    expect(secondWiselyResult.status).toEqual(WiselyAccountStatus.DONOTSHOW);
  }));

  it('should fetch data if the cache does not exist', fakeAsync(async () => {
    Mock.extend(userProfileService).with({
      hasD2E: of(true)
    });

    const wiselyCall = wiselyAccountService.getWiselyAccount(true);
    flush();
    const apiCall = httpClient.expectOne('/payroll/v1/paycard/cardholders/1234');

    apiCall.flush({}, { status: 500, statusText: 'nt' });

    const wiselyAccount = await wiselyCall;

    expect(wiselyAccount.status).toEqual(WiselyAccountStatus.DONOTSHOW);
  }));

  it('should cache bust when asked to', fakeAsync(async () => {
    Mock.extend(userProfileService).with({
      hasD2E: of(true)
    });

    const wiselyCall = wiselyAccountService.getWiselyAccount();
    flush();
    const apiCall = httpClient.expectOne('/payroll/v1/paycard/cardholders/1234');

    apiCall.flush({}, { status: 500, statusText: 'nt' });

    const wiselyAccount = await wiselyCall;

    expect(wiselyAccount.status).toEqual(WiselyAccountStatus.DONOTSHOW);

    const secondWiselyCall = wiselyAccountService.getWiselyAccount(true);
    flush();
    const secondApiCall = httpClient.expectOne('/payroll/v1/paycard/cardholders/1234');

    delete mock.cardholders[0].cards[0].cardStatusCode;

    secondApiCall.flush(mock);

    const secondWiselyResult = await secondWiselyCall;

    expect(secondWiselyResult.isWiselyDirect).toBeTrue();
    expect(secondWiselyResult.accountNumber).toEqual('8100000063521237');
    expect(secondWiselyResult.routingNumber).toEqual('071922476');
    expect(secondWiselyResult.status).toEqual(WiselyAccountStatus.UNCREATED);
  }));

  it('should check to see if there is an existing wisely account for dd and yields false', () => {
    Mock.extend(payDistributionStore).with({
      hasWiselyAccount: false
    });

    expect(wiselyAccountService.hasExistingWisely()).toBe(false);
  });

  it('should check to see if there is an existing wisely account for dd and yields true', () => {
    Mock.extend(payDistributionStore).with({
      hasWiselyAccount: false
    });

    directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS, {
      data: [
        {
          isWisely: true,
          currentData: null,
          pendingData: {
            precedence: '1',
            accountTypeName: 'WIS',
            accountNumber: 'X123456P7',
            routingNumber: '021000021',
            flatAmount: { amountValue: 123, currencyCode: 'USD' },
            codeValueData: {
              longName: 'WISELY PAY',
              accountCode: 'W'
            }
          }
        }
      ]
    });

    expect(wiselyAccountService.hasExistingWisely()).toBe(true);
  });

  it('should see if the user qualifies through wisely by codeList', () => {
    Mock.extend(payDistributionStore).with({
      payDistributionMetaSnapshot: {
        accountTypeList: [
          {
            codeValue: 'WIS'
          }
        ]
      }
    });

    expect(wiselyAccountService.hasWiselyPayDeductionCode()).toBe(true);
  });

  it('should see if the user is not qualified through wisely by codeList', () => {
    Mock.extend(payDistributionStore).with({
      payDistributionMetaSnapshot: {
        accountTypeList: [
          {
            codeValue: 'Checking'
          }
        ]
      }
    });

    expect(wiselyAccountService.hasWiselyPayDeductionCode()).toBe(false);
  });

  it('should transform details for direct', () => {
    Mock.extend(payDistributionStore).with({
      payDistributionMetaSnapshot: {
        accountTypeList: [
          {
            codeValue: 'C',
            longName: 'Checking'
          }
        ]
      }
    });

    directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS, {
      data: []
    });

    expect(
      wiselyAccountService.transformDetails({
        isWiselyDirect: true,
        routingNumber: '123',
        accountNumber: '123',
        isActivated: true
      })
    ).toEqual({
      distributionType: null,
      percentageAmount: null,
      accountTypeCode: { longName: 'WISELY DIRECT', value: 'C' },
      flatAmount: null,
      codeValueData: {
        itemID: null,
        accountCode: 'C',
        shortName: null,
        longName: 'WISELY DIRECT'
      },
      precedence: '1',
      precedenceCode: 'WISELY DIRECT',
      accountName: 'WISELY DIRECT',
      accountTypeName: 'WISELY DIRECT',
      accountNumber: '123',
      routingNumber: '123',
      prenoteIndicator: false
    });
  });

  it('should transform details for pay', () => {
    Mock.extend(payDistributionStore).with({
      payDistributionMetaSnapshot: {
        accountTypeList: [
          {
            codeValue: 'WIS',
            longName: 'wisely pay'
          }
        ]
      }
    });

    expect(
      wiselyAccountService.transformDetails({
        isWiselyDirect: false,
        routingNumber: '123',
        accountNumber: '123',
        isActivated: true
      })
    ).toEqual({
      distributionType: null,
      percentageAmount: null,
      accountTypeCode: { codeValue: 'WIS', longName: 'wisely pay' },
      flatAmount: null,
      codeValueData: {
        itemID: null,
        accountCode: 'WIS',
        longName: null,
        shortName: undefined
      },
      precedence: '1',
      precedenceCode: 'WISELY PAY',
      accountName: 'WISELY PAY',
      accountTypeName: 'wisely pay',
      accountNumber: '123',
      routingNumber: '123',
      prenoteIndicator: false
    });
  });

  it('should show DO NOT SHOW as the UI when receiving code 500 for wisely pay', fakeAsync(async () => {
    Mock.extend(userProfileService).with({
      hasD2E: of(false)
    });

    const wiselyCall = wiselyAccountService.getWiselyAccount();
    flush();
    const apiCall = httpClient.expectOne('/payroll/v1/paycard/cardholders/1234');

    apiCall.flush({}, { status: 500, statusText: 'nt' });

    const wiselyAccount = await wiselyCall;

    expect(wiselyAccount.status).toEqual(WiselyAccountStatus.DONOTSHOW);
  }));

  it('should show DO NOT SHOW as the UI when receiving code 500 for wisely direct, ', fakeAsync(async () => {
    Mock.extend(userProfileService).with({
      hasD2E: of(true)
    });

    const wiselyCall = wiselyAccountService.getWiselyAccount();
    flush();
    const apiCall = httpClient.expectOne('/payroll/v1/paycard/cardholders/1234');

    apiCall.flush({}, { status: 500, statusText: 'nt' });

    const wiselyAccount = await wiselyCall;

    expect(wiselyAccount.status).toEqual(WiselyAccountStatus.DONOTSHOW);
  }));

  it('should set up an uncreated state', fakeAsync(async () => {
    const wiselyCall = wiselyAccountService.getWiselyAccount();
    flush();
    const apiCall = httpClient.expectOne('/payroll/v1/paycard/cardholders/1234');

    delete mock.cardholders[0].cards[0].cardStatusCode;

    apiCall.flush(mock);

    const wiselyAccount = await wiselyCall;

    expect(wiselyAccount.isWiselyDirect).toBeFalse();
    expect(wiselyAccount.accountNumber).toEqual('8100000063521237');
    expect(wiselyAccount.routingNumber).toEqual('071922476');
    expect(wiselyAccount.status).toEqual(WiselyAccountStatus.UNCREATED);
  }));

  it('should set up a canceled state', fakeAsync(async () => {
    const wiselyCall = wiselyAccountService.getWiselyAccount();
    flush();
    const apiCall = httpClient.expectOne('/payroll/v1/paycard/cardholders/1234');

    mock.cardholders[0].cards[0].cardStatusCode.codeValue = 'canceled';

    apiCall.flush(mock);

    const wiselyAccount = await wiselyCall;

    expect(wiselyAccount.isWiselyDirect).toBeFalse();
    expect(wiselyAccount.accountNumber).toEqual('8100000063521237');
    expect(wiselyAccount.routingNumber).toEqual('071922476');
    expect(wiselyAccount.status).toEqual(WiselyAccountStatus.CANCELED);
    expect(wiselyAccount.wiselyErrorMessage).toEqual('myadp-pay.DD_WISELY_PAY_ALERT_CANCELED');
  }));

  it('should set up a lost state', fakeAsync(async () => {
    const wiselyCall = wiselyAccountService.getWiselyAccount();
    flush();
    const apiCall = httpClient.expectOne('/payroll/v1/paycard/cardholders/1234');

    mock.cardholders[0].cards[0].cardStatusCode.codeValue = 'lost';

    apiCall.flush(mock);

    const wiselyAccount = await wiselyCall;

    expect(wiselyAccount.isWiselyDirect).toBeFalse();
    expect(wiselyAccount.accountNumber).toEqual('8100000063521237');
    expect(wiselyAccount.routingNumber).toEqual('071922476');
    expect(wiselyAccount.status).toEqual(WiselyAccountStatus.LOST);
    expect(wiselyAccount.wiselyErrorMessage).toEqual('myadp-pay.DD_WISELY_PAY_ALERT_LOST');
  }));

  it('should set up a closed state', fakeAsync(async () => {
    const wiselyCall = wiselyAccountService.getWiselyAccount();
    flush();
    const apiCall = httpClient.expectOne('/payroll/v1/paycard/cardholders/1234');

    mock.cardholders[0].cards[0].cardStatusCode.codeValue = 'closed';

    apiCall.flush(mock);

    const wiselyAccount = await wiselyCall;

    expect(wiselyAccount.isWiselyDirect).toBeFalse();
    expect(wiselyAccount.accountNumber).toEqual('8100000063521237');
    expect(wiselyAccount.routingNumber).toEqual('071922476');
    expect(wiselyAccount.status).toEqual(WiselyAccountStatus.CANCELED);
    expect(wiselyAccount.wiselyErrorMessage).toEqual('myadp-pay.DD_WISELY_PAY_ALERT_CLOSED');
  }));

  it('should set up a deceased state', fakeAsync(async () => {
    const wiselyCall = wiselyAccountService.getWiselyAccount();
    flush();
    const apiCall = httpClient.expectOne('/payroll/v1/paycard/cardholders/1234');

    mock.cardholders[0].cards[0].cardStatusCode.codeValue = 'deceased';

    apiCall.flush(mock);

    const wiselyAccount = await wiselyCall;

    expect(wiselyAccount.isWiselyDirect).toBeFalse();
    expect(wiselyAccount.accountNumber).toEqual('8100000063521237');
    expect(wiselyAccount.routingNumber).toEqual('071922476');
    expect(wiselyAccount.status).toEqual(WiselyAccountStatus.DONOTSHOW);
    expect(wiselyAccount.wiselyErrorMessage).toEqual('myadp-pay.DD_WISELY_PAY_ALERT_DECEASED');
  }));

  it('should set up a deceased state', fakeAsync(async () => {
    const wiselyCall = wiselyAccountService.getWiselyAccount();
    flush();
    const apiCall = httpClient.expectOne('/payroll/v1/paycard/cardholders/1234');

    mock.cardholders[0].cards[0].cardStatusCode.codeValue = 'idle';

    apiCall.flush(mock);

    const wiselyAccount = await wiselyCall;

    expect(wiselyAccount.isWiselyDirect).toBeFalse();
    expect(wiselyAccount.accountNumber).toEqual('8100000063521237');
    expect(wiselyAccount.routingNumber).toEqual('071922476');
    expect(wiselyAccount.status).toEqual(WiselyAccountStatus.DONOTSHOW);
    expect(wiselyAccount.wiselyErrorMessage).toEqual('myadp-pay.DD_WISELY_PAY_ALERT_IDLE');
  }));

  it('should set up a ofac state', fakeAsync(async () => {
    const wiselyCall = wiselyAccountService.getWiselyAccount();
    flush();
    const apiCall = httpClient.expectOne('/payroll/v1/paycard/cardholders/1234');

    mock.cardholders[0].cards[0].cardStatusCode.codeValue = 'ofac';

    apiCall.flush(mock);

    const wiselyAccount = await wiselyCall;

    expect(wiselyAccount.isWiselyDirect).toBeFalse();
    expect(wiselyAccount.accountNumber).toEqual('8100000063521237');
    expect(wiselyAccount.routingNumber).toEqual('071922476');
    expect(wiselyAccount.status).toEqual(WiselyAccountStatus.DONOTSHOW);
    expect(wiselyAccount.wiselyErrorMessage).toEqual('myadp-pay.DD_WISELY_PAY_ALERT_OFAC');
  }));

  it('should set up a disabled state', fakeAsync(async () => {
    const wiselyCall = wiselyAccountService.getWiselyAccount();
    flush();
    const apiCall = httpClient.expectOne('/payroll/v1/paycard/cardholders/1234');

    mock.cardholders[0].cards[0].cardStatusCode.codeValue = 'disabled';

    apiCall.flush(mock);

    const wiselyAccount = await wiselyCall;

    expect(wiselyAccount.isWiselyDirect).toBeFalse();
    expect(wiselyAccount.accountNumber).toEqual('8100000063521237');
    expect(wiselyAccount.routingNumber).toEqual('071922476');
    expect(wiselyAccount.status).toEqual(WiselyAccountStatus.DONOTSHOW);
    expect(wiselyAccount.wiselyErrorMessage).toEqual('myadp-pay.DD_WISELY_PAY_ALERT_DISABLED');
  }));

  it('should show DONOTSHOW when the status code is 400', fakeAsync(async () => {
    const wiselyCall = wiselyAccountService.getWiselyAccount();
    flush();
    const apiCall = httpClient.expectOne('/payroll/v1/paycard/cardholders/1234');
    apiCall.flush({}, { status: 400, statusText: 'n/a' });

    flush();

    const wiselyAccount = await wiselyCall;

    expect(wiselyAccount.isWiselyDirect).toBeFalse();
    expect(wiselyAccount.status).toEqual(WiselyAccountStatus.DONOTSHOW);
  }));

  it('should set up a locked state', fakeAsync(async () => {
    const wiselyCall = wiselyAccountService.getWiselyAccount();
    flush();
    const apiCall = httpClient.expectOne('/payroll/v1/paycard/cardholders/1234');

    mock.cardholders[0].cards[0].cardStatusCode.codeValue = 'locked';

    apiCall.flush(mock);

    const wiselyAccount = await wiselyCall;

    expect(wiselyAccount.isWiselyDirect).toBeFalse();
    expect(wiselyAccount.accountNumber).toEqual('8100000063521237');
    expect(wiselyAccount.routingNumber).toEqual('071922476');
    expect(wiselyAccount.status).toEqual(WiselyAccountStatus.DONOTSHOW);
    expect(wiselyAccount.wiselyErrorMessage).toEqual('myadp-pay.DD_WISELY_PAY_ALERT_LOCKED');
  }));

  it('should be DONOTSHOW when a Direct user is limited', fakeAsync(async () => {
    Mock.extend(userProfileService).with({
      hasD2E: of(true)
    });

    const wiselyCall = wiselyAccountService.getWiselyAccount();
    flush();
    const apiCall = httpClient.expectOne('/payroll/v1/paycard/cardholders/1234');

    mock.cardholders[0].cards[0].cardStatusCode.codeValue = 'limited';

    apiCall.flush(mock);

    const wiselyAccount = await wiselyCall;

    expect(wiselyAccount.isWiselyDirect).toBeTrue();
    expect(wiselyAccount.accountNumber).toEqual('8100000063521237');
    expect(wiselyAccount.routingNumber).toEqual('071922476');
    expect(wiselyAccount.status).toEqual(WiselyAccountStatus.DONOTSHOW);
    expect(wiselyAccount.wiselyErrorMessage).toEqual('myadp-pay.DD_WISELY_DIRECT_ALERT_LIMITED');
  }));

  it('should treat Pay users with limited the same as active', fakeAsync(async () => {
    const wiselyCall = wiselyAccountService.getWiselyAccount();
    flush();
    const apiCall = httpClient.expectOne('/payroll/v1/paycard/cardholders/1234');

    mock.cardholders[0].cards[0].cardStatusCode.codeValue = 'limited';

    apiCall.flush(mock);

    const wiselyAccount = await wiselyCall;

    expect(wiselyAccount.isWiselyDirect).toBeFalse();
    expect(wiselyAccount.accountNumber).toEqual('8100000063521237');
    expect(wiselyAccount.routingNumber).toEqual('071922476');
    expect(wiselyAccount.status).toEqual(WiselyAccountStatus.UNCREATED);
  }));

  it('should set up a stolen state', fakeAsync(async () => {
    const wiselyCall = wiselyAccountService.getWiselyAccount();
    flush();
    const apiCall = httpClient.expectOne('/payroll/v1/paycard/cardholders/1234');

    apiCall.flush(mock);

    const wiselyAccount = await wiselyCall;

    expect(wiselyAccount.status).toEqual(WiselyAccountStatus.STOLEN);
  }));

  it('should set up a max out state', fakeAsync(async () => {
    directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS, {
      data: [
        {
          isWisely: true,
          currentData: null,
          pendingData: {
            precedence: '1',
            accountTypeName: 'Checking 1',
            accountNumber: 'X123456P7',
            routingNumber: '021000021',
            flatAmount: { amountValue: 123, currencyCode: 'USD' },
            codeValueData: {
              shortName: 'ckg1',
              longName: 'Checking 1',
              accountCode: 'C'
            }
          }
        }
      ]
    });

    const wiselyCall = wiselyAccountService.getWiselyAccount(true);
    flush();
    const apiCall = httpClient.expectOne('/payroll/v1/paycard/cardholders/1234');
    delete mock.cardholders[0].cards[0].cardStatusCode;
    apiCall.flush(mock);

    const wiselyAccount = await wiselyCall;

    expect(wiselyAccount.status).toEqual(WiselyAccountStatus.MAX);
  }));

  it('should set up an inactive state', fakeAsync(async () => {
    const wiselyCall = wiselyAccountService.getWiselyAccount();
    flush();
    const apiCall = httpClient.expectOne('/payroll/v1/paycard/cardholders/1234');

    mock.cardholders[0].cards[0].pinSet = false;
    delete mock.cardholders[0].cards[0].cardStatusCode;
    apiCall.flush(mock);

    const wiselyAccount = await wiselyCall;

    expect(wiselyAccount.status).toEqual(WiselyAccountStatus.INACTIVE);
  }));

  it('should set state to unenrolled when api returns 404 and organizationProfile call yields false', fakeAsync(async () => {
    const wiselyCall = wiselyAccountService.getWiselyAccount();
    flush();
    const apiCall = httpClient.expectOne('/payroll/v1/paycard/cardholders/1234');

    apiCall.flush({}, { status: 404, statusText: 'nt' });

    flush();
    const orgProfileCall = httpClient.expectOne(
      '/money-management/v1/paycard/organization-profiles'
    );

    orgProfileCall.flush({
      organizationProfiles: [
        {
          profileSettings: {
            allowSelfEnrollment: 'false'
          }
        }
      ]
    });

    const wiselyAccount = await wiselyCall;

    expect(wiselyAccount.status).toEqual(WiselyAccountStatus.UNENROLLED);
  }));

  it('should set state to selfenroll when api returns 404 and organizationProfile call yields true', fakeAsync(async () => {
    const wiselyCall = wiselyAccountService.getWiselyAccount();
    flush();
    const apiCall = httpClient.expectOne('/payroll/v1/paycard/cardholders/1234');

    apiCall.flush({}, { status: 404, statusText: 'n/a' });

    flush();
    const orgProfileCall = httpClient.expectOne(
      '/money-management/v1/paycard/organization-profiles'
    );

    orgProfileCall.flush({
      organizationProfiles: [
        {
          profileSettings: {
            allowSelfEnrollment: 'yes'
          }
        }
      ]
    });

    const wiselyAccount = await wiselyCall;

    expect(wiselyAccount.status).toEqual(WiselyAccountStatus.SELFENROLL);
  }));

  it('should set state to selfenroll when api returns 404 and the user is a Wisely Direct account', fakeAsync(async () => {
    Mock.extend(userProfileService).with({
      hasD2E: of(true)
    });

    const wiselyCall = wiselyAccountService.getWiselyAccount();
    flush();
    const apiCall = httpClient.expectOne('/payroll/v1/paycard/cardholders/1234');

    apiCall.flush({}, { status: 404, statusText: 'n/a' });

    flush();

    httpClient.expectNone('/money-management/v1/paycard/organization-profiles');

    const wiselyAccount = await wiselyCall;

    expect(wiselyAccount.status).toEqual(WiselyAccountStatus.SELFENROLL);
  }));
});
