export interface HelpItem {
  helpItemKey: string;
  helpItemTitleKey?: string;
  helpLinkKey?: string;
  helpLinkUrl?: string;
  helpLinkIcon?: string;
  helpLearnMoreUrl?: string;
}

export interface FormItem {
  id: string; // FormControl name
  label?: string;
  helpText?: string; // sub-labels
  type?: string;
  list?: ListItem[];
  pattern?: string; // input whitelist/blacklist
  instructions?: string; // tooltips
  tags?: string[];

  // Differs from VanG
  content?: ContentItem[];
  link?: LinkItem;
}

export interface ContentItem {
  textItem?: TextItem;
  linkItem?: LinkItem;
  tooltipItem?: TooltipItem;
}

export interface TextItem {
  key: string;
  metaData?: Record<string, string>;
}

export interface LinkItem {
  key: string;
  url: string;
  icon?: string;
  metaData?: Record<string, string>;
}

export interface TooltipItem {
  key: string;
  title?: string;
  link?: LinkItem;
  ariaLabel?: string;
  metaData?: Record<string, string>;
}

export interface ListItem {
  label: string;
  value?: string | boolean | number;
  helpText?: string; // sub-labels
  instructions?: HelpItem | string; // tooltips
  disabled?: boolean;
  required?: boolean;
  metaData?: Record<string, string>;
}
