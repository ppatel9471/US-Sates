import { Injectable } from '@angular/core';
import { LoggerFactory } from '@espresso/core';
import { Logger } from 'log4javascript';
import * as moment from 'moment';
import { EMPTY } from 'rxjs';
import { catchError, finalize, take, tap } from 'rxjs/operators';

import { UserProfileService } from '@myadp/common';
import {
  PayrollWorker,
  PayrollWorkerWorkAssignment,
  WorkAssignment,
  Worker,
  WorkerDates
} from '@myadp/dto';

import { PayrollWorkerProfileService } from '../../../services/payroll-worker-profile.service';
import { EMPTY_WORKER_INFO_STORE, WorkerInfoStoreSlice } from '../models/worker-info-state.model';
import { ValidateReason, WorkerInfo } from '../models/worker-info.model';
import { WorkerInfoStore } from './worker-info.store';

@Injectable({
  providedIn: 'root'
})
export class WorkerInfoStoreActions {
  private logger: Logger;

  constructor(
    private payrollWorkerProfileService: PayrollWorkerProfileService,
    private workerInfoStore: WorkerInfoStore,
    private loggerFactory: LoggerFactory,
    private userProfileService: UserProfileService
  ) {
    this.logger = this.loggerFactory.getLogger(
      'pay.modules.tax-withholding-management.shared.store.WorkerInfoStoreActions'
    );
  }

  public getWorker(bustCache: boolean = false): void {
    const currentWorker = this.workerInfoStore.stateValue[WorkerInfoStoreSlice.WORKER]?.data;
    // No reason to bust cache for Payroll Worker since the user can't modify their data
    const shouldBustCache = bustCache && this.userProfileService.hasWorkerProfile();

    if (!currentWorker || shouldBustCache) {
      this.clearCache();
      this.workerInfoStore.update(WorkerInfoStoreSlice.WORKER, {
        loading: true
      });

      this.payrollWorkerProfileService
        .getWorker(bustCache)
        .then((worker: Worker | PayrollWorker) => {
          this.workerInfoStore.update(WorkerInfoStoreSlice.WORKER_INFO, {
            data: this.transformWorkerInfo(worker)
          });
          this.workerInfoStore.update(WorkerInfoStoreSlice.WORKER, {
            data: worker
          });
          this.workerInfoStore.update(WorkerInfoStoreSlice.WORKER_WORK_ASSIGNMENTS, {
            data: (worker as Worker)?.workAssignments || (worker as PayrollWorker)?.workAssignment
          });
          this.workerInfoStore.update(WorkerInfoStoreSlice.WORKER_DATES, {
            data: worker?.workerDates
          });
        })
        .catch((error) => {
          this.workerInfoStore.update(WorkerInfoStoreSlice.WORKER, {
            error: {
              loadWorkerError: true,
              info: error
            }
          });
          this.logger.error('getWorker', error);
        })
        .finally(() => {
          this.workerInfoStore.update(WorkerInfoStoreSlice.WORKER, {
            loading: false
          });
        });
    }
  }

  public unmaskSsn(): void {
    if (!this.workerInfoStore.stateValue[WorkerInfoStoreSlice.WORKER_SSN]?.data) {
      this.workerInfoStore.update(WorkerInfoStoreSlice.WORKER_SSN, {
        loading: true,
        error: null
      });

      this.payrollWorkerProfileService
        .getUnmaskedDataFromWorker$(WorkerInfoStoreSlice.WORKER_SSN)
        .pipe(
          tap((worker: Worker) => {
            this.updateSSN(worker);
            if (this.userProfileService.isRun()) {
              this.updateBirthDate(worker);
            }
          }),
          take(1),
          catchError((error) => {
            this.workerInfoStore.update(WorkerInfoStoreSlice.WORKER_SSN, {
              error: {
                loadWorkerSsnError: true,
                info: error
              }
            });
            return EMPTY;
          }),
          finalize(() => {
            this.workerInfoStore.update(WorkerInfoStoreSlice.WORKER_SSN, {
              loading: false
            });
          })
        )
        .subscribe();
    }
  }

  public async getPayrollGroupCode(): Promise<string> {
    const workAssignments = await this.getWorkAssignments();
    return (
      workAssignments?.[0]?.payrollGroupCode ||
      (workAssignments as PayrollWorkerWorkAssignment)?.payrollGroupCode?.codeValue
    );
  }

  public unmaskBirthDate(): void {
    if (!this.workerInfoStore.stateValue[WorkerInfoStoreSlice.WORKER_BIRTHDATE]?.data) {
      this.workerInfoStore.update(WorkerInfoStoreSlice.WORKER_BIRTHDATE, {
        loading: true,
        error: null
      });

      this.payrollWorkerProfileService
        .getUnmaskedDataFromWorker$(WorkerInfoStoreSlice.WORKER_BIRTHDATE)
        .pipe(
          tap((worker: Worker) => {
            this.updateBirthDate(worker);
            if (this.userProfileService.isRun()) {
              this.updateSSN(worker);
            }
          }),
          take(1),
          catchError((error) => {
            this.workerInfoStore.update(WorkerInfoStoreSlice.WORKER_BIRTHDATE, {
              error: {
                loadWorkerBirthDateError: true,
                info: error
              }
            });
            return EMPTY;
          }),
          finalize(() => {
            this.workerInfoStore.update(WorkerInfoStoreSlice.WORKER_BIRTHDATE, {
              loading: false
            });
          })
        )
        .subscribe();
    }
  }

  public async getWorkedInState(): Promise<string> {
    return await this.payrollWorkerProfileService.getWorkedInState();
  }

  public getWorkAssignments(
    bustCache: boolean = false
  ): Promise<WorkAssignment[] | PayrollWorkerWorkAssignment> {
    return new Promise((resolve) => {
      const currentWorkAssignments =
        this.workerInfoStore.stateValue[WorkerInfoStoreSlice.WORKER_WORK_ASSIGNMENTS]?.data;

      if (!currentWorkAssignments || bustCache) {
        this.workerInfoStore.update(WorkerInfoStoreSlice.WORKER_WORK_ASSIGNMENTS, {
          loading: true,
          error: null
        });

        this.payrollWorkerProfileService
          .getWorkAssignmentsFromWorker()
          .then((worker: Worker | PayrollWorker) => {
            this.workerInfoStore.update(WorkerInfoStoreSlice.WORKER_WORK_ASSIGNMENTS, {
              data: (worker as Worker)?.workAssignments || (worker as PayrollWorker)?.workAssignment
            });
          })
          .catch((error) => {
            this.workerInfoStore.update(WorkerInfoStoreSlice.WORKER_WORK_ASSIGNMENTS, {
              error: {
                loadWorkAssignmentsError: true,
                info: error
              }
            });
            this.logger.error('getWorkAssignment', error);
          })
          .finally(() => {
            this.workerInfoStore.update(WorkerInfoStoreSlice.WORKER_WORK_ASSIGNMENTS, {
              loading: false
            });

            // regardless of successful or fail resolve the promise with current value in store
            resolve(
              this.workerInfoStore.stateValue[WorkerInfoStoreSlice.WORKER_WORK_ASSIGNMENTS]?.data
            );
          });
      } else {
        resolve(currentWorkAssignments);
      }
    });
  }

  public async getWorkerDates(bustCache: boolean = false): Promise<WorkerDates> {
    return new Promise((resolve) => {
      const currentWorkerDates =
        this.workerInfoStore.stateValue[WorkerInfoStoreSlice.WORKER_DATES]?.data;

      if (!currentWorkerDates || bustCache) {
        this.workerInfoStore.update(WorkerInfoStoreSlice.WORKER_DATES, {
          loading: true,
          error: null
        });

        this.payrollWorkerProfileService
          .getWorkerDatesFromWorker()
          .then((worker: Worker) => {
            this.workerInfoStore.update(WorkerInfoStoreSlice.WORKER_DATES, {
              data: worker?.workerDates
            });
          })
          .catch((error) => {
            this.workerInfoStore.update(WorkerInfoStoreSlice.WORKER_DATES, {
              error: {
                loadWorkerDatesError: true,
                info: error
              }
            });
            this.logger.error('getWorkerDates', error);
          })
          .finally(() => {
            this.workerInfoStore.update(WorkerInfoStoreSlice.WORKER_DATES, {
              loading: false
            });

            // regardless of successful or fail resolve the promise with current value in store
            resolve(this.workerInfoStore.stateValue[WorkerInfoStoreSlice.WORKER_DATES]?.data);
          });
      } else {
        resolve(currentWorkerDates);
      }
    });
  }

  public async getEffectiveDate(): Promise<string> {
    const workerDates = await this.getWorkerDates();
    const { rehireDate, adjustedServiceDate, originalHireDate } = workerDates || {};
    const hireDate: string = rehireDate || adjustedServiceDate || originalHireDate;
    const isFutureHire: boolean = moment(hireDate).isAfter(moment());
    // TODO: do we want to format the worker dates? - effectiveDate=2021-06-07T00:00:00Z
    return Promise.resolve(isFutureHire ? hireDate : moment().format('YYYY-MM-DD'));
  }

  public clearCache(): void {
    this.workerInfoStore.set(EMPTY_WORKER_INFO_STORE);
  }

  private updateSSN(worker: Worker): void {
    let [ssn, formattedSSN]: [string, string] = this.getSSN(worker);
    const ssnFormat = /^\d{3}-?\d{2}-?\d{4}$/;
    const isValid = ssnFormat.test(ssn);
    const isUnmask = /X|\*/.test(ssn);
    let validateReason: ValidateReason;
    // If the SSN has format issue and it also includes X or *, we will only display unmask error
    if (ssn) {
      if (isUnmask) {
        validateReason = 'unmask';
      } else if (!isValid) {
        validateReason = 'format';
      }
    } else {
      formattedSSN = 'MISSING';
      validateReason = 'empty';
    }

    if (
      worker?.person?.governmentIDs?.find((govId) => govId?.idValue === ssn)?.statusCode
        ?.codeValue === 'APPLIED' &&
      isValid
    ) {
      formattedSSN = 'APPLIED FOR';
    }

    this.workerInfoStore.update(WorkerInfoStoreSlice.WORKER_SSN, {
      data: {
        ssn,
        formattedSSN,
        isValid,
        validateReason
      }
    });
  }
  private updateBirthDate(worker: Worker): void {
    const birthDate: string = worker?.person?.birthDate;

    this.workerInfoStore.update(WorkerInfoStoreSlice.WORKER_INFO, {
      data: { birthDate: birthDate }
    });
    this.workerInfoStore.update(WorkerInfoStoreSlice.WORKER_BIRTHDATE, {
      data: birthDate
    });
  }

  private transformWorkerInfo(worker: Worker): WorkerInfo {
    return <WorkerInfo>{
      legalName: worker?.person?.legalName,
      legalAddress: worker?.person?.legalAddress,
      birthDate: worker?.person?.birthDate,
      associateOID: worker?.associateOID
    };
  }

  // returns a tuple of [ssn, formattedSSN]
  private getSSN(worker: Worker): [string, string] {
    const ssn =
      worker?.person?.governmentIDs?.[0]?.idValue ??
      worker?.person?.governmentIDs?.find((govId) => govId?.itemID === 'SSN')?.idValue;

    return [ssn, this.formatSSN(ssn)];
  }

  private formatSSN(ssn: string): string {
    return ssn?.includes('*')
      ? ssn?.replace(/(\d{3}|\*{3})(\d{2}|\*{2})(\d{4})/, '$1-$2-$3')
      : ssn?.replace(/(\d{3}|X{3})(\d{2}|X{2})(\d{4})/, '$1-$2-$3');
  }
}
