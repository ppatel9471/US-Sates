import { Pipe, PipeTransform } from '@angular/core';

import { Amount } from '@myadp/dto';

import { PayStatementsUI } from '../../pay-statements-shared/models/pay-statement-ui';

@Pipe({ name: 'earningsDataSelector', pure: true })
export class EarningsDataSelectorPipe implements PipeTransform {
  public transform(earnings: PayStatementsUI.Earning[]): Array<{
    columns: {
      label: string;
      value: string | number | Amount;
    }[];
  }> {
    return earnings?.map((earning: PayStatementsUI.Earning, index: number) => {
      const isFirstRow = index === 0;
      const hours = earning?.payPeriodHours;
      const rate = earning?.rate;
      const rateValue = rate?.amountValue;
      const amount = earning?.amount;

      return {
        columns: [
          {
            // only add labels to the first row
            label: isFirstRow ? 'myadp-pay.PAY_EARNINGS_TYPE' : '',
            value: earning?.name
          },
          {
            label: isFirstRow ? 'myadp-pay.PAY_EARNINGS_UNITS' : '',
            value: hours
          },
          {
            label: isFirstRow ? 'myadp-pay.PAY_EARNINGS_RATE' : '',
            value: rate
          },
          {
            label: isFirstRow ? 'myadp-pay.PAY_EARNINGS_AMOUNT' : '',
            value: rateValue ? amount : !!rateValue && !!amount?.amountValue ? null : amount
          }
        ]
      };
    });
  }
}
