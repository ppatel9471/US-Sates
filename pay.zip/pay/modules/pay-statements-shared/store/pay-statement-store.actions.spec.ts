import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { fakeAsync, flush, TestBed } from '@angular/core/testing';
import { LoggerFactory } from '@espresso/core';
import {
  BreakpointMatches,
  BreakpointService,
  ClientDeviceService
} from '@synerg/components/shared';
import { from, of } from 'rxjs';
import { Mock } from 'ts-mockery';

import { BaseHttpClient, LanguageService, UserProfileService } from '@myadp/common';
import { PayrollWorker, PayStatementsDTO, Worker } from '@myadp/dto';
import { FindSffoService } from '@myadp/pay-shared';
import { PaymentCalculationAnalysis } from '@myadp/pay/models/payment-calculation-analysis.model';
import { MockLoggerFactory } from '@specHelpers';

import {
  MOCK_PAY_STATEMENT_DETAILS_RESPONSE,
  MOCK_TRANSFORMED_PAY_STATEMENT_DETAILS_RESPONSE_SLICE
} from '../../../../../../src/spec-helpers/pay/pay-statement/pay-statement-details';
import {
  MOCK_PAY_STATEMENTS_RESPONSE,
  MOCK_TRANSFORMED_PAY_STATEMENTS,
  MOCK_TRANSFORMED_PAY_STATEMENTS_PDFS
} from '../../../../../../src/spec-helpers/pay/pay-statement/pay-statements';
import { TransparencyService } from '../../../services/transparency.service';
import { WorkerInfoStoreActions } from '../../worker-info-shared/store/worker-info-store.actions';
import { WorkerInfoStore } from '../../worker-info-shared/store/worker-info.store';
import { PayStatementsStoreSlice, PayStatementsUI } from '../models/pay-statement-ui';
import { PayStatementStoreActions } from './pay-statement-store.actions';
import { PayStatementStore } from './pay-statement.store';

const sffo = {
  sffo: {
    sffo: [
      'payrollManagement',
      'payStatementManagement',
      'payStatementViewing',
      'payStatement.read'
    ]
  },
  href: 'foo'
};

const mockWorker: Partial<Worker> = {
  workAssignments: [
    {
      payCycleCode: {
        codeValue: '2',
        longName: 'Biweekly'
      },
      baseRemuneration: {
        payPeriodRateAmount: {
          nameCode: {
            codeValue: '1',
            longName: 'Hourly'
          },
          amountValue: 11.76,
          currencyCode: 'USD'
        }
      },
      assignedWorkLocations: [
        {
          nameCode: { codeValue: 'something' },
          address: {
            countryCode: 'US'
          }
        }
      ]
    }
  ]
};

const mockPayrollWorker: Partial<PayrollWorker> = {
  workAssignment: {
    payrollGroupCode: {
      codeValue: 'abc'
    },
    payCycleCode: {
      codeValue: '2',
      longName: 'Biweekly'
    },
    baseRemuneration: {
      payPeriodRateAmount: {
        nameCode: {
          codeValue: '1',
          longName: 'Hourly'
        },
        amountValue: 11.76,
        currencyCode: 'USD'
      }
    },
    assignedWorkLocations: [
      {
        nameCode: { codeValue: 'something' },
        address: {
          countryCode: 'US'
        }
      }
    ]
  }
};

const workerPayInfo: PayStatementsUI.WorkerPayInfo = {
  rate: {
    nameCode: { codeValue: '1', longName: 'Hourly' },
    amountValue: 11.76,
    currencyCode: 'USD'
  },
  frequency: 'Biweekly'
};

const transformedStatements = MOCK_TRANSFORMED_PAY_STATEMENTS;

const mockStatementDetails = {
  payDate: 'Feb 13, 2020',
  grossPay: { amountValue: 1500, currencyCode: 'USD' }
};

const breakpoints: BreakpointMatches = {
  xs: false,
  sm: false,
  md: false,
  lg: false,
  xl: false,
  xxl: false
};

describe('PayStatementStoreActions', () => {
  let payStatementStoreActions: PayStatementStoreActions;
  let payStatementStore: PayStatementStore;
  let baseHttpClient: BaseHttpClient;
  let httpClient: HttpClient;
  let findSffoService: FindSffoService;
  let workerInfoStore: WorkerInfoStore;
  let workerInfoStoreActions: WorkerInfoStoreActions;
  let transparencyService: TransparencyService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        PayStatementStore,
        PayStatementStoreActions,
        {
          provide: BaseHttpClient,
          useValue: Mock.of<BaseHttpClient>({
            get: () => Promise.resolve<PayStatementsDTO.APIResponse>(MOCK_PAY_STATEMENTS_RESPONSE)
          })
        },
        {
          provide: HttpClient,
          useValue: Mock.of<HttpClient>({
            get: () => of(MOCK_PAY_STATEMENT_DETAILS_RESPONSE)
          })
        },
        {
          provide: FindSffoService,
          useValue: Mock.of<FindSffoService>({
            findSffo: () => sffo
          })
        },
        {
          provide: UserProfileService,
          useValue: Mock.of<UserProfileService>({
            getApplicationId: () => 'ADP'
          })
        },
        {
          provide: WorkerInfoStore,
          useValue: Mock.of<WorkerInfoStore>({
            worker$: () => of(mockWorker),
            workerError$: () => of(false)
          })
        },
        {
          provide: WorkerInfoStoreActions,
          useValue: Mock.of<WorkerInfoStoreActions>({
            getWorker: () => Mock.noop()
          })
        },
        {
          provide: LanguageService,
          useValue: Mock.of<LanguageService>({ get: (key) => key })
        },
        { provide: LoggerFactory, useClass: MockLoggerFactory },
        {
          provide: TransparencyService,
          useValue: Mock.of<TransparencyService>({
            hasTransparency: () => Promise.resolve(false)
          })
        },
        {
          provide: BreakpointService,
          useValue: Mock.of<BreakpointService>({
            matches$: of(breakpoints)
          })
        },
        {
          provide: ClientDeviceService,
          useValue: Mock.of<ClientDeviceService>({
            isNative: () => false,
            isMobile: () => false
          })
        }
      ]
    });

    payStatementStore = TestBed.inject(PayStatementStore);
    payStatementStoreActions = TestBed.inject(PayStatementStoreActions);
    baseHttpClient = TestBed.inject(BaseHttpClient);
    httpClient = TestBed.inject(HttpClient);
    findSffoService = TestBed.inject(FindSffoService);
    workerInfoStore = TestBed.inject(WorkerInfoStore);
    workerInfoStoreActions = TestBed.inject(WorkerInfoStoreActions);
    transparencyService = TestBed.inject(TransparencyService);
  });

  it('should get notification permissions when initializing', fakeAsync(() => {
    expect(findSffoService.findSffo).toHaveBeenCalledTimes(1);
  }));

  it('should get transform config', () => {
    expect(payStatementStoreActions.getTransformConfig()).toEqual({
      SOR: 'ADP',
      TRANSLATIONS: {
        UNKNOWN_DATE: 'myadp-pay.PAY_UNKNOWN_DATE',
        ADJUSTMENT: 'myadp-pay.PAY_ADJUSTMENT'
      }
    });
  });

  describe('loadPayStatements()', () => {
    it('should an make API call to get pay statements and update the store', fakeAsync(() => {
      Mock.extend(baseHttpClient).with({
        get: () => Promise.resolve<PayStatementsDTO.APIResponse>(MOCK_PAY_STATEMENTS_RESPONSE)
      });

      payStatementStoreActions.loadPayStatements();
      flush();

      expect(baseHttpClient.get).toHaveBeenCalled();
      const statementData: PayStatementsUI.PayStatementDetailsState = {
        statement: {
          id: 1,
          payDate: 'Apr 6, 2019',
          netPay: { amountValue: 771.95, currencyCode: 'USD' },
          grossPay: { amountValue: 1744.1, currencyCode: 'USD' },
          totalHours: 80,
          payDetailUri: '/v1_0/O/A/payStatement/1074162519254260000198001043941',
          statementImageUri:
            '/l2/v1_0/O/A/payStatement/1074162519254260000198001043941/images/CERooo008000520000r7013E3AE9EFC521.pdf',
          payAdjustment: false,
          statementFiscalYear: '2019',
          statementType: null
        },
        statementDetails: MOCK_TRANSFORMED_PAY_STATEMENT_DETAILS_RESPONSE_SLICE,
        id: 1,
        payDetailUri: '/v1_0/O/A/payStatement/1074162519254260000198001043941',
        statementImageUri:
          '/l2/v1_0/O/A/payStatement/1074162519254260000198001043941/images/CERooo008000520000r7013E3AE9EFC521.pdf',
        statementFiscalYear: '2019'
      };

      expect(payStatementStore.stateValue).toEqual({
        [PayStatementsStoreSlice.PAY_STATEMENTS]: {
          data: {
            statements: transformedStatements,
            statementsForPdfViewer: MOCK_TRANSFORMED_PAY_STATEMENTS_PDFS,
            workerPayInfo: null,
            hasNotificationPermission: true
          },
          loading: false,
          error: {}
        },
        [PayStatementsStoreSlice.CURRENT_STATEMENT_DETAILS]: {
          data: statementData,
          loading: false,
          error: {
            detailsError: false
          }
        },
        [PayStatementsStoreSlice.STATEMENT_DETAILS_CACHE]: {
          data: { 1: statementData },
          loading: false,
          error: {
            1: { detailsError: false }
          }
        },
        [PayStatementsStoreSlice.CURRENT_PAYMENT_CALCULATION_ANALYSIS]: {
          data: null,
          loading: false,
          error: {}
        },
        [PayStatementsStoreSlice.PAYMENT_CALCULATION_ANALYSIS_CACHE]: {
          data: {},
          loading: false,
          error: {}
        }
      });
    }));

    it('should handle errors and updating the store when loading pay statements', fakeAsync(() => {
      Mock.extend(baseHttpClient).with({
        get: () => Promise.reject({ message: 'failed' })
      });
      payStatementStoreActions.loadPayStatements();
      flush();

      expect(baseHttpClient.get).toHaveBeenCalled();
      expect(workerInfoStoreActions.getWorker).toHaveBeenCalledTimes(1);
      expect(payStatementStore.stateValue).toEqual({
        [PayStatementsStoreSlice.PAY_STATEMENTS]: {
          data: {
            statements: [],
            statementsForPdfViewer: [],
            workerPayInfo,
            hasNotificationPermission: true
          },
          loading: false,
          error: {
            statementsError: true
          }
        },
        [PayStatementsStoreSlice.CURRENT_STATEMENT_DETAILS]: {
          data: { statement: {} },
          loading: false,
          error: {
            statementsError: true
          }
        },
        [PayStatementsStoreSlice.STATEMENT_DETAILS_CACHE]: {
          data: {},
          loading: false,
          error: {}
        },
        [PayStatementsStoreSlice.CURRENT_PAYMENT_CALCULATION_ANALYSIS]: {
          data: null,
          loading: false,
          error: {}
        },
        [PayStatementsStoreSlice.PAYMENT_CALCULATION_ANALYSIS_CACHE]: {
          data: {},
          loading: false,
          error: {}
        }
      });
    }));

    it('should handle workerPayInfo and updating the store when no pay statement', fakeAsync(() => {
      Mock.extend(baseHttpClient).with({
        get: () => Promise.resolve<PayStatementsDTO.APIResponse>({ payStatements: [] })
      });
      payStatementStoreActions.loadPayStatements();
      flush();

      expect(workerInfoStoreActions.getWorker).toHaveBeenCalledTimes(1);
      expect(payStatementStore.stateValue).toEqual({
        [PayStatementsStoreSlice.PAY_STATEMENTS]: {
          data: {
            statements: [],
            statementsForPdfViewer: [],
            workerPayInfo,
            hasNotificationPermission: true
          },
          loading: false,
          error: {
            statementsError: true
          }
        },
        [PayStatementsStoreSlice.CURRENT_STATEMENT_DETAILS]: {
          data: { statement: {} },
          loading: false,
          error: {
            statementsError: true
          }
        },
        [PayStatementsStoreSlice.STATEMENT_DETAILS_CACHE]: {
          data: {},
          loading: false,
          error: {}
        },
        [PayStatementsStoreSlice.CURRENT_PAYMENT_CALCULATION_ANALYSIS]: {
          data: null,
          loading: false,
          error: {}
        },
        [PayStatementsStoreSlice.PAYMENT_CALCULATION_ANALYSIS_CACHE]: {
          data: {},
          loading: false,
          error: {}
        }
      });
    }));

    it('should handle PayrollWorker workerPayInfo and updating the store when no pay statement', fakeAsync(() => {
      Mock.extend(baseHttpClient).with({
        get: () => Promise.resolve<PayStatementsDTO.APIResponse>({ payStatements: [] })
      });

      Mock.extend(workerInfoStore).with({
        worker$: () => of(mockPayrollWorker)
      });

      payStatementStoreActions.loadPayStatements();
      flush();

      expect(workerInfoStoreActions.getWorker).toHaveBeenCalledTimes(1);
      expect(payStatementStore.stateValue).toEqual({
        [PayStatementsStoreSlice.PAY_STATEMENTS]: {
          data: {
            statements: [],
            statementsForPdfViewer: [],
            workerPayInfo,
            hasNotificationPermission: true
          },
          loading: false,
          error: {
            statementsError: true
          }
        },
        [PayStatementsStoreSlice.CURRENT_STATEMENT_DETAILS]: {
          data: { statement: {} },
          loading: false,
          error: {
            statementsError: true
          }
        },
        [PayStatementsStoreSlice.STATEMENT_DETAILS_CACHE]: {
          data: {},
          loading: false,
          error: {}
        },
        [PayStatementsStoreSlice.CURRENT_PAYMENT_CALCULATION_ANALYSIS]: {
          data: null,
          loading: false,
          error: {}
        },
        [PayStatementsStoreSlice.PAYMENT_CALCULATION_ANALYSIS_CACHE]: {
          data: {},
          loading: false,
          error: {}
        }
      });
    }));

    it('should handle updating workerPayInfo with annual rate and frequency when no pay statement', fakeAsync(() => {
      Mock.extend(baseHttpClient).with({
        get: () => Promise.resolve<PayStatementsDTO.APIResponse>({ payStatements: [] })
      });

      Mock.extend(workerInfoStore).with({
        worker$: () =>
          of({
            workAssignment: {
              payrollGroupCode: {
                codeValue: 'abc'
              },
              payCycleCode: {
                codeValue: '4',
                shortName: 'Monthly'
              },
              baseRemuneration: {
                annualRateAmount: {
                  nameCode: {
                    codeValue: '6',
                    longName: 'Annual'
                  },
                  amountValue: 75600,
                  currencyCode: 'USD'
                }
              },
              assignedWorkLocations: [
                {
                  nameCode: { codeValue: 'something' },
                  address: {
                    countryCode: 'US'
                  }
                }
              ]
            }
          } as Partial<PayrollWorker>)
      });

      payStatementStoreActions.loadPayStatements();
      flush();

      expect(workerInfoStoreActions.getWorker).toHaveBeenCalledTimes(1);
      expect(payStatementStore.stateValue[PayStatementsStoreSlice.PAY_STATEMENTS]).toEqual({
        data: {
          statements: [],
          statementsForPdfViewer: [],
          workerPayInfo: {
            rate: {
              nameCode: { codeValue: '6', longName: 'Annual' },
              amountValue: 75600,
              currencyCode: 'USD'
            },
            frequency: 'Monthly'
          },
          hasNotificationPermission: true
        },
        loading: false,
        error: {
          statementsError: true
        }
      });
    }));

    it('should handle updating workerPayInfo with hourly rate and frequency when no pay statement', fakeAsync(() => {
      Mock.extend(baseHttpClient).with({
        get: () => Promise.resolve<PayStatementsDTO.APIResponse>({ payStatements: [] })
      });

      Mock.extend(workerInfoStore).with({
        worker$: () =>
          of({
            workAssignment: {
              payrollGroupCode: {
                codeValue: 'abc'
              },
              payCycleCode: {
                codeValue: '2',
                shortName: 'Biweekly'
              },
              baseRemuneration: {
                hourlyRateAmount: {
                  nameCode: {
                    codeValue: '2',
                    longName: 'Hourly'
                  },
                  amountValue: 21.5,
                  currencyCode: 'USD'
                }
              },
              assignedWorkLocations: [
                {
                  nameCode: { codeValue: 'something' },
                  address: {
                    countryCode: 'US'
                  }
                }
              ]
            }
          } as Partial<PayrollWorker>)
      });

      payStatementStoreActions.loadPayStatements();
      flush();

      expect(workerInfoStoreActions.getWorker).toHaveBeenCalledTimes(1);
      expect(payStatementStore.stateValue[PayStatementsStoreSlice.PAY_STATEMENTS]).toEqual({
        data: {
          statements: [],
          statementsForPdfViewer: [],
          workerPayInfo: {
            rate: {
              nameCode: { codeValue: '2', longName: 'Hourly' },
              amountValue: 21.5,
              currencyCode: 'USD'
            },
            frequency: 'Biweekly'
          },
          hasNotificationPermission: true
        },
        loading: false,
        error: {
          statementsError: true
        }
      });
    }));

    it('should not make call to get statements if sffo not found', () => {
      Mock.extend(findSffoService).with({
        findSffo: () => {
          return {
            sffo: undefined,
            href: undefined
          };
        }
      });
      payStatementStoreActions.loadPayStatements();

      expect(httpClient.get).not.toHaveBeenCalled();
    });

    it('should not make call to get statements if sffo found but href is undefined', () => {
      Mock.extend(findSffoService).with({
        findSffo: () => {
          return {
            sffo: {
              sffo: [
                'payrollManagement',
                'payStatementManagement',
                'payStatementViewing',
                'payStatement.read'
              ]
            },
            href: undefined
          };
        }
      });
      payStatementStoreActions.loadPayStatements();

      expect(httpClient.get).not.toHaveBeenCalled();
    });
  });

  describe('loadStatementDetails()', () => {
    it('should make an API call to get statement details', fakeAsync(() => {
      payStatementStoreActions.loadStatementDetails(transformedStatements[0]);
      flush();

      expect(httpClient.get).toHaveBeenCalledTimes(1);

      const id = transformedStatements[0].id;
      const currentStatement =
        payStatementStore.stateValue[PayStatementsStoreSlice.CURRENT_STATEMENT_DETAILS]?.data;

      expect(Object.keys(currentStatement?.statementDetails)?.length).toBeGreaterThan(0);
      expect(
        payStatementStore.stateValue[PayStatementsStoreSlice.STATEMENT_DETAILS_CACHE]?.data[id]
      ).toEqual(currentStatement);
    }));

    it('should not make api call again when pay statement is in cache', fakeAsync(() => {
      payStatementStoreActions.loadStatementDetails(transformedStatements[0]);
      flush();
      // get statement 0 again
      payStatementStoreActions.loadStatementDetails(transformedStatements[0]);
      flush();
      // should only call api once
      expect(httpClient.get).toHaveBeenCalledTimes(1);

      const id = transformedStatements[0].id;
      const currentStatement =
        payStatementStore.stateValue[PayStatementsStoreSlice.CURRENT_STATEMENT_DETAILS]?.data;

      expect(Object.keys(currentStatement?.statementDetails)?.length).toBeGreaterThan(0);
      expect(
        payStatementStore.stateValue[PayStatementsStoreSlice.STATEMENT_DETAILS_CACHE]?.data[id]
      ).toEqual(currentStatement);
    }));

    it('should handle errors and updating the store when loading statement details', fakeAsync(() => {
      Mock.extend(httpClient).with({
        get: () => from(Promise.reject<HttpErrorResponse>({ message: 'details failed' }))
      });
      payStatementStoreActions.loadStatementDetails(transformedStatements[0]);
      flush();

      const stateValue =
        payStatementStore.stateValue[PayStatementsStoreSlice.CURRENT_STATEMENT_DETAILS];
      const cacheStateValue =
        payStatementStore.stateValue[PayStatementsStoreSlice.STATEMENT_DETAILS_CACHE];
      const id = transformedStatements[0].id;

      expect(httpClient.get).toHaveBeenCalled();
      expect(stateValue.data.statementDetails).toBeNull();
      expect(cacheStateValue.data[id].statementDetails).toBeNull();
      expect(stateValue.error.detailsError).toBe(true);
      expect(cacheStateValue.error[id].detailsError).toBe(true);
    }));

    it('should make api call again when statement detail has error', fakeAsync(() => {
      Mock.extend(httpClient).with({
        get: () => from(Promise.reject<HttpErrorResponse>({ message: 'details failed' }))
      });
      payStatementStoreActions.loadStatementDetails(transformedStatements[0]);
      flush();

      // handle error
      const stateValue =
        payStatementStore.stateValue[PayStatementsStoreSlice.CURRENT_STATEMENT_DETAILS];
      const cacheStateValue =
        payStatementStore.stateValue[PayStatementsStoreSlice.STATEMENT_DETAILS_CACHE];
      const id = transformedStatements[0].id;

      expect(httpClient.get).toHaveBeenCalled();
      expect(stateValue.data.statementDetails).toBeNull();
      expect(cacheStateValue.data[id].statementDetails).toBeNull();
      expect(stateValue.error.detailsError).toBe(true);
      expect(cacheStateValue.error[id].detailsError).toBe(true);

      // get statement 0 again, statementDetail has error, should make api call again
      Mock.extend(httpClient).with({
        get: () => of(MOCK_PAY_STATEMENT_DETAILS_RESPONSE)
      });
      payStatementStoreActions.loadStatementDetails(transformedStatements[0]);
      flush();

      expect(httpClient.get).toHaveBeenCalledTimes(1);

      const currentStatement =
        payStatementStore.stateValue[PayStatementsStoreSlice.CURRENT_STATEMENT_DETAILS]?.data;

      expect(Object.keys(currentStatement?.statementDetails)?.length).toBeGreaterThan(0);
      expect(
        payStatementStore.stateValue[PayStatementsStoreSlice.STATEMENT_DETAILS_CACHE]?.data[id]
      ).toEqual(currentStatement);
    }));
  });

  describe('resetCurrentStatement()', () => {
    it('should reset current statement', () => {
      payStatementStore.update(PayStatementsStoreSlice.PAY_STATEMENTS, {
        data: {
          statements: transformedStatements
        }
      });
      payStatementStoreActions.loadStatementDetails(transformedStatements[3]);

      const beforeId =
        payStatementStore.stateValue[PayStatementsStoreSlice.CURRENT_STATEMENT_DETAILS].data.id;

      expect(beforeId).toBe(4);

      payStatementStoreActions.resetCurrentStatement();
      const afterId =
        payStatementStore.stateValue[PayStatementsStoreSlice.CURRENT_STATEMENT_DETAILS].data.id;

      expect(afterId).toBe(1);
    });
  });

  describe('statement cache', () => {
    it('should get statement by id', async (done: DoneFn) => {
      payStatementStore.update(PayStatementsStoreSlice.STATEMENT_DETAILS_CACHE, {
        data: {
          1: {
            statement: transformedStatements[0],
            statementDetails: mockStatementDetails
          }
        }
      });
      payStatementStore.statementDetailsById$(1).subscribe((statementDetails) => {
        expect(statementDetails).toEqual(mockStatementDetails);
        done();
      });
    });

    it('should get statement error by id', async (done: DoneFn) => {
      payStatementStore.update(PayStatementsStoreSlice.STATEMENT_DETAILS_CACHE, {
        data: {
          1: { statement: transformedStatements[0], statementDetails: mockStatementDetails }
        },
        error: { 1: { detailsError: true } }
      });
      payStatementStore.statementDetailErrorById$(1).subscribe((error) => {
        expect(error).toBeTruthy();
        done();
      });
    });

    it('should get if the statement cache is loading', async (done: DoneFn) => {
      payStatementStore.update(PayStatementsStoreSlice.STATEMENT_DETAILS_CACHE, {
        loading: true
      });
      payStatementStore.isStatementCacheLoading$().subscribe((loading) => {
        expect(loading).toBeTruthy();
        done();
      });
    });
  });

  describe('loadTransparencyPaymentCalcAnalysis', () => {
    const MOCK_ANALYSIS: PaymentCalculationAnalysis = {
      associateOid: 'G3FSRWQC0Z551ZV6',
      paymentCalculationId: '1eace21b-faad-0d8c-adb7-dda1c8da2b25',
      payPeriodId: '2020-10',
      insights: [{ rank: 1, text: 'Mock Insight', tags: [] }],
      facts: []
    };

    const MOCK_ANALYSIS_NO_INSIGHTS: PaymentCalculationAnalysis = {
      associateOid: 'G3FSRWQC0Z551ZV6',
      paymentCalculationId: '1eace21b-faad-0d8c-adb7-dda1c8da2b26',
      payPeriodId: '2020-10',
      facts: []
    };

    it('should make an API call to get statement analysis', fakeAsync(() => {
      Mock.extend(transparencyService).with({
        hasTransparency: () => Promise.resolve<boolean>(true),
        getPaymentCalculationAnalysis: () =>
          Promise.resolve<PaymentCalculationAnalysis>(MOCK_ANALYSIS)
      });
      payStatementStoreActions.loadStatementDetails(transformedStatements[0]);
      flush();

      const id = transformedStatements[0].id;
      const currentAnalysis =
        payStatementStore.stateValue[PayStatementsStoreSlice.CURRENT_PAYMENT_CALCULATION_ANALYSIS]
          ?.data?.paymentCalcAnalysis;

      expect(transparencyService.getPaymentCalculationAnalysis).toHaveBeenCalledTimes(1);
      expect(currentAnalysis).toEqual(MOCK_ANALYSIS);
      expect(
        payStatementStore.stateValue[PayStatementsStoreSlice.PAYMENT_CALCULATION_ANALYSIS_CACHE]
          ?.data[id]?.paymentCalcAnalysis
      ).toEqual(currentAnalysis);
    }));

    it('should not make api call again when pay statement is in cache', fakeAsync(() => {
      Mock.extend(transparencyService).with({
        hasTransparency: () => Promise.resolve<boolean>(true),
        getPaymentCalculationAnalysis: () =>
          Promise.resolve<PaymentCalculationAnalysis>(MOCK_ANALYSIS)
      });

      payStatementStoreActions.loadStatementDetails(transformedStatements[0]);
      flush();
      // get statement 0 again
      payStatementStoreActions.loadStatementDetails(transformedStatements[0]);
      flush();

      const id = transformedStatements[0].id;
      const currentAnalysis =
        payStatementStore.stateValue[PayStatementsStoreSlice.CURRENT_PAYMENT_CALCULATION_ANALYSIS]
          ?.data?.paymentCalcAnalysis;

      expect(transparencyService.getPaymentCalculationAnalysis).toHaveBeenCalledTimes(1);
      expect(currentAnalysis).toEqual(MOCK_ANALYSIS);
      expect(
        payStatementStore.stateValue[PayStatementsStoreSlice.PAYMENT_CALCULATION_ANALYSIS_CACHE]
          ?.data[id]?.paymentCalcAnalysis
      ).toEqual(currentAnalysis);
    }));

    it('should update current analysis when a different payment is selected', fakeAsync(() => {
      Mock.extend(transparencyService).with({
        hasTransparency: () => Promise.resolve<boolean>(true),
        getPaymentCalculationAnalysis: () =>
          Promise.resolve<PaymentCalculationAnalysis>(MOCK_ANALYSIS)
      });
      payStatementStoreActions.loadStatementDetails(transformedStatements[0]);
      flush();

      let currentAnalysis =
        payStatementStore.stateValue[PayStatementsStoreSlice.CURRENT_PAYMENT_CALCULATION_ANALYSIS];

      expect(transparencyService.getPaymentCalculationAnalysis).toHaveBeenCalledTimes(1);
      expect(currentAnalysis?.data?.paymentCalcAnalysis).toEqual(MOCK_ANALYSIS);

      // get statement 0 again, statementDetail has error, should make api call again
      Mock.extend(transparencyService).with({
        getPaymentCalculationAnalysis: () =>
          Promise.resolve<PaymentCalculationAnalysis>(MOCK_ANALYSIS_NO_INSIGHTS)
      });
      payStatementStoreActions.loadStatementDetails(transformedStatements[2]);
      flush();

      currentAnalysis =
        payStatementStore.stateValue[PayStatementsStoreSlice.CURRENT_PAYMENT_CALCULATION_ANALYSIS];

      expect(transparencyService.getPaymentCalculationAnalysis).toHaveBeenCalledTimes(1);
      expect(currentAnalysis?.data?.paymentCalcAnalysis).toEqual(MOCK_ANALYSIS_NO_INSIGHTS);
    }));

    it('should update current analysis when a different payment is selected', fakeAsync(() => {
      Mock.extend(transparencyService).with({
        hasTransparency: () => Promise.resolve<boolean>(true),
        getPaymentCalculationAnalysis: () =>
          Promise.resolve<PaymentCalculationAnalysis>(MOCK_ANALYSIS)
      });
      payStatementStoreActions.loadStatementDetails(transformedStatements[0]);
      flush();

      let currentAnalysis =
        payStatementStore.stateValue[PayStatementsStoreSlice.CURRENT_PAYMENT_CALCULATION_ANALYSIS];

      expect(transparencyService.getPaymentCalculationAnalysis).toHaveBeenCalledTimes(1);
      expect(currentAnalysis?.data?.paymentCalcAnalysis).toEqual(MOCK_ANALYSIS);

      // get statement 0 again, statementDetail has error, should make api call again
      Mock.extend(transparencyService).with({
        getPaymentCalculationAnalysis: () =>
          Promise.resolve<PaymentCalculationAnalysis>(MOCK_ANALYSIS_NO_INSIGHTS)
      });
      payStatementStoreActions.loadStatementDetails(transformedStatements[2]);
      flush();

      currentAnalysis =
        payStatementStore.stateValue[PayStatementsStoreSlice.CURRENT_PAYMENT_CALCULATION_ANALYSIS];

      expect(transparencyService.getPaymentCalculationAnalysis).toHaveBeenCalledTimes(1);
      expect(currentAnalysis?.data?.paymentCalcAnalysis).toEqual(MOCK_ANALYSIS_NO_INSIGHTS);
    }));

    it('should handle errors and updating the store when api call fails', fakeAsync(() => {
      Mock.extend(transparencyService).with({
        hasTransparency: () => Promise.resolve<boolean>(true),
        getPaymentCalculationAnalysis: () => Promise.reject<PaymentCalculationAnalysis>('error')
      });
      payStatementStoreActions.loadStatementDetails(transformedStatements[0]);
      flush();

      const currentAnalysis =
        payStatementStore.stateValue[PayStatementsStoreSlice.CURRENT_PAYMENT_CALCULATION_ANALYSIS];
      const cachedAnalysis =
        payStatementStore.stateValue[PayStatementsStoreSlice.PAYMENT_CALCULATION_ANALYSIS_CACHE];
      const id = transformedStatements[0].id;

      expect(transparencyService.getPaymentCalculationAnalysis).toHaveBeenCalledTimes(1);
      expect(currentAnalysis.data).toBeNull();
      expect(cachedAnalysis.data[id]).toBeNull();
      expect(currentAnalysis.error.detailsError).toBe(true);
      expect(cachedAnalysis.error[id].detailsError).toBe(true);
    }));

    it('should make api call again when payment calc analysis api call fails', fakeAsync(() => {
      Mock.extend(transparencyService).with({
        hasTransparency: () => Promise.resolve<boolean>(true),
        getPaymentCalculationAnalysis: () => Promise.reject<PaymentCalculationAnalysis>('error')
      });
      payStatementStoreActions.loadStatementDetails(transformedStatements[0]);
      flush();

      // handle error
      let currentAnalysis =
        payStatementStore.stateValue[PayStatementsStoreSlice.CURRENT_PAYMENT_CALCULATION_ANALYSIS];
      const cachedAnalysis =
        payStatementStore.stateValue[PayStatementsStoreSlice.PAYMENT_CALCULATION_ANALYSIS_CACHE];
      const id = transformedStatements[0].id;

      expect(transparencyService.getPaymentCalculationAnalysis).toHaveBeenCalledTimes(1);
      expect(currentAnalysis.data).toBeNull();
      expect(cachedAnalysis.data[id]).toBeNull();
      expect(currentAnalysis.error.detailsError).toBe(true);
      expect(cachedAnalysis.error[id].detailsError).toBe(true);

      // get statement 0 again, statementDetail has error, should make api call again
      Mock.extend(transparencyService).with({
        getPaymentCalculationAnalysis: () =>
          Promise.resolve<PaymentCalculationAnalysis>(MOCK_ANALYSIS)
      });
      payStatementStoreActions.loadStatementDetails(transformedStatements[0]);
      flush();

      currentAnalysis =
        payStatementStore.stateValue[PayStatementsStoreSlice.CURRENT_PAYMENT_CALCULATION_ANALYSIS];

      expect(transparencyService.getPaymentCalculationAnalysis).toHaveBeenCalledTimes(1);
      expect(currentAnalysis?.data?.paymentCalcAnalysis).toEqual(MOCK_ANALYSIS);
      expect(
        payStatementStore.stateValue[PayStatementsStoreSlice.PAYMENT_CALCULATION_ANALYSIS_CACHE]
          ?.data[id]
      ).toEqual(currentAnalysis?.data);
    }));
  });
});
