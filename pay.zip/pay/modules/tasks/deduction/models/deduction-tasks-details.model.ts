import { DeductionsDTO } from '@myadp/dto';

export enum DEDUCTION_EVENT_TYPE {
  CHANGE = 'change',
  START = 'start',
  STOP = 'stop'
}
export const DEDUCTION_PATH = {
  TASK_CURRENT_DATA:
    'currentData.workerGeneralDeductionInstructions[0].generalDeductionInstructions',
  TASK_PENDING_DATA:
    'pendingEvents[0].body.events[0].data.transform.workerGeneralDeductionInstruction.generalDeductionInstruction',
  TASK_RESOURCE_PATH: 'pendingEvents[0].resourcePath',
  TASK_ITEM_ID:
    'pendingEvents[0].body.events[0].data.eventContext.workerGeneralDeductionInstruction.generalDeductionInstruction.itemID',
  NOTIFICATION_CURRENT_DATA:
    'oldData.workerGeneralDeductionInstructions[0].generalDeductionInstructions',
  NOTIFICATION_PENDING_DATA:
    'body.events[0].data.transform.workerGeneralDeductionInstruction.generalDeductionInstruction',
  NOTIFICATION_RESOURCE_PATH: 'resourcePath',
  NOTIFICATION_ITEM_ID:
    'body.events[0].data.eventContext.workerGeneralDeductionInstruction.generalDeductionInstruction.itemID'
};
export interface DeductionComparisonData {
  currentData?: DeductionsDTO.GeneralDeductionInstruction;
  pendingData?: DeductionsDTO.GeneralDeductionInstruction;
  type?: DEDUCTION_EVENT_TYPE;
  itemID?: string;
}
