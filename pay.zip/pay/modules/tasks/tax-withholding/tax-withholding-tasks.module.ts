import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AlertModule } from '@synerg/components/alert';

import { MyAdpCommonModule } from '@myadp/common';
import { CoreModule } from '@synerg/angular-components';

import {
  NOTIFICATION_EVENT_NAME_CODES,
  NotificationsService,
  TaskModule,
  ThingsToDoSharedModule
} from '@myadp/thingstodo-shared';


import { SharedModule } from '../../shared/shared.module';
import { TaxWithholdingManagementModule } from '../../tax-withholding-management/tax-withholding-management.module';

import { TaskTaxWithholdingDetailsComponent } from './componets/details/task-tax-withholding-details.component';

@NgModule({
  imports: [
    CommonModule,
    AlertModule,
    MyAdpCommonModule,
    SharedModule,
    TaskModule,
    ThingsToDoSharedModule,
    TaxWithholdingManagementModule,
    CoreModule
  ],
  declarations: [ TaskTaxWithholdingDetailsComponent ]
})
export class TaxWithholdingTasksModule {
  constructor(private notificationsService: NotificationsService) {
    [
      NOTIFICATION_EVENT_NAME_CODES.pay.worker_usFederal_taxWithholding_election_change,
      NOTIFICATION_EVENT_NAME_CODES.pay.worker_usState_taxWithholding_election_change
    ].forEach(event => this.notificationsService.setTaskDetailsRoute(event, TaskTaxWithholdingDetailsComponent));
  }

}
