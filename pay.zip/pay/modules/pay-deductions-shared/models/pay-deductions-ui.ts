import { DeductionsDTO } from '@myadp/dto';
import { RawMetaObject } from '@myadp/forms';

import { WorkflowUI } from '../../shared/models/workflow-ui.model';

export enum PayDeductionsStoreSlice {
  PAY_DEDUCTIONS = 'payDeductions',
  PAY_DEDUCTIONS_INITIAL = 'payDeductionsInitial',
  PAY_DEDUCTIONS_META = 'payDeductionsStartMeta'
}

export interface PayDeductionsStoreState {
  [PayDeductionsStoreSlice.PAY_DEDUCTIONS]?: PayDeductionsUI.Deduction[];
  [PayDeductionsStoreSlice.PAY_DEDUCTIONS_INITIAL]?: PayDeductionsUI.Deduction[];
  [PayDeductionsStoreSlice.PAY_DEDUCTIONS_META]?: PayDeductionsUI.PayDeductionMeta;
}

export namespace PayDeductionsUI {
  export type Deduction = WorkflowUI.WorkflowData<DeductionDetails>;

  export type DeductionDetails = DeductionsDTO.GeneralDeductionInstruction;

  // codeList raw meta and deduction raw meta by itemID
  export type PayDeductionMeta = {
    addFormMeta?: Record<string, RawMetaObject>;
    editFormMeta?: Record<string, RawMetaObject>;
    rawStartMeta?: RawMetaObject;
    maxDeductionsReached?: boolean;
  };
}
