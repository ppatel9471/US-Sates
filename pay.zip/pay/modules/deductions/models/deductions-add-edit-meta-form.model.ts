import { MetaFormGroup } from '@myadp/forms';
import { DeductionForm } from './deduction-form.model';

export class DeductionsAddEditMetaForm extends MetaFormGroup {
  public deductionRateValue = this.numberControl({
    meta: this.meta,
    path: '/workerGeneralDeductionInstruction/generalDeductionInstruction/deductionRate/rateValue'
  });

  public deductionGoalLimit = this.numberControl({
    meta: this.meta,
    path:
      '/workerGeneralDeductionInstruction/generalDeductionInstruction/deductionGoal/goalLimitAmount/amountValue'
  });

  // this path will exist in the meta API response if the rateValue amountValue is a percentage
  public deductionRateUnitCode = this.meta.has(
    '/workerGeneralDeductionInstruction/generalDeductionInstruction/deductionRate/unitCode/codeValue'
  )
    ? this.stringControl({
      meta: this.meta,
      path:
          '/workerGeneralDeductionInstruction/generalDeductionInstruction/deductionRate/unitCode/codeValue'
    })
    : null;

  transform(): DeductionForm {
    const rateValueTypeObj = this.deductionRateUnitCode
      ? {
        unitCode: {
          codeValue: 'percent'
        }
      }
      : {
        currencyCode: 'USD'
      };

    return {
      deductionRate: {
        rateValue: this.deductionRateValue?.value,
        ...rateValueTypeObj
      },
      deductionGoal: {
        goalLimitAmount: {
          amountValue: this.deductionGoalLimit?.value,
          currencyCode: 'USD'
        }
      }
    };
  }
}
