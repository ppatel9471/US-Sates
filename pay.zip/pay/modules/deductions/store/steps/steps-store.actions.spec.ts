import { ComponentFactoryResolver, ViewContainerRef } from '@angular/core';
import { fakeAsync, flush, TestBed, tick } from '@angular/core/testing';
import { BrowserModule } from '@angular/platform-browser';
import { of } from 'rxjs';
import { Mock } from 'ts-mockery';

import { Worker } from '@myadp/dto';
import { MOCK_WORKFLOW_DEDUCTIONS } from '@specHelpers/pay/pay-deductions/pay-deductions';

import { WorkerInfoStoreActions } from '../../../worker-info-shared/store/worker-info-store.actions';
import { WorkerInfoStore } from '../../../worker-info-shared/store/worker-info.store';
import { STEPS } from '../../models/steps.enum';
import { DeductionsStoreActions } from '../deductions-store.actions';
import { DeductionsStore } from '../deductions.store';
import { StepsStoreActions } from './steps-store.actions';
import { StepsStore } from './steps.store';

describe('StepsStoreActions', () => {
  let stepsStoreActions: StepsStoreActions;
  let stepsStore: StepsStore;
  let deductionsStore: DeductionsStore;
  let deductionsStoreActions: DeductionsStoreActions;
  let workerInfoStoreActions: WorkerInfoStoreActions;
  let mockViewContainerRef: ViewContainerRef;

  const mockFormData = {
    itemID: '40A',
    deductionCode: {
      codeValue: '40A'
    },
    terms: true
  };

  const mockWorker: Worker = {
    associateOID: '1',
    person: {
      communication: {
        mobiles: [{ formattedNumber: '1234567890' }],
        landlines: [{ formattedNumber: '9876543210' }]
      },
      legalName: {
        givenName: 'Rachel',
        familyName1: 'Melony',
        middleName: 'Lisa',
        generationAffixCode: { longName: 'Jr', codeValue: '1' }
      },
      legalAddress: {
        lineOne: '123 Westside Pkwy'
      },
      governmentIDs: [
        {
          idValue: 'XXXXX6789',
          itemID: 'SSN',
          nameCode: {
            codeValue: 'SSN',
            shortName: 'SSN',
            longName: 'Social Security Number'
          }
        }
      ],
      birthDate: 'XXXX-12-01'
    }
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [BrowserModule],
      providers: [
        StepsStoreActions,
        StepsStore,
        {
          provide: DeductionsStore,
          useValue: Mock.of<DeductionsStore>({
            hasDeductions: true,
            formData: mockFormData,
            changedDeductionDetails: MOCK_WORKFLOW_DEDUCTIONS[1].pendingData,
            hasUnsavedAdd: false
          })
        },
        {
          provide: DeductionsStoreActions,
          useValue: Mock.of<DeductionsStoreActions>({
            recallDeduction: () => Mock.noop(),
            resetFormData: () => Mock.noop(),
            postDeduction: () => Mock.noop(),
            updateFormData: () => Mock.noop(),
            revertAllChanges: () => Mock.noop(),
            deleteDeduction: () => Promise.resolve(),
            updateChangedDeduction: () => Mock.noop()
          })
        },
        {
          provide: WorkerInfoStoreActions,
          useValue: Mock.of<WorkerInfoStoreActions>({
            getWorker: () => Mock.noop()
          })
        },
        {
          provide: WorkerInfoStore,
          useValue: Mock.of<WorkerInfoStore>({
            worker$: () => of(mockWorker)
          })
        },
        {
          provide: ComponentFactoryResolver,
          useValue: Mock.of<ComponentFactoryResolver>({
            resolveComponentFactory: () => Mock.noop()
          })
        }
      ]
    });

    stepsStoreActions = TestBed.inject(StepsStoreActions);
    stepsStore = TestBed.inject(StepsStore);
    deductionsStore = TestBed.inject(DeductionsStore);
    deductionsStoreActions = TestBed.inject(DeductionsStoreActions);
    workerInfoStoreActions = TestBed.inject(WorkerInfoStoreActions);

    mockViewContainerRef = Mock.of<ViewContainerRef>({
      clear: () => Mock.noop(),
      createComponent: (): any => ({ instance: { step: 0 } })
    });
    stepsStoreActions.stepContainer = mockViewContainerRef;
  });

  describe('init', () => {
    it('should init and load the LIST step', () => {
      stepsStoreActions.init(mockViewContainerRef);

      expect(stepsStore.stateValue['steps'].data.step).toEqual(
        jasmine.objectContaining({
          current: 0,
          name: STEPS.LIST
        })
      );
    });

    it('should init and load the DEDUCTION_DETAILS step', () => {
      Mock.extend(deductionsStore).with({
        hasDeductions: false
      });
      stepsStoreActions.init(mockViewContainerRef);

      expect(stepsStore.stateValue['steps'].data.step).toEqual(
        jasmine.objectContaining({
          current: 1,
          name: STEPS.DEDUCTION_DETAILS
        })
      );
    });

    it('should call to initialize a worker', () => {
      stepsStoreActions.init(mockViewContainerRef);
      expect(workerInfoStoreActions.getWorker).toHaveBeenCalled();
    });

    it('should fetch a worker', async () => {
      expect(await stepsStoreActions.getWorker()).toEqual(mockWorker);
    });
  });

  describe('slidein controls', () => {
    it('should open the slidein', () => {
      stepsStoreActions.openSlidein();
      expect(stepsStore.isSlideinOpen$.getValue()).toBe(true);
    });

    it('should close the slidein', () => {
      stepsStoreActions.closeSlidein();
      expect(deductionsStoreActions.revertAllChanges).toHaveBeenCalled();
      expect(deductionsStoreActions.resetFormData).toHaveBeenCalled();
      expect(stepsStore.isSlideinOpen$.getValue()).toBe(false);
    });
  });

  describe('Next/Prev button attributes', () => {
    it('should disable next', () => {
      stepsStoreActions.init(mockViewContainerRef);
      stepsStoreActions.disableNext(true);

      expect(stepsStore.stateValue['steps'].data.next).toEqual({
        disabled: true,
        hidden: false
      });
    });

    it('should disable prev', () => {
      stepsStoreActions.init(mockViewContainerRef);
      stepsStoreActions.disablePrev(true);

      expect(stepsStore.stateValue['steps'].data.prev).toEqual({
        disabled: true,
        hidden: false
      });
    });

    it('should hide the prev button', () => {
      stepsStoreActions.init(mockViewContainerRef);
      stepsStoreActions.resetCurrentStep();
      stepsStoreActions.hidePrev(true);

      expect(stepsStore.stateValue['steps'].data.prev).toEqual({
        hidden: true
      });

      stepsStoreActions.hidePrev(false);

      expect(stepsStore.stateValue['steps'].data.prev).toEqual({
        hidden: false
      });
    });
  });

  describe('nextStep()', () => {
    it('should go to DEDUCTION_DETAILS step when adding', () => {
      stepsStoreActions.init(mockViewContainerRef);
      stepsStoreActions.nextStep('add');

      expect(stepsStoreActions.currentStep.name).toEqual(STEPS.DEDUCTION_DETAILS);
    });

    it('should go to DEDUCTION_DETAILS step when editing', () => {
      stepsStoreActions.init(mockViewContainerRef);
      stepsStoreActions.nextStep('edit');

      expect(deductionsStoreActions.updateChangedDeduction).not.toHaveBeenCalled();
      expect(stepsStoreActions.currentStep.name).toEqual(STEPS.DEDUCTION_DETAILS);
    });

    it('should go to DONE step when finished editing', () => {
      stepsStoreActions.init(mockViewContainerRef);
      stepsStoreActions.nextStep('edit');
      stepsStoreActions.nextStep();

      expect(deductionsStoreActions.updateChangedDeduction).toHaveBeenCalledTimes(1);
      expect(deductionsStoreActions.updateChangedDeduction).toHaveBeenCalledWith(mockFormData);
      expect(stepsStoreActions.currentStep.name).toEqual(STEPS.REVIEW);
    });
  });

  describe('prevStep()', () => {
    it('should reset form data when going back to List step', () => {
      stepsStoreActions.init(mockViewContainerRef);
      stepsStoreActions.nextStep('add');

      expect(stepsStoreActions.currentStep.name).toEqual(STEPS.DEDUCTION_DETAILS);

      stepsStoreActions.prevStep();

      expect(deductionsStoreActions.updateChangedDeduction).not.toHaveBeenCalled();
      expect(deductionsStoreActions.resetFormData).toHaveBeenCalled();
      expect(stepsStoreActions.currentStep.name).toEqual(STEPS.LIST);
    });
  });

  describe('hasFormDetailChanges()', () => {
    it('should return true', () => {
      expect(stepsStoreActions.hasFormDetailChanges()).toBeTrue();
    });

    it('should return false', () => {
      Mock.extend(deductionsStore).with({
        formData: null
      });

      expect(stepsStoreActions.hasFormDetailChanges()).toBeFalse();
    });

    it('should return false when current step is in done', () => {
      stepsStoreActions.init(mockViewContainerRef);
      stepsStoreActions.nextStep('add');
      stepsStoreActions.nextStep();
      stepsStoreActions.nextStep();

      expect(stepsStoreActions.hasFormDetailChanges()).toBeFalse();
    });
  });

  describe('deleteDeduction()', () => {
    beforeEach(() => {
      stepsStoreActions.init(mockViewContainerRef);
      stepsStoreActions.nextStep('edit');
      spyOn(stepsStoreActions, 'disablePrev').and.callThrough();
      spyOn(stepsStoreActions, 'disableNext').and.callThrough();
    });

    it('PIMYPI-T990 should delete the deduction and jump to Done step', fakeAsync(() => {
      spyOn(stepsStoreActions, 'returnToListStep').and.callThrough();
      spyOn(stepsStoreActions, 'skipToDoneStep').and.callThrough();
      stepsStoreActions.deleteDeduction();
      flush();

      expect(deductionsStoreActions.deleteDeduction).toHaveBeenCalledWith(
        MOCK_WORKFLOW_DEDUCTIONS[1].pendingData
      );
      expect(stepsStoreActions.returnToListStep).not.toHaveBeenCalled();
      expect(stepsStoreActions.skipToDoneStep).toHaveBeenCalled();
      expect(deductionsStoreActions.resetFormData).not.toHaveBeenCalled();
      expect(deductionsStoreActions.revertAllChanges).not.toHaveBeenCalled();
    }));

    it('PIMYPI-T993 should delete the deduction locally and jump to List step', fakeAsync(() => {
      Mock.extend(deductionsStore).with({
        hasUnsavedAdd: true
      });
      spyOn(stepsStoreActions, 'returnToListStep').and.callThrough();
      spyOn(stepsStoreActions, 'skipToDoneStep').and.callThrough();
      stepsStoreActions.deleteDeduction();
      flush();

      expect(deductionsStoreActions.deleteDeduction).toHaveBeenCalledWith(
        MOCK_WORKFLOW_DEDUCTIONS[1].pendingData
      );
      expect(stepsStoreActions.returnToListStep).toHaveBeenCalled();
      expect(stepsStoreActions.skipToDoneStep).not.toHaveBeenCalled();
      expect(deductionsStoreActions.resetFormData).toHaveBeenCalled();
      expect(deductionsStoreActions.revertAllChanges).toHaveBeenCalled();
    }));

    it('should enable prev and next button while delete deduction from deductions store actions is loading', fakeAsync(() => {
      // this scenario has next enabled initially
      stepsStoreActions.currentStep.stepProps.next.disabled = false;
      Mock.extend(deductionsStoreActions).with({
        deleteDeduction: () =>
          new Promise((resolve) => {
            return setTimeout(() => {
              resolve();
            }, 50);
          })
      });

      stepsStoreActions.deleteDeduction();

      expect(stepsStoreActions.disablePrev).toHaveBeenCalledWith(true);
      expect(stepsStore.stateValue['steps'].data.prev).toEqual({
        disabled: true,
        hidden: false
      });
      expect(stepsStore.stateValue['steps'].data.next).toEqual({
        disabled: true,
        hidden: false
      });

      tick(50);

      expect(stepsStoreActions.disablePrev).toHaveBeenCalledWith(false);
      expect(stepsStoreActions.disableNext).toHaveBeenCalledWith(false);
      expect(stepsStore.stateValue['steps'].data.prev).toEqual({
        disabled: false,
        hidden: false
      });
      expect(stepsStore.stateValue['steps'].data.next).toEqual({
        disabled: false,
        hidden: false
      });
    }));

    it('should enable prev and next button when promise is rejected', fakeAsync(() => {
      // this scenario has next enabled initially
      stepsStoreActions.currentStep.stepProps.next.disabled = false;
      Mock.extend(deductionsStoreActions).with({
        deleteDeduction: () => Promise.reject()
      });
      const prevSpy = stepsStoreActions.disablePrev as jasmine.Spy;
      const nextSpy = stepsStoreActions.disableNext as jasmine.Spy;

      stepsStoreActions.deleteDeduction();
      flush();

      expect(prevSpy.calls.argsFor(1)[0]).toBe(false);
      expect(nextSpy.calls.argsFor(1)[0]).toBe(false);
      expect(stepsStore.stateValue['steps'].data.prev).toEqual({
        disabled: false,
        hidden: false
      });
      expect(stepsStore.stateValue['steps'].data.prev).toEqual({
        disabled: false,
        hidden: false
      });
    }));

    it('should keep next button disabled when promise is resolved', fakeAsync(() => {
      // this scenario has next initially disabled
      stepsStoreActions.currentStep.stepProps.next.disabled = true;
      const prevSpy = stepsStoreActions.disablePrev as jasmine.Spy;
      const nextSpy = stepsStoreActions.disableNext as jasmine.Spy;

      stepsStoreActions.deleteDeduction();
      flush();

      expect(prevSpy.calls.argsFor(1)[0]).toBe(false);
      expect(nextSpy.calls.argsFor(1)[0]).toBe(true);
      expect(stepsStore.stateValue['steps'].data.prev).toEqual({
        disabled: false,
        hidden: false
      });
      expect(stepsStore.stateValue['steps'].data.next).toEqual({
        disabled: true,
        hidden: false
      });
    }));
  });

  it('should cancel the current step when on Review step', () => {
    stepsStoreActions.init(mockViewContainerRef);
    stepsStoreActions.nextStep('add');
    stepsStoreActions.nextStep();
    stepsStoreActions.cancelStep();

    expect(deductionsStoreActions.resetFormData).toHaveBeenCalled();
    expect(deductionsStoreActions.revertAllChanges).toHaveBeenCalled();
  });

  it('should call cancel pending account', () => {
    stepsStoreActions.cancelPendingRequest(null);
    expect(deductionsStoreActions.recallDeduction).toHaveBeenCalledWith(null);
  });

  it('should submit/POST deductions', () => {
    Mock.extend(deductionsStore).with({
      changes: { changeType: 'add', deductionDetails: deductionsStore.changedDeductionDetails }
    });
    stepsStoreActions.submit();
    expect(deductionsStoreActions.postDeduction).toHaveBeenCalledWith(
      MOCK_WORKFLOW_DEDUCTIONS[1].pendingData,
      'add'
    );
  });

  it('should reset current step', () => {
    stepsStoreActions.resetCurrentStep();

    expect(stepsStore.stateValue['steps'].data).toBeNull();
    expect(deductionsStoreActions.resetFormData).toHaveBeenCalledTimes(1);
  });

  it('should skip to the Done step', () => {
    stepsStoreActions.init(mockViewContainerRef);
    stepsStoreActions.loadEditStep(MOCK_WORKFLOW_DEDUCTIONS[1]);

    stepsStoreActions.skipToDoneStep();

    expect(stepsStoreActions.currentStep.name).toEqual(STEPS.DONE);
  });

  describe('loadEditStep', () => {
    it('should reset form data and load deduction into step', () => {
      const mockDeduction = MOCK_WORKFLOW_DEDUCTIONS[2];
      stepsStoreActions.init(mockViewContainerRef);
      stepsStoreActions.loadEditStep(mockDeduction);

      expect(deductionsStoreActions.resetFormData).toHaveBeenCalled();
      expect(deductionsStoreActions.updateFormData).toHaveBeenCalledWith(mockDeduction.pendingData);
      expect(deductionsStoreActions.updateChangedDeduction).toHaveBeenCalledTimes(1);
      expect(deductionsStoreActions.updateChangedDeduction).toHaveBeenCalledWith(mockDeduction);
    });
  });
});
