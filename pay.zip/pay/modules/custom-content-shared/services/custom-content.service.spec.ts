import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { CustomContentService } from './custom-content.service';
import { Observable } from 'rxjs';

describe('CustomContentService', () => {
  const featureKey: string = 'taxwithholding';
  const contentKey: string = 'details';
  let service: CustomContentService;
  let httpMock: HttpTestingController;
  const mockData = {
    taxwithholding: {
      message: 'mockMessage',
      details: 'Mock details string'
    },
    exceptions: {
      message: 'mockExceptionMessage',
      details: 'Mock exception details string'
    }
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [CustomContentService]
    });

    service = TestBed.inject(CustomContentService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should return an Observable of custom content when passed only "featureKey" parameter', (done: DoneFn) => {
    const contentObs = service.getCustomContent(featureKey);
    expect(contentObs).toBeAnInstanceOf(Observable);

    contentObs.subscribe(data => {
      expect(data).toBe('mockMessage');
      done();
    });

    httpMock.expectOne(`/myadpapi/client-content/v1/pay`).flush(mockData);
  });

  it('should return an Observable of custom content when passed "featureKey" and "contentKey" parameters', (done: DoneFn) => {
    const contentObs = service.getCustomContent(featureKey, contentKey);
    expect(contentObs).toBeAnInstanceOf(Observable);

    contentObs.subscribe(data => {
      expect(data).toBe('Mock details string');
      done();
    });

    httpMock.expectOne(`/myadpapi/client-content/v1/pay`).flush(mockData);
  });

  it('should return "undefined" if passed params do not match keys in data', (done: DoneFn) => {
    const contentObs = service.getCustomContent('keyShouldFail');

    contentObs.subscribe(data => {
      expect(data).toBeUndefined();
      done();
    });

    httpMock.expectOne(`/myadpapi/client-content/v1/pay`).flush(mockData);
  });
});
