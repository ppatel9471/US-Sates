import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Injector } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { ClientDeviceService } from '@espresso/core';
import { Mock } from 'ts-mockery';

import { PayDashboardTileMobileService } from './pay-dashboard-tile-mobile.service';
import { PayDashboardTileServiceFactory } from './pay-dashboard-tile-service.factory';
import { PayDashboardTileService } from './pay-dashboard-tile.service';

describe('PayDashboardTileServiceFactory', () => {
  let payDashboardTileServiceFactory: PayDashboardTileServiceFactory;
  let mockInjector: Injector;
  let clientDeviceService: ClientDeviceService;

  beforeEach(() => {
    mockInjector = Mock.of<Injector>({
      get: () => ''
    });
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        PayDashboardTileServiceFactory,
        {
          provide: ClientDeviceService,
          useValue: Mock.of<ClientDeviceService>({
            isNative: () => false
          })
        },
        {
          provide: Injector,
          useValue: mockInjector
        }
      ]
    });

    payDashboardTileServiceFactory = TestBed.inject(PayDashboardTileServiceFactory);
    clientDeviceService = TestBed.inject(ClientDeviceService);
  });

  describe('get tile service', () => {
    it('should get web service', () => {
      payDashboardTileServiceFactory.getPayDashboardTileService();
      expect(mockInjector.get).toHaveBeenCalledWith(PayDashboardTileService);
    });

    it('should get mobile service', () => {
      Mock.extend(clientDeviceService).with({
        isNative: () => true
      });
      payDashboardTileServiceFactory.getPayDashboardTileService();
      expect(mockInjector.get).toHaveBeenCalledWith(PayDashboardTileMobileService);
    });
  });
});
