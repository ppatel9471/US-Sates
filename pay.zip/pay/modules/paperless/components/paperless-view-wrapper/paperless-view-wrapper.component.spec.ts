import { ClientDeviceService } from '@espresso/core';
import { ModalComponent } from '@synerg/components/modal';
import { EMPTY, of } from 'rxjs';
import { Shallow } from 'shallow-render';
import { Mock } from 'ts-mockery';

import { LanguagePipe, LanguageService, PrintModalService } from '@myadp/common';
import { PageType, PaperlessStore, PaperlessStoreActions, PaperlessType } from '@myadp/pay-paperless-shared';

import { PaperlessModule } from '../../paperless.module';
import { PaperlessViewWrapperComponent } from './paperless-view-wrapper.component';

describe('PaperlessViewWrapperComponent', () => {
  let shallow: Shallow<PaperlessViewWrapperComponent>;

  beforeEach(() => {
    shallow = new Shallow(PaperlessViewWrapperComponent, PaperlessModule)
      .provide(LanguageService, ClientDeviceService)
      .mockPipe(LanguagePipe, (key) => key)
      .mock(LanguageService, { get: (key: string) => key })
      .mock(PaperlessStore, {
        onlyEmailSettingsVisible$: () => of(false)
      })
      .mock(ClientDeviceService, {
        isNative: () => false,
        isMobile: () => false
      })
      .mock(PaperlessStoreActions, {
        getAllPreferences: () => Mock.noop(),
        setSettingsModalOpen: () => Mock.noop()
      })
      .mock(PrintModalService, {
        printText: () => EMPTY
      })
      .mock(ModalComponent, {
        close: () => Mock.noop()
      });
  });

  describe('Settings modal', () => {
    it('should be visible', async () => {
      const { get, instance } = await shallow.render();
      const mockPaperlessStoreActions = get(PaperlessStoreActions);
      instance.setDisplaySettingsModal(true);

      expect(instance.showSettingsModal).toBeTruthy();
      expect(mockPaperlessStoreActions.setSettingsModalOpen).toHaveBeenCalledWith(true);
    });

    it('should be hidden', async () => {
      const { get, instance } = await shallow.render();
      const mockPaperlessStoreActions = get(PaperlessStoreActions);
      instance.setDisplaySettingsModal(false);

      expect(instance.showSettingsModal).toBeFalsy();
      expect(mockPaperlessStoreActions.setSettingsModalOpen).toHaveBeenCalledWith(false);
    });

    it('should not be a modal for inline', async () => {
      const { find, instance, fixture } = await shallow.render({
        bind: {
          pageType: PageType.PAY,
          displaySettingsType: 'inline'
        }
      });
      instance.setDisplaySettingsModal(true);
      fixture.detectChanges();

      expect(find('adp-modal')).toHaveFound(0);
      expect(find('pay-paperless-settings')).toHaveFound(1);
    });

    it('should be a modal on retirement page on native', async () => {
      const { find, instance, fixture } = await shallow
        .mock(ClientDeviceService, {
          isNative: () => true,
          isMobile: () => true
        })
        .render({
          bind: {
            pageType: PageType.RETIREMENT
          }
        });
      instance.setDisplaySettingsModal(true);
      fixture.detectChanges();

      expect(find('adp-modal')).toHaveFound(1);
    });

    it('should be a modal on pay page on tablet native', async () => {
      const { find, instance, fixture } = await shallow
        .mock(ClientDeviceService, {
          isNative: () => true,
          isMobile: () => false
        })
        .render({
          bind: {
            pageType: PageType.RETIREMENT
          }
        });
      instance.setDisplaySettingsModal(true);
      fixture.detectChanges();

      expect(find('adp-modal')).toHaveFound(1);
    });
  });

  describe('Consent modal', () => {
    it('should be visible', async () => {
      const { instance } = await shallow.render();
      instance.setDisplayConsentModal(true);

      expect(instance.showConsentModal).toBeTruthy();
    });

    it('should be hidden', async () => {
      const { instance } = await shallow.render();
      instance.setDisplayConsentModal(false);

      expect(instance.showConsentModal).toBeFalsy();
    });
  });

  describe('Print Consent modal', () => {
    it('should be visible', async () => {
      const { instance } = await shallow.render();
      instance.setDisplayPrintConsentModal(true);

      expect(instance.showPrintConsentModal).toBeTruthy();
    });

    it('should be hidden', async () => {
      const { instance } = await shallow.render();
      instance.setDisplayPrintConsentModal(false);

      expect(instance.showPrintConsentModal).toBeFalsy();
    });
  });

  describe('Modal title', () => {
    it('should be "Paperless Settings" if other settings are visible', async () => {
      const { get, instance } = await shallow.render();
      const languageService = get(LanguageService);

      expect(languageService.get).toHaveBeenCalledWith(
        'myadp-pay.GO_PAPERLESS_SETTINGS_MODAL_TITLE'
      );
      expect(instance.settingsModalTitle).toBe('myadp-pay.GO_PAPERLESS_SETTINGS_MODAL_TITLE');
    });

    it('should be "Email Notification Settings" if only email settings are visible', async () => {
      const { get, instance } = await shallow
        .mock(PaperlessStore, {
          onlyEmailSettingsVisible$: () => of(true)
        })
        .render();
      const languageService = get(LanguageService);

      expect(languageService.get).toHaveBeenCalledWith(
        'myadp-pay.GO_PAPERLESS_SETTINGS_EMAIL_MODAL_TITLE'
      );
      expect(instance.settingsModalTitle).toBe('myadp-pay.GO_PAPERLESS_SETTINGS_EMAIL_MODAL_TITLE');
    });
  });

  describe('Print consent', () => {
    it('should print consent text for pay', async () => {
      const { instance, get } = await shallow.render();
      const printModalService = get(PrintModalService);
      instance.type = PaperlessType.PAY;
      instance.printConsent();
      const text =
        'myadp-pay.GO_PAPERLESS_CONTENT_INFO_PAY_LABELmyadp-pay.GO_PAPERLESS_PAY_TAX_SHARED_CONSENT_PAY' +
        'myadp-pay.GO_PAPERLESS_PAY_CONSENTmyadp-pay.GO_PAPERLESS_SHARED_CONSENT_AGREEMENT_PAY';

      expect(printModalService.printText).toHaveBeenCalledWith(`
      <html>
        <head>
          <title>myadp-pay.GO_PAPERLESS_PAY_CONSENT_MODAL_TITLE</title>
        </head>
        <body>
          ${text}
        </body>
      </html>`);
    });

    it('should print consent text for tax', async () => {
      const { instance, get } = await shallow.render();
      const printModalService = get(PrintModalService);
      instance.type = PaperlessType.TAX;
      instance.printConsent();

      expect(printModalService.printText).toHaveBeenCalledWith(`
      <html>
        <head>
          <title>myadp-pay.GO_PAPERLESS_TAX_CONSENT_MODAL_TITLE</title>
        </head>
        <body>
          myadp-pay.GO_PAPERLESS_PAY_TAX_SHARED_CONSENTmyadp-pay.GO_PAPERLESS_TAX_CONSENT
        </body>
      </html>`);
    });

    it('should print consent text for tax coverage insurance', async () => {
      const { instance, get } = await shallow.render();
      const printModalService = get(PrintModalService);
      instance.type = PaperlessType.TAX_COVERAGE_INSURANCE;
      instance.printConsent();

      expect(printModalService.printText).toHaveBeenCalledWith(`
      <html>
        <head>
          <title>myadp-pay.GO_PAPERLESS_TAX_COVERAGE_INSURANCE_CONSENT_MODAL_TITLE</title>
        </head>
        <body>
          myadp-pay.GO_PAPERLESS_PAY_TAX_SHARED_CONSENTmyadp-pay.GO_PAPERLESS_TAX_COVERAGE_INSURANCE_CONSENT
        </body>
      </html>`);
    });

    it('should print consent text for retirement', async () => {
      const { instance, get } = await shallow.render();
      const printModalService = get(PrintModalService);
      instance.type = PaperlessType.RETIREMENT;
      instance.printConsent();

      expect(printModalService.printText).toHaveBeenCalledWith(`
      <html>
        <head>
          <title>myadp-pay.GO_PAPERLESS_RETIREMENT_CONSENT_MODAL_TITLE</title>
        </head>
        <body>
          myadp-pay.GO_PAPERLESS_RETIREMENT_CONSENT
        </body>
      </html>`);
    });
  });
});
