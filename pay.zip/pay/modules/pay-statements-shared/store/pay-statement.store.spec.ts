import { TestBed } from '@angular/core/testing';
import { BreakpointService } from '@synerg/components/shared';
import { of } from 'rxjs';
import { Mock } from 'ts-mockery';

import { MOCK_TRANSFORMED_PAY_STATEMENTS } from '../../../../../../src/spec-helpers/pay/pay-statement/pay-statements';
import { PayStatementsStoreSlice } from '../models/pay-statement-ui';
import { PayStatementStore } from './pay-statement.store';

describe('PayStatementStore', () => {
  let payStatementStore: PayStatementStore;
  let breakpointService: BreakpointService;

  const transformedStatements = MOCK_TRANSFORMED_PAY_STATEMENTS;
  const mockStatementDetails = {
    payDate: 'Feb 13, 2020',
    grossPay: { amountValue: 1500, currencyCode: 'USD' }
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        PayStatementStore,
        {
          provide: BreakpointService,
          useValue: Mock.of<BreakpointService>({
            lte: () => of(false)
          })
        }
      ]
    });

    payStatementStore = TestBed.inject(PayStatementStore);
    breakpointService = TestBed.inject(BreakpointService);
  });

  it('should create the store with an initial state', () => {
    expect(payStatementStore.stateValue).toEqual({
      [PayStatementsStoreSlice.PAY_STATEMENTS]: {
        data: {
          statements: [],
          statementsForPdfViewer: [],
          workerPayInfo: null,
          hasNotificationPermission: null
        },
        loading: false,
        error: {}
      },
      [PayStatementsStoreSlice.CURRENT_STATEMENT_DETAILS]: {
        data: { statement: {} },
        loading: false,
        error: {}
      },
      [PayStatementsStoreSlice.STATEMENT_DETAILS_CACHE]: {
        data: {},
        loading: false,
        error: {}
      },
      [PayStatementsStoreSlice.CURRENT_PAYMENT_CALCULATION_ANALYSIS]: {
        data: null,
        loading: false,
        error: {}
      },
      [PayStatementsStoreSlice.PAYMENT_CALCULATION_ANALYSIS_CACHE]: {
        data: {},
        loading: false,
        error: {}
      }
    });
  });

  describe('showTile', () => {
    it('should show statements activity Tile when has statements and screen is md', async (done: DoneFn) => {
      Mock.extend(breakpointService).with({
        lte: () => of(true)
      });
      payStatementStore.update(PayStatementsStoreSlice.PAY_STATEMENTS, {
        data: { statements: transformedStatements }
      });
      payStatementStore.update(PayStatementsStoreSlice.CURRENT_STATEMENT_DETAILS, {
        data: { statement: transformedStatements[0] }
      });

      payStatementStore.showStatementsActivityTile$.subscribe((value: boolean) => {
        expect(value).toBeTruthy();
        done();
      });
    });

    it('should hide statements activity Tile when has statements and screen is large', async (done: DoneFn) => {
      payStatementStore.update(PayStatementsStoreSlice.PAY_STATEMENTS, {
        data: { statements: transformedStatements }
      });
      payStatementStore.update(PayStatementsStoreSlice.CURRENT_STATEMENT_DETAILS, {
        data: { statement: transformedStatements[0] }
      });

      payStatementStore.showStatementsActivityTile$.subscribe((value: boolean) => {
        expect(value).toBeFalsy();
        done();
      });
    });

    it('should not show statements activity Tile when has no statements', async (done: DoneFn) => {
      Mock.extend(breakpointService).with({
        lte: () => of(true)
      });
      payStatementStore.update(PayStatementsStoreSlice.PAY_STATEMENTS, {
        data: { statements: [] }
      });

      payStatementStore.showStatementsActivityTile$.subscribe((value: boolean) => {
        expect(value).toBeFalsy();
        done();
      });
    });
  });

  describe('statement cache', () => {
    it('should get statement by id', async (done: DoneFn) => {
      payStatementStore.update(PayStatementsStoreSlice.STATEMENT_DETAILS_CACHE, {
        data: {
          1: {
            statement: transformedStatements[0],
            statementDetails: mockStatementDetails
          }
        }
      });
      payStatementStore.statementDetailsById$(1).subscribe((statementDetails) => {
        expect(statementDetails).toEqual(mockStatementDetails);
        done();
      });
    });

    it('should get statement error by id', async (done: DoneFn) => {
      payStatementStore.update(PayStatementsStoreSlice.STATEMENT_DETAILS_CACHE, {
        data: {
          1: { statement: transformedStatements[0], statementDetails: mockStatementDetails }
        },
        error: { 1: { detailsError: true } }
      });
      payStatementStore.statementDetailErrorById$(1).subscribe((error) => {
        expect(error).toBeTruthy();
        done();
      });
    });

    it('should get statement is loading', async (done: DoneFn) => {
      payStatementStore.update(PayStatementsStoreSlice.STATEMENT_DETAILS_CACHE, {
        loading: true
      });
      payStatementStore.isStatementCacheLoading$().subscribe((loading) => {
        expect(loading).toBeTruthy();
        done();
      });
    });
  });
});
