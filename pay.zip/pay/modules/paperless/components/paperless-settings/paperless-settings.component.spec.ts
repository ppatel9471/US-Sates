import { of } from 'rxjs';
import { Shallow } from 'shallow-render';
import { Mock } from 'ts-mockery';

import { BarbecueService, LanguagePipe, LanguageService } from '@myadp/common';
import { PaperlessStore, PaperlessStoreActions, PaperlessType } from '@myadp/pay-paperless-shared';

import { PaperlessModule } from '../../paperless.module';
import { PaperlessSettingsComponent } from './paperless-settings.component';

describe('PaperlessSettingsComponent', () => {
  let shallow: Shallow<PaperlessSettingsComponent>;

  beforeEach(() => {
    shallow = new Shallow(PaperlessSettingsComponent, PaperlessModule)
      .provide(LanguageService, BarbecueService)
      .mockPipe(LanguagePipe, (key: string) => key)
      .mock(LanguageService, { get: (key: string) => key })
      .mock(PaperlessStore, {
        isLoading$: () => of(false),
        paySettings$: () => of(null),
        taxSettings$: () => of(null),
        healthSettings$: () => of(null),
        retirementSettings$: () => of(null),
        saveSuccess$: () => of(null),
        allLoadError$: () => of(null),
        payLoadError$: () => of(null),
        retirementLoadError$: () => of(null),
        canViewStatementSection$: () => of(true),
        pageHasPaySection: () => true,
        pageHasRetirementSection: () => true,
        pageHasRedirectSettings: () => false,
        pageHasRedirectPay: () => true,
        hasRetirementPermissions: () => true
      })
      .mock(PaperlessStoreActions, {
        savePayStatementPaperless: () => Mock.noop(),
        saveTaxStatementPaperless: () => Mock.noop(),
        saveRetirementNotification: () => Mock.noop()
      })
      .mock(BarbecueService, {
        isBarbecue: () => false
      });
  });

  describe('Pay Section', () => {
    it('should not show the pay settings if they current page should not have it', async () => {
      const { find } = await shallow
        .mock(PaperlessStore, {
          pageHasPaySection: () => false
        })
        .render();

      expect(find('div[data-e2e="pay-section"]')).toHaveFound(0);
    });

    it('should show the pay settings if the type can be viewed', async () => {
      const { find } = await shallow
        .mock(PaperlessStore, {
          canViewStatementSection$: () => of(true)
        })
        .render();

      expect(find('div[data-e2e="pay-section"]')).toHaveFoundOne();
    });

    it('should not show the pay settings if type cannot be viewed', async () => {
      const { find } = await shallow
        .mock(PaperlessStore, {
          canViewStatementSection$: () => of(false)
        })
        .render();

      expect(find('div[data-e2e="pay-section"]')).toHaveFound(0);
    });
  });

  describe('Tax Section', () => {
    it('should not show the tax settings if they current page should not have it', async () => {
      const { find } = await shallow
        .mock(PaperlessStore, {
          pageHasPaySection: () => false
        })
        .render();

      expect(find('div[data-e2e="tax-section"]')).toHaveFound(0);
    });

    it('should show the tax settings if the type can be viewed', async () => {
      const { find } = await shallow
        .mock(PaperlessStore, {
          canViewStatementSection$: () => of(true)
        })
        .render();

      expect(find('div[data-e2e="tax-section"]')).toHaveFoundOne();
    });

    it('should not show the tax settings if type cannot be viewed', async () => {
      const { find } = await shallow
        .mock(PaperlessStore, {
          canViewStatementSection$: () => of(false)
        })
        .render();

      expect(find('div[data-e2e="tax-section"]')).toHaveFound(0);
    });
  });

  describe('Retirement Section', () => {
    it('should not show the tax settings if they current page should not have it', async () => {
      const { find } = await shallow
        .mock(PaperlessStore, {
          pageHasRetirementSection: () => false
        })
        .render();

      expect(find('div[data-e2e="retirement-section"]')).toHaveFound(0);
    });

    it('should show the retirement settings if the type can be viewed', async () => {
      const { find } = await shallow
        .mock(PaperlessStore, {
          canViewStatementSection$: () => of(true)
        })
        .render();

      expect(find('div[data-e2e="retirement-section"]')).toHaveFoundOne();
    });

    it('should not show the retirement settings if type cannot be viewed', async () => {
      const { find } = await shallow
        .mock(PaperlessStore, {
          canViewStatementSection$: () => of(false)
        })
        .render();

      expect(find('div[data-e2e="retirement-section"]')).toHaveFound(0);
    });
  });

  it('should show a loading indicator if anything is loading', async () => {
    const { find } = await shallow
      .mock(PaperlessStore, {
        isLoading$: () => of(true)
      })
      .render();

    expect(find('sdf-shimmer')).toHaveFound(1);
    expect(find('.section-container')).toHaveFound(0);
  });

  it('should not show a loading indicator if nothing is loading', async () => {
    const { find } = await shallow
      .mock(PaperlessStore, {
        isLoading$: () => of(false)
      })
      .render();

    expect(find('sdf-shimmer')).toHaveFound(0);
    expect(find('.section-container')).toHaveFound(5);
    expect(find('pay-paperless-setting-options')).toHaveFound(4);
  });

  it('should show a success alert if saving a preference was successful', async () => {
    const { find } = await shallow
      .mock(PaperlessStore, {
        isLoading$: () => of(false),
        saveSuccess$: () => of({ success: true, message: 'success' })
      })
      .render();
    const alert = find('adp-alert');

    expect(find('sdf-shimmer')).toHaveFound(0);
    expect(find('.section-container')).toHaveFound(5);
    expect(find('pay-paperless-setting-options')).toHaveFound(4);
    expect(alert).toHaveFound(2);
    expect(alert[0].nativeElement.innerHTML).toContain('success');
  });

  it('should show an error alert if saving a preference was unsuccessful', async () => {
    const { find } = await shallow
      .mock(PaperlessStore, {
        isLoading$: () => of(false),
        saveSuccess$: () => of({ success: false, message: 'error' })
      })
      .render();
    const alert = find('adp-alert');

    expect(find('sdf-shimmer')).toHaveFound(0);
    expect(find('.section-container')).toHaveFound(5);
    expect(find('pay-paperless-setting-options')).toHaveFound(4);
    expect(alert).toHaveFound(2);
    expect(alert[0].nativeElement.innerHTML).toContain('error');
  });

  it('should show an error alert for pay/tax if loading pay preferences failed', async () => {
    const { find } = await shallow
      .mock(PaperlessStore, {
        isLoading$: () => of(false),
        allLoadError$: () => of(false),
        payLoadError$: () => of(true),
        retirementLoadError$: () => of(false)
      })
      .render();
    const alert = find('adp-alert');

    expect(find('sdf-shimmer')).toHaveFound(0);
    expect(find('.section-container')).toHaveFound(3);
    expect(find('pay-paperless-setting-options')).toHaveFound(1);
    expect(alert).toHaveFound(2);
    expect(alert[0].nativeElement.innerHTML).toContain(
      'myadp-pay.GO_PAPERLESS_SETTINGS_LOAD_ERROR'
    );
  });

  it('should show an error alert for retirement if loading retirement preferences failed', async () => {
    const { find } = await shallow
      .mock(PaperlessStore, {
        isLoading$: () => of(false),
        allLoadError$: () => of(false),
        payLoadError$: () => of(false),
        retirementLoadError$: () => of(true)
      })
      .render();
    const alert = find('adp-alert');

    expect(find('sdf-shimmer')).toHaveFound(0);
    expect(find('.section-container')).toHaveFound(5);
    expect(find('pay-paperless-setting-options')).toHaveFound(3);
    expect(alert).toHaveFound(2);
    expect(alert[0].nativeElement.innerHTML).toContain(
      'myadp-pay.GO_PAPERLESS_SETTINGS_LOAD_ERROR'
    );
  });

  it('should show an error alert if loading all preferences failed', async () => {
    const { find } = await shallow
      .mock(PaperlessStore, {
        isLoading$: () => of(false),
        allLoadError$: () => of(true)
      })
      .render();
    const alert = find('adp-alert');

    expect(find('sdf-shimmer')).toHaveFound(0);
    expect(find('.section-container')).toHaveFound(0);
    expect(find('pay-paperless-setting-options')).toHaveFound(0);
    expect(alert).toHaveFound(1);
    expect(alert.nativeElement.innerHTML).toContain('myadp-pay.GO_PAPERLESS_SETTINGS_LOAD_ERROR');
  });

  describe('Redirect sections', () => {
    it('should show the redirect section to settings page', async () => {
      const { find } = await shallow
        .mock(PaperlessStore, {
          pageHasRedirectPay: () => false,
          pageHasRedirectSettings: () => true
        })
        .render();

      const emailRedirectSection = find('div[data-e2e="email-section"]');

      expect(emailRedirectSection).toHaveFound(1);
      expect(emailRedirectSection.nativeElement.innerHTML).toContain(
        'myadp-pay.GO_PAPERLESS_SETTINGS_EMAIL_REDIRECT_TIP'
      );
    });

    it('should show the redirect section to pay page', async () => {
      const { find } = await shallow
        .mock(PaperlessStore, {
          pageHasRedirectPay: () => true,
          pageHasRedirectSettings: () => false
        })
        .render();

      const emailRedirectSection = find('div[data-e2e="pay-redirect-section"]');

      expect(emailRedirectSection).toHaveFound(1);
      expect(emailRedirectSection.nativeElement.innerHTML).toContain(
        'myadp-pay.GO_PAPERLESS_SETTINGS_PAY_REDIRECT_TIP'
      );
    });

    it('should not show a redirect section', async () => {
      const { find } = await shallow
        .mock(PaperlessStore, {
          pageHasRedirectPay: () => false,
          pageHasRedirectSettings: () => false
        })
        .render();

      expect(find('div[data-e2e="email-section"]')).toHaveFound(0);
      expect(find('div[data-e2e="pay-redirect-section"]')).toHaveFound(0);
    });
  });

  describe('typeChanged', () => {
    it('should emit "pay" when paperless type changes', async () => {
      const { find, outputs } = await shallow.render();
      const options = find(
        'pay-paperless-setting-options[data-e2e="pay-paperless-setting-options"]'
      );
      options.triggerEventHandler('onPaperlessChange', true);

      expect(outputs.typeChanged.emit).toHaveBeenCalledWith(PaperlessType.PAY);
    });

    it('should emit "tax" when paperless type changes', async () => {
      const { find, outputs } = await shallow.render();
      const options = find(
        'pay-paperless-setting-options[data-e2e="tax-paperless-setting-options"]'
      );
      options.triggerEventHandler('onPaperlessChange', true);

      expect(outputs.typeChanged.emit).toHaveBeenCalledWith(PaperlessType.TAX);
    });

    it('should emit "retirement" when paperless type changes', async () => {
      const { find, outputs } = await shallow.render();
      const options = find(
        'pay-paperless-setting-options[data-e2e="retirement-paperless-setting-options"]'
      );
      options.triggerEventHandler('onNotificationChange', true);

      expect(outputs.typeChanged.emit).toHaveBeenCalledWith(PaperlessType.RETIREMENT);
    });
  });

  describe('displayConsentModal', () => {
    it('should emit true when toggling the paperless statement setting on', async () => {
      const { find, outputs } = await shallow.render();
      const options = find(
        'pay-paperless-setting-options[data-e2e="pay-paperless-setting-options"]'
      );
      options.triggerEventHandler('onPaperlessChange', true);

      expect(outputs.displayConsentModal.emit).toHaveBeenCalled();
    });

    it('should not emit anything when toggling the paperless statement setting off', async () => {
      const { find, outputs } = await shallow.render();
      const options = find(
        'pay-paperless-setting-options[data-e2e="pay-paperless-setting-options"]'
      );
      options.triggerEventHandler('onPaperlessChange', false);

      expect(outputs.displayConsentModal.emit).not.toHaveBeenCalled();
    });
  });

  describe('displayPrintConsentModal', () => {
    it('should emit true when viewing the paperless consent', async () => {
      const { find, outputs } = await shallow.render();
      const options = find(
        'pay-paperless-setting-options[data-e2e="tax-paperless-setting-options"]'
      );
      options.triggerEventHandler('onViewConsent', true);

      expect(outputs.displayPrintConsentModal.emit).toHaveBeenCalled();
    });
  });
});
