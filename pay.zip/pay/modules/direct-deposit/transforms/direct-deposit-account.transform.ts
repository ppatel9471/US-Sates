import { SORS } from '@myadp/common';

import { PayDistributionsUI } from '../../pay-distributions-shared/models/pay-distributions-ui';
import { mapAmountType } from '../../pay-distributions-shared/transforms/amount-type-mapping.transform';
import { AccountDetailsControls } from '../models/account-details-form.model';
import { DirectDepositAccount } from '../models/direct-deposit-account.model';
import { FormDetails } from '../models/form-details.model';

interface AccountNameOrType {
  accountName?: string;
  accountTypeName?: string;
}

export function isWisely(account: AccountNameOrType): boolean {
  return !!(
    account?.accountTypeName?.toLowerCase().indexOf('wis') > -1 ||
    account?.accountName?.toLowerCase().indexOf('wisely') > -1
  );
}

export function transformDirectDepositAccounts(
  payDistributions: PayDistributionsUI.PayDistribution[],
  payDistributionMeta: PayDistributionsUI.PayDistributionMeta,
  SOR: string,
  hasChangePermission: boolean
): DirectDepositAccount[] {
  return payDistributions.map((payDistribution) => {
    const isDailyPay = isEWA(payDistribution, payDistributionMeta);
    const isAVSEmailNotConfigured =
      !payDistributionMeta?.isEmailConfigured && SOR === SORS.US.AVSDDM;
    const isReadOnly = !hasChangePermission || isDailyPay || isAVSEmailNotConfigured;
    const hasAltWorkflow = !!payDistribution.pendingEvent?.altWorkflowMessage;
    return {
      isReadOnly,
      isWisely: isWisely(payDistribution?.pendingData) || isWisely(payDistribution?.currentData),
      isDailyPay,
      hasAltWorkflow,
      ...payDistribution
    } as DirectDepositAccount;
  });
}

export function transformFormDetails(
  isNewAccount: boolean,
  accountChanges: FormDetails,
  directDepositAccounts: DirectDepositAccount[]
): DirectDepositAccount {
  const modifiedAccount = !isNewAccount
    ? directDepositAccounts?.find(
      ({ currentData, pendingData }) => (pendingData ?? currentData)?.id === accountChanges?.id
    )
    : null;

  const { longName, shortName, value } = accountChanges?.[AccountDetailsControls.ACCOUNT_TYPE_CODE];
  const [accountName, accountTypeName] = [
    accountChanges?.[AccountDetailsControls.ACCOUNT_NAME],
    accountChanges?.accountTypeName || longName || shortName || value
  ];

  return {
    ...modifiedAccount,
    currentData: modifiedAccount?.currentData ?? null,
    isWisely: isWisely({ accountName, accountTypeName }),
    pendingData: {
      id:
        (modifiedAccount?.pendingData ?? modifiedAccount?.currentData)?.id ??
        new Date().toISOString(),
      codeValueData: {
        ...accountChanges?.codeValueData,
        accountCode:
          accountChanges?.[AccountDetailsControls.ACCOUNT_TYPE_CODE]?.value ??
          accountChanges?.codeValueData?.accountCode,
        ...(shortName && { shortName }),
        ...(longName && { longName })
      },
      accountName,
      accountTypeName,
      ...(accountChanges?.transitNumber && {
        transitNumber: accountChanges?.[AccountDetailsControls.TRANSIT_NUMBER]
      }),
      ...(accountChanges?.institution && {
        institution: accountChanges?.[AccountDetailsControls.INSTITUTION]?.value
      }),
      accountNumber: accountChanges?.[AccountDetailsControls.ACCOUNT_NUMBER],
      routingNumber: accountChanges?.[AccountDetailsControls.ROUTING_NUMBER],
      prenoteIndicator: accountChanges?.prenoteIndicator || false,
      ...transformAccountAmountDetails(accountChanges)
    },
    pendingEvent: modifiedAccount?.pendingEvent ? {} : null
  };
}

function transformAccountAmountDetails({
  distributionType,
  percentageAmount = null,
  flatAmount = null
}: Partial<FormDetails>): Partial<PayDistributionsUI.PayDistributionDetails> {
  return mapAmountType({
    type: distributionType,
    percentage: Number(percentageAmount),
    amount: { amountValue: Number(flatAmount?.replace(/,/g, '')), currencyCode: 'USD' }
  });
}

// Earned Wage Access
function isEWA(
  distribution: PayDistributionsUI.PayDistribution,
  meta: PayDistributionsUI.PayDistributionMeta
): boolean {
  const DAILY_PAY_SHORT_NAME: string = 'DailyPay';
  const accountCodeValue: string = distribution?.currentData?.codeValueData?.accountCode;
  const { codeList, readOnly = false } = meta?.paymentMethodCodes ?? {};

  const isDailyPayAccount = !!codeList?.find(
    (codeListItem) =>
      codeListItem?.codeValue === accountCodeValue &&
      codeListItem?.shortName === DAILY_PAY_SHORT_NAME
  );

  return isDailyPayAccount && readOnly;
}
