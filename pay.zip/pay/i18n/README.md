# Tax Withholding Messages Bundle Patterns #
Note: html tags should only be used for help content.

- TWM_{state}_{step}_STEP_TITLE
- TWM_{state}_{step}_STEP_HELP

- TWM_{state}_{step}_{field}_LABEL
- TWM_{state}_{step}_{field}_SUB_LABEL
- TWM_{state}_{step}_{field}_ERROR_{type}
- TWM_{state}_{step}_{field}_{option}_LABEL
- TWM_{state}_{step}_{field}_{option}_HELP_TITLE
- TWM_{state}_{step}_{field}_{option}_HELP_CONTENT
