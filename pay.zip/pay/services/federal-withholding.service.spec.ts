import { fakeAsync, TestBed, tick } from '@angular/core/testing';
import { Mock } from 'ts-mockery';

import { BaseHttpClient } from '@myadp/common';
import { PAY_SFFO } from '@myadp/pay-shared';

import { UsFederalTaxWithholdingElections } from '../models/us-federal-tax-withholding-election.model';
import { FederalWithholdingTransformService } from '../modules/shared/services/federal-withholding-transform.service';
import { WorkerUSFederalWithholdingElectionChangeEvent } from '../modules/tax-withholding-management/us/shared/models/state-income-tw-election-event';
import { FederalWithholdingService } from './federal-withholding.service';

describe('FederalWithholdingService', () => {
  let service: FederalWithholdingService,
    federalWithholdingTransformService: FederalWithholdingTransformService;
  const mockResponse: UsFederalTaxWithholdingElections = {
    usFederalTaxWithholdingElections: [
      {
        usFederalIncomeTaxWithholdingElection: { additionalTaxPercentage: 0.2 }
      }
    ]
  };
  const mockEvent: WorkerUSFederalWithholdingElectionChangeEvent = {
    data: {
      eventContext: {
        worker: {
          associateOID: 'mockAOID'
        },
        payrollGroupCode: {
          codeValue: 'myPayrollGroupCode'
        },
        payrollRegionCode: {
          codeValue: 'myPayrollRegionCode'
        }
      },
      transform: {
        effectiveDateTime: '',
        usFederalTaxWithholdingElection: {
          taxWithholdingAllowanceQuantity: 10
        }
      }
    },
    actor: {
      associateOID: 'mockAOID'
    },
    serviceCategoryCode: null,
    eventNameCode: null
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        FederalWithholdingService,
        {
          provide: BaseHttpClient,
          useValue: Mock.of<BaseHttpClient>({
            get: () => Promise.resolve<UsFederalTaxWithholdingElections>(mockResponse),
            post: () =>
              Promise.resolve<{
                events: WorkerUSFederalWithholdingElectionChangeEvent[];
              }>({ events: [mockEvent] })
          })
        },
        {
          provide: FederalWithholdingTransformService,
          useValue: Mock.of<FederalWithholdingTransformService>({
            getWithholdingItems: () => [
              {
                isCompleted: false
              }
            ]
          })
        }
      ]
    });

    service = TestBed.inject(FederalWithholdingService);
    federalWithholdingTransformService = TestBed.inject(FederalWithholdingTransformService);
  });

  it('should get federal withholding', (done: DoneFn) => {
    service.getFederalWithholding().then((res: UsFederalTaxWithholdingElections) => {
      expect(res).toEqual(mockResponse);
      done();
    });
  });

  it('should post federal withholding', (done: DoneFn) => {
    const mockClient = TestBed.inject(BaseHttpClient);
    const postSpy = mockClient.post as jasmine.Spy;
    const mockBody: Object = { mockEvents: 'mockEvents' };
    service
      .saveWithholding(mockBody)
      .subscribe((res: { events: WorkerUSFederalWithholdingElectionChangeEvent[] }) => {
        const actual = postSpy.calls.first().args[0];
        expect(actual.userPermission).toEqual(PAY_SFFO.TAX_WITHHOLDING_FEDERAL_CHANGE);
        expect(actual.payload).toEqual(mockBody);
        expect(res).toEqual({ events: [mockEvent] });
        done();
      });
  });

  it('should recall federal withholding', (done: DoneFn) => {
    const mockClient = TestBed.inject(BaseHttpClient);
    const postSpy = mockClient.post as jasmine.Spy;
    service.recallWithholding().subscribe(() => {
      const actual = postSpy.calls.first().args[0];
      expect(actual.userPermission).toEqual(PAY_SFFO.TAX_WITHHOLDING_FEDERAL_CHANGE);
      expect(actual.urlTransform('/url')).toEqual('/recall/url');
      done();
    });
  });

  describe('isFederalWithholdingComplete', () => {
    it('should return false', fakeAsync(() => {
      service.isFederalWithholdingComplete().subscribe((isComplete) => {
        expect(isComplete).toBe(false);
      });
      tick();
    }));

    it('should return true', fakeAsync(() => {
      Mock.extend(federalWithholdingTransformService).with({
        getWithholdingItems: () => {
          return [
            {
              isCompleted: true
            }
          ];
        }
      });

      service.isFederalWithholdingComplete().subscribe((isComplete) => {
        expect(isComplete).toBe(true);
      });
      tick();
    }));
  });
});
