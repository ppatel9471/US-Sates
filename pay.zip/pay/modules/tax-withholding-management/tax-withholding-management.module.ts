import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CoreModule } from '@synerg/angular-components';
import { AlertModule } from '@synerg/components/alert';
import { BusyIndicatorModule } from '@synerg/components/busy-indicator';
import { ButtonModule } from '@synerg/components/button';
import { CheckboxModule } from '@synerg/components/checkbox';
import { DatePickerModule } from '@synerg/components/date-picker';
import { FormGroupModule } from '@synerg/components/form-group';
import { IconModule } from '@synerg/components/icon';
import { ListViewModule } from '@synerg/components/list-view';
import { ModalModule } from '@synerg/components/modal';
import { ObfuscationModule } from '@synerg/components/obfuscation';
import { ProgressBarModule } from '@synerg/components/progress-bar';
import { RadioGroupModule } from '@synerg/components/radio-group';
import { SelectModule } from '@synerg/components/select';
import { DateFormatService } from '@synerg/components/shared';
import { SnackbarModule } from '@synerg/components/snackbar';
import { TextareaModule } from '@synerg/components/textarea';
import { TextboxModule } from '@synerg/components/textbox';
import { TileModule } from '@synerg/components/tile';
import { PdfViewerModule } from 'ng2-pdf-viewer';

import { MyAdpCommonModule } from '@myadp/common';
import { FeedbackModule } from '@myadp/feedback';
import { MyAdpFormsModule } from '@myadp/forms';

import { ValidDateDirective } from '../../directives/valid-date.directive';
import { MetaModule } from '../meta/meta.module';
import { SharedModule } from '../shared/shared.module';
import { SHARED_COMPONENTS } from './shared';
import { ElectronicSignatureComponent } from './shared/steps/electronic-signature/electronic-signature.component';
import { WizardContainerComponent } from './shared/steps/wizard-container/wizard-container.component';
import { WizardProgressBarComponent } from './shared/steps/wizard-progress-bar/wizard-progress-bar.component';
import { AL_COMPONENTS } from './us/al';
import { AR_COMPONENTS } from './us/ar';
import { AZ_COMPONENTS } from './us/az';
import { CA_COMPONENTS } from './us/ca';
import { CO_COMPONENTS } from './us/co';
import { CO2019_COMPONENTS } from './us/co2019';
import { CO2022_COMPONENTS } from './us/co2022';
import { CT_COMPONENTS } from './us/ct';
import { DC_COMPONENTS } from './us/dc';
import { DE_COMPONENTS } from './us/de';
import { FED_COMPONENTS } from './us/fed';
import { GA_COMPONENTS } from './us/ga';
import { HI_COMPONENTS } from './us/hi';
import { IA_COMPONENTS } from './us/ia';
import { ID_COMPONENTS } from './us/id';
import { IL_COMPONENTS } from './us/il';
import { IN_COMPONENTS } from './us/in';
import { KS_COMPONENTS } from './us/ks';
import { KY_COMPONENTS } from './us/ky';
import { LA_COMPONENTS } from './us/la';
import { MA_COMPONENTS } from './us/ma';
import { MD_COMPONENTS } from './us/md';
import { ME_COMPONENTS } from './us/me';
import { MI_COMPONENTS } from './us/mi';
import { MN_COMPONENTS } from './us/mn';
import { MO_COMPONENTS } from './us/mo';
import { MS_COMPONENTS } from './us/ms';
import { MT_COMPONENTS } from './us/mt';
import { NC_COMPONENTS } from './us/nc';
import { ND_COMPONENTS } from './us/nd';
import { ND2019_COMPONENTS } from './us/nd2019';
import { NE_COMPONENTS } from './us/ne';
import { NE2019_COMPONENTS } from './us/ne2019';
import { NJ_COMPONENTS } from './us/nj';
import { NM_COMPONENTS } from './us/nm';
import { NM2019_COMPONENTS } from './us/nm2019';
import { NY_COMPONENTS } from './us/ny';
import { OH_COMPONENTS } from './us/oh';
import { OH2020_COMPONENTS } from './us/oh2020';
import { OK_COMPONENTS } from './us/ok';
import { OR_COMPONENTS } from './us/or';
import { PA_COMPONENTS } from './us/pa';
import { PA2020_COMPONENTS } from './us/pa2020';
import { RI_COMPONENTS } from './us/ri';
import { SC_COMPONENTS } from './us/sc';
import { US_SHARED_COMPONENTS } from './us/shared';
import { UT_COMPONENTS } from './us/ut';
import { UT2019_COMPONENTS } from './us/ut2019';
import { VA_COMPONENTS } from './us/va';
import { VT_COMPONENTS } from './us/vt';
import { WI_COMPONENTS } from './us/wi';
import { WV_COMPONENTS } from './us/wv';

@NgModule({
  imports: [
    CommonModule,
    MyAdpCommonModule,
    MyAdpFormsModule,
    FormsModule,
    ReactiveFormsModule,
    SnackbarModule,
    ButtonModule,
    CheckboxModule,
    SelectModule,
    TileModule,
    ListViewModule,
    FeedbackModule,
    DatePickerModule,
    ProgressBarModule,
    AlertModule,
    IconModule,
    BusyIndicatorModule,
    ObfuscationModule,
    ModalModule,
    SharedModule,
    PdfViewerModule,
    MetaModule,
    RadioGroupModule,
    TextboxModule,
    TextareaModule,
    FormGroupModule,
    CoreModule
  ],
  declarations: [
    ...AL_COMPONENTS,
    ...AR_COMPONENTS,
    ...AZ_COMPONENTS,
    ...CA_COMPONENTS,
    ...CO_COMPONENTS,
    ...CO2019_COMPONENTS,
    ...CO2022_COMPONENTS,
    ...CT_COMPONENTS,
    ...DC_COMPONENTS,
    ...DE_COMPONENTS,
    ...FED_COMPONENTS,
    ...GA_COMPONENTS,
    ...HI_COMPONENTS,
    ...IA_COMPONENTS,
    ...ID_COMPONENTS,
    ...IL_COMPONENTS,
    ...IN_COMPONENTS,
    ...KS_COMPONENTS,
    ...KY_COMPONENTS,
    ...LA_COMPONENTS,
    ...MA_COMPONENTS,
    ...ME_COMPONENTS,
    ...MD_COMPONENTS,
    ...MI_COMPONENTS,
    ...MN_COMPONENTS,
    ...MO_COMPONENTS,
    ...MS_COMPONENTS,
    ...MT_COMPONENTS,
    ...NC_COMPONENTS,
    ...ND_COMPONENTS,
    ...ND2019_COMPONENTS,
    ...NE_COMPONENTS,
    ...NE2019_COMPONENTS,
    ...NJ_COMPONENTS,
    ...NM_COMPONENTS,
    ...NM2019_COMPONENTS,
    ...NY_COMPONENTS,
    ...OH_COMPONENTS,
    ...OH2020_COMPONENTS,
    ...OK_COMPONENTS,
    ...OR_COMPONENTS,
    ...PA_COMPONENTS,
    ...PA2020_COMPONENTS,
    ...RI_COMPONENTS,
    ...SC_COMPONENTS,
    ...UT_COMPONENTS,
    ...UT2019_COMPONENTS,
    ...WI_COMPONENTS,
    ...VA_COMPONENTS,
    ...VT_COMPONENTS,
    ...WV_COMPONENTS,
    ...SHARED_COMPONENTS,
    ...US_SHARED_COMPONENTS,
    ValidDateDirective
  ],
  exports: [WizardContainerComponent, WizardProgressBarComponent, ElectronicSignatureComponent],
  providers: [DateFormatService]
})
export class TaxWithholdingManagementModule {}
