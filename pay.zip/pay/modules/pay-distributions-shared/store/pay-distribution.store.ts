import { Injectable } from '@angular/core';
import { combineLatest, Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { BaseStore } from '@myadp/pay-shared';

import {
  PayDistributionsStoreSlice,
  PayDistributionsStoreState,
  PayDistributionsUI
} from '../models/pay-distributions-ui';
import { CountryDetails } from '../models/country';

@Injectable({
  providedIn: 'root'
})
export class PayDistributionStore extends BaseStore<PayDistributionsStoreState> {
  constructor() {
    super({
      [PayDistributionsStoreSlice.PAY_DISTRIBUTIONS]: {
        data: {
          hasChangePermission: false,
          distributions: null,
          itemID: null
        },
        loading: false,
        error: {}
      },
      [PayDistributionsStoreSlice.PAY_DISTRIBUTIONS_META]: {
        data: {
          meta: null
        },
        loading: false,
        error: {}
      }
    });
  }

  public get payDistributions$(): Observable<PayDistributionsUI.PayDistribution[]> {
    return this.getData$(PayDistributionsStoreSlice.PAY_DISTRIBUTIONS, 'distributions', null);
  }

  public get payDistributionMeta$(): Observable<PayDistributionsUI.PayDistributionMeta> {
    return this.getData$(PayDistributionsStoreSlice.PAY_DISTRIBUTIONS_META, 'meta', null);
  }

  public get hasChangePermission$(): Observable<boolean> {
    return this.getData$(PayDistributionsStoreSlice.PAY_DISTRIBUTIONS, 'hasChangePermission', null);
  }

  public get hasPayDistributions(): boolean {
    return this.getData(PayDistributionsStoreSlice.PAY_DISTRIBUTIONS, 'distributions')?.length > 0;
  }

  public get hasWiselyAccount(): boolean {
    return !!this.getData(PayDistributionsStoreSlice.PAY_DISTRIBUTIONS, 'distributions')?.some(
      (payDistribution) => {
        const current = payDistribution?.currentData?.precedenceCode;
        const pending = payDistribution?.pendingData?.precedenceCode;
        return (
          current?.toLowerCase()?.indexOf('wisely') > -1 ||
          pending?.toLowerCase()?.indexOf('wisely') > -1
        );
      }
    );
  }

  public get payDistributionsSnapshot(): PayDistributionsUI.PayDistribution[] {
    return this.getData(PayDistributionsStoreSlice.PAY_DISTRIBUTIONS, 'distributions', []);
  }

  public get itemId(): string {
    return this.getData(PayDistributionsStoreSlice.PAY_DISTRIBUTIONS, 'itemID');
  }

  public get payDistributionMetaSnapshot(): PayDistributionsUI.PayDistributionMeta {
    return this.getData(PayDistributionsStoreSlice.PAY_DISTRIBUTIONS_META, 'meta', null);
  }

  public get payDistributionCountry(): CountryDetails {
    return this.stateValue[PayDistributionsStoreSlice.PAY_DISTRIBUTIONS]?.data?.country;
  }

  public get isLoading$(): Observable<boolean> {
    return this.isSliceLoading$(
      PayDistributionsStoreSlice.PAY_DISTRIBUTIONS,
      PayDistributionsStoreSlice.PAY_DISTRIBUTIONS_META
    );
  }

  public get isPayDistributionsLoading$(): Observable<boolean> {
    return this.isSliceLoading$(PayDistributionsStoreSlice.PAY_DISTRIBUTIONS);
  }

  public get hasDistributionError$(): Observable<boolean> {
    return combineLatest([
      this.hasError$(PayDistributionsStoreSlice.PAY_DISTRIBUTIONS, 'distributionsError'),
      this.hasError$(
        PayDistributionsStoreSlice.PAY_DISTRIBUTIONS_META,
        'distributionsMetaError'
      )
    ]).pipe(
      map(
        ([payDistributionsError, payDistributionsMetaError]) =>
          payDistributionsError || payDistributionsMetaError
      )
    );
  }
}
