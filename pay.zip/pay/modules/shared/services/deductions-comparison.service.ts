import { Injectable } from '@angular/core';

import { PayDeductionsUI } from '../../pay-deductions-shared/models/pay-deductions-ui';
import { DeductionComparisonDetails } from '../models/workflow-comparison-details.model';
import { WorkflowUI } from '../models/workflow-ui.model';
import { WorkflowComparisonService } from './workflow-comparison.service';

@Injectable({
  providedIn: 'root'
})
export class DeductionsComparisonService extends WorkflowComparisonService<
PayDeductionsUI.Deduction,
DeductionComparisonDetails
> {
  public getComparisonData(
    deduction: PayDeductionsUI.Deduction
  ): [DeductionComparisonDetails, DeductionComparisonDetails] {
    const currentData = this.mapToComparisonDetails(deduction?.currentData);
    const pendingData = this.mapToComparisonDetails(deduction?.pendingData);

    const actionTypeLookup: Record<
    WorkflowUI.ChangeType,
    () => [DeductionComparisonDetails, DeductionComparisonDetails]
    > = {
      add: () => [
        { addOrDeleteMsg: 'myadp-pay.DEDUCTIONS_WORKFLOW_COMPARISON_PENDING_ADD' },
        pendingData
      ],
      delete: () => [
        currentData,
        { addOrDeleteMsg: 'myadp-pay.DEDUCTIONS_WORKFLOW_COMPARISON_PENDING_DELETE' }
      ],
      edit: () => [currentData, this.getDifferences([currentData, pendingData])]
    };

    return actionTypeLookup?.[deduction?.pendingEvent?.changeType]?.();
  }

  private mapToComparisonDetails(
    data: PayDeductionsUI.DeductionDetails
  ): Partial<DeductionComparisonDetails> {
    return {
      ...data,
      displayAmount: data?.deductionRate ? this.getDisplayAmount(data) : null,
      goalDisplayAmount: data?.deductionGoal ? this.getGoalDisplayAmount(data) : null
    };
  }

  private getDifferences([currentData, pendingData]: [
    DeductionComparisonDetails,
    DeductionComparisonDetails
  ]): Partial<DeductionComparisonDetails> {
    const differences: Partial<PayDeductionsUI.DeductionDetails> = {};

    if (currentData?.deductionRate?.rateValue !== pendingData?.deductionRate?.rateValue) {
      differences['deductionRate'] = pendingData?.deductionRate;
    }

    if (
      currentData?.deductionGoal?.goalLimitAmount?.amountValue !==
      pendingData?.deductionGoal?.goalLimitAmount?.amountValue
    ) {
      differences['deductionGoal'] = pendingData?.deductionGoal;
    }

    return this.mapToComparisonDetails(differences);
  }

  private getDisplayAmount(
    deductionDetails: Partial<PayDeductionsUI.DeductionDetails>
  ): string | null {
    const deductionRate = deductionDetails?.deductionRate;
    if (!deductionRate?.rateValue) {
      return this.formatCurrency({
        amountValue: 0,
        currencyCode: deductionRate?.currencyCode
      });
    } else {
      const isPercentRate = String(deductionRate?.unitCode?.codeValue === 'percent');
      return {
        true: () => this.formatPercentage(deductionRate?.rateValue),
        false: () =>
          this.formatCurrency({
            amountValue: deductionRate?.rateValue,
            currencyCode: deductionRate?.currencyCode
          })
      }[isPercentRate]?.();
    }
  }

  private getGoalDisplayAmount(
    deductionDetails: Partial<PayDeductionsUI.DeductionDetails>
  ): string | null {
    const goalLimitAmount = deductionDetails?.deductionGoal?.goalLimitAmount;
    if (!goalLimitAmount?.amountValue) {
      return this.formatCurrency({
        amountValue: 0,
        currencyCode: goalLimitAmount?.currencyCode
      });
    } else {
      return this.formatCurrency(goalLimitAmount);
    }
  }
}
