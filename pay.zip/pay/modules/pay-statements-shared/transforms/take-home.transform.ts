import { Amount, PayStatementsDTO } from '@myadp/dto';

import { PayStatementsUI } from '../models/pay-statement-ui';
import { deductionCategoryMetadata } from '../constants/deduction-category-metadata.const';
import { buildCalculatorLink } from './category-calculator-link.transform';

// TODO: should this be generic and not specific to takehome?
export function buildCategory(
  categoryId: string,
  statementDetails: PayStatementsDTO.PayStatementDetailRaw
): PayStatementsUI.DeductionsCategory {
  const donutMetadata = deductionCategoryMetadata[categoryId];
  const takeHomeAmount: Amount = statementDetails?.netPayAmount;

  return {
    id: categoryId,
    name: donutMetadata.name,
    amount: takeHomeAmount,
    deductions: getDistributions(statementDetails),
    displayConfig: {
      ...donutMetadata.displayConfig,
      calculatorLink: buildCalculatorLink(categoryId, takeHomeAmount, null)
    }
  };
}

function getDistributions(
  statementDetails: PayStatementsDTO.PayStatementDetailRaw
): PayStatementsUI.DeductionsCategoryItem[] {
  const payDistributions = statementDetails?.payDistributions;
  const distributionLookup = {
    true: () => {
      let distributions: PayStatementsDTO.Distribution[] = [];

      /**
       * Legacy statement-details API returns 'payDistributions'
       * as an Object instead of an Array
       */
      if (!Array.isArray(payDistributions)) {
        distributions = payDistributions?.distributions;
      } else {
        distributions = getPayDistributionInfo(payDistributions);
      }
      return distributions?.map((pd) => getMappedPayDistributions(pd));
    },
    false: () => {
      const directDeposits = statementDetails?.directDeposits;
      return directDeposits?.map((dd) => getMappedDirectDeposits(dd));
    }
  };

  // if payDistributions is valid, use it; otherwise, use directDeposits
  return distributionLookup[`${!!payDistributions}`]();
}

function getPayDistributionInfo(
  payDistributions: PayStatementsDTO.PayDistribution[]
): PayStatementsDTO.PayDistribution[] {
  const distributions = payDistributions?.map(
    (payDistribution) => payDistribution['distributions']
  );
  const flattenedDistributions: PayStatementsDTO.PayDistribution[] = [].concat(...distributions);

  // remove falsey values
  return flattenedDistributions.filter((distribution) => !!distribution);
}

function getMappedPayDistributions(
  distribution: PayStatementsDTO.Distribution
): PayStatementsUI.DeductionsCategoryItem {
  const name: string =
    distribution?.depositAccount?.financialAccount?.typeCode?.shortName ??
    distribution?.paymentMethodCode?.shortName;
  const accountNumber: string = distribution?.depositAccount?.financialAccount?.accountNumber;
  const amount: Amount = distribution?.distributionAmount;

  return buildCategoryItem(name, accountNumber, amount);
}

function getMappedDirectDeposits(
  directDeposit: PayStatementsDTO.DirectDeposit
): PayStatementsUI.DeductionsCategoryItem {
  const name: string = directDeposit?.financialAccountTypeName;
  const accountNumber: string = directDeposit?.financialAccountID;
  const amount: Amount = directDeposit?.depositAmount;

  return buildCategoryItem(name, accountNumber, amount);
}

function buildCategoryItem(
  name: string,
  accountNumber: string,
  amount: Amount
): PayStatementsUI.DeductionsCategoryItem {
  const useOnlyName = !!name && !accountNumber;
  const useOnlyAccountNumber = !name && !!accountNumber;
  const useBoth = !!name && !!accountNumber;
  let _name: string;

  name = name?.trim() ?? name;
  accountNumber = accountNumber?.trim() ?? accountNumber;

  if (useOnlyName) {
    _name = name;
  } else if (useOnlyAccountNumber) {
    _name = accountNumber;
  } else if (useBoth) {
    _name = `${name} (${accountNumber})`;
  }

  return {
    name: _name,
    amount: amount
  };
}
