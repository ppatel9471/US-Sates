export { PayTasksModule } from './modules/tasks/pay-tasks.module';
