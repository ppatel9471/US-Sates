import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { RawMetaObject } from '@myadp/forms';
import { BaseStore } from '@myadp/pay-shared';

import {
  PayDeductionsStoreSlice,
  PayDeductionsStoreState,
  PayDeductionsUI
} from '../models/pay-deductions-ui';

@Injectable({
  providedIn: 'root'
})
export class PayDeductionsStore extends BaseStore<PayDeductionsStoreState> {
  constructor() {
    super({
      [PayDeductionsStoreSlice.PAY_DEDUCTIONS]: {
        data: null,
        loading: false,
        error: {}
      },
      [PayDeductionsStoreSlice.PAY_DEDUCTIONS_INITIAL]: {
        data: null
      },
      [PayDeductionsStoreSlice.PAY_DEDUCTIONS_META]: {
        data: {
          rawStartMeta: null
        },
        loading: false,
        error: {}
      }
    });
  }

  public get payDeductions$(): Observable<PayDeductionsUI.Deduction[]> {
    return this.getData$(PayDeductionsStoreSlice.PAY_DEDUCTIONS, undefined, null);
  }

  public get payDeductionsSnapshot(): PayDeductionsUI.Deduction[] {
    return this.getData(PayDeductionsStoreSlice.PAY_DEDUCTIONS);
  }

  public get payDeductionsInitialSnapshot(): PayDeductionsUI.Deduction[] {
    return this.getData(PayDeductionsStoreSlice.PAY_DEDUCTIONS_INITIAL);
  }

  public get payDeductionsStartMeta$(): Observable<RawMetaObject> {
    return this.getData$(PayDeductionsStoreSlice.PAY_DEDUCTIONS_META, 'rawStartMeta', null);
  }

  public payDeductionAddFormMeta$(itemID: string): Observable<RawMetaObject> {
    return this.state$.pipe(
      map((state) => state?.payDeductionsStartMeta?.data?.addFormMeta?.[itemID] ?? null),
      this.distinctUntilChangedObj()
    );
  }

  public payDeductionEditFormMeta$(itemID: string): Observable<RawMetaObject> {
    return this.state$.pipe(
      map((state) => state?.payDeductionsStartMeta?.data?.editFormMeta?.[itemID] ?? null),
      this.distinctUntilChangedObj()
    );
  }

  public payDeductionMetaItemSnapshot(itemID: string, isEdit: boolean): RawMetaObject {
    return (
      this.getData(
        PayDeductionsStoreSlice.PAY_DEDUCTIONS_META,
        !isEdit ? 'addFormMeta' : 'editFormMeta'
      )?.[itemID] ?? null
    );
  }

  public get hasDeductionError$(): Observable<boolean> {
    return this.hasError$(PayDeductionsStoreSlice.PAY_DEDUCTIONS, 'deductionsError');
  }

  public get hasDeductionStopError$(): Observable<boolean> {
    return this.hasError$(PayDeductionsStoreSlice.PAY_DEDUCTIONS, 'stopError');
  }

  public get hasDeductionMetaError$(): Observable<boolean> {
    return this.hasError$(PayDeductionsStoreSlice.PAY_DEDUCTIONS_META, 'deductionMetaError');
  }

  public get hasDeductionMetaError(): boolean {
    return this.hasError(PayDeductionsStoreSlice.PAY_DEDUCTIONS_META, 'deductionMetaError');
  }

  public get hasPayDeductionsStartMeta(): boolean {
    return !!this.getData(PayDeductionsStoreSlice.PAY_DEDUCTIONS_META, 'rawStartMeta');
  }

  public get isPayDeductionsLoading$(): Observable<boolean> {
    return this.isSliceLoading$(PayDeductionsStoreSlice.PAY_DEDUCTIONS);
  }

  public get isPayDeductionsMetaLoading$(): Observable<boolean> {
    return this.isSliceLoading$(PayDeductionsStoreSlice.PAY_DEDUCTIONS_META);
  }
}
