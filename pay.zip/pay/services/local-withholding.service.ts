import { Injectable } from '@angular/core';
import { get } from 'lodash';

import { BaseHttpClient } from '@myadp/common';
import { PAY_SFFO } from '@myadp/pay-shared';
import { UsLocalTaxInstruction } from '../models/us-local-tax-instruction.model';

@Injectable({
  providedIn: 'root'
})
export class LocalWithholdingService {
  constructor(private httpClient: BaseHttpClient) {}

  getLocalWithholding(): Promise<UsLocalTaxInstruction[]> {
    return this.httpClient
      .get<UsLocalTaxInstruction>({
      userPermission: PAY_SFFO.TAX_WITHHOLDING_LOCAL_READ
    })
      .then(response => {
        const instructions = get<UsLocalTaxInstruction[]>(
          response,
          'usTaxProfiles[0].usLocalTaxInstructions'
        );
        return instructions;
      });
  }
}
