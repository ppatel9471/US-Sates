import { ClientDeviceService } from '@espresso/core';
import { BehaviorSubject, of } from 'rxjs';
import { Shallow } from 'shallow-render';
import { Mock } from 'ts-mockery';

import { LanguagePipe } from '@myadp/common';
import {
  ForcedDialogPageType,
  PaperlessStore,
  PaperlessStoreActions
} from '@myadp/pay-paperless-shared';
import { PayPermissionService } from '@myadp/pay-shared';

import { PaperlessModule } from '../../paperless.module';
import { ForcedDialogComponent } from './forced-dialog.component';

describe('ForcedDialogComponent', () => {
  let shallow: Shallow<ForcedDialogComponent>;

  beforeEach(() => {
    shallow = new Shallow(ForcedDialogComponent, PaperlessModule)
      .mockPipe(LanguagePipe, (key) => key)
      .mock(PayPermissionService, { canViewPayAndTaxStatements: () => false })
      .mock(ClientDeviceService, {
        isNative: () => false
      })
      .mock(PaperlessStore, {
        showForcedDialog$: () => of(true),
        forcedDialogClosed$: Mock.of<BehaviorSubject<boolean>>({ next: () => Mock.noop })
      })
      .mock(PaperlessStoreActions, { getAllPreferences: () => Mock.noop });
  });

  it('should setDisplayScreen', async () => {
    const { find, instance, fixture } = await shallow.render();
    instance.setDisplayScreen(ForcedDialogPageType.INTRO, true);
    fixture.detectChanges();

    expect(find('forced-dialog-intro')).toHaveFound(1);
  });

  it('should hide all screens', async () => {
    const { find, instance, fixture } = await shallow.render();
    instance.showScreen();
    fixture.detectChanges();

    expect(find('forced-dialog-intro')).toHaveFound(0);
    expect(find('forced-dialog-consent')).toHaveFound(0);
    expect(find('forced-dialog-email')).toHaveFound(0);
    expect(find('forced-dialog-done')).toHaveFound(0);
    expect(find('forced-dialog-logout')).toHaveFound(0);
    expect(find('close-confirm')).toHaveFound(0);
  });

  it('should show logout screen if user is tax only', async () => {
    const { find, instance, fixture } = await shallow.render();
    instance.closeForcedDialog();
    fixture.detectChanges();

    expect(find('forced-dialog-logout')).toHaveFound(1);
  });

  it('should not show logout screen if user is not tax only', async () => {
    const { find, instance, fixture } = await shallow
      .mock(PayPermissionService, { canViewPayAndTaxStatements: () => true })
      .render();
    instance.closeForcedDialog();
    fixture.detectChanges();

    expect(find('forced-dialog-logout')).toHaveFound(0);
  });

  it('should not show any screens when exiting on native mobile', async () => {
    const { find, instance, fixture } = await shallow
      .mock(ClientDeviceService, {
        isNative: () => true
      })
      .render();
    instance.closeForcedDialog();
    fixture.detectChanges();

    expect(find('forced-dialog-intro')).toHaveFound(0);
    expect(find('forced-dialog-consent')).toHaveFound(0);
    expect(find('forced-dialog-email')).toHaveFound(0);
    expect(find('forced-dialog-done')).toHaveFound(0);
    expect(find('forced-dialog-logout')).toHaveFound(0);
    expect(find('close-confirm')).toHaveFound(0);
  });
});
