import { TestBed } from '@angular/core/testing';
import { Mock } from 'ts-mockery';
import { BaseHttpClient } from '@myadp/common';
import { WorkerTaxStatementsDTO } from '@myadp/dto';

import { PayPermissionService, PAY_SFFO } from '@myadp/pay-shared';
import { TaxStatementsService } from './tax-statements.service';

describe('TaxStatementsService', () => {
  let service: TaxStatementsService;
  let baseHttpClient: BaseHttpClient;
  let payPermissionService: PayPermissionService;

  const mockStatements: WorkerTaxStatementsDTO.APIResponse = {
    workerTaxStatements: [
      {
        statementName: '2013 W-2',
        employerName: 'AUTOMATIC DATA PROCESSING',
        form: {
          code: '1095-C'
        },

        statementYear: {
          year: '2013'
        },
        summaryAmount: {
          amountValue: 20130,
          currencyCode: 'USD'
        },
        statementImageUri: {
          href: 'mockPDF.pdf'
        }
      }
    ]
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        TaxStatementsService,
        {
          provide: BaseHttpClient,
          useValue: Mock.of<BaseHttpClient>({
            get: () => Promise.resolve<WorkerTaxStatementsDTO.APIResponse>(mockStatements)
          })
        },
        {
          provide: PayPermissionService,
          useValue: Mock.of<PayPermissionService>({
            hasTaxStatementsReadPermission: () => true
          })
        }
      ]
    });

    service = TestBed.inject(TaxStatementsService);
    baseHttpClient = TestBed.inject(BaseHttpClient);
    payPermissionService = TestBed.inject(PayPermissionService);
  });

  it('should get tax statements', async () => {
    service.getTaxStatements().then((response) => expect(response).toEqual(mockStatements));
    expect(baseHttpClient.get).toHaveBeenCalledWith({
      userPermission: PAY_SFFO.TAX_STATEMENTS_READ
    });
  });

  it('should get tax statements', async () => {
    Mock.extend(payPermissionService).with({
      hasTaxStatementsReadPermission: () => false
    });
    service.getTaxStatements().then((response) => expect(response).toEqual(mockStatements));
    expect(baseHttpClient.get).toHaveBeenCalledWith({
      userPermission: PAY_SFFO.TAX_STATEMENTS_READ_LEGACY
    });
  });
});
