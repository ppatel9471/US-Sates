import { camelCase } from 'lodash';

import {
  Insight,
  INSIGHTS_TAG
} from '../../../models/payment-calculation-analysis.model';
import { PayStatementsUI } from '../models/pay-statement-ui';

export function transformInsights(
  insights: Insight[],
  deductionsCategories: PayStatementsUI.DeductionsCategory[]
): Record<string, Insight[]> {
  // TODO: might need this in the future
  // let insights = insights?.sort((i1, i2) => i2.rank - i1.rank);

  if (insights?.length && deductionsCategories) {
    const categorizedInsights: Record<string, Insight[]> = {};
    const tags = deductionsCategories.map((category) => {
      return category.insightsTag;
    }).filter((tag) => !!tag);
    tags.push(INSIGHTS_TAG.EARNINGS);
    for (const tag of tags) {
      const filteredInsights = insights.filter((insight) => {
        if (insight.tags) {
          insight.tags = insight.tags.map((insightTag) => camelCase(insightTag));
          return insight.tags.includes(camelCase(tag));
        }
      });
      if (filteredInsights.length > 0) {
        categorizedInsights[tag] = filteredInsights;
        insights = insights.filter((insight) => !filteredInsights.includes(insight));
      }
    }
    if (insights.length > 0) {
      categorizedInsights['top'] = insights;
    }
    return categorizedInsights;
  }
}
