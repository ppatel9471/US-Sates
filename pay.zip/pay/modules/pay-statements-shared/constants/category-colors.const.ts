// Colors approved by SynerG UX as accessible for charts
export const categoryColors: Record<string, string> = {
  accent1: '#22aa22',
  accent4: '#dd57ff',
  accent3: '#e70b5b',
  primaryLight: '#21a0c0',
  accent7: '#22aa22',
  accent4Dark: '#dd57ff',
  accent6: '#e70b5b',
  primaryDark: '#21a0c0',
  accent3Dark: '#e70b5b',
  accent7Dark: '#22aa22',
  accent4Light: '#dd57ff',
  accent6Dark: '#e70b5b',
  accent2: '#ea6f0b',
  primary: '#21a0c0'
};
