import { TestBed } from '@angular/core/testing';

import { PayStatementsUI } from '../../pay-statements-shared/models/pay-statement-ui';
import { EarningsDataSelectorPipe } from './earnings-data-selector.pipe';

describe('EarningsDataSelectorPipe', () => {
  let pipe: EarningsDataSelectorPipe;

  const mockEarnings: PayStatementsUI.Earning[] = [
    {
      name: 'Regular',
      amount: {
        amountValue: 90.23,
        currencyCode: 'USD'
      },
      rate: {
        amountValue: 4.892,
        currencyCode: 'USD'
      },
      payPeriodHours: 13,
      preTax: false
    },
    {
      name: 'NoHours',
      amount: {
        amountValue: 123.45,
        currencyCode: 'USD'
      },
      rate: {
        amountValue: 6.6,
        currencyCode: 'USD'
      },
      payPeriodHours: undefined,
      preTax: false
    },
    {
      name: 'NoRateOrHours',
      amount: {
        amountValue: 123.45,
        currencyCode: 'USD'
      },
      rate: undefined,
      payPeriodHours: undefined,
      preTax: false
    }
  ];

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [EarningsDataSelectorPipe]
    });

    pipe = new EarningsDataSelectorPipe();
  });

  it('should return formatted earnings', () => {
    const transformedEarnings = pipe.transform(mockEarnings);

    expect(transformedEarnings.length).toBe(3);
    expect(transformedEarnings[0].columns).toEqual([
      {
        label: 'myadp-pay.PAY_EARNINGS_TYPE',
        value: mockEarnings[0].name
      },
      {
        label: 'myadp-pay.PAY_EARNINGS_UNITS',
        value: mockEarnings[0].payPeriodHours
      },
      {
        label: 'myadp-pay.PAY_EARNINGS_RATE',
        value: mockEarnings[0].rate
      },
      {
        label: 'myadp-pay.PAY_EARNINGS_AMOUNT',
        value: mockEarnings[0].amount
      }
    ]);

    expect(transformedEarnings[1].columns).toEqual([
      {
        label: '',
        value: mockEarnings[1].name
      },
      {
        label: '',
        value: undefined
      },
      {
        label: '',
        value: mockEarnings[1].rate
      },
      {
        label: '',
        value: mockEarnings[1].amount
      }
    ]);

    expect(transformedEarnings[2].columns).toEqual([
      {
        label: '',
        value: mockEarnings[2].name
      },
      {
        label: '',
        value: undefined
      },
      {
        label: '',
        value: undefined
      },
      {
        label: '',
        value: mockEarnings[2].amount
      }
    ]);
  });

  it('should return earnings without amounts', () => {
    const transformedEarnings = pipe.transform([
      {
        name: 'XYZ',
        amount: {
          amountValue: 78.9,
          currencyCode: 'USD'
        },
        rate: undefined,
        payPeriodHours: 12,
        preTax: false
      }
    ]);

    expect(transformedEarnings.length).toBe(1);
    expect(transformedEarnings[0].columns).toEqual([
      {
        label: 'myadp-pay.PAY_EARNINGS_TYPE',
        value: 'XYZ'
      },
      {
        label: 'myadp-pay.PAY_EARNINGS_UNITS',
        value: 12
      },
      {
        label: 'myadp-pay.PAY_EARNINGS_RATE',
        value: undefined
      },
      {
        label: 'myadp-pay.PAY_EARNINGS_AMOUNT',
        value: { amountValue: 78.9, currencyCode: 'USD' }
      }
    ]);
  });
});
