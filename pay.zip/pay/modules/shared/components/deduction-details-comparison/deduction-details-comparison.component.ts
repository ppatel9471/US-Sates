import { Component, OnInit } from '@angular/core';

import { PayDeductionsUI } from '../../../pay-deductions-shared/models/pay-deductions-ui';
import { DeductionComparisonDetails } from '../../models/workflow-comparison-details.model';
import { DeductionsComparisonService } from '../../services/deductions-comparison.service';
import { WorkflowDetailsComparisonComponent } from '../workflow-details-comparison/workflow-details-comparison.component';

@Component({
  selector: 'vded-details-comparison',
  templateUrl: './deduction-details-comparison.component.html'
})
export class DeductionDetailsComparisonComponent
  extends WorkflowDetailsComparisonComponent<PayDeductionsUI.Deduction, DeductionComparisonDetails>
  implements OnInit {
  constructor(private comparisonService: DeductionsComparisonService) {
    super();
  }

  public ngOnInit() {
    [this.currentComparisonData, this.pendingComparisonData] =
      this.comparisonService.getComparisonData(this.data);
  }
}
