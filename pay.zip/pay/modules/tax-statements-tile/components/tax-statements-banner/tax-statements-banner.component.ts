import { Component, HostBinding } from '@angular/core';
import { modalAnimation } from '@synerg/components/modal';

@Component({
  selector: 'tax-statements-banner',
  templateUrl: 'tax-statements-banner.component.html',
  styleUrls: ['./tax-statements-banner.component.scss'],
  animations: [modalAnimation]
})
export class TaxStatementsBannerComponent {
  @HostBinding('@modalTransition') modalTransition = 'modal';
  public modalOpen: boolean = false;

  openModal() {
    this.modalOpen = true;
  }

  closeModal() {
    this.modalOpen = false;
  }
}
