import { SdfShimmer } from '@synerg/angular-components';
import { TabComponent, TabsComponent } from '@synerg/components/tabs';
import { of } from 'rxjs';
import { Shallow } from 'shallow-render';
import { Mock } from 'ts-mockery';

import { BarbecueService, LanguagePipe } from '@myadp/common';

import { PayStatementsUI } from '../../../pay-statements-shared/models/pay-statement-ui';
import { PayStatementStoreActions } from '../../../pay-statements-shared/store/pay-statement-store.actions';
import { PayStatementStore } from '../../../pay-statements-shared/store/pay-statement.store';
import { PaylensModule } from '../../paylens.module';
import { PaylensStatementDetailsTabsComponent } from '../statement-details-tabs/statement-details-tabs.component';
import { PaylensNoStatementsComponent } from '../statements-list/no-statements/no-statements.component';
import { PaylensStatementsListComponent } from '../statements-list/statements-list.component';
import { PaylensContainerComponent } from './paylens-container.component';

describe('PaylensContainerComponent', () => {
  let shallow: Shallow<PaylensContainerComponent>;

  const statement: PayStatementsUI.PayStatement = {
    id: 1,
    payDate: 'Apr 14, 2019',
    netPay: undefined,
    grossPay: { amountValue: 1732.1, currencyCode: 'USD' },
    totalHours: 80,
    payDetailUri: '/v1_0/O/A/payStatement/1074162519254260000198001043940',
    statementImageUri:
      '/l2/v1_0/O/A/payStatement/1074162519264497000198001612729/images/CERooo008000620000r701AC7680FFC521.pdf',
    payAdjustment: true,
    statementFiscalYear: '2019',
    statementType: undefined
  };

  const state = {
    payStatements: {
      data: {
        statements: [statement]
      },
      loading: false
    },
    currentStatementDetails: {
      data: {
        statement: {
          ...statement
        },
        statementDetails: {}
      }
    }
  };

  beforeEach(() => {
    shallow = new Shallow(PaylensContainerComponent, PaylensModule)
      .dontMock(PaylensStatementsListComponent)
      .dontMock(TabsComponent)
      .dontMock(TabComponent)
      .mock(BarbecueService, { isBarbecue: () => false })
      .mock(PayStatementStore, {
        isPayStatementsLoading$: of(false),
        payStatements$: of(state.payStatements.data.statements),
        currentDetailsData$: of(state.currentStatementDetails.data)
      })
      .mock(PayStatementStoreActions, {
        loadPayStatements: () => Mock.noop(),
        loadStatementDetails: () => Mock.noop()
      })
      .mockPipe(LanguagePipe, (key) => key);
  });

  it('should make call to load pay statements', async () => {
    const { get } = await shallow.render();
    const payStatementStoreActions = get(PayStatementStoreActions);
    expect(payStatementStoreActions.loadPayStatements).toHaveBeenCalled();
  });

  it('should make call to load and set current statement selected', async () => {
    const { instance, get } = await shallow.render();
    const payStatementStoreActions = get(PayStatementStoreActions);
    spyOn(instance, 'onLoadDetails').and.callThrough();
    instance.onLoadDetails(statement);

    expect(instance.onLoadDetails).toHaveBeenCalledWith(statement);
    expect(payStatementStoreActions.loadPayStatements).toHaveBeenCalled();
  });

  describe('statement view', () => {
    it('should show pay statements list', async () => {
      const { findComponent } = await shallow.render();

      expect(findComponent(PaylensStatementsListComponent)).toHaveFoundOne();
      expect(findComponent(SdfShimmer)).toHaveFound(0);
      expect(findComponent(PaylensNoStatementsComponent)).toHaveFound(0);
    });

    it('should show the no pay statements view', async () => {
      const { findComponent } = await shallow
        .mock(PayStatementStore, {
          payStatements$: of([])
        })
        .render();

      expect(findComponent(PaylensStatementsListComponent)).toHaveFound(0);
      expect(findComponent(SdfShimmer)).toHaveFound(0);
      expect(findComponent(PaylensNoStatementsComponent)).toHaveFoundOne();
    });
  });

  describe('statement details tabs', () => {
    it('should show pay statement details tabs component', async () => {
      const { findComponent } = await shallow.render();

      expect(findComponent(PaylensStatementDetailsTabsComponent)).toHaveFoundOne();
      expect(findComponent(SdfShimmer)).toHaveFound(0);
    });
  });

  describe('loading shimmer', () => {
    it('should show the loading shimmer when fetching statements', async () => {
      const { findComponent } = await shallow
        .mock(PayStatementStore, {
          payStatements$: of([statement]),
          isPayStatementsLoading$: of(true)
        })
        .render();

      expect(findComponent(PaylensStatementsListComponent)).toHaveFound(0);
      expect(findComponent(PaylensStatementDetailsTabsComponent)).toHaveFound(0);
      expect(findComponent(SdfShimmer)).toHaveFoundOne();
    });
  });

  describe('no statements view', () => {
    it('should show no statements view if we have no statements', async () => {
      const { findComponent } = await shallow
        .mock(PayStatementStore, {
          payStatements$: of([])
        })
        .render();

      expect(findComponent(PaylensNoStatementsComponent)).toHaveFoundOne();
      expect(findComponent(SdfShimmer)).toHaveFound(0);
    });
  });
});
