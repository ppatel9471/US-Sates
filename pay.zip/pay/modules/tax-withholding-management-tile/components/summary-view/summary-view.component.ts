import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { ClientDeviceService, LoggerFactory } from '@espresso/core';
import { find, get } from 'lodash';
import * as log4javascript from 'log4javascript';
import { Observable, Subscription } from 'rxjs';
import { finalize, take } from 'rxjs/operators';

import { LanguageService, NativeHelperService, SORS, UserProfileService } from '@myadp/common';
import { PayPermissionService } from '@myadp/pay-shared';

import { WithholdingInfo, WithholdingItem, WithholdingType } from '../../../../models/formatted-tax-withholding.model';
import { FEDERAL, StateModel, StateUtil } from '../../../../models/states.model';
import { PendingEventType } from '../../../../models/tax-withholding.model';
import { FederalWithholdingService } from '../../../../services/federal-withholding.service';
import { StateWithholdingService } from '../../../../services/state-withholding.service';
import { TaxWithholdingStore } from '../../../../services/tax-withholding.store';
import { PdfStatement, StatementType } from '../../../shared/models/pdf-viewer.model';
import { WithholdingFormatterService } from '../../../shared/services/withholding-formatter.service';
import { StepsService } from '../../../tax-withholding-management/shared/services/steps.service';
import { WizardContainerComponent } from '../../../tax-withholding-management/shared/steps/wizard-container/wizard-container.component';
import { FederalWithholdingHelperService } from '../../services/federal-withholding-helper.service';
import { JurisdictionFactoryService } from '../../services/jurisdiction-factory.service';
import { StateWithholdingHelperService } from '../../services/state-withholding-helper.service';

export enum TileState {
  NONE,
  NOT_SETUP,
  HAS_SETUP
}

@Component({
  selector: 'pay-summary-view',
  templateUrl: './summary-view.component.html',
  styleUrls: ['./summary-view.component.scss']
})
export class SummaryViewComponent implements OnInit, OnDestroy {
  @ViewChild('wizardModal', { static: true }) modalContent: WizardContainerComponent;
  public loading: boolean;
  public withholdingData: WithholdingInfo[];
  public activeWithholdingItems: WithholdingItem[];
  public inactiveWithholdingItems: WithholdingItem[];
  public errorMessage: string;
  public modalTitle: string;
  public tileState: TileState = TileState.NONE;
  public tileStateValue = TileState;
  public hasEditPermission: boolean;
  public expandedM: number = -1;
  public expandedN: number = -1;
  public expandedWithholdingItem: WithholdingItem;
  public pendingEmployeeInit: boolean;
  public pendingPractitionerInit: boolean;
  public approver: string;
  public cancelSuccess: boolean;
  public cancelError: boolean;
  public readonly FEDERAL = FEDERAL;
  public showWizardModal: boolean = false;
  public showExitModal: boolean = false;
  public showCancelConfirmModal: boolean = false;
  public showUpgradeModal: boolean = false;
  public statementType = StatementType;
  public statements: PdfStatement[];
  public stepUpEnabled: boolean = true;

  public showESignModal$: Observable<boolean>;
  public refreshTile$: Subscription;
  public closeModal$: Subscription;
  public closeExitModal$: Subscription;
  public wizardModalTitle$: Subscription;
  private withholdingToCancel: WithholdingItem;

  private logger: log4javascript.Logger;

  constructor(
    private payPermissionService: PayPermissionService,
    private federalWithholdingService: FederalWithholdingService,
    private federalWithholdingHelperService: FederalWithholdingHelperService,
    private stateWithholdingService: StateWithholdingService,
    private stateWithholdingHelperService: StateWithholdingHelperService,
    private withholdingFormatterService: WithholdingFormatterService,
    private languageService: LanguageService,
    private stepsService: StepsService,
    private taxWithholdingStore: TaxWithholdingStore,
    private jurisdictionFactory: JurisdictionFactoryService,
    loggerFactory: LoggerFactory,
    // TEMP: see PIMYPI-10633
    private clientDeviceService: ClientDeviceService,
    private nativeHelperService: NativeHelperService,
    private userProfileService: UserProfileService
  ) {
    this.logger = loggerFactory.getLogger(
      'myadp.pay.tax-withholding-management-tile.summary-view.component'
    );
  }

  public ngOnInit(): void {
    this.stepsService.wizardModal = this.modalContent;
    this.showESignModal$ = this.stepsService.eSignModalSubject.asObservable();
    this.refreshTile$ = this.stepsService.refreshTile.subscribe(() => {
      this.loadWithholding();
    });
    this.closeModal$ = this.stepsService.closeModalSubject.subscribe(() => {
      this.showWizardModal = false;
      this.showExitModal = false;
    });
    this.stepUpEnabled = this.isStepUpEnabled();
    this.wizardModalTitle$ = this.stepsService.wizardModalTitleSubject.subscribe((title) => {
      this.modalTitle = title;
    });
  }

  public loadWithholding(): void {
    this.loading = true;
    // get federal data first for federal states dependency on filing status
    this.loadFederalWithholding()
      .then((res) => Promise.all([Promise.resolve(res), this.loadStateWithholding()]))
      .then((res) => {
        this.withholdingData = res;
        this.activeWithholdingItems = this.taxWithholdingStore.getActiveWithholdingItems();
        this.inactiveWithholdingItems = this.taxWithholdingStore.getInactiveWithholdingItems();
        this.statements = this.taxWithholdingStore.getWithholdingForms();
        this.getErrorMessage();
        this.initWorkflow();
      })
      .finally(() => (this.loading = false));
  }

  public openModal(state: StateModel): void {
    if (this.clientDeviceService.isIOS() && this.clientDeviceService.isNative()) {
      this.nativeHelperService.compareContainerVersion('3.17.0').then((value: number) => {
        if (value > 0) {
          this.showUpgradeModal = true;
        } else {
          // same as below but why bother breaking this out for TEMP code, eh?
          this.showWizardModal = true;
          this.modalTitle = this.languageService.get(
            `myadp-pay.${state.shortName}_TAX_WITHHOLDING`
          );

          this.initStepService(state);
        }
      });
    } else {
      this.showWizardModal = true;
      this.modalTitle = this.languageService.get(`myadp-pay.${state.shortName}_TAX_WITHHOLDING`);

      this.initStepService(state);
    }
  }

  public closeWizardModal(): void {
    if (this.stepsService.showExitModal()) {
      this.showExitModal = true;
    } else {
      this.showWizardModal = false;
    }
  }

  public closeESignModal(): void {
    this.stepsService.closeESignModal();
  }

  public closeUpgradeModal(): void {
    this.showUpgradeModal = false;
  }

  public closeExitModal(): void {
    this.showExitModal = false;
  }

  public exitWizardModal(): void {
    this.showExitModal = false;
    this.showWizardModal = false;
  }

  public closeCancelConfirmModal(): void {
    this.showCancelConfirmModal = false;
  }

  public openCancelConfirm(withholdingInfo: WithholdingItem): void {
    this.cancelError = false;
    this.withholdingToCancel = withholdingInfo;
    this.showCancelConfirmModal = true;
  }

  public cancel(): void {
    const recallService = {
      [WithholdingType.FEDERAL]: this.federalWithholdingService,
      [WithholdingType.STATE]: this.stateWithholdingService
    };

    this.loading = true;
    recallService[this.withholdingToCancel.type]
      .recallWithholding()
      .pipe(
        take(1),
        finalize(() => (this.loading = false))
      )
      .subscribe(
        () => {
          this.loadWithholding();
          this.cancelSuccess = true;
          this.showCancelConfirmModal = false;
        },
        () => (this.cancelError = true)
      );
  }

  public toggleExpansion(withholdingItem: WithholdingItem): void {
    this.expandedWithholdingItem = withholdingItem;
  }

  public isExpandPanel(withholdingItem: WithholdingItem): boolean {
    return withholdingItem.state.shortName === this.expandedWithholdingItem?.state?.shortName;
  }

  public showFederalIcon(stateShortName: string): boolean {
    return StateUtil.isFederal(stateShortName);
  }

  public ngOnDestroy() {
    if (this.refreshTile$) {
      this.refreshTile$.unsubscribe();
    }
    if (this.closeModal$) {
      this.closeModal$.unsubscribe();
    }
    this.wizardModalTitle$?.unsubscribe();
  }

  private async loadFederalWithholding(): Promise<WithholdingInfo> {
    return this.federalWithholdingService
      .getFederalWithholding()
      .then((res) => {
        const federal = this.federalWithholdingHelperService.getWithholdingModel(res);
        this.taxWithholdingStore.federalWithholding = federal;
        this.tileState = federal.hasElections ? TileState.HAS_SETUP : TileState.NOT_SETUP;
        this.hasEditPermission =
          this.payPermissionService.hasFederalTaxWithholdingChangePermission();
        return federal;
      })
      .catch((error) => {
        this.logger.error('loadFederalWithholding', error);
        return this.withholdingFormatterService.getErrorModel(WithholdingType.FEDERAL);
      });
  }

  private async loadStateWithholding(): Promise<WithholdingInfo> {
    if (!this.payPermissionService.hasStateTaxWithholdingReadPermission()) {
      return Promise.resolve({ withholdingItems: [] });
    } else {
      return this.stateWithholdingService
        .getStateWithholding()
        .then((res) => {
          const states = this.stateWithholdingHelperService.getWithholdingModel(res);
          this.taxWithholdingStore.stateWithholding = states;
          return states;
        })
        .catch((error) => {
          this.logger.error('loadStateWithholding', error);
          return this.withholdingFormatterService.getErrorModel(WithholdingType.STATE);
        });
    }
  }

  private initWorkflow(): void {
    const withholdingItemWithPending = find(this.withholdingData, (w) => w.pendingEvents);
    const hasPending = withholdingItemWithPending != null;

    if (hasPending) {
      this.approver = get(withholdingItemWithPending, 'pendingEvents.history[0].assignedTo');
      this.pendingEmployeeInit =
        withholdingItemWithPending.pendingEvents.eventTypeId ===
        PendingEventType.EMPLOYEE_INITIATED;
      this.pendingPractitionerInit = !this.pendingEmployeeInit;

      this.activeWithholdingItems.forEach((i) => (i.allowEdit = false));

      if (this.pendingEmployeeInit) {
        this.addPendingMessage(this.activeWithholdingItems);
      }
    }
  }

  private addPendingMessage(allWithholdingItems: WithholdingItem[]): void {
    allWithholdingItems
      .filter((i) => !i.pendingEvents)
      .filter((i) => !i.info || i.info.type === 'warning')
      .forEach(
        (i) =>
          (i.info = {
            type: 'info',
            message: this.languageService.get('common.WF_PENDING_ITEMS_EXIST_NO_CHANGES_ALLOWED')
          })
      );
  }

  private getErrorMessage(): void {
    const error = this.withholdingData.filter((data) => data.hasError);
    switch (error.length) {
      case 0:
        this.errorMessage = undefined;
        break;
      case 1:
        this.errorMessage = this.languageService.get('myadp-pay.TAXWITHHOLDING_LOADING_ERROR', {
          type: this.languageService.get(`myadp-pay.${error[0].type}`)
        });
        break;
      default:
        this.errorMessage = this.languageService.get('myadp-pay.TAXWITHHOLDING_LOADING_ERROR', {
          type: ''
        });
        break;
    }
  }

  private initStepService(state: StateModel): void {
    this.stepsService.setupWizard(
      state,
      this.jurisdictionFactory.getAttachmentNameCode(state),
      this.jurisdictionFactory.getDoneMetaDataService(state),
      this.jurisdictionFactory.getESignMetaDataService(state),
      this.jurisdictionFactory.getStepComponents(state),
      this.jurisdictionFactory.getStepNavigationService(state),
      this.jurisdictionFactory.getStepsMetaData(state),
      this.jurisdictionFactory.getSummaryMetaDataService(state),
      this.jurisdictionFactory.getTwChangeEventService(state)
    );
  }

  private isStepUpEnabled(): boolean {
    return !this.userProfileService.hasFeaturedForSOR('MobileESSTaxWithholding', [
      SORS.US.GLOBAL_VIEW
    ]);
  }
}
