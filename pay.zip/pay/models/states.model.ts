import { sortBy } from 'lodash';

import { WithholdingType } from './formatted-tax-withholding.model';

export interface StateOptionModel {
  value: string;
  label: string;
}

export interface StateModel {
  shortName: string;
  longName: string;
  noIncomeState?: boolean;
  flatRateState?: boolean;
  countryCode: string;
  iconCode?: string;
  deprecated?: boolean;
}

export const COUNTRY_CODES = {
  US: 'US',
  CA: 'CA'
};

export const STATES: StateModel[] = [
  { shortName: 'AL', longName: 'Alabama', countryCode: COUNTRY_CODES['US'] },
  { shortName: 'AK', longName: 'Alaska', countryCode: COUNTRY_CODES['US'], noIncomeState: true },
  { shortName: 'AZ', longName: 'Arizona', countryCode: COUNTRY_CODES['US'] },
  { shortName: 'AR', longName: 'Arkansas', countryCode: COUNTRY_CODES['US'] },
  { shortName: 'CA', longName: 'California', countryCode: COUNTRY_CODES['US'] },
  { shortName: 'CO', longName: 'Colorado', countryCode: COUNTRY_CODES['US'] },
  {
    shortName: 'CO2019',
    longName: 'Colorado',
    countryCode: COUNTRY_CODES['US'],
    iconCode: 'CO',
    deprecated: true
  },
  {
    shortName: 'CO2022',
    longName: 'Colorado',
    countryCode: COUNTRY_CODES['US'],
    iconCode: 'CO',
    deprecated: true
  },
  { shortName: 'CT', longName: 'Connecticut', countryCode: COUNTRY_CODES['US'] },
  { shortName: 'DE', longName: 'Delaware', countryCode: COUNTRY_CODES['US'] },
  { shortName: 'DC', longName: 'District of Columbia', countryCode: COUNTRY_CODES['US'] },
  { shortName: 'FL', longName: 'Florida', countryCode: COUNTRY_CODES['US'], noIncomeState: true },
  { shortName: 'GA', longName: 'Georgia', countryCode: COUNTRY_CODES['US'] },
  { shortName: 'HI', longName: 'Hawaii', countryCode: COUNTRY_CODES['US'] },
  { shortName: 'ID', longName: 'Idaho', countryCode: COUNTRY_CODES['US'] },
  { shortName: 'IL', longName: 'Illinois', countryCode: COUNTRY_CODES['US'] },
  { shortName: 'IN', longName: 'Indiana', countryCode: COUNTRY_CODES['US'] },
  { shortName: 'IA', longName: 'Iowa', countryCode: COUNTRY_CODES['US'] },
  { shortName: 'KS', longName: 'Kansas', countryCode: COUNTRY_CODES['US'] },
  { shortName: 'KY', longName: 'Kentucky', countryCode: COUNTRY_CODES['US'] },
  { shortName: 'LA', longName: 'Louisiana', countryCode: COUNTRY_CODES['US'] },
  { shortName: 'ME', longName: 'Maine', countryCode: COUNTRY_CODES['US'] },
  { shortName: 'MD', longName: 'Maryland', countryCode: COUNTRY_CODES['US'] },
  { shortName: 'MA', longName: 'Massachusetts', countryCode: COUNTRY_CODES['US'] },
  { shortName: 'MI', longName: 'Michigan', countryCode: COUNTRY_CODES['US'] },
  { shortName: 'MN', longName: 'Minnesota', countryCode: COUNTRY_CODES['US'] },
  { shortName: 'MS', longName: 'Mississippi', countryCode: COUNTRY_CODES['US'] },
  { shortName: 'MO', longName: 'Missouri', countryCode: COUNTRY_CODES['US'] },
  { shortName: 'MT', longName: 'Montana', countryCode: COUNTRY_CODES['US'] },
  { shortName: 'NE', longName: 'Nebraska', countryCode: COUNTRY_CODES['US'] },
  {
    shortName: 'NE2019',
    longName: 'Nebraska',
    countryCode: COUNTRY_CODES['US'],
    iconCode: 'NE',
    deprecated: true
  },
  { shortName: 'NV', longName: 'Nevada', countryCode: COUNTRY_CODES['US'], noIncomeState: true },
  {
    shortName: 'NH',
    longName: 'New Hampshire',
    countryCode: COUNTRY_CODES['US'],
    noIncomeState: true
  },
  { shortName: 'NJ', longName: 'New Jersey', countryCode: COUNTRY_CODES['US'] },
  { shortName: 'NM', longName: 'New Mexico', countryCode: COUNTRY_CODES['US'] },
  {
    shortName: 'NM2019',
    longName: 'New Mexico',
    countryCode: COUNTRY_CODES['US'],
    iconCode: 'NM',
    deprecated: true
  },
  { shortName: 'NY', longName: 'New York', countryCode: COUNTRY_CODES['US'] },
  { shortName: 'NC', longName: 'North Carolina', countryCode: COUNTRY_CODES['US'] },
  { shortName: 'ND', longName: 'North Dakota', countryCode: COUNTRY_CODES['US'] },
  {
    shortName: 'ND2019',
    longName: 'North Dakota',
    countryCode: COUNTRY_CODES['US'],
    iconCode: 'ND',
    deprecated: true
  },
  { shortName: 'OH', longName: 'Ohio', countryCode: COUNTRY_CODES['US'] },
  {
    shortName: 'OH2020',
    longName: 'Ohio',
    countryCode: COUNTRY_CODES['US'],
    iconCode: 'OH',
    deprecated: true
  },
  { shortName: 'OK', longName: 'Oklahoma', countryCode: COUNTRY_CODES['US'] },
  { shortName: 'OR', longName: 'Oregon', countryCode: COUNTRY_CODES['US'] },
  {
    shortName: 'PA',
    longName: 'Pennsylvania',
    countryCode: COUNTRY_CODES['US']
  },
  {
    shortName: 'PA2020',
    longName: 'Pennsylvania',
    countryCode: COUNTRY_CODES['US'],
    flatRateState: true,
    iconCode: 'PA',
    deprecated: true
  },
  { shortName: 'RI', longName: 'Rhode Island', countryCode: COUNTRY_CODES['US'] },
  { shortName: 'SC', longName: 'South Carolina', countryCode: COUNTRY_CODES['US'] },
  {
    shortName: 'SD',
    longName: 'South Dakota',
    countryCode: COUNTRY_CODES['US'],
    noIncomeState: true
  },
  { shortName: 'TN', longName: 'Tennessee', countryCode: COUNTRY_CODES['US'], noIncomeState: true },
  { shortName: 'TX', longName: 'Texas', countryCode: COUNTRY_CODES['US'], noIncomeState: true },
  { shortName: 'UT', longName: 'Utah', countryCode: COUNTRY_CODES['US'] },
  {
    shortName: 'UT2019',
    longName: 'Utah',
    countryCode: COUNTRY_CODES['US'],
    iconCode: 'UT',
    deprecated: true
  },
  { shortName: 'VT', longName: 'Vermont', countryCode: COUNTRY_CODES['US'] },
  { shortName: 'VA', longName: 'Virginia', countryCode: COUNTRY_CODES['US'] },
  {
    shortName: 'WA',
    longName: 'Washington',
    countryCode: COUNTRY_CODES['US'],
    noIncomeState: true
  },
  { shortName: 'WV', longName: 'West Virginia', countryCode: COUNTRY_CODES['US'] },
  { shortName: 'WI', longName: 'Wisconsin', countryCode: COUNTRY_CODES['US'] },
  { shortName: 'WY', longName: 'Wyoming', countryCode: COUNTRY_CODES['US'], noIncomeState: true }
];

export const FEDERAL_STATES: string[] = ['CO', 'ND', 'NM', 'UT'];

export const US_TERRITORIES: StateModel[] = [
  { shortName: 'PR', longName: 'Puerto Rico', countryCode: COUNTRY_CODES['US'] },
  { shortName: 'VI', longName: 'Virgin Islands', countryCode: COUNTRY_CODES['US'] },
  { shortName: 'GU', longName: 'Guam', countryCode: COUNTRY_CODES['US'] },
  { shortName: 'MP', longName: 'Northern Mariana Islands', countryCode: COUNTRY_CODES['US'] },
  { shortName: 'AS', longName: 'American Samoa', countryCode: COUNTRY_CODES['US'] }
];

export const FEDERAL: StateModel = {
  shortName: 'FED',
  longName: 'Federal',
  countryCode: COUNTRY_CODES['US']
};

export function getState(state: string): StateModel | undefined {
  if (state?.toUpperCase() === WithholdingType.FEDERAL.toUpperCase()) {
    return FEDERAL;
  }

  return STATES.concat(US_TERRITORIES).find((s) => {
    return (
      s.shortName.toUpperCase() === state?.toUpperCase() ||
      s.longName.toUpperCase() === state?.toUpperCase()
    );
  });
}

export class StateUtil {
  public static isFederal(stateShortName: string): boolean {
    return stateShortName === FEDERAL.shortName;
  }

  public getState = getState;

  public getStates(): StateOptionModel[] {
    return STATES.filter((s) => !s.deprecated).map((s) => {
      return {
        value: s.shortName,
        label: s.longName
      };
    });
  }

  public getTerritories(): StateOptionModel[] {
    return US_TERRITORIES.map((s) => {
      return {
        value: s.shortName,
        label: s.longName
      };
    });
  }

  public removeStates(
    states: string[],
    stateOptions: StateOptionModel[] = this.getStates()
  ): StateOptionModel[] {
    return stateOptions.filter((s) => {
      return !states.includes(s.value);
    });
  }

  public removeStatesOrTerritories(
    states: string[],
    stateOptions: StateOptionModel[] = this.getStates().concat(this.getTerritories())
  ): StateOptionModel[] {
    const allStatesTerritories: StateOptionModel[] = stateOptions.filter(
      (s) => !states.includes(s.value)
    );
    return sortBy(allStatesTerritories, (o) => o.label);
  }

  public addStatesOrTerritories(
    states: string[],
    stateOptions: StateOptionModel[] = this.getStates().concat(this.getTerritories())
  ): StateOptionModel[] {
    const allStatesTerritories: StateOptionModel[] = stateOptions.filter((s) =>
      states.includes(s.value)
    );
    return sortBy(allStatesTerritories, (o) => o.label);
  }
}
