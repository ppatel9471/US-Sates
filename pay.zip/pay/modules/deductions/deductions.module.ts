import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { CoreModule } from '@synerg/angular-components';
import { AlertModule } from '@synerg/components/alert';
import { ButtonModule } from '@synerg/components/button';
import { CheckboxModule } from '@synerg/components/checkbox';
import { IconModule } from '@synerg/components/icon';
import { ListViewModule } from '@synerg/components/list-view';
import { ModalModule } from '@synerg/components/modal';
import { ProgressBarModule } from '@synerg/components/progress-bar';
import { SlideinModule } from '@synerg/components/slidein';
import { SnackbarModule } from '@synerg/components/snackbar';
import { WizardContainerModule } from '@synerg/components/wizard-container';

import { MyAdpCommonModule } from '@myadp/common';
import { MyAdpFormsModule } from '@myadp/forms';

import { SharedModule } from '../shared/shared.module';
import { DeductionsContainerComponent } from './components/deductions-container/deductions-container.component';
import { DeductionsSlideinComponent } from './components/deductions-slidein/deductions-slidein.component';
import { DeductionsTileComponent } from './components/deductions-tile/deductions-tile.component';
import { DeductionAmountFormatComponent } from './components/shared/deduction-amount-format/deduction-amount-format.component';
import { DeductionListComponent } from './components/shared/deduction-list/deduction-list.component';
import { StepsNavigationComponent } from './components/steps-navigation/steps-navigation.component';
import { DeductionAmountsComponent } from './components/steps/deduction-details/deduction-amounts/deduction-amounts.component';
import { DeductionCheckboxComponent } from './components/steps/deduction-details/deduction-checkbox/deduction-checkbox.component';
import { DeductionDeleteComponent } from './components/steps/deduction-details/deduction-delete/deduction-delete.component';
import { DeductionDetailsComponent } from './components/steps/deduction-details/deduction-details.component';
import { DeductionSelectComponent } from './components/steps/deduction-details/deduction-select/deduction-select.component';
import { DeductionDoneComponent } from './components/steps/deduction-done/deduction-done.component';
import { DeductionReviewComponent } from './components/steps/deduction-review/deduction-review.component';
import { DeductionDetailsSelectorPipe } from './pipes/deduction-details-selector.pipe';

const DEDUCTIONS_COMPONENTS = [
  DeductionsContainerComponent,
  DeductionsTileComponent,
  DeductionsSlideinComponent,
  DeductionListComponent,
  DeductionAmountFormatComponent,
  DeductionDetailsComponent,
  DeductionSelectComponent,
  DeductionAmountsComponent,
  DeductionReviewComponent,
  StepsNavigationComponent,
  DeductionDetailsSelectorPipe,
  DeductionCheckboxComponent,
  DeductionDoneComponent,
  DeductionDeleteComponent
];

@NgModule({
  imports: [
    CommonModule,
    ButtonModule,
    ModalModule,
    SlideinModule,
    AlertModule,
    SnackbarModule,
    ProgressBarModule,
    WizardContainerModule,
    ListViewModule,
    MyAdpCommonModule,
    SharedModule,
    MyAdpFormsModule,
    CheckboxModule,
    IconModule,
    CoreModule
  ],
  declarations: DEDUCTIONS_COMPONENTS
})
export class DeductionsModule {
  static components = {
    default: DeductionsTileComponent
  };
}
