import { CurrencyPipe } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { BehaviorSubject, of } from 'rxjs';
import { Shallow } from 'shallow-render';
import { Mock } from 'ts-mockery';

import { StoreState } from '@myadp/pay-shared';

import { LanguagePipe, LanguageService } from '../../../../../common';
import { DistributionOptions } from '../../../pay-distributions-shared/models/pay-distributions-ui';
import { PayDistributionStore } from '../../../pay-distributions-shared/store/pay-distribution.store';
import { PayDistributionStoreActions } from '../../../pay-distributions-shared/store/pay-distribution.store.actions';
import { PrivacyModeStore } from '../../../privacy-mode-shared/store/privacy-mode.store';
import { CloseConfirmComponent } from '../../../shared/components/close-confirm/close-confirm.component';
import { CurrencyFormatComponent } from '../../../shared/components/currency-format/currency-format.component';
import { HasWorkflowChangesPipe } from '../../../shared/pipes/has-workflow-changes/has-workflow-changes.pipe';
import { ValueFormatterService } from '../../../shared/services/value-formatter.service';
import { MyADPDirectDepositModule } from '../../direct-deposit.module';
import { DirectDepositAccount } from '../../models/direct-deposit-account.model';
import { AccountDetailsSelectorPipe } from '../../pipes/account-details-selector/account-details-selector.pipe';
import { MaskNumberPipe } from '../../pipes/mask-number/mask-number.pipe';
import { DirectDepositStoreActions } from '../../store/direct-deposit-store.actions';
import {
  DirectDepositStore,
  DirectDepositStoreSlice,
  DirectDepositStoreState
} from '../../store/direct-deposit.store';
import { StepsStore, StepsStoreActions } from '../../store/steps/steps.store';
import { DepositAmountFormatComponent } from '../shared/deposit-amount-format/deposit-amount-format.component';
import { DirectDepositSlideinComponent } from './direct-deposit-slidein.component';

describe('DirectDepositSlideinComponent', () => {
  let shallow: Shallow<DirectDepositSlideinComponent>;
  let mockShowSlidein$: BehaviorSubject<boolean>;

  const accounts: DirectDepositAccount[] = [
    {
      currentData: {
        precedence: '1',
        accountTypeName: 'Checking 1',
        accountNumber: 'X123456P7',
        routingNumber: '021000021',
        distributionType: DistributionOptions.FLAT,
        flatAmount: { amountValue: 123, currencyCode: 'USD' }
      }
    },
    {
      currentData: {
        precedence: '2',
        accountTypeName: 'Checking 2',
        accountNumber: '123-45678',
        routingNumber: '021000021',
        distributionType: DistributionOptions.PERCENTAGE,
        percentageAmount: 25
      }
    },
    {
      currentData: {
        precedence: '3',
        accountName: 'My Account Name',
        accountTypeName: 'Checking 3',
        accountNumber: '12345',
        routingNumber: '021000021',
        distributionType: DistributionOptions.REMAINING
      }
    }
  ];

  const state: StoreState<DirectDepositStoreState> = {
    [DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS]: {
      data: accounts,
      loading: false
    }
  };

  const slideinElm = 'adp-slidein';

  beforeEach(() => {
    mockShowSlidein$ = new BehaviorSubject<boolean>(false);

    shallow = new Shallow(DirectDepositSlideinComponent, MyADPDirectDepositModule)
      .provide(
        Router,
        ActivatedRoute,
        CurrencyPipe,
        LanguageService,
        ValueFormatterService,
        DirectDepositStore
      )
      .dontMock(
        CurrencyPipe,
        ValueFormatterService,
        CurrencyFormatComponent,
        MaskNumberPipe,
        HasWorkflowChangesPipe,
        DepositAmountFormatComponent,
        CloseConfirmComponent
      )
      .mock(ActivatedRoute, {
        queryParams: of({})
      })
      .mockPipe(AccountDetailsSelectorPipe, () => [
        {
          ...accounts[0].currentData,
          isReadOnly: false,
          directDepositAccount: accounts[0],
          pendingEvent: null
        },
        {
          ...accounts[1].currentData,
          isReadOnly: false,
          directDepositAccount: accounts[1],
          pendingEvent: null
        },
        {
          ...accounts[2].currentData,
          isReadOnly: false,
          directDepositAccount: accounts[2],
          pendingEvent: null
        }
      ])
      .mock(StepsStore, {
        showStepNavigation$: of(true),
        isSlideinOpenObs$: mockShowSlidein$,
        isSlideinOpen$: new BehaviorSubject<boolean>(false)
      })
      .mock(DirectDepositStore, {
        state$: of(state),
        update: Mock.noop(),
        getValidationStatus: Mock.noop()
      })
      .mock(DirectDepositStoreActions, {
        resetFormData: () => Mock.noop(),
        resetModifiedAccounts: () => Mock.noop()
      })
      .mock(PrivacyModeStore, {
        showMaskedValue$: of(false)
      })
      .mock(StepsStoreActions, {
        loadAccounts: () => Mock.noop(),
        resetCurrentStep: () => Mock.noop(),
        openSlidein: () => mockShowSlidein$.next(true),
        closeSlidein: () => mockShowSlidein$.next(false),
        hasAccountChanges: () => false,
        resetModifiedAccounts: () => Mock.noop()
      })
      .mock(PayDistributionStore, {
        payDistributions$: Mock.noop(),
        payDistributionMeta$: Mock.noop(),
        hasChangePermission$: Mock.noop(),
        hasPayDistributions: true,
        hasDistributionError$: of(false),
        isPayDistributionsLoading$: of(false)
      })
      .mock(PayDistributionStoreActions, {
        loadDistributions: () => Mock.noop()
      })
      .mock(ActivatedRoute, {
        snapshot: {
          queryParams: of({})
        }
      })
      .mockPipe(LanguagePipe, (key) => key);
  });

  describe('error', () => {
    const ddUnmaskedAlertElm = '.direct-deposit-unmasked-error';
    const ddContainerElm = 'dd-direct-deposit-container';

    it('should only show error message in slidein when the unmask call fails and nonPayDashboardView is true', async () => {
      const { find, instance } = await shallow
        .mock(PayDistributionStore, {
          hasDistributionError$: of(true),
          isSliceLoading$: () => of(false)
        })
        .render();

      expect(instance.show).toBeTrue();
      expect(find(slideinElm)).toHaveFoundOne();
      expect(find(ddUnmaskedAlertElm)).toHaveFoundOne();
      expect(find(ddContainerElm)).toHaveFound(0);
    });

    it('should only emit error when the unmask call fails nonPayDashboardView is false', async () => {
      const { find, outputs } = await shallow
        .mock(PayDistributionStore, {
          hasDistributionError$: of(true),
          isSliceLoading$: () => of(false)
        })
        .render({
          bind: {
            nonPayDashboardView: false
          }
        });

      expect(outputs.error.emit).toHaveBeenCalledWith(true);
      expect(find(slideinElm)).toHaveFound(0);
      expect(find(ddUnmaskedAlertElm)).toHaveFound(0);
      expect(find(ddContainerElm)).toHaveFound(0);
    });
  });

  describe('openSlidein()', () => {
    it('should open slidein and call for unmasked data and meta for non pay dashboard views (onboarding/campaign)', async () => {
      const { find, get, instance } = await shallow.render();

      const stepsStoreActions = get(StepsStoreActions);
      const stepsStore = get(StepsStore);

      expect(stepsStore.isSlideinOpen$.getValue()).toBeTrue();
      expect(instance.unmaskError).toBeFalse();
      expect(stepsStoreActions.loadAccounts).toHaveBeenCalledTimes(1);
      expect(stepsStoreActions.loadAccounts).toHaveBeenCalledWith({ getMeta: true });

      expect(find(slideinElm)).toHaveFoundOne();
    });

    it('should open slidein and shimmer when loading on non pay dashboard views (onboarding/campaign)', async () => {
      const { find, get, instance } = await shallow
        .mock(PayDistributionStore, {
          hasDistributionError$: of(false),
          isPayDistributionsLoading$: of(true)
        })
        .render();

      const stepsStoreActions = get(StepsStoreActions);
      const stepsStore = get(StepsStore);

      expect(stepsStore.isSlideinOpen$.getValue()).toBeTrue();
      expect(instance.unmaskError).toBeFalse();
      expect(stepsStoreActions.loadAccounts).toHaveBeenCalledTimes(1);
      expect(stepsStoreActions.loadAccounts).toHaveBeenCalledWith({ getMeta: true });
      expect(instance.show).toBeFalse();
      expect(find('sdf-shimmer')).toHaveFoundOne();

      expect(find(slideinElm)).toHaveFoundOne();
    });

    it('should call to get unmaksed data but not meta if nonPayDashboardView is false', async () => {
      const { find, get, instance } = await shallow.render({
        bind: {
          nonPayDashboardView: false
        }
      });
      const stepsStoreActions = get(StepsStoreActions);

      expect(instance.unmaskError).toBeFalse();
      expect(stepsStoreActions.loadAccounts).toHaveBeenCalledTimes(1);
      expect(stepsStoreActions.loadAccounts).toHaveBeenCalledWith();
      expect(find(slideinElm)).toHaveFoundOne();
    });

    it('should open slidein and not call for unmasked data', async () => {
      const { get } = await shallow
        .mock(PayDistributionStore, {
          hasPayDistributions: false
        })
        .render();
      const stepsStoreActions = get(StepsStoreActions);

      expect(stepsStoreActions.loadAccounts).not.toHaveBeenCalledWith();
    });

    it('should open slidein and not call for unmasked data if AVSDDM', async () => {
      const { get } = await shallow
        .mock(PayDistributionStore, {
          hasPayDistributions: true
        })
        .mock(DirectDepositStore, {
          state$: of(state),
          update: Mock.noop(),
          getValidationStatus: Mock.noop(),
          isAvsddm: true
        })
        .render();
      const stepsStoreActions = get(StepsStoreActions);

      expect(stepsStoreActions.loadAccounts).not.toHaveBeenCalledWith();
    });
  });

  describe('closeSlidein()', () => {
    it('should emit to close slidein', async () => {
      const { instance, outputs, fixture } = await shallow.render();

      instance.closeSlidein();
      fixture.detectChanges();

      expect(outputs.closed.emit).toHaveBeenCalled();
    });
  });

  describe('confirm cancel modal', () => {
    describe('confirmClose()', () => {
      it('should close modal and emit to close slidein by clicking exit button', async () => {
        mockShowSlidein$.next(true);
        const { find, instance, outputs, fixture, get } = await shallow.render();
        instance.showConfirmCancelModal = true;
        fixture.detectChanges();

        expect(find(slideinElm)).toHaveFoundOne();
        expect(find('close-confirm')).toHaveFoundOne();

        const [, { nativeElement: yesBtn }] = find('close-confirm adp-button');
        yesBtn.click();
        fixture.detectChanges();

        expect(instance.showConfirmCancelModal).toBe(false);
        expect(get(StepsStoreActions).closeSlidein).toHaveBeenCalledTimes(1);
        expect(find('close-confirm')).toHaveFound(0);
        expect(outputs.closed.emit).toHaveBeenCalled();
      });
    });

    describe('cancel()', () => {
      it('should close only modal by clicking cancel button', async () => {
        mockShowSlidein$.next(true);
        const { find, instance, outputs, fixture, get } = await shallow.render();
        instance.showConfirmCancelModal = true;
        fixture.detectChanges();

        expect(find(slideinElm)).toHaveFoundOne();
        expect(find('close-confirm')).toHaveFoundOne();

        const [{ nativeElement: noBtn }] = find('close-confirm adp-button');
        noBtn.click();
        fixture.detectChanges();

        expect(instance.showConfirmCancelModal).toBe(false);
        expect(get(StepsStoreActions).closeSlidein).not.toHaveBeenCalled();
        expect(find(slideinElm)).toHaveFoundOne();
        expect(find('close-confirm')).toHaveFound(0);
        expect(outputs.closed.emit).not.toHaveBeenCalled();
      });
    });
  });
});
