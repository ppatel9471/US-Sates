import { Component, OnInit, Optional } from '@angular/core';
import { TileService } from '@synerg/components/tile';

import { PayPermissionService } from '@myadp/pay-shared';

@Component({
  selector: 'tax-withholding-management-tile',
  templateUrl: 'tax-withholding-management-tile.component.html'
})
export class TaxWithholdingManagementTileComponent implements OnInit {
  public isVersionSupported: boolean;

  constructor(
    private payPermissionService: PayPermissionService,
    @Optional() private tileService: TileService
  ) {}

  public ngOnInit() {
    this.tileService?.setIsLoading(false);
    this.isVersionSupported = this.payPermissionService.getTaxWithholdingVersion() === 'v2';
  }
}
