import { NeIntroComponent } from '../ne/steps/intro/ne-intro.component';
import { Ne2019AllowancesComponent } from './steps/allowances/ne2019-allowances.component';
import { NeExemptionComponent } from '../ne/steps/exemption/ne-exemption.component';
import { Ne2019MaritalStatusComponent } from './steps/marital-status/ne2019-marital-status.component';

export { Ne2019TWChangeEventService } from './services/ne2019-tw-change-event.service';
export { Ne2019SummaryMetaDataService } from './services/ne2019-summary-meta-data.service';
export { Ne2019StepNavigationService } from './services/ne2019-step-navigation.service';

export const NE2019_COMPONENTS = [
  NeIntroComponent,
  NeExemptionComponent,
  Ne2019AllowancesComponent,
  Ne2019MaritalStatusComponent
];

export { NE2019STEP_COMPONENT } from './models/steps-component.model';

export { Ne2019AttachmentCodes } from './models/ne2019-tw-change-event';
