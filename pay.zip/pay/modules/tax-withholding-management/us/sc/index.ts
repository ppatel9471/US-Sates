import { ScIntroComponent } from './steps/intro/sc-intro.component';
import { ScPersonalInfoComponent } from './steps/personal-info/sc-personal-info.component';
import { ScMaritalStatusComponent } from './steps/marital-status/sc-marital-status.component';
import { ScExemptionComponent } from './steps/exemption/sc-exemption.component';
import { ScAllowancesComponent } from './steps/allowances/sc-allowances.component';
import { ScAdditionalWithholdingComponent } from './steps/additional-withholding/sc-additional-withholding.component';

export { ScTWChangeEventService } from './services/sc-tw-change-event.service';
export { ScSummaryMetaDataService } from './services/sc-summary-meta-data.service';
export { ScStepNavigationService } from './services/sc-step-navigation.service';

export const SC_COMPONENTS = [
  ScIntroComponent,
  ScPersonalInfoComponent,
  ScMaritalStatusComponent,
  ScExemptionComponent,
  ScAllowancesComponent,
  ScAdditionalWithholdingComponent
];

export { SCSTEP_COMPONENT } from './models/steps-component.model';

export { ScAttachmentCodes } from './models/sc-tw-change-event';
