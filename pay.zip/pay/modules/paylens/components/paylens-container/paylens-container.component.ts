import { Component, OnInit, Optional } from '@angular/core';
import { TileService } from '@synerg/components/tile';
import { Observable } from 'rxjs';

import { BarbecueService } from '@myadp/common';

import { PayStatementsUI } from '../../../pay-statements-shared/models/pay-statement-ui';
import { PayStatementStoreActions } from '../../../pay-statements-shared/store/pay-statement-store.actions';
import { PayStatementStore } from '../../../pay-statements-shared/store/pay-statement.store';
import { StatementType } from '../../../shared/models/pdf-viewer.model';

@Component({
  selector: 'paylens',
  templateUrl: './paylens-container.component.html',
  styleUrls: [
    '../../shared/paylens.scss',
    './paylens-container.scss',
    './paylens-container-alt.scss'
  ]
})
export class PaylensContainerComponent implements OnInit {
  public store: Record<string, Observable<any>>;
  public statementType = StatementType;
  public isBbq: boolean;

  constructor(
    private bbqService: BarbecueService,
    private payStatementStore: PayStatementStore,
    private payStatementStoreActions: PayStatementStoreActions,
    @Optional() public tileService: TileService
  ) {}

  public ngOnInit() {
    this.tileService?.setIsLoading(false);
    this.isBbq = this.bbqService.isBarbecue();
    this.store = {
      payStatements$: this.payStatementStore.payStatements$,
      pdfStatements$: this.payStatementStore.pdfStatements$,
      workerPayInfo$: this.payStatementStore.workerPayInfo$,
      currentDetailsData$: this.payStatementStore.currentDetailsData$,
      hasStatementsError$: this.payStatementStore.hasPayStatementError$,
      isStatementsLoading$: this.payStatementStore.isPayStatementsLoading$,
      isStatementDetailsLoading$: this.payStatementStore.isStatementDetailsLoading$,
      hasNotificationPermission$: this.payStatementStore.hasNotificationPermission$
    };

    this.payStatementStoreActions.loadPayStatements();
  }

  public onLoadDetails(statement: PayStatementsUI.PayStatement) {
    this.payStatementStoreActions.loadStatementDetails(statement);
  }
}
