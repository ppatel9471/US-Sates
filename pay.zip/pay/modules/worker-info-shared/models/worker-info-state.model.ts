import {
  PayrollWorker,
  PayrollWorkerWorkAssignment,
  WorkAssignment,
  Worker,
  WorkerDates
} from '@myadp/dto';
import { StoreState } from '@myadp/pay-shared';

import { WorkerInfo, WorkerSsn } from './worker-info.model';

export enum WorkerInfoStoreSlice {
  WORKER = 'worker',
  WORKER_INFO = 'workerInfo',
  WORKER_SSN = 'ssn',
  WORKER_BIRTHDATE = 'birthDate',
  WORKER_WORK_ASSIGNMENTS = 'workAssignments',
  WORKER_DATES = 'workerDates'
}

export interface WorkerInfoStoreState {
  [WorkerInfoStoreSlice.WORKER]: Worker | PayrollWorker;
  [WorkerInfoStoreSlice.WORKER_INFO]: WorkerInfo;
  [WorkerInfoStoreSlice.WORKER_SSN]: WorkerSsn;
  [WorkerInfoStoreSlice.WORKER_BIRTHDATE]: string;
  [WorkerInfoStoreSlice.WORKER_WORK_ASSIGNMENTS]: WorkAssignment[] | PayrollWorkerWorkAssignment;
  [WorkerInfoStoreSlice.WORKER_DATES]: WorkerDates;
}

export const EMPTY_WORKER_INFO_STORE: StoreState<WorkerInfoStoreState> = {
  [WorkerInfoStoreSlice.WORKER]: { data: undefined, loading: false, error: {} },
  [WorkerInfoStoreSlice.WORKER_INFO]: { data: undefined },
  [WorkerInfoStoreSlice.WORKER_SSN]: { data: undefined, loading: false, error: {} },
  [WorkerInfoStoreSlice.WORKER_BIRTHDATE]: { data: undefined, loading: false, error: {} },
  [WorkerInfoStoreSlice.WORKER_WORK_ASSIGNMENTS]: {
    data: undefined,
    loading: false,
    error: {}
  },
  [WorkerInfoStoreSlice.WORKER_DATES]: { data: undefined, loading: false, error: {} }
};
