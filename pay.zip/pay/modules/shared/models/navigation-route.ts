export interface NavigationRouteDetails {
  tag?: string | any;
  name: string;
}

export class NavigationRoute {
  public name: string;

  public parent: Partial<NavigationRoute> = null;
  public returnTo: Partial<NavigationRoute> = null;
  public tag: string | any;

  public routes: Partial<NavigationRoute>[] = [];

  constructor({ name, tag }: NavigationRouteDetails) {
    this.name = name;
    this.tag = tag;
  }

  public appendRoute(step: Partial<NavigationRoute>): Partial<NavigationRoute> {
    this.routes.push(step);
    return this.routes[this.routes.length - 1];
  }

  public buildRoutes(
    navigationRoutes: Partial<NavigationRoute>[],
    returnTo: boolean = false
  ): Partial<NavigationRoute> {
    let lastReference: Partial<NavigationRoute>;

    navigationRoutes.forEach((route) => {
      if (!lastReference) {
        lastReference = this.appendRoute(route);
        route.setParent(this);
      } else {
        route.setParent(lastReference);
        lastReference = lastReference.appendRoute(route);
      }

      if (returnTo) {
        lastReference.setReturnTo(this);
      }
    });

    return lastReference;
  }

  public setParent(reference: Partial<NavigationRoute>): Partial<NavigationRoute> {
    this.parent = reference;
    return this;
  }

  public setReturnTo(reference: Partial<NavigationRoute>): Partial<NavigationRoute> {
    this.returnTo = reference;
    return this;
  }

  public prev(): Partial<NavigationRoute> {
    return this.parent || this.returnTo;
  }

  public findByTag(tag?: string | any): Partial<NavigationRoute> {
    return tag ? this.routes.find((route: Partial<NavigationRoute>) => tag === route.tag) : null;
  }

  public findNearestRouteWithoutTag(): Partial<NavigationRoute> {
    return this.routes.find((route: Partial<NavigationRoute>) => !route.tag);
  }

  public next(tag?: string | any): Partial<NavigationRoute> {
    return this.findByTag(tag) || this.findNearestRouteWithoutTag() || this.returnTo;
  }

  public cancel(): Partial<NavigationRoute> {
    return this.returnTo;
  }
}
