import { Injectable } from '@angular/core';
import { BreakpointService } from '@synerg/components/shared';
import { combineLatest, Observable } from 'rxjs';
import { distinctUntilChanged, filter, map } from 'rxjs/operators';

import { BaseStore } from '@myadp/pay-shared';

import { PdfStatement } from '../../shared/models/pdf-viewer.model';
import {
  PayStatementsStoreSlice,
  PayStatementsStoreState,
  PayStatementsUI
} from '../models/pay-statement-ui';

@Injectable({
  providedIn: 'root'
})
export class PayStatementStore extends BaseStore<PayStatementsStoreState> {
  constructor(private breakPointService: BreakpointService) {
    super({
      [PayStatementsStoreSlice.PAY_STATEMENTS]: {
        data: {
          statements: [],
          statementsForPdfViewer: [],
          workerPayInfo: null,
          hasNotificationPermission: null
        },
        loading: false,
        error: {}
      },
      [PayStatementsStoreSlice.CURRENT_STATEMENT_DETAILS]: {
        data: {
          statement: {}
        },
        loading: false,
        error: {}
      },
      [PayStatementsStoreSlice.STATEMENT_DETAILS_CACHE]: {
        data: {},
        loading: false,
        error: {}
      },
      [PayStatementsStoreSlice.CURRENT_PAYMENT_CALCULATION_ANALYSIS]: {
        data: null,
        loading: false,
        error: {}
      },
      [PayStatementsStoreSlice.PAYMENT_CALCULATION_ANALYSIS_CACHE]: {
        data: {},
        loading: false,
        error: {}
      }
    });
  }

  public get showStatementsActivityTile$(): Observable<boolean> {
    return combineLatest([this.hasStatementsActivity$, this.breakPointService.lte('md')]).pipe(
      map(([hasStatementsActivity, isMobile]) => hasStatementsActivity && isMobile)
    );
  }

  public get payStatements$(): Observable<PayStatementsUI.PayStatement[]> {
    return this.getData$(PayStatementsStoreSlice.PAY_STATEMENTS, 'statements', null);
  }

  public get currentDetailsData$(): Observable<PayStatementsUI.PayStatementDetailsState> {
    return this.getData$(PayStatementsStoreSlice.CURRENT_STATEMENT_DETAILS, undefined, null);
  }

  public get currentStatement$(): Observable<PayStatementsUI.PayStatement> {
    return this.getData$(PayStatementsStoreSlice.CURRENT_STATEMENT_DETAILS, 'statement', null);
  }

  public statementDetails$(slice?: keyof PayStatementsUI.PayStatementDetails): Observable<any> {
    return this.state$.pipe(
      map((state) =>
        slice
          ? state[PayStatementsStoreSlice.CURRENT_STATEMENT_DETAILS].data?.statementDetails?.[
            slice
          ] ?? null
          : state[PayStatementsStoreSlice.CURRENT_STATEMENT_DETAILS].data?.statementDetails ?? null
      ),
      this.distinctUntilChangedObj()
    );
  }

  public get isPayStatementsLoading$(): Observable<boolean> {
    return this.isSliceLoading$(PayStatementsStoreSlice.PAY_STATEMENTS);
  }

  public get isStatementDetailsLoading$(): Observable<boolean> {
    return this.isSliceLoading$(PayStatementsStoreSlice.CURRENT_STATEMENT_DETAILS);
  }

  public statementDetailsById$(
    statementId: number
  ): Observable<PayStatementsUI.PayStatementDetails> {
    return this.state$.pipe(
      map(
        (state) =>
          state[PayStatementsStoreSlice.STATEMENT_DETAILS_CACHE]?.data?.[statementId]
            ?.statementDetails ?? null
      ),
      this.distinctUntilChangedObj()
    );
  }

  public statementDetailErrorById$(statementId: number): Observable<boolean> {
    return this.state$.pipe(
      map(
        (state) =>
          state[PayStatementsStoreSlice.STATEMENT_DETAILS_CACHE].error?.[statementId]
            ?.detailsError ?? null
      ),
      distinctUntilChanged()
    );
  }

  public get pdfStatements$(): Observable<PdfStatement[]> {
    return this.getData$(PayStatementsStoreSlice.PAY_STATEMENTS, 'statementsForPdfViewer', null);
  }

  public isStatementCacheLoading$(): Observable<boolean> {
    return this.isSliceLoading$(PayStatementsStoreSlice.STATEMENT_DETAILS_CACHE);
  }

  public get hasNotificationPermission$(): Observable<boolean> {
    return this.getData$(
      PayStatementsStoreSlice.PAY_STATEMENTS,
      'hasNotificationPermission',
      false
    );
  }

  public get workerPayInfo$(): Observable<PayStatementsUI.WorkerPayInfo> {
    return this.getData$(PayStatementsStoreSlice.PAY_STATEMENTS, 'workerPayInfo', null);
  }

  public get hasPayStatementError$(): Observable<boolean> {
    return combineLatest([
      this.hasError$(PayStatementsStoreSlice.PAY_STATEMENTS, 'statementsError'),
      this.hasError$(PayStatementsStoreSlice.CURRENT_STATEMENT_DETAILS, 'statementsError')
    ]).pipe(
      map(
        ([payStatementError, currentStatementError]) => payStatementError || currentStatementError
      )
    );
  }

  public get hasStatementDetailsError$(): Observable<boolean> {
    return this.hasError$(PayStatementsStoreSlice.CURRENT_STATEMENT_DETAILS, 'detailsError');
  }

  public get categorizedInsights$(): Observable<any> {
    return this.getData$(
      PayStatementsStoreSlice.CURRENT_PAYMENT_CALCULATION_ANALYSIS,
      'categorizedInsights'
    );
  }

  public getNonAdjustmentStatements(): PayStatementsUI.PayStatement[] {
    return this.getData(PayStatementsStoreSlice.PAY_STATEMENTS, 'statements').filter(
      (statement: PayStatementsUI.PayStatement) => !statement.payAdjustment
    );
  }

  private get hasStatementsActivity$(): Observable<boolean> {
    return this.state$.pipe(
      filter((state) => !state[PayStatementsStoreSlice.PAY_STATEMENTS].loading),
      map((state) => {
        const statements = state[PayStatementsStoreSlice.PAY_STATEMENTS]?.data?.statements;
        const statementsActivityList = statements?.filter(
          (statement) =>
            statement?.id !==
            state[PayStatementsStoreSlice.CURRENT_STATEMENT_DETAILS]?.data?.statement?.id
        );
        return statementsActivityList.length > 0;
      }),
      distinctUntilChanged()
    );
  }
}
