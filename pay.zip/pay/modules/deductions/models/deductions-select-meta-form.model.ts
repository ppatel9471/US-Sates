import { ROLE } from '@myadp/common';
import { MetaFormGroup } from '@myadp/forms';

import { DeductionForm } from './deduction-form.model';

export class DeductionsSelectMetaForm extends MetaFormGroup {
  public deductionsCodeList = this.codeListControl({
    meta: this.meta,
    codeListHrefIndex: 0,
    path: '/workerGeneralDeductionInstruction/generalDeductionInstruction/deductionCode',
    codeListRole: ROLE.EMPLOYEE
  });

  public transform(): DeductionForm {
    return {
      itemID: this.deductionsCodeList?.value?.codeValue,
      deductionCode: {
        codeValue: this.deductionsCodeList?.value?.codeValue,
        longName: this.deductionsCodeList?.value?.longName
      }
    };
  }
}
