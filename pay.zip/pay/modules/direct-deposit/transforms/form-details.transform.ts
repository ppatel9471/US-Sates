import { PayDistributionsUI } from '../../pay-distributions-shared/models/pay-distributions-ui';
import { AccountDetailsControls } from '../models/account-details-form.model';
import { DepositAmountControls } from '../models/deposit-amount-form.model';
import { FormDetails } from '../models/form-details.model';

export function transformToFormDetails(
  depositAccountDetails: Partial<PayDistributionsUI.PayDistributionDetails>
): FormDetails {
  const percentageAmount = depositAccountDetails?.percentageAmount;
  const flatAmount = depositAccountDetails?.flatAmount?.amountValue;

  return {
    ...depositAccountDetails,
    [AccountDetailsControls.ACCOUNT_TYPE_CODE]: {
      label:
        depositAccountDetails?.codeValueData?.longName ||
        depositAccountDetails?.codeValueData?.shortName ||
        depositAccountDetails?.codeValueData?.accountCode,
      longName: depositAccountDetails?.codeValueData?.longName,
      value: depositAccountDetails?.codeValueData?.accountCode,
      shortName: depositAccountDetails?.codeValueData?.shortName
    },
    [DepositAmountControls.PERCENTAGE_AMOUNT]: percentageAmount ? String(percentageAmount) : null,
    [DepositAmountControls.FLAT_AMOUNT]: flatAmount ? String(flatAmount) : null
  };
}
