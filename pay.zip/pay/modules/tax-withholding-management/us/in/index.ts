import { InIntroComponent } from './steps/intro/in-intro.component';
import { InCountyComponent } from './steps/county/in-county.component';
import { InAllowancesComponent } from './steps/allowances/in-allowances.component';
import { InDependentAllowancesComponent } from './steps/dependent-allowances/in-dependent-allowances.component';
import { InAdditionalWithholdingComponent } from './steps/additional-withholding/in-additional-withholding.component';

export { InTWChangeEventService } from './services/in-tw-change-event.service';
export { InSummaryMetaDataService } from './services/in-summary-meta-data.service';
export { InMetaDataDecoratorService } from './services/in-meta-data-decorator.service';

export const IN_COMPONENTS = [
  InIntroComponent,
  InCountyComponent,
  InAllowancesComponent,
  InDependentAllowancesComponent,
  InAdditionalWithholdingComponent
];
export { INSTEP_COMPONENT } from './models/steps-component.model';

export { InAttachmentCodes } from './models/in-tw-change-event';
