import {
  Directive,
  ElementRef,
  Host,
  HostListener,
  Input,
  OnInit,
  Optional
} from '@angular/core';
import { ClientDeviceService, NativeActionService, WindowService } from '@espresso/core';

import {
  AudioEyeService,
  ImpersonationService,
  LanguageService,
  MyadpUrlDecorationHelperService,
  ROLE,
  UrlService,
  UserProfileService
} from '@myadp/common';
import { PreAuthResponse, StepUpFlowService } from '@myadp/step-up';
import { ButtonComponent } from '@synerg/components/button';

import { PdfStatement, StatementType } from '../models/pdf-viewer.model';
import { DownloadPdfService } from '../services/download-pdf.service';

@Directive({
  selector: '[payDownloadPdfUri]'
})
export class DownloadPdfDirective implements OnInit {
  @Input('payDownloadPdfUri') public uri: string;
  @Input('type') public type: StatementType;
  @Input() public stepUpEnabled: boolean = false;
  @Input('accessibilityEnabled') public useAudioEye: boolean = true;
  @Input('statement') public statement?: PdfStatement;

  private isNative: boolean;
  private audioEyeEnabled: boolean;
  private readonly ACCESSIBLE_PDF_URL: string = '/ext/framework/views/accessible-w2.html?url=';

  constructor(
    private urlDecorationHelperService: MyadpUrlDecorationHelperService,
    private urlService: UrlService,
    private windowService: WindowService,
    private nativeActionService: NativeActionService,
    private clientDeviceService: ClientDeviceService,
    private stepUpFlowService: StepUpFlowService,
    private audioEyeService: AudioEyeService,
    private languageService: LanguageService,
    private el: ElementRef,
    private impersonationService: ImpersonationService,
    private downloadPdfService: DownloadPdfService,
    private userProfileService: UserProfileService,
    @Optional() @Host() private buttonComponent: ButtonComponent
  ) {}

  @HostListener('click', ['$event'])
  public clickDownload(): void {
    if (this.el.nativeElement.querySelector('button')) {
      this.download();
    }
  }

  public download(uriFromPaginator?: string) {
    this.uri = uriFromPaginator ? uriFromPaginator : this.uri;
    this.handleFlow(this.audioEyeEnabled && this.useAudioEye);
  }

  public async ngOnInit() {
    this.isNative = this.clientDeviceService.isNative();
    this.audioEyeEnabled = this.audioEyeService.isAudioEyeScriptActive();
    if (this.impersonationService.isImpersonating()) {
      this.buttonComponent.disabled = true;
    }
  }

  private handleFlow(_audioEyeEnabled: boolean = false): void {
    const finalUrl: string = this.buildFinalUrl(this.uri, _audioEyeEnabled);
    const cleanedUri: string = this.stripL2(this.uri);

    if (this.stepUpEnabled) {
      this.stepUpFlowService
        .stepUpPreAuth({
          url: cleanedUri,
          method: 'GET',
          synchronousCallbackConfig:
            this.isNative || this.openIframe(_audioEyeEnabled)
              ? null
              : {
                callback: (res: PreAuthResponse) => {
                  this.handleOpen(
                    this.buildFinalUrl(res.newUrl, _audioEyeEnabled),
                    _audioEyeEnabled
                  );
                },
                loadingMessage: this.languageService.get(
                  'myadp-pay.STEP_UP_DOWNLOAD_SECURITY_WINDOW_LOADING_MESSAGE'
                ),
                message: this.languageService.get(
                  'myadp-pay.STEP_UP_DOWNLOAD_SECURITY_WINDOW_MESSAGE'
                ),
                buttonText: this.languageService.get('myadp-pay.STEP_UP_DOWNLOAD_BUTTON_LABEL')
              }
        })
        .then((res: PreAuthResponse) => {
          if (this.isNative) {
            this.handleOpen(res.newUrl, _audioEyeEnabled);
          } else if (this.openIframe(_audioEyeEnabled)) {
            this.handleOpen(this.buildFinalUrl(res.newUrl, _audioEyeEnabled), _audioEyeEnabled);
          }
        })
        .catch((err: any) => {
          if (err !== 'canceled') {
            this.handleOpen(finalUrl, _audioEyeEnabled);
          }
        });
    } else {
      this.handleOpen(finalUrl, _audioEyeEnabled);
    }
  }

  private handleOpen(finalUrl: string, _audioEyeEnabled: boolean): void {
    if (this.openIframe(_audioEyeEnabled)) {
      this.downloadPdfService.pdfSlideinData$.next({
        finalUrl: finalUrl,
        uri: this.uri,
        type: this.type,
        stepUpEnabled: this.stepUpEnabled,
        useAudioEye: this.useAudioEye,
        singleStatement: this.statement
      });
    } else if (this.isNative) {
      this.openNativeModal(finalUrl);
    } else {
      this.windowService.getWindow().open(finalUrl);
    }
  }

  private openIframe(_audioEyeEnabled: boolean): boolean {
    return this.clientDeviceService.isDesktop() && !_audioEyeEnabled && this.canIframeSOR();
  }

  private canIframeSOR(): boolean {
    // RUN pay & tax statements send header that prevents iframing
    return !(
      this.userProfileService.isRun() &&
      [StatementType.PAY_STATEMENT, StatementType.TAX_STATEMENT].includes(this.type)
    );
  }

  private openNativeModal(url: string): void {
    this.nativeActionService.openModal(this.getNativeWindowConfig(url));
  }

  private getNativeWindowConfig(uri: string) {
    return {
      ...this.urlDecorationHelperService.getNativeApiUrlConfig(uri),
      options: {
        documentFormat: 'PDF'
      }
    };
  }

  private buildFinalUrl(uri: string, _audioEyeEnabled: boolean): string {
    const cleanedUri: string = this.stripL2(uri);
    const decoratedApiUri: string = this.urlDecorationHelperService.decorateApiUrl(cleanedUri);
    const decoratedAccessiblePdfUrl = this.urlDecorationHelperService
      .decorateApiUrl(this.ACCESSIBLE_PDF_URL)
      .replace(/myadp_prefix[^\/]*/, 'static/redbox');

    const finalUrl = _audioEyeEnabled
      ? `${decoratedAccessiblePdfUrl}${this.urlDecorationHelperService.getFullUrl(decoratedApiUri)}`
      : decoratedApiUri;

    return this.urlService.addParam(finalUrl, 'rolecode', ROLE.EMPLOYEE);
  }

  // Sometimes the URIs will contain '/l2/' at the start of the
  // URI; leaving it there causes the URI to be incorrect
  private stripL2(uri: string): string {
    return uri?.includes('/l2/') ? uri?.split('/l2')[1] : uri;
  }
}
