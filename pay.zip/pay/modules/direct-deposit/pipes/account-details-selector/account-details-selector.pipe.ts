import { Pipe, PipeTransform } from '@angular/core';

import { PayDistributionsUI } from '../../../pay-distributions-shared/models/pay-distributions-ui';
import { ValidationStatusObj } from '../../models/deposit-account.model';
import { DirectDepositAccount } from '../../models/direct-deposit-account.model';
import { DirectDepositStore } from '../../store/direct-deposit.store';

export type AccountListDetails = PayDistributionsUI.PayDistributionDetails & {
  isReadOnly: boolean;
  isWisely?: boolean;
  directDepositAccount: DirectDepositAccount;
  pendingEvent: PayDistributionsUI.PendingEvent;
  validationStatus?: ValidationStatusObj;
};

@Pipe({ name: 'accountDetailsSelector', pure: true })
export class AccountDetailsSelectorPipe implements PipeTransform {
  constructor(private directDepositStore: DirectDepositStore) {}

  public transform(
    accounts: DirectDepositAccount[],
    mode: 'list' | 'tile' = 'list'
  ): AccountListDetails[] {
    return accounts
      ?.filter(({ currentData, pendingData, pendingEvent }) =>
        mode === 'tile'
          ? pendingEvent?.changeType !== 'delete' && (pendingData || currentData)
          : pendingData || currentData
      )
      ?.map((account) => {
        const accountProps = account.pendingData ?? account.currentData;
        return {
          ...accountProps,
          isWisely: account.isWisely,
          isReadOnly: account.isReadOnly || account.pendingEvent?.changeType === 'delete',
          directDepositAccount: account,
          pendingEvent: account.pendingEvent,
          validationStatus: this.directDepositStore.getValidationStatus(
            `${accountProps?.routingNumber}${accountProps?.accountNumber}`
          )
        } as AccountListDetails;
      });
  }
}
