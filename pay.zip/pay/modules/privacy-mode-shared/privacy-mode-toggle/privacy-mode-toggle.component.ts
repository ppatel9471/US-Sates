import { ChangeDetectionStrategy, Component, Input, OnInit } from '@angular/core';
import { Observable } from 'rxjs';

import { PrivacyModeStore } from '../store/privacy-mode.store';

@Component({
  selector: 'pay-privacy-mode-toggle',
  styleUrls: ['./privacy-mode-toggle.component.scss'],
  templateUrl: './privacy-mode-toggle.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class PrivacyModeToggleComponent implements OnInit {
  // Whether or not this is a global toggle or a tile-specific one
  @Input() public tileOnly?: boolean = false;
  public isEnabled: Observable<boolean>;

  constructor(private privacyModeStore: PrivacyModeStore) {}

  public togglePrivacyMode(privacyModeEnabled: boolean): void {
    this.privacyModeStore.setPrivacyMode(privacyModeEnabled);
  }

  public ngOnInit() {
    this.isEnabled = this.privacyModeStore.privacyMode$;
  }
}
