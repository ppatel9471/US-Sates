import { Injectable } from '@angular/core';
import { GridData } from '@synerg/components/datagrid';
import { SelectOption } from '@synerg/components/select';
import { sortBy } from 'lodash';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { LanguageService } from '@myadp/common';
import { WorkerTaxStatementsDTO } from '@myadp/dto';
import { BaseStore } from '@myadp/pay-shared';

import { PdfStatement } from '../../shared/models/pdf-viewer.model';
import { RowDataProperties, RowDataPropertiesType } from '../models/tax-statements-modal.model';
import { TaxStatementsStoreSlice, TaxStatementsStoreState } from '../models/tax-statements-state.model';
import { TaxStatementsType } from '../models/tax-statements.model';

@Injectable({
  providedIn: 'root'
})
export class TaxStatementsStore extends BaseStore<TaxStatementsStoreState> {
  constructor(private languageService: LanguageService) {
    super({
      [TaxStatementsStoreSlice.TAX_STATEMENTS]: { data: undefined, loading: false, error: {} }
    });
  }

  public taxStatements$(): Observable<WorkerTaxStatementsDTO.WorkerTaxStatement[]> {
    return this.getData$(TaxStatementsStoreSlice.TAX_STATEMENTS);
  }

  public taxStatementsError$(): Observable<boolean> {
    return this.hasError$(TaxStatementsStoreSlice.TAX_STATEMENTS, 'loadTaxStatementsError');
  }

  public taxStatementsIsLoading$(): Observable<boolean> {
    return this.isSliceLoading$(TaxStatementsStoreSlice.TAX_STATEMENTS);
  }

  public emptyTaxStatement$(): Observable<boolean> {
    return this.taxStatements$().pipe(
      map((taxStatements) => {
        return !taxStatements || taxStatements?.length === 0;
      })
    );
  }

  public selectionYears$(): Observable<SelectOption[]> {
    return this.statementsByYear$().pipe(
      map((statements) => {
        const yearSet = [...new Set(statements.map((statement) => statement.statementYear?.year))];
        return yearSet.map((year) => {
          const label = year === '0' ? this.languageService.get('common.OTHER') : year;
          if (year) {
            return {
              value: year,
              label: `${label} (${this.filterStatementsByYear(statements, year).length})`
            };
          }
        });
      })
    );
  }

  public statementsByYear$(): Observable<WorkerTaxStatementsDTO.WorkerTaxStatement[]> {
    return this.taxStatements$().pipe(
      map((taxStatements) => {
        return this.sortStatementsByYear(taxStatements);
      })
    );
  }

  public filterStatementsByYear$(
    selectedYear: string
  ): Observable<WorkerTaxStatementsDTO.WorkerTaxStatement[]> {
    return this.statementsByYear$().pipe(
      map((taxStatements) => {
        return this.filterStatementsByYear(taxStatements, selectedYear);
      })
    );
  }

  public mostRecentTaxYear$(): Observable<string> {
    return this.statementsByYear$().pipe(
      map((statements) => {
        return statements[0]?.statementYear?.year;
      })
    );
  }

  public statementsForPdfViewer$(): Observable<PdfStatement[]> {
    return this.statementsByYear$().pipe(
      map((statements) => {
        return statements.map((statement) => {
          return {
            uri: statement?.statementImageUri?.href,
            title: this.languageService.get('myadp-pay.PDF_VIEWER_SLIDEIN_HEADER_STATEMENT', {
              value: statement?.statementYear.year
            }),
            statementDetails: [
              {
                label: 'myadp-pay.PDF_VIEWER_SLIDEIN_TAX_YEAR',
                value: statement?.statementYear?.year
              },
              { label: 'myadp-pay.PDF_VIEWER_SLIDEIN_FORM_TYPE', value: statement?.form?.code }
            ]
          };
        });
      })
    );
  }

  public dataGridStatements(
    taxStatements: WorkerTaxStatementsDTO.WorkerTaxStatement[]
  ): GridData<RowDataProperties> {
    const dataGridData: GridData<RowDataProperties> = [];
    for (const statement of taxStatements) {
      dataGridData.push({
        [RowDataPropertiesType.YEAR]: statement?.statementYear?.year,
        [RowDataPropertiesType.TYPE]: statement?.form?.code,
        [RowDataPropertiesType.EMPLOYER]:
          showEmployerName && !!statement?.employerName ? statement?.employerName : '--',
        [RowDataPropertiesType.AMOUNT]: showAmount(statement)
          ? statement?.summaryAmount?.amountValue
          : null,
        [RowDataPropertiesType.CURRENCY]: showAmount(statement)
          ? statement?.summaryAmount?.currencyCode
          : '',
        [RowDataPropertiesType.DOWNLOAD]: statement?.statementImageUri?.href
      });
    }
    return dataGridData;
  }

  private filterStatementsByYear(
    taxStatements: WorkerTaxStatementsDTO.WorkerTaxStatement[],
    selectedYear: string
  ): WorkerTaxStatementsDTO.WorkerTaxStatement[] {
    return taxStatements.filter((statement) => statement.statementYear.year === selectedYear);
  }

  private sortStatementsByYear(
    taxStatements: WorkerTaxStatementsDTO.WorkerTaxStatement[]
  ): WorkerTaxStatementsDTO.WorkerTaxStatement[] {
    return sortBy(taxStatements, 'statementYear.year').reverse();
  }
}

export function showAmount(statement: WorkerTaxStatementsDTO.WorkerTaxStatement): boolean {
  return (
    statement?.form?.code !== TaxStatementsType.MISCELLANEOUS &&
    statement?.form?.code !== TaxStatementsType.COVERAGE_INSURANCE &&
    statement?.summaryAmount?.amountValue !== undefined
  );
}

export function showEmployerName(statement: WorkerTaxStatementsDTO.WorkerTaxStatement): boolean {
  const type = [
    TaxStatementsType.MISCELLANEOUS,
    TaxStatementsType.SELFEMPLOYMENT,
    TaxStatementsType.RETIREMENT
  ];
  return !!statement?.employerName && !type.includes(statement?.form?.code);
}
