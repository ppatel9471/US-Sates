import { CurrencyPipe } from '@angular/common';
import { TestBed } from '@angular/core/testing';
import { cloneDeep } from 'lodash';
import { Mock } from 'ts-mockery';

import { LanguageService } from '@myadp/common';
import { WorkerTaxStatementsDTO } from '@myadp/dto';

import { ValueFormatterService } from '../../shared/services/value-formatter.service';
import { RowDataPropertiesType } from '../models/tax-statements-modal.model';
import { TaxStatementsStoreSlice } from '../models/tax-statements-state.model';
import { showAmount, showEmployerName, TaxStatementsStore } from './tax-statements.store';

describe('TaxStatementsStore', () => {
  let taxStatementsStore: TaxStatementsStore;

  const mockStatement: WorkerTaxStatementsDTO.WorkerTaxStatement = {
    statementName: '2013 1095-C',
    employerName: 'AUTOMATIC DATA PROCESSING',
    form: {
      code: '1095-C'
    },

    statementYear: {
      year: '2013'
    },
    summaryAmount: {
      amountValue: 20130,
      currencyCode: 'USD'
    },
    statementImageUri: {
      href: 'mockPDF.pdf'
    }
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        TaxStatementsStore,
        ValueFormatterService,
        CurrencyPipe,
        {
          provide: LanguageService,
          useValue: Mock.of<LanguageService>({ get: (key) => key })
        }
      ]
    });
    taxStatementsStore = TestBed.inject(TaxStatementsStore);
  });

  it('should create the store with an initial state', () => {
    expect(taxStatementsStore).toBeTruthy();
    expect(taxStatementsStore.stateValue).toEqual({
      [TaxStatementsStoreSlice.TAX_STATEMENTS]: {
        data: undefined,
        loading: false,
        error: {}
      }
    });
  });

  it('should get isLoading', async (done: DoneFn) => {
    taxStatementsStore.update(TaxStatementsStoreSlice.TAX_STATEMENTS, {
      loading: true
    });
    taxStatementsStore.taxStatementsIsLoading$().subscribe((loading) => {
      expect(loading).toBe(true);
      done();
    });
  });

  it('should get hasError', async (done: DoneFn) => {
    taxStatementsStore.update(TaxStatementsStoreSlice.TAX_STATEMENTS, {
      error: { loadTaxStatementsError: true }
    });
    taxStatementsStore.taxStatementsError$().subscribe((error) => {
      expect(error).toBe(true);
      done();
    });
  });

  it('should get unsorted statements', async (done: DoneFn) => {
    const mockStatement2 = cloneDeep(mockStatement);
    mockStatement2.statementYear.year = '2018';
    taxStatementsStore.update(TaxStatementsStoreSlice.TAX_STATEMENTS, {
      data: [mockStatement, mockStatement2]
    });
    taxStatementsStore.taxStatements$().subscribe((statements) => {
      expect(statements).toEqual([mockStatement, mockStatement2]);
      done();
    });
  });

  it('should get sorted statements', async (done: DoneFn) => {
    const mockStatement2 = cloneDeep(mockStatement);
    mockStatement2.statementYear.year = '2018';
    taxStatementsStore.update(TaxStatementsStoreSlice.TAX_STATEMENTS, {
      data: [mockStatement, mockStatement2]
    });
    taxStatementsStore.statementsByYear$().subscribe((statements) => {
      expect(statements).toEqual([mockStatement2, mockStatement]);
      done();
    });
    taxStatementsStore.mostRecentTaxYear$().subscribe((year) => {
      expect(year).toEqual('2018');
      done();
    });
  });

  it('should get selectionYears', async (done: DoneFn) => {
    const mockStatement2 = cloneDeep(mockStatement);
    mockStatement2.statementYear.year = '0';
    taxStatementsStore.update(TaxStatementsStoreSlice.TAX_STATEMENTS, {
      data: [mockStatement, mockStatement, mockStatement2]
    });
    taxStatementsStore.selectionYears$().subscribe((selectionYears) => {
      expect(selectionYears).toEqual([
        { value: '2013', label: '2013 (2)' },
        { value: '0', label: 'common.OTHER (1)' }
      ]);
      done();
    });
  });

  it('should show -- when employer name is missing', () => {
    const mockStatement2 = cloneDeep(mockStatement);
    mockStatement2.employerName = '';
    const data = taxStatementsStore.dataGridStatements([mockStatement2]);
    expect(data[0][RowDataPropertiesType.EMPLOYER]).toEqual('--');
  });

  it('should get pdf statements', async (done: DoneFn) => {
    const mockStatement2 = cloneDeep(mockStatement);
    mockStatement2.statementYear.year = '2018';
    taxStatementsStore.update(TaxStatementsStoreSlice.TAX_STATEMENTS, {
      data: [mockStatement, mockStatement2]
    });
    taxStatementsStore.statementsByYear$().subscribe((statements) => {
      expect(statements).toEqual([mockStatement2, mockStatement]);
      done();
    });
    taxStatementsStore.statementsForPdfViewer$().subscribe((statements) => {
      expect(statements).toEqual([
        {
          title: 'myadp-pay.PDF_VIEWER_SLIDEIN_HEADER_STATEMENT',
          uri: 'mockPDF.pdf',
          statementDetails: [
            {
              label: 'myadp-pay.PDF_VIEWER_SLIDEIN_TAX_YEAR',
              value: mockStatement2.statementYear.year
            },
            { label: 'myadp-pay.PDF_VIEWER_SLIDEIN_FORM_TYPE', value: mockStatement2.form.code }
          ]
        },
        {
          title: 'myadp-pay.PDF_VIEWER_SLIDEIN_HEADER_STATEMENT',
          uri: 'mockPDF.pdf',
          statementDetails: [
            {
              label: 'myadp-pay.PDF_VIEWER_SLIDEIN_TAX_YEAR',
              value: mockStatement.statementYear.year
            },
            { label: 'myadp-pay.PDF_VIEWER_SLIDEIN_FORM_TYPE', value: mockStatement.form.code }
          ]
        }
      ]);
      done();
    });
  });

  describe('show amount', () => {
    it('should show amount', () => {
      expect(showAmount(mockStatement)).toEqual(false);
      mockStatement.form.code = 'W-2';
      expect(showAmount(mockStatement)).toEqual(true);
      mockStatement.form.code = '1099-MISC';
      expect(showAmount(mockStatement)).toEqual(false);
    });

    it('should show amount when amount is 0', () => {
      mockStatement.form.code = 'W-2';
      mockStatement.summaryAmount.amountValue = 0;
      expect(showAmount(mockStatement)).toEqual(true);
    });

    it('should not show amount when amount value is undefined', () => {
      mockStatement.form.code = 'W-2';
      mockStatement.summaryAmount.amountValue = undefined;
      expect(showAmount(mockStatement)).toEqual(false);

      mockStatement.summaryAmount = undefined;
      expect(showAmount(mockStatement)).toEqual(false);
    });
  });

  describe('empty tax statment', () => {
    it('should return emptyTaxStatement as false', async (done: DoneFn) => {
      taxStatementsStore.update(TaxStatementsStoreSlice.TAX_STATEMENTS, {
        data: [mockStatement]
      });
      taxStatementsStore.emptyTaxStatement$().subscribe((emptyTaxStatement) => {
        expect(emptyTaxStatement).toBeFalse();
        done();
      });
    });

    it('should return emptyTaxStatement as true when empty array', async (done: DoneFn) => {
      taxStatementsStore.update(TaxStatementsStoreSlice.TAX_STATEMENTS, {
        data: []
      });
      taxStatementsStore.emptyTaxStatement$().subscribe((emptyTaxStatement) => {
        expect(emptyTaxStatement).toBeTrue();
        done();
      });
    });

    it('should return emptyTaxStatement as true when data is null', async (done: DoneFn) => {
      taxStatementsStore.update(TaxStatementsStoreSlice.TAX_STATEMENTS, {
        data: null
      });
      taxStatementsStore.emptyTaxStatement$().subscribe((emptyTaxStatement) => {
        expect(emptyTaxStatement).toBeTrue();
        done();
      });
    });
  });

  it('should showEmployerName', () => {
    mockStatement.form.code = '1099-MISC';
    expect(showEmployerName(mockStatement)).toEqual(false);
    mockStatement.form.code = '1099';
    expect(showEmployerName(mockStatement)).toEqual(false);
    mockStatement.form.code = '1099-R';
    expect(showEmployerName(mockStatement)).toEqual(false);
    mockStatement.form.code = 'W-2';
    expect(showEmployerName(mockStatement)).toEqual(true);
  });
});
