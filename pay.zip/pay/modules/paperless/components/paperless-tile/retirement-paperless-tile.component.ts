import { Component, OnInit, Optional } from '@angular/core';
import { TileService } from '@synerg/components/tile';
import { PageType } from '@myadp/pay-paperless-shared/models/page-type.enum';

@Component({
  selector: 'go-retirement-paperless-tile',
  template: '<go-paperless-tile [pageType]="pageType"></go-paperless-tile>'
})
export class RetirementPaperlessTileComponent implements OnInit {
  pageType: PageType;
  constructor(@Optional() private tileService: TileService) {}

  ngOnInit() {
    this.pageType = PageType.RETIREMENT;
    this.tileService?.setIsLoading(false);
  }
}
