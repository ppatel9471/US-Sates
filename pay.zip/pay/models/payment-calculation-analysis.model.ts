export interface PaymentCalculationAnalysis {
  associateOid: string;
  paymentCalculationId: string;
  payPeriodId: string;
  insights?: Insight[];
  facts: Fact[];
}

export interface Fact {
  code: string;
  rank: number;
}

export interface Insight {
  text: string;
  rank: number;
  tags?: string[];
}

export enum INSIGHTS_TAG {
  RETIREMENT = 'Retirement',
  BENEFITS = 'Benefits',
  TAXES = 'Taxes',
  EARNINGS = 'Earnings'
}
