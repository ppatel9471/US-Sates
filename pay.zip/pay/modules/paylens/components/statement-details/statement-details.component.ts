import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { Observable } from 'rxjs';

import { PayStatementStore } from '../../../pay-statements-shared/store/pay-statement.store';

@Component({
  selector: 'paylens-statement-details',
  styleUrls: ['./statement-details.component.scss'],
  templateUrl: './statement-details.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class PaylensStatementDetailsComponent {
  // whether or not to use YTD values
  @Input() public yearToDate?: boolean = false;
  @Input() public isMobileView?: boolean = false;
  @Input() public onInsightsTab?: boolean = false;
  public listExpanded: boolean = false;
  public store: Record<string, Observable<any>>;

  constructor(private payStatementStore: PayStatementStore) {
    this.store = {
      memos$: this.payStatementStore.statementDetails$('memos'),
      currentStatement$: this.payStatementStore.currentStatement$,
      hasError$: this.payStatementStore.hasStatementDetailsError$,
      statementDetails$: this.payStatementStore.statementDetails$(),
      isLoading$: this.payStatementStore.isStatementDetailsLoading$,
      isStatementsLoading$: this.payStatementStore.isPayStatementsLoading$,
      currentDetailsData$: this.payStatementStore.currentDetailsData$,
      earnings$: this.payStatementStore.statementDetails$('earnings'),
      donutData$: this.payStatementStore.statementDetails$('donutData'),
      categorizedInsights$: this.payStatementStore.categorizedInsights$,
      deductions$: this.payStatementStore.statementDetails$('deductionsCategories')
    };
  }

  public clickListExpand(listExpanded: boolean) {
    this.listExpanded = listExpanded;
  }
}
