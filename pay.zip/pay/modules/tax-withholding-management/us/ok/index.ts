import { OkIntroComponent } from './steps/intro/ok-intro.component';
import { OkMaritalStatusComponent } from './steps/marital-status/ok-marital-status.component';
import { OkExemptionComponent } from './steps/exemption/ok-exemption.component';
import { OkAllowancesComponent } from './steps/allowances/ok-allowances.component';

export { OkStepNavigationService } from './services/ok-step-navigation.service';
export { OkTWChangeEventService } from './services/ok-tw-change-event.service';
export { OkSummaryMetaDataService } from './services/ok-summary-meta-data.service';

export const OK_COMPONENTS = [
  OkIntroComponent,
  OkMaritalStatusComponent,
  OkExemptionComponent,
  OkAllowancesComponent
];

export { OKSTEP_COMPONENT } from './models/steps-component.model';

export { OkAttachmentCodes } from './models/ok-tw-change-event';
