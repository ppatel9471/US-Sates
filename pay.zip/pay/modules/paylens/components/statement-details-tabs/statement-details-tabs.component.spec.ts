import { TabComponent } from '@synerg/components/tabs';
import { Shallow } from 'shallow-render';

import { LanguagePipe } from '@myadp/common';

import { PaylensModule } from '../../paylens.module';
import { PaylensStatementDetailsComponent } from '../statement-details/statement-details.component';
import { PaylensStatementDetailsTabsComponent } from './statement-details-tabs.component';

describe('PaylensStatementDetailsTabsComponent', () => {
  let shallow: Shallow<PaylensStatementDetailsTabsComponent>;

  beforeEach(() => {
    shallow = new Shallow(PaylensStatementDetailsTabsComponent, PaylensModule).mockPipe(
      LanguagePipe,
      (key) => key
    );
  });

  it('should have 3 tabs', async () => {
    const { findComponent } = await shallow.render();
    const tabComp = findComponent(TabComponent);
    const [currentComp, ytdComp] = findComponent(PaylensStatementDetailsComponent);

    expect(tabComp).toHaveFound(3);
    expect(currentComp.yearToDate).toBeFalsy();
    expect(ytdComp.yearToDate).toBe(true);
  });

  it('should have tabs labeled', async () => {
    const { findComponent } = await shallow.render();
    const [currentTab, ytdTab] = findComponent(TabComponent);

    expect(currentTab.label).toBe('common.CURRENT');
    expect(ytdTab.label).toBe('myadp-pay.PAY_YTD_TAB_TITLE');
  });

  it('should set onInsightsTab to be false', async () => {
    const { findComponent, instance } = await shallow.render();
    const currentTab = findComponent(TabComponent)[0];
    currentTab.tabClick.emit();
    expect(instance.onInsightsTab).toBeFalse();
  });

  it('should set onInsightsTab to be true', async () => {
    const { findComponent, instance } = await shallow.render();
    const insightsTab = findComponent(TabComponent)[2];
    insightsTab.tabClick.emit();
    expect(instance.onInsightsTab).toBeTrue();
  });
});
