import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { of, throwError } from 'rxjs';
import { CustomContentComponent } from './custom-content.component';
import { Mock } from 'ts-mockery';
import { MockLoggerFactory } from '@specHelpers';
import { LoggerFactory } from '@espresso/core';
import { CustomContentService } from '../../services/custom-content.service';

describe('CustomContentComponent', () => {
  let component: CustomContentComponent;
  let fixture: ComponentFixture<CustomContentComponent>;
  let mockCustomContentService: CustomContentService;
  const mockResponse = 'test';
  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [CustomContentComponent],
      providers: [
        {
          provide: CustomContentService,
          useValue: Mock.of<CustomContentService>()
        },
        { provide: LoggerFactory, useClass: MockLoggerFactory }
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomContentComponent);
    component = fixture.componentInstance;
    mockCustomContentService = TestBed.inject(CustomContentService);
    component.featureKey = 'taxWithholding';
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should hide custom content when call fails', () => {
    Mock.extend(mockCustomContentService).with({
      getCustomContent: () => throwError(new Error('error'))
    });
    fixture.detectChanges();
    const element = fixture.nativeElement.querySelector('article');
    expect(element).toBe(null);
  });

  it('should show custom content when call succeeds', () => {
    Mock.extend(mockCustomContentService).with({
      getCustomContent: () => of(mockResponse)
    });
    fixture.detectChanges();
    expect(fixture.nativeElement.innerHTML).toContain(mockResponse);
  });
});
