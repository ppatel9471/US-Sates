import { FormItem } from '../../meta/models/form-item.model';

export const ContentDemo: FormItem[] = [
  {
    id: 'text',
    type: 'content',
    content: [
      {
        textItem: { key: 'textItem' }
      }
    ]
  },
  {
    id: 'link',
    type: 'content',
    content: [
      {
        linkItem: {
          key: 'linkItem',
          url: 'https://www.adp.com',
          icon: 'external-link'
        }
      }
    ]
  },
  {
    id: 'tooltip',
    type: 'content',
    content: [
      {
        tooltipItem: {
          key: 'tooltip key',
          title: 'tooltip title',
          link: {
            key: 'linkItem',
            url: 'https://www.adp.com',
            icon: 'external-link'
          }
        }
      }
    ]
  },
  {
    id: 'text-tooltip',
    type: 'content',
    content: [
      {
        textItem: { key: 'textItem and tooltip' },
        tooltipItem: {
          key: 'tooltip key',
          title: 'tooltip title',
          link: {
            key: 'linkItem',
            url: 'https://www.adp.com',
            icon: 'external-link'
          }
        }
      }
    ]
  },
  {
    id: 'grid-text-link',
    type: 'content',
    content: [
      {
        textItem: { key: 'text and link' },
        linkItem: {
          key: 'link',
          url: 'https://www.adp.com',
          icon: 'external-link'
        }
      }
    ]
  },
  {
    id: 'grid-text-tooltip-link',
    type: 'content',
    content: [
      {
        textItem: { key: 'text, tooltip and link' },
        tooltipItem: {
          key: 'tooltip key',
          title: 'tooltip title',
          link: {
            key: 'link',
            url: 'https://www.adp.com',
            icon: 'external-link'
          }
        },
        linkItem: {
          key: 'link',
          url: 'https://www.adp.com',
          icon: 'external-link'
        }
      }
    ]
  },
  {
    id: 'combo',
    type: 'content',
    content: [
      {
        textItem: { key: 'textItem' }
      },
      {
        textItem: { key: 'text and link' },
        linkItem: {
          key: 'link',
          url: 'https://www.adp.com',
          icon: 'external-link'
        }
      }
    ]
  }
];
