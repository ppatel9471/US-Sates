import { fakeAsync, tick } from '@angular/core/testing';
import { DomSanitizer } from '@angular/platform-browser';
import { BehaviorSubject, of, throwError } from 'rxjs';
import { Shallow } from 'shallow-render';
import { Mock } from 'ts-mockery';

import { ExternalWindowService, LanguagePipe, LanguageService } from '@myadp/common';
import { expectButtonToBeDisabled } from '@myadp/pay-shared/testing/spec-util.spec';

import { DownloadPdfDirective } from '../../directives/download-pdf.directive';
import {
  PdfStatement,
  StatementBehaviorSubject,
  StatementType
} from '../../models/pdf-viewer.model';
import { DownloadPdfService } from '../../services/download-pdf.service';
import { SharedModule } from '../../shared.module';
import { PdfViewerSlideinComponent } from './pdf-viewer-slidein.component';

describe('PdfViewerSlideinComponent', () => {
  let shallow: Shallow<PdfViewerSlideinComponent>;
  const payStatementUri = '/l2/v1_0/O/A/payStatement/1/images/1.pdf';
  const nextPayStatementUri = '/l2/v1_0/O/A/payStatement/2/images/2.pdf';

  const payStatements: PdfStatement[] = [
    {
      title: 'Apr 14, 2019',
      uri: payStatementUri,
      statementDetails: [
        { label: 'Pay Date: ', value: 'Apr 14, 2019' },
        { label: 'Gross Pay: ', value: '1732.1' },
        { label: 'Net Pay: ', value: '800.15' }
      ]
    },
    {
      title: 'Apr 07, 2019',
      uri: nextPayStatementUri,
      statementDetails: [
        { label: 'Pay Date: ', value: 'Apr 07, 2019' },
        { label: 'Gross Pay: ', value: '1732.1' },
        { label: 'Net Pay: ', value: '800.15' }
      ]
    }
  ];
  const taxStatementUri = '/image/1.pdf';

  const taxStatements: PdfStatement[] = [
    {
      title: 'myadp-pay.PDF_VIEWER_SLIDEIN_HEADER_STATEMENT',
      uri: taxStatementUri
    }
  ];

  const blankFormStatement: PdfStatement = {
    title: 'Blank Form Title',
    uri: '/blank/form.pdf'
  };

  const pdfSlideinDataPay: StatementBehaviorSubject = {
    finalUrl: payStatementUri,
    uri: payStatementUri,
    type: StatementType.PAY_STATEMENT,
    stepUpEnabled: false,
    useAudioEye: false
  };
  const pdfSlideinDataTax: StatementBehaviorSubject = {
    finalUrl: taxStatementUri,
    uri: taxStatementUri,
    type: StatementType.TAX_STATEMENT,
    stepUpEnabled: false,
    useAudioEye: false
  };
  const pdfSlideinDataBankForm: StatementBehaviorSubject = {
    finalUrl: blankFormStatement.uri,
    uri: blankFormStatement.uri,
    type: StatementType.TAX_WITHHOLDING_BLANK_FORM,
    singleStatement: blankFormStatement,
    stepUpEnabled: false,
    useAudioEye: false
  };
  const pdfSlideinDataTaxWithholding: StatementBehaviorSubject = {
    finalUrl: 'mock/tax-withholding.pdf',
    uri: 'mock/tax-withholding.pdf',
    type: StatementType.TAX_WITHHOLDING,
    singleStatement: {
      title: 'Tax withholding Form Title',
      uri: 'mock/tax-withholding.pdf'
    },
    stepUpEnabled: false,
    useAudioEye: false
  };
  let pdfSlideinData$: BehaviorSubject<StatementBehaviorSubject>;

  beforeEach(() => {
    pdfSlideinData$ = new BehaviorSubject(pdfSlideinDataPay);

    shallow = new Shallow(PdfViewerSlideinComponent, SharedModule)
      .provide(LanguageService)
      .dontMock(PdfViewerSlideinComponent)
      .mock(DownloadPdfService, {
        pdfSlideinData$: pdfSlideinData$,
        getPdf: () => of(new ArrayBuffer(8))
      })
      .dontMock(DomSanitizer)
      .mock(LanguageService, { get: (key: string) => key })
      .mock(ExternalWindowService, {
        open: () => Mock.noop()
      })
      .mockPipe(LanguagePipe, (key) => key)
      .mock(DownloadPdfDirective, { download: () => Mock.noop() });
  });

  it('should show statement detail for Pay Statements', async () => {
    const { fixture, instance } = await shallow.render({
      bind: {
        statements: payStatements,
        type: StatementType.PAY_STATEMENT
      }
    });
    fixture.detectChanges();
    expect(instance.title).toEqual(payStatements[0].title);
  });

  it('should show statement detail for Tax Statements', async () => {
    pdfSlideinData$.next(pdfSlideinDataTax);
    const { fixture, instance } = await shallow.render({
      bind: {
        statements: taxStatements,
        type: StatementType.TAX_STATEMENT
      }
    });
    fixture.detectChanges();
    expect(instance.title).toEqual('myadp-pay.PDF_VIEWER_SLIDEIN_HEADER_STATEMENT');
  });

  it('should show statement detail for Tax Withholding Blank Forms', async () => {
    pdfSlideinData$.next(pdfSlideinDataBankForm);
    const { fixture, instance } = await shallow.render({
      bind: {
        type: StatementType.TAX_WITHHOLDING_BLANK_FORM
      }
    });
    fixture.detectChanges();
    expect(instance.title).toEqual(blankFormStatement.title);
  });

  it('should show get current statement, previous and next statement url', async () => {
    const { fixture, instance } = await shallow.render({
      bind: {
        statements: payStatements,
        type: StatementType.PAY_STATEMENT
      }
    });
    fixture.detectChanges();
    expect(instance.currentStatement).toEqual(payStatements[0]);
    expect(instance.nextStatementUrl).toEqual(nextPayStatementUri);
    expect(instance.previousStatementUrl).toBeUndefined();
  });

  it('should disable previous statement button', async () => {
    const { fixture, find } = await shallow.render({
      bind: {
        statements: payStatements,
        type: StatementType.PAY_STATEMENT
      }
    });
    fixture.detectChanges();
    expectButtonToBeDisabled(find, 'previous');
  });

  it('should disable next statement button', async () => {
    pdfSlideinDataPay.uri = nextPayStatementUri;
    const { fixture, find, instance } = await shallow.render({
      bind: {
        statements: payStatements,
        type: StatementType.PAY_STATEMENT
      }
    });
    fixture.detectChanges();

    expect(instance.currentStatement).toEqual(payStatements[1]);
    expect(instance.previousStatementUrl).toEqual(payStatementUri);
    expect(instance.nextStatementUrl).toBeUndefined();
    expectButtonToBeDisabled(find, 'next');
  });

  it('should show slide in footer for multiple statement', async () => {
    const { fixture, find } = await shallow.render({
      bind: {
        statements: payStatements,
        type: StatementType.PAY_STATEMENT
      }
    });
    fixture.detectChanges();

    expect(find('adp-slidein').attributes['ng-reflect-show-footer']).toEqual('true');
  });

  it('should hide slide in footer for single statement', async () => {
    pdfSlideinData$.next(pdfSlideinDataBankForm);
    const { fixture, find } = await shallow.render({
      bind: {
        type: StatementType.TAX_WITHHOLDING_BLANK_FORM
      }
    });
    fixture.detectChanges();

    expect(find('adp-slidein').attributes['ng-reflect-show-footer']).toEqual('false');
  });

  it('should get final safeUrl', async () => {
    const { fixture, get, instance } = await shallow.render({
      bind: {
        statements: payStatements,
        type: StatementType.PAY_STATEMENT
      }
    });
    fixture.detectChanges();
    const sanitizer = get(DomSanitizer);

    expect(instance.finalUrl).toEqual(
      sanitizer.bypassSecurityTrustResourceUrl(pdfSlideinDataPay.finalUrl)
    );
  });

  describe('paginator', () => {
    it('should hide paginator', async () => {
      const { fixture, find } = await shallow.render({
        bind: {
          statements: undefined,
          type: StatementType.PAY_STATEMENT
        }
      });
      fixture.detectChanges();
      expect(find('adp-paginator')).toHaveFound(0);
    });

    it('should hide paginator for tax statement', async () => {
      const { fixture, find } = await shallow.render({
        bind: {
          statements: payStatements,
          type: StatementType.TAX_STATEMENT
        }
      });
      fixture.detectChanges();
      expect(find('adp-paginator')).toHaveFound(0);
    });

    it('should show paginator', async () => {
      const { fixture, find } = await shallow.render({
        bind: {
          statements: payStatements,
          type: StatementType.PAY_STATEMENT
        }
      });
      fixture.detectChanges();
      expect(find('adp-paginator')).toHaveFound(1);
    });
  });
  describe('on page changes', () => {
    it('should call download when select a new statement', async () => {
      const { fixture, instance, findDirective } = await shallow.render({
        bind: {
          statements: payStatements,
          type: StatementType.PAY_STATEMENT
        }
      });
      // current statement 2, select new statement 1
      instance.onPageChange(1);
      fixture.detectChanges();

      const downloadPdfDirective = findDirective(DownloadPdfDirective);
      expect(downloadPdfDirective[0].download).toHaveBeenCalled();
    });

    it('should not call download when select current statement', async () => {
      const { fixture, instance, findDirective } = await shallow.render({
        bind: {
          statements: payStatements,
          type: StatementType.PAY_STATEMENT
        }
      });
      // current statement 2, select new statement 2
      instance.onPageChange(2);
      fixture.detectChanges();

      const downloadPdfDirective = findDirective(DownloadPdfDirective);
      expect(downloadPdfDirective[0].download).not.toHaveBeenCalled();
    });
  });

  describe('download error', () => {
    it('should not show download error', async () => {
      const { fixture, instance, find } = await shallow.render({
        bind: {
          statements: payStatements,
          type: StatementType.PAY_STATEMENT
        }
      });
      fixture.detectChanges();
      expect(instance.downloadError).toBeFalsy();
      find('#download').nativeElement.click();
      fixture.detectChanges();
      expect(instance.downloadError).toBeFalsy();
    });

    it('should show download error for Pay Statements', fakeAsync(async () => {
      shallow.mock(DownloadPdfService, {
        getPdf: () => throwError({})
      });
      const { fixture, instance, find } = await shallow.render({
        bind: {
          statements: payStatements,
          type: StatementType.PAY_STATEMENT
        }
      });
      fixture.detectChanges();
      expect(instance.downloadError).toBeFalsy();
      find('#download').nativeElement.click();
      fixture.detectChanges();
      tick();
      expect(instance.downloadError).toBeTruthy();
      expect(instance.errorMessage).toEqual('myadp-pay.PDF_SLIDEIN_PAY_STATEMENT_DOWNLOAD_ERROR');
    }));

    it('should show download error for Tax Statements', fakeAsync(async () => {
      shallow.mock(DownloadPdfService, {
        getPdf: () => throwError({})
      });
      pdfSlideinData$.next(pdfSlideinDataTax);
      const { fixture, instance, find } = await shallow.render({
        bind: {
          statements: taxStatements,
          type: StatementType.TAX_STATEMENT
        }
      });
      fixture.detectChanges();
      expect(instance.downloadError).toBeFalsy();
      find('#download').nativeElement.click();
      fixture.detectChanges();
      tick();
      expect(instance.downloadError).toBeTruthy();
      expect(instance.errorMessage).toEqual('myadp-pay.PDF_SLIDEIN_TAX_STATEMENT_DOWNLOAD_ERROR');
    }));

    it('should show download error for Tax Withholding Blank Forms', fakeAsync(async () => {
      shallow.mock(DownloadPdfService, {
        getPdf: () => throwError({})
      });
      pdfSlideinData$.next(pdfSlideinDataBankForm);
      const { fixture, instance, find } = await shallow.render({
        bind: {
          type: StatementType.TAX_WITHHOLDING_BLANK_FORM
        }
      });
      fixture.detectChanges();
      expect(instance.downloadError).toBeFalsy();
      find('#download').nativeElement.click();
      fixture.detectChanges();
      tick();
      expect(instance.downloadError).toBeTruthy();
      expect(instance.errorMessage).toEqual('myadp-pay.PDF_SLIDEIN_TAX_WITHHOLDING_DOWNLOAD_ERROR');
    }));
  });

  it('should show download error for Tax Withholding Forms', fakeAsync(async () => {
    shallow.mock(DownloadPdfService, {
      getPdf: () => throwError({})
    });
    pdfSlideinData$.next(pdfSlideinDataTaxWithholding);
    const { fixture, instance, find } = await shallow.render({
      bind: {
        type: StatementType.TAX_WITHHOLDING
      }
    });
    fixture.detectChanges();
    expect(instance.downloadError).toBeFalsy();
    find('#download').nativeElement.click();
    fixture.detectChanges();
    tick();
    expect(instance.downloadError).toBeTruthy();
    expect(instance.errorMessage).toEqual('myadp-pay.PDF_SLIDEIN_TAX_WITHHOLDING_DOWNLOAD_ERROR');
  }));
});
