import { MnAdditionalAllowancesComponent } from './steps/additional-allowances/mn-additional-allowances.component';
import { MnAllowancesComponent } from './steps/allowances/mn-allowances.component';
import { MnExemptionComponent } from './steps/exemption/mn-exemption.component';
import { MnIntroComponent } from './steps/intro/mn-intro.component';
import { MnMaritalStatusComponent } from './steps/marital-status/mn-marital-status.component';

export { MnStepNavigationService } from './services/mn-step-navigation.service';
export { MnTWChangeEventService } from './services/mn-tw-change-event.service';
export { MnSummaryMetaDataService } from './services/mn-summary-meta-data.service';

export const MN_COMPONENTS = [
  MnIntroComponent,
  MnMaritalStatusComponent,
  MnExemptionComponent,
  MnAllowancesComponent,
  MnAdditionalAllowancesComponent
];

export { MNSTEP_COMPONENT } from './models/steps-component.model';

export { MnAttachmentCodes } from './models/mn-tw-change-event';
