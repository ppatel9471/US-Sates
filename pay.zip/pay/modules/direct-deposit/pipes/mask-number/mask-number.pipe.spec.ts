import { TestBed } from '@angular/core/testing';

import { MaskNumberPipe } from './mask-number.pipe';

describe('MaskNumberPipe', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [MaskNumberPipe]
    });
  });

  it('should partially mask (account/routing) numbers with X', async () => {
    const pipe: MaskNumberPipe = new MaskNumberPipe();
    expect(pipe.transform('123456789')).toBe('XXXXX6789');
    expect(pipe.transform('1234567-89')).toBe('XXXXX7-89');
    expect(pipe.transform('1234567X9')).toBe('XXXXX67X9');
    expect(pipe.transform('1234567')).toBe('XXXXX4567');
    expect(pipe.transform('123456')).toBe('XXXXX3456');
    expect(pipe.transform('12345')).toBe('XXXXXXX345');
    expect(pipe.transform('1234')).toBe('XXXXXXX34');
    expect(pipe.transform('234')).toBe('XXXXXXX4');
    expect(pipe.transform('34')).toBe('XXXXXXX');
  });
});
