import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'pay-wizard-done-step',
  templateUrl: './wizard-done-step.component.html',
  styleUrls: ['./wizard-done-step.component.scss']
})
export class WizardDoneStepComponent {
  @Input() restartText: string; // text for "restart" btn
  @Output() closed: EventEmitter<void> = new EventEmitter<void>();
  @Output() restarted: EventEmitter<void> = new EventEmitter<void>();

  public close() {
    this.closed.emit();
  }

  public restart() {
    this.restarted.emit();
  }
}
