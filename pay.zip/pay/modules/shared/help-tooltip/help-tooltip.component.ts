import { Component, Input } from '@angular/core';

@Component({
  selector: 'help-tooltip',
  templateUrl: './help-tooltip.component.html'
})
export class HelpTooltipComponent {
  @Input() public title?: string;

  public click(event: any): void {
    // iOS safari mobile - the popover won't even open if we don't add event.preventDefault()
    event.preventDefault();
    // this will prevent further propagation of this current event in the capturing and bubbling phases
    event.stopPropagation();
  }
}
