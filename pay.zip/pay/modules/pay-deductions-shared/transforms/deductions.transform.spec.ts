import { cloneDeep } from 'lodash';

import { DeductionsDTO } from '@myadp/dto';
import {
  MOCK_WORKFLOW_ADD_DEDUCTION_RES,
  MOCK_WORKFLOW_DELETE_DEDUCTION_RES,
  MOCK_WORKFLOW_EDIT_DEDUCTION_RES
} from '@specHelpers/pay/pay-deductions/pay-deductions';
import {
  MOCK_TRANSFORMED_POST_ADD_DEDUCTION_PAYLOAD,
  MOCK_TRANSFORMED_POST_CHANGE_DEDUCTION_PAYLOAD,
  MOCK_TRANSFORMED_POST_STOP_DEDUCTION_NESTED_ITEM_PAYLOAD,
  MOCK_TRANSFORMED_POST_STOP_DEDUCTION_PAYLOAD
} from '@specHelpers/pay/pay-deductions/post/pay-deductions';

import { PayDeductionsUI } from '../models/pay-deductions-ui';
import { transformDeductions, transformToDTO, transformToStopDTO } from './deductions.transform';

describe('transformDeductions', () => {
  const aoid = 'XG234234';

  describe('Non-workflow transforms', () => {
    it('should transform a non-pending deduction', () => {
      const mockResponse: DeductionsDTO.WfResponse = {
        currentData: {
          workerGeneralDeductionInstructions: [
            {
              generalDeductionInstructions: [
                {
                  itemID: 'ALA',
                  deductionCode: { codeValue: 'ALA', longName: 'ALLOWANCE 1' },
                  deductionRate: { rateValue: 101, currencyCode: 'USD' },
                  deductionGoal: {
                    goalBalanceAmount: { amountValue: 0, currencyCode: 'USD' },
                    goalLimitAmount: { amountValue: 100, currencyCode: 'USD' }
                  }
                }
              ]
            }
          ]
        }
      };

      expect(transformDeductions(mockResponse)).toEqual([
        {
          currentData: {
            itemID: 'ALA',
            deductionCode: { codeValue: 'ALA', longName: 'ALLOWANCE 1' },
            deductionRate: { rateValue: 101, currencyCode: 'USD' },
            deductionGoal: {
              goalBalanceAmount: { amountValue: 0, currencyCode: 'USD' },
              goalLimitAmount: { amountValue: 100, currencyCode: 'USD' }
            }
          },
          pendingData: null,
          pendingEvent: null
        }
      ]);
    });

    it('should transform a non-pending deduction when missing deductionRate', () => {
      const mockResponse: DeductionsDTO.WfResponse = {
        currentData: {
          workerGeneralDeductionInstructions: [
            {
              generalDeductionInstructions: [
                {
                  itemID: 'ALA',
                  deductionCode: { codeValue: 'ALA', longName: 'ALLOWANCE 1' },
                  deductionGoal: {
                    goalBalanceAmount: { amountValue: 0, currencyCode: 'USD' },
                    goalLimitAmount: { amountValue: 100, currencyCode: 'USD' }
                  }
                }
              ]
            }
          ]
        }
      };

      expect(transformDeductions(mockResponse)).toEqual([
        {
          currentData: {
            itemID: 'ALA',
            deductionCode: { codeValue: 'ALA', longName: 'ALLOWANCE 1' },
            deductionGoal: {
              goalBalanceAmount: { amountValue: 0, currencyCode: 'USD' },
              goalLimitAmount: { amountValue: 100, currencyCode: 'USD' }
            }
          },
          pendingData: null,
          pendingEvent: null
        }
      ]);
    });
  });

  describe('Workflow transforms', () => {
    it('should transform a pending add', () => {
      const mockPendingAddWfResponse: DeductionsDTO.WfResponse = MOCK_WORKFLOW_ADD_DEDUCTION_RES;

      expect(transformDeductions(mockPendingAddWfResponse)).toEqual([
        {
          currentData: {
            itemID: 'A',
            deductionCode: { codeValue: 'A', longName: 'Medicare Surtax' },
            deductionRate: { rateValue: 15, currencyCode: 'USD' },
            deductionGoal: {
              goalBalanceAmount: { amountValue: 0, currencyCode: 'USD' },
              goalLimitAmount: { amountValue: 199, currencyCode: 'USD' }
            }
          },
          pendingData: null,
          pendingEvent: null
        },
        {
          currentData: null,
          pendingData: {
            itemID: 'H',
            deductionCode: { codeValue: 'H' },
            deductionRate: { rateValue: 12, currencyCode: 'USD' },
            deductionGoal: {
              goalLimitAmount: { currencyCode: 'USD' }
            }
          },
          pendingEvent: { changeType: 'add', approver: 'Sanchez, Richard' }
        }
      ]);
    });

    it('should transform a pending add when missing deductionRate.rateValue', () => {
      const mockPendingAddWfResponse: DeductionsDTO.WfResponse = changeRateValue(
        MOCK_WORKFLOW_ADD_DEDUCTION_RES,
        undefined
      );

      expect(transformDeductions(mockPendingAddWfResponse)).toEqual([
        {
          currentData: {
            itemID: 'A',
            deductionCode: { codeValue: 'A', longName: 'Medicare Surtax' },
            deductionRate: { rateValue: 15, currencyCode: 'USD' },
            deductionGoal: {
              goalBalanceAmount: { amountValue: 0, currencyCode: 'USD' },
              goalLimitAmount: { amountValue: 199, currencyCode: 'USD' }
            }
          },
          pendingData: null,
          pendingEvent: null
        },
        {
          currentData: null,
          pendingData: {
            itemID: 'H',
            deductionCode: { codeValue: 'H' },
            deductionRate: { rateValue: null, currencyCode: 'USD' },
            deductionGoal: {
              goalLimitAmount: { currencyCode: 'USD' }
            }
          },
          pendingEvent: { changeType: 'add', approver: 'Sanchez, Richard' }
        }
      ]);
    });

    it('should transform a pending add when deductionRate.rateValue is 0', () => {
      const mockPendingAddWfResponse: DeductionsDTO.WfResponse = changeRateValue(
        MOCK_WORKFLOW_ADD_DEDUCTION_RES,
        0
      );

      expect(transformDeductions(mockPendingAddWfResponse)).toEqual([
        {
          currentData: {
            itemID: 'A',
            deductionCode: { codeValue: 'A', longName: 'Medicare Surtax' },
            deductionRate: { rateValue: 15, currencyCode: 'USD' },
            deductionGoal: {
              goalBalanceAmount: { amountValue: 0, currencyCode: 'USD' },
              goalLimitAmount: { amountValue: 199, currencyCode: 'USD' }
            }
          },
          pendingData: null,
          pendingEvent: null
        },
        {
          currentData: null,
          pendingData: {
            itemID: 'H',
            deductionCode: { codeValue: 'H' },
            deductionRate: { rateValue: 0, currencyCode: 'USD' },
            deductionGoal: {
              goalLimitAmount: { currencyCode: 'USD' }
            }
          },
          pendingEvent: { changeType: 'add', approver: 'Sanchez, Richard' }
        }
      ]);
    });

    it('should transform a pending edit', () => {
      const mockPendingEditWfResponse: DeductionsDTO.WfResponse = MOCK_WORKFLOW_EDIT_DEDUCTION_RES;

      expect(transformDeductions(mockPendingEditWfResponse)).toEqual([
        {
          currentData: {
            itemID: 'A',
            deductionCode: { codeValue: 'A', longName: 'Medicare Surtax' },
            deductionRate: { rateValue: 15, currencyCode: 'USD' },
            deductionGoal: {
              goalBalanceAmount: { amountValue: 0, currencyCode: 'USD' },
              goalLimitAmount: { amountValue: 199, currencyCode: 'USD' }
            }
          },
          pendingData: {
            itemID: 'A',
            deductionCode: { codeValue: 'A', longName: 'Medicare Surtax' },
            deductionRate: { rateValue: 10, currencyCode: 'USD' },
            deductionGoal: {
              goalBalanceAmount: { amountValue: 0, currencyCode: 'USD' },
              goalLimitAmount: { amountValue: 199, currencyCode: 'USD' }
            }
          },
          pendingEvent: { changeType: 'edit', approver: 'Sanchez, Richard' }
        },
        {
          currentData: {
            itemID: 'E',
            deductionCode: { codeValue: 'E', longName: 'Basic Life' },
            deductionRate: { rateValue: 10, unitCode: { codeValue: 'percent' } },
            deductionGoal: {
              goalBalanceAmount: { amountValue: 0, currencyCode: 'USD' },
              goalLimitAmount: { amountValue: 0, currencyCode: 'USD' }
            }
          },
          pendingData: null,
          pendingEvent: null
        }
      ]);
    });

    it('should transform a pending edit when deductionRate.rateValue is empty', () => {
      const mockPendingEditWfResponse: DeductionsDTO.WfResponse = changeRateValue(
        MOCK_WORKFLOW_EDIT_DEDUCTION_RES,
        ''
      );

      expect(transformDeductions(mockPendingEditWfResponse)).toEqual([
        {
          currentData: {
            itemID: 'A',
            deductionCode: { codeValue: 'A', longName: 'Medicare Surtax' },
            deductionRate: { rateValue: 15, currencyCode: 'USD' },
            deductionGoal: {
              goalBalanceAmount: { amountValue: 0, currencyCode: 'USD' },
              goalLimitAmount: { amountValue: 199, currencyCode: 'USD' }
            }
          },
          pendingData: {
            itemID: 'A',
            deductionCode: { codeValue: 'A', longName: 'Medicare Surtax' },
            deductionRate: { rateValue: null, currencyCode: 'USD' },
            deductionGoal: {
              goalBalanceAmount: { amountValue: 0, currencyCode: 'USD' },
              goalLimitAmount: { amountValue: 199, currencyCode: 'USD' }
            }
          },
          pendingEvent: { changeType: 'edit', approver: 'Sanchez, Richard' }
        },
        {
          currentData: {
            itemID: 'E',
            deductionCode: { codeValue: 'E', longName: 'Basic Life' },
            deductionRate: { rateValue: 10, unitCode: { codeValue: 'percent' } },
            deductionGoal: {
              goalBalanceAmount: { amountValue: 0, currencyCode: 'USD' },
              goalLimitAmount: { amountValue: 0, currencyCode: 'USD' }
            }
          },
          pendingData: null,
          pendingEvent: null
        }
      ]);
    });

    it('should transform a pending edit when deductionRate.rateValue is 0', () => {
      const mockPendingEditWfResponse: DeductionsDTO.WfResponse = changeRateValue(
        MOCK_WORKFLOW_EDIT_DEDUCTION_RES,
        0
      );

      expect(transformDeductions(mockPendingEditWfResponse)).toEqual([
        {
          currentData: {
            itemID: 'A',
            deductionCode: { codeValue: 'A', longName: 'Medicare Surtax' },
            deductionRate: { rateValue: 15, currencyCode: 'USD' },
            deductionGoal: {
              goalBalanceAmount: { amountValue: 0, currencyCode: 'USD' },
              goalLimitAmount: { amountValue: 199, currencyCode: 'USD' }
            }
          },
          pendingData: {
            itemID: 'A',
            deductionCode: { codeValue: 'A', longName: 'Medicare Surtax' },
            deductionRate: { rateValue: 0, currencyCode: 'USD' },
            deductionGoal: {
              goalBalanceAmount: { amountValue: 0, currencyCode: 'USD' },
              goalLimitAmount: { amountValue: 199, currencyCode: 'USD' }
            }
          },
          pendingEvent: { changeType: 'edit', approver: 'Sanchez, Richard' }
        },
        {
          currentData: {
            itemID: 'E',
            deductionCode: { codeValue: 'E', longName: 'Basic Life' },
            deductionRate: { rateValue: 10, unitCode: { codeValue: 'percent' } },
            deductionGoal: {
              goalBalanceAmount: { amountValue: 0, currencyCode: 'USD' },
              goalLimitAmount: { amountValue: 0, currencyCode: 'USD' }
            }
          },
          pendingData: null,
          pendingEvent: null
        }
      ]);
    });

    it('should transform a pending delete', () => {
      const mockPendingDeleteWfResponse: DeductionsDTO.WfResponse = MOCK_WORKFLOW_DELETE_DEDUCTION_RES;

      expect(transformDeductions(mockPendingDeleteWfResponse)).toEqual([
        {
          currentData: {
            itemID: 'A',
            deductionCode: { codeValue: 'A', longName: 'Auto Allowance' },
            deductionRate: { rateValue: 200, currencyCode: 'USD' },
            deductionGoal: {
              goalBalanceAmount: { amountValue: 0, currencyCode: 'USD' },
              goalLimitAmount: { amountValue: 4000, currencyCode: 'USD' }
            }
          },
          pendingData: null,
          pendingEvent: null
        },
        {
          currentData: {
            itemID: 'B',
            deductionCode: { codeValue: 'B', longName: 'Savings Bonds' },
            deductionRate: { rateValue: 115, currencyCode: 'USD' },
            deductionGoal: {
              goalBalanceAmount: { amountValue: 0, currencyCode: 'USD' },
              goalLimitAmount: { amountValue: 3000, currencyCode: 'USD' }
            }
          },
          pendingData: null,
          pendingEvent: { changeType: 'delete', approver: 'Sanchez, Richard' }
        }
      ]);
    });
  });

  describe('transformToDTO', () => {
    it('should transform captured deduction data to POST DTO for deduction add', () => {
      const mockCapturedDeductionData: PayDeductionsUI.DeductionDetails = {
        deductionCode: {
          codeValue: '40A'
        },
        deductionRate: {
          rateValue: 2,
          currencyCode: 'USD'
        },
        deductionGoal: {
          goalLimitAmount: {
            amountValue: 4,
            currencyCode: 'USD'
          }
        }
      };

      expect(transformToDTO({ deduction: mockCapturedDeductionData, aoid }, false)).toEqual(
        MOCK_TRANSFORMED_POST_ADD_DEDUCTION_PAYLOAD
      );
    });

    it('should transform captured deduction data to POST DTO for deduction change', () => {
      const mockCapturedDeductionData: PayDeductionsUI.DeductionDetails = {
        deductionCode: {
          codeValue: '40A'
        },
        deductionRate: {
          rateValue: 4,
          currencyCode: 'USD'
        },
        deductionGoal: {
          goalLimitAmount: {
            amountValue: 8,
            currencyCode: 'USD'
          }
        }
      };

      expect(transformToDTO({ deduction: mockCapturedDeductionData, aoid }, true)).toEqual(
        MOCK_TRANSFORMED_POST_CHANGE_DEDUCTION_PAYLOAD
      );
    });

    it('should transform captured deduction data to POST DTO for deduction change and not include goalBalanceAmount', () => {
      const mockCapturedDeductionData: PayDeductionsUI.DeductionDetails = {
        deductionCode: {
          codeValue: '40A'
        },
        deductionRate: {
          rateValue: 4,
          currencyCode: 'USD'
        },
        deductionGoal: {
          goalBalanceAmount: {
            amountValue: 2,
            currencyCode: 'USD'
          },
          goalLimitAmount: {
            amountValue: 8,
            currencyCode: 'USD'
          }
        }
      };

      expect(transformToDTO({ deduction: mockCapturedDeductionData, aoid }, true)).toEqual(
        MOCK_TRANSFORMED_POST_CHANGE_DEDUCTION_PAYLOAD
      );
    });
  });

  describe('transformToStopDTO', () => {
    const mockItemID = 'A';

    it('should transform captured deduction itemID to stop POST DTO with itemID not nested', () => {
      expect(
        transformToStopDTO({ aoid, deduction: { deductionCode: { codeValue: mockItemID } } }, false)
      ).toEqual(MOCK_TRANSFORMED_POST_STOP_DEDUCTION_PAYLOAD);
    });

    it('should transform captured deduction itemID to stop POST DTO with itemID nested', () => {
      expect(
        transformToStopDTO({ aoid, deduction: { deductionCode: { codeValue: mockItemID } } }, true)
      ).toEqual(MOCK_TRANSFORMED_POST_STOP_DEDUCTION_NESTED_ITEM_PAYLOAD);
    });
  });

  function changeRateValue(data: any, value: any): DeductionsDTO.WfResponse {
    const wfResponse: DeductionsDTO.WfResponse = cloneDeep(data);
    /* eslint-disable-next-line max-len */
    wfResponse.pendingEvents[0].body.events[0].data.transform.workerGeneralDeductionInstruction.generalDeductionInstruction.deductionRate.rateValue = value;

    return wfResponse;
  }
});
