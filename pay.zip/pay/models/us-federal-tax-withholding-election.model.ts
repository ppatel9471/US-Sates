import {
  Action,
  AdditionalStatutoryInput,
  AdditionalTaxAmount,
  AttachmentType,
  CodeType,
  ESignatureIndicator,
  Link,
  PendingEvent,
  TaxWithholdingStatus
} from './tax-withholding.model';
import { ApiError } from '@myadp/dto';

export interface UsFederalTaxWithholdingElections {
  usFederalTaxWithholdingElections?: UsFederalTaxWithholdingElection[];
}

export interface UsFederalTaxWithholdingElection {
  links?: Link[];
  payrollFileNumber?: string;
  payrollGroupCode?: CodeType;
  payrollRegionCode?: CodeType;
  itemID?: string;
  usFederalIncomeTaxWithholdingElection?: UsFederalIncomeTaxWithholdingElection;
  workflowData?: UsFederalTaxWithholdingElectionsWorkFlowData;
}

export interface UsFederalIncomeTaxWithholdingElection {
  actions?: Action[];
  taxWithholdingStatus?: TaxWithholdingStatus;
  taxFilingStatusCode?: CodeType;
  taxWithholdingAllowanceQuantity?: number;
  additionalTaxPercentage?: number;
  overrideTaxPercentage?: number;
  additionalTaxAmount?: AdditionalTaxAmount;
  overrideTaxAmount?: AdditionalTaxAmount;
  nonResidentAlienIndicator?: boolean;
  legalNameDiffersFromSSCardIndicator?: boolean;
  additionalStatutoryInputs?: AdditionalStatutoryInput[];
  attachments?: AttachmentType[];
  eSignature?: ESignatureIndicator;
}

export interface UsFederalTaxWithholdingElectionsWorkFlowData {
  pendingData?: UsFederalTaxWithholdingElections;
  pendingEvents?: PendingEvent;
  confirmMessage?: {
    resourceMessages?: {
      processMessages: {
        userMessage: ApiError.UserMessage
      }[]
    }[]
  };
}
