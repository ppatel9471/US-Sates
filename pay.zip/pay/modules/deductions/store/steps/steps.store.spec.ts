import { TestBed } from '@angular/core/testing';

import { STEPS } from '../../models/steps.enum';
import { StepsStore } from './steps.store';

describe('StepsStore', () => {
  let stepsStore: StepsStore;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [StepsStore]
    });

    stepsStore = TestBed.inject(StepsStore);
  });

  it('should get the store data', () => {
    expect(stepsStore.stepsStoreData).toEqual(null);
  });

  it('should get the current step name', () => {
    stepsStore.update('steps', {
      data: {
        step: {
          name: 'Some Step'
        }
      }
    });
    expect(stepsStore.currentStepName).toEqual('Some Step');
  });

  describe('isSlideinOpen', () => {
    it('should return true when slidein is open', (done) => {
      stepsStore.isSlideinOpen$.next(true);
      stepsStore.isSlideinOpenObs$.subscribe((isOpen) => {
        expect(isOpen).toBe(true);
        done();
      });
    });

    it('should return false when slidein is closed', (done) => {
      stepsStore.isSlideinOpen$.next(false);
      stepsStore.isSlideinOpenObs$.subscribe((isOpen) => {
        expect(isOpen).toBe(false);
        done();
      });
    });
  });

  it('should get the stepStore', (done) => {
    stepsStore.update('steps', {
      data: {
        step: {
          name: 'Some Step'
        }
      }
    });
    stepsStore.stepsStore$.subscribe((data) => {
      expect(data.step.name).toEqual('Some Step');
      done();
    });
  });

  it('should return whether or not is submitStep', (done) => {
    stepsStore.update('steps', {
      data: {
        isSubmitStep: true
      }
    });
    stepsStore.stepsStore$.subscribe(({ isSubmitStep }) => {
      expect(isSubmitStep).toEqual(true);
      done();
    });
  });

  describe('Step Name', () => {
    it('should get deduction details step name', async (done: DoneFn) => {
      stepsStore.update('steps', {
        data: {
          isEditing: false,
          step: {
            name: STEPS.DEDUCTION_DETAILS
          }
        }
      });

      stepsStore.stepName$.subscribe((stepName) => {
        expect(stepName).toContain('myadp-pay.DEDUCTIONS_STEP_TITLE_DEDUCTION_DETAILS');
        done();
      });
    });

    it('should get edit step name', async (done: DoneFn) => {
      stepsStore.update('steps', {
        data: {
          isEditing: true,
          step: {
            name: STEPS.DEDUCTION_DETAILS
          }
        }
      });

      stepsStore.stepName$.subscribe((stepName) => {
        expect(stepName).toContain('myadp-pay.DEDUCTIONS_STEP_TITLE_EDIT_DEDUCTION');
        done();
      });
    });
  });

  describe('Step Navigation', () => {
    it('should show step navigation', async (done: DoneFn) => {
      stepsStore.update('steps', {
        data: {
          isFirstStep: false,
          isLastStep: false,
          hideNavigation: false
        }
      });

      stepsStore.showStepNavigation$.subscribe((showStepNav) => {
        expect(showStepNav).toBeTruthy();
        done();
      });
    });

    it('should not show step navigation', async (done: DoneFn) => {
      stepsStore.update('steps', {
        data: {
          isFirstStep: false,
          isLastStep: true
        }
      });

      stepsStore.showStepNavigation$.subscribe((showStepNav) => {
        expect(showStepNav).toBeFalsy();
        done();
      });
    });
  });

  describe('Progress Properties', () => {
    it('should get next progress properties', async (done: DoneFn) => {
      stepsStore.update('steps', {
        data: {
          next: {
            disabled: true,
            hidden: false
          }
        }
      });

      stepsStore.getPrevOrNextProperties$('next').subscribe((nextProps) => {
        expect(nextProps).toEqual({ disabled: true, hidden: false });
        done();
      });
    });

    it('should get prev progress properties', async (done: DoneFn) => {
      stepsStore.getPrevOrNextProperties$('prev').subscribe((prevProps) => {
        expect(prevProps).toEqual(jasmine.objectContaining({ disabled: false, hidden: false }));
        done();
      });
    });
  });
});
