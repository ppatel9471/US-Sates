import { Injectable } from '@angular/core';
import { LanguageService } from '@myadp/common';
import { StepsStoreActions } from '../store/steps/steps.store';

@Injectable({
  providedIn: 'root'
})
export class DeductionsTermsService {
  private workerName: string;
  private consentText: string;

  constructor(
    private languageService: LanguageService,
    private stepsStoreActions: StepsStoreActions
  ) {}

  public get consent(): string {
    return this.consentText;
  }

  public get printedConsentText(): string {
    return `${this.consentText} ${this.languageService.get(
      'myadp-pay.TERMS_AND_CONDITIONS_SIGNATURE',
      {
        workerName: this.workerName
      }
    )}`;
  }

  public get consentTitle(): string {
    return this.languageService.get('myadp-pay.TERMS_CONDITIONS');
  }

  public async init(): Promise<void> {
    const worker = await this.stepsStoreActions.getWorker();
    this.workerName = `${worker?.person?.legalName?.givenName} ${worker?.person?.legalName?.familyName1}`;
    this.consentText = this.languageService.get('myadp-pay.DEDUCTIONS_AUTHORIZE');
  }
}
