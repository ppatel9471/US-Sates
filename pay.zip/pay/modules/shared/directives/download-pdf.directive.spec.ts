import { ClientDeviceService } from '@espresso/core';
import { ButtonModule } from '@synerg/components/button';
import { Shallow } from 'shallow-render';
import { Mock } from 'ts-mockery';

import {
  AudioEyeService,
  ImpersonationService,
  LanguageService,
  MyadpUrlDecorationHelperService,
  NativeActionImplService as NativeActionService,
  UserProfileService
} from '@myadp/common';
import { WindowImplService as WindowService } from '@myadp/common/services/window-impl.service';
import { PreAuthResponse, StepUpFlowService } from '@myadp/step-up';
import { MockWindow } from '@specHelpers';

import { StatementType } from '../models/pdf-viewer.model';
import { DownloadPdfService } from '../services/download-pdf.service';
import { SharedModule } from '../shared.module';
import { DownloadPdfDirective } from './download-pdf.directive';

describe('DownloadPdfDirective', () => {
  let shallow: Shallow<DownloadPdfDirective>;

  const payStatementUri: string = '/l2/v1_0/O/A/payStatement/66/images/sbubby157.pdf';
  const payStatementDecoratedUri: string = '/v1_0/O/A/payStatement/66/images/sbubby157.pdf';
  const finalUrl = '/v1_0/O/A/payStatement/66/images/sbubby157.pdf?rolecode=employee';
  const downloadPdfTemplate = `
  <adp-button [payDownloadPdfUri]="uri"
       [stepUpEnabled]="stepUpEnabled"
       [accessibilityEnabled]="accessibilityEnabled"
       [type]="type"
       [statement]="statement">
       <button></button>
  </adp-button>`;

  const downloadPdfPaginatorTemplate = `
  <adp-paginator  [pageNumber]="1"
                  [pageSize]="1"
                  [pageSizes]="[]"
                  [labels]="paginatorLabel"
                  [totalItems]="1"
                  payDownloadPdfUri
                  [accessibilityEnabled]="accessibilityEnabled"
                  [stepUpEnabled]="stepUpEnabled"
                  [type]="type">
  </adp-paginator>`;

  const fullDownloadUrl: string =
    'http://cdlrdboxsc005.es.ad.adp.com/v1_0/O/A/payStatement/66/images/sbubby157.pdf';
  const nativeApiUrlConfig: any = {
    baseURL: 'http://cdlrdboxsc005.es.ad.adp.com',
    options: {
      documentFormat: 'PDF'
    },
    uri: '/v1/0/A/workerTaxStatement/statement.pdf'
  };
  let mockWindow: MockWindow;

  beforeEach(() => {
    mockWindow = new MockWindow();
    spyOn(mockWindow, 'open');

    shallow = new Shallow(DownloadPdfDirective, SharedModule)
      .dontMock(ButtonModule)
      .provide(LanguageService, ClientDeviceService, DownloadPdfService)
      .provideMock({
        provide: StepUpFlowService,
        useValue: Mock.of<StepUpFlowService>({
          stepUpPreAuth: () =>
            Promise.resolve<PreAuthResponse>({
              newUrlOrHeadersRequired: false,
              newUrl: `preAuth/${payStatementUri}`,
              additionalHeaders: undefined
            })
        })
      })
      .mock(MyadpUrlDecorationHelperService, {
        decorateApiUrl: (url: string) => url,
        getFullUrl: () => fullDownloadUrl,
        getNativeApiUrlConfig: () => nativeApiUrlConfig
      })
      .mock(AudioEyeService, {
        isAudioEyeScriptActive: () => false
      })
      .mock(LanguageService, { get: (key: string) => key })
      .mock(WindowService, {
        getWindow: () => mockWindow
      })
      .mock(NativeActionService, {
        openModal: () => Mock.noop()
      })
      .mock(ClientDeviceService, {
        isNative: () => false,
        isDesktop: () => true
      })
      .mock(ImpersonationService, {
        isImpersonating: () => false
      })
      .mock(UserProfileService, {
        isRun: () => false
      })
      .mock(DownloadPdfService, {
        pdfSlideinData$: {
          next: () => Mock.noop()
        }
      });
  });

  it('should format the URL correctly', async () => {
    const { element, fixture, get } = await shallow.render(downloadPdfTemplate, {
      bind: {
        uri: payStatementUri,
        stepUpEnabled: false,
        accessibilityEnabled: true
      }
    });
    spyOn(get(DownloadPdfService).pdfSlideinData$, 'next');
    element.nativeElement.click();
    await fixture.whenStable();

    expect(get(DownloadPdfService).pdfSlideinData$.next).toHaveBeenCalledWith(
      jasmine.objectContaining({ finalUrl: finalUrl })
    );
  });

  describe('StepUpAuth', () => {
    it('should call step-up PreAuth when step-up enabled', async () => {
      const { element, fixture, get } = await shallow.render(downloadPdfTemplate, {
        bind: {
          uri: payStatementUri,
          stepUpEnabled: true,
          accessibilityEnabled: true
        }
      });
      element.nativeElement.click();
      await fixture.whenStable();

      expect(get(StepUpFlowService).stepUpPreAuth).toHaveBeenCalled();
    });

    it('should not pass step-up PreAuth content when isNative', async () => {
      const { element, fixture, get } = await shallow
        .mock(ClientDeviceService, {
          isNative: () => true,
          isDesktop: () => false
        })
        .render(downloadPdfTemplate, {
          bind: {
            uri: payStatementUri,
            stepUpEnabled: true,
            accessibilityEnabled: true
          }
        });
      element.nativeElement.click();
      await fixture.whenStable();

      expect(get(StepUpFlowService).stepUpPreAuth).toHaveBeenCalledWith({
        url: payStatementDecoratedUri,
        method: 'GET',
        synchronousCallbackConfig: null
      });

      expect(get(NativeActionService).openModal).toHaveBeenCalledWith(nativeApiUrlConfig);
    });

    it('should not pass step-up PreAuth content when opens in iframe', async () => {
      const { element, fixture, get } = await shallow
        .mock(ClientDeviceService, {
          isNative: () => false,
          isDesktop: () => true
        })
        .render(downloadPdfTemplate, {
          bind: {
            uri: payStatementUri,
            stepUpEnabled: true,
            accessibilityEnabled: true
          }
        });
      spyOn(get(DownloadPdfService).pdfSlideinData$, 'next');
      element.nativeElement.click();
      await fixture.whenStable();

      expect(get(StepUpFlowService).stepUpPreAuth).toHaveBeenCalledWith({
        url: payStatementDecoratedUri,
        method: 'GET',
        synchronousCallbackConfig: null
      });
      expect(get(DownloadPdfService).pdfSlideinData$.next).toHaveBeenCalledWith(
        jasmine.objectContaining({ finalUrl: finalUrl })
      );
    });
  });

  describe('open pdf', async () => {
    it('should have the downloadPdfService open a slide in', async () => {
      const { element, fixture, get } = await shallow.render(downloadPdfTemplate, {
        bind: {
          uri: payStatementUri,
          stepUpEnabled: false,
          accessibilityEnabled: true,
          type: StatementType.PAY_STATEMENT
        }
      });
      spyOn(get(DownloadPdfService).pdfSlideinData$, 'next');
      element.nativeElement.click();
      await fixture.whenStable();
      expect(get(NativeActionService).openModal).not.toHaveBeenCalled();
      expect(mockWindow.open).not.toHaveBeenCalled();
      expect(get(DownloadPdfService).pdfSlideinData$.next).toHaveBeenCalledWith({
        finalUrl: finalUrl,
        uri: '/l2/v1_0/O/A/payStatement/66/images/sbubby157.pdf',
        type: StatementType.PAY_STATEMENT,
        stepUpEnabled: false,
        useAudioEye: true,
        singleStatement: undefined
      });
    });

    it('should have the downloadPdfService open a slide in for a single statement', async () => {
      const singleStatement = {
        title: 'My Title',
        href: '/some/where'
      };
      const { element, fixture, get } = await shallow.render(downloadPdfTemplate, {
        bind: {
          uri: payStatementUri,
          stepUpEnabled: false,
          accessibilityEnabled: true,
          type: StatementType.PAY_STATEMENT,
          statement: singleStatement
        }
      });
      spyOn(get(DownloadPdfService).pdfSlideinData$, 'next');
      element.nativeElement.click();
      await fixture.whenStable();
      expect(get(NativeActionService).openModal).not.toHaveBeenCalled();
      expect(mockWindow.open).not.toHaveBeenCalled();
      expect(get(DownloadPdfService).pdfSlideinData$.next).toHaveBeenCalledWith(
        jasmine.objectContaining({ singleStatement: singleStatement })
      );
    });

    it('should open native modal when isNative', async () => {
      const { element, fixture, get } = await shallow
        .mock(ClientDeviceService, {
          isNative: () => true,
          isDesktop: () => false
        })
        .render(downloadPdfTemplate, {
          bind: {
            uri: payStatementUri,
            stepUpEnabled: false,
            accessibilityEnabled: true,
            type: StatementType.PAY_STATEMENT
          }
        });
      element.nativeElement.click();
      await fixture.whenStable();
      expect(get(NativeActionService).openModal).toHaveBeenCalledWith(nativeApiUrlConfig);
    });

    it('should open external window when audio eye is enabled', async () => {
      const { element, fixture, get } = await shallow
        .mock(AudioEyeService, {
          isAudioEyeScriptActive: () => true
        })
        .render(downloadPdfTemplate, {
          bind: {
            uri: payStatementUri,
            stepUpEnabled: false,
            accessibilityEnabled: true,
            type: StatementType.PAY_STATEMENT
          }
        });
      element.nativeElement.click();
      await fixture.whenStable();
      expect(get(NativeActionService).openModal).not.toHaveBeenCalled();
      expect(mockWindow.open).toHaveBeenCalledWith(
        `/ext/framework/views/accessible-w2.html?url=${fullDownloadUrl}&rolecode=employee`
      );
      expect(mockWindow.open).toHaveBeenCalledTimes(1);
    });

    it('should open external window when isRun pay statements', async () => {
      const { element, fixture, get } = await shallow
        .mock(UserProfileService, {
          isRun: () => true
        })
        .render(downloadPdfTemplate, {
          bind: {
            uri: payStatementUri,
            stepUpEnabled: false,
            accessibilityEnabled: true,
            type: StatementType.PAY_STATEMENT
          }
        });
      element.nativeElement.click();
      await fixture.whenStable();
      expect(get(NativeActionService).openModal).not.toHaveBeenCalled();
      expect(mockWindow.open).toHaveBeenCalledWith(finalUrl);
    });

    it('should open external window when isRun tax statements', async () => {
      const { element, fixture, get } = await shallow
        .mock(UserProfileService, {
          isRun: () => true
        })
        .render(downloadPdfTemplate, {
          bind: {
            uri: payStatementUri,
            stepUpEnabled: false,
            accessibilityEnabled: true,
            type: StatementType.TAX_STATEMENT
          }
        });
      element.nativeElement.click();
      await fixture.whenStable();
      expect(get(NativeActionService).openModal).not.toHaveBeenCalled();
      expect(mockWindow.open).toHaveBeenCalledWith(finalUrl);
    });

    it('should open slide in when isRun tax withholding', async () => {
      const mockStatement = {
        title: 'My Title',
        href: '/some/where'
      };
      const { element, fixture, get } = await shallow
        .mock(UserProfileService, {
          isRun: () => true
        })
        .render(downloadPdfTemplate, {
          bind: {
            uri: payStatementUri,
            stepUpEnabled: false,
            accessibilityEnabled: true,
            type: StatementType.TAX_WITHHOLDING_GSS,
            statement: mockStatement
          }
        });
      spyOn(get(DownloadPdfService).pdfSlideinData$, 'next');
      element.nativeElement.click();
      await fixture.whenStable();
      expect(get(NativeActionService).openModal).not.toHaveBeenCalled();
      expect(mockWindow.open).not.toHaveBeenCalled();
      expect(get(DownloadPdfService).pdfSlideinData$.next).toHaveBeenCalledWith(
        jasmine.objectContaining({ singleStatement: mockStatement })
      );
    });
  });

  describe('AudioEye', () => {
    it('should format the URL correctly when AudioEye has not been loaded', async () => {
      const { element, fixture, get } = await shallow
        .mock(AudioEyeService, {
          isAudioEyeScriptActive: () => false
        })
        .render(downloadPdfTemplate, {
          bind: {
            uri: payStatementUri,
            stepUpEnabled: false,
            accessibilityEnabled: true,
            type: StatementType.PAY_STATEMENT
          }
        });
      spyOn(get(DownloadPdfService).pdfSlideinData$, 'next');
      element.nativeElement.click();
      await fixture.whenStable();

      expect(get(DownloadPdfService).pdfSlideinData$.next).toHaveBeenCalledWith(
        jasmine.objectContaining({ finalUrl: finalUrl })
      );
    });

    it('should format the URL correctly when not using AudioEye settings', async () => {
      const { element, fixture, get } = await shallow
        .mock(AudioEyeService, {
          isAudioEyeScriptActive: () => true
        })
        .render(downloadPdfTemplate, {
          bind: {
            uri: payStatementUri,
            stepUpEnabled: false,
            accessibilityEnabled: false,
            type: StatementType.PAY_STATEMENT
          }
        });
      spyOn(get(DownloadPdfService).pdfSlideinData$, 'next');
      element.nativeElement.click();
      await fixture.whenStable();

      expect(get(DownloadPdfService).pdfSlideinData$.next).toHaveBeenCalledWith(
        jasmine.objectContaining({ finalUrl: finalUrl })
      );
    });

    it('should format the URL correctly when AudioEye is enabled', async () => {
      const { element, fixture } = await shallow
        .mock(AudioEyeService, {
          isAudioEyeScriptActive: () => true
        })
        .render(downloadPdfTemplate, {
          bind: {
            uri: payStatementUri,
            stepUpEnabled: false,
            accessibilityEnabled: true,
            type: StatementType.PAY_STATEMENT
          }
        });
      element.nativeElement.click();
      await fixture.whenStable();

      expect(mockWindow.open).toHaveBeenCalledWith(
        `/ext/framework/views/accessible-w2.html?url=${fullDownloadUrl}&rolecode=employee`
      );
    });
  });

  describe('Download', () => {
    it('should enable download button when not impersonating', async () => {
      const { fixture } = await shallow.render(downloadPdfTemplate, {
        bind: {
          uri: payStatementUri,
          stepUpEnabled: false,
          accessibilityEnabled: false
        }
      });
      fixture.detectChanges();

      const button = fixture.nativeElement.querySelector('button');
      expect(button.disabled).toBeFalsy();
    });

    it('should disable download button when impersonating', async () => {
      const { fixture } = await shallow
        .mock(ImpersonationService, {
          isImpersonating: () => true
        })
        .render(downloadPdfTemplate, {
          bind: {
            uri: payStatementUri,
            stepUpEnabled: false,
            accessibilityEnabled: false
          }
        });
      fixture.detectChanges();

      const button = fixture.nativeElement.querySelector('button');
      expect(button.disabled).toBeTruthy();
    });
  });

  describe('click download', () => {
    it('should call download when clicking download button', async () => {
      const { element, fixture, instance } = await shallow.render(downloadPdfTemplate, {
        bind: {
          uri: payStatementUri,
          stepUpEnabled: false,
          accessibilityEnabled: true
        }
      });
      spyOn(instance, 'download').and.callThrough();
      element.nativeElement.click();
      await fixture.whenStable();

      expect(instance.download).toHaveBeenCalled();
    });

    it('should not call download when clicking paginator', async () => {
      const { element, fixture, instance } = await shallow.render(downloadPdfPaginatorTemplate, {
        bind: {
          uri: payStatementUri,
          stepUpEnabled: false,
          accessibilityEnabled: true
        }
      });
      spyOn(instance, 'download').and.callThrough();
      element.nativeElement.click();
      await fixture.whenStable();

      expect(instance.download).not.toHaveBeenCalled();
    });
  });
});
