import { DebugElement } from '@angular/core';
import { fakeAsync, tick } from '@angular/core/testing';
import { ModalComponent } from '@synerg/components/deprecated/espresso/components/modal';
import { ClientDeviceService } from '@synerg/components/shared';
import { BehaviorSubject, of, throwError } from 'rxjs';
import { Shallow } from 'shallow-render';
import { QueryMatch } from 'shallow-render/dist/lib/models/query-match';
import { Mock } from 'ts-mockery';

import { LanguagePipe, LanguageService, NativeHelperService, UserProfileService } from '@myadp/common';
import { PayPermissionService } from '@myadp/pay-shared';

import { Info, WithholdingInfo, WithholdingItem, WithholdingType } from '../../../../models/formatted-tax-withholding.model';
import { FEDERAL } from '../../../../models/states.model';
import { PendingEvent, PendingEventType } from '../../../../models/tax-withholding.model';
import { UsFederalTaxWithholdingElections } from '../../../../models/us-federal-tax-withholding-election.model';
import { UsStateTaxWithholdingElections } from '../../../../models/us-state-tax-withholding-election.model';
import { TaxWithholdingSummaryDetailsComponent } from '../../../../modules/shared/components/tax-withholding-summary/details/tax-withholding-summary-details.component';
import { FederalWithholdingService } from '../../../../services/federal-withholding.service';
import { StateWithholdingService } from '../../../../services/state-withholding.service';
import { TaxWithholdingStore } from '../../../../services/tax-withholding.store';
import { DownloadPdfDirective } from '../../../shared/directives/download-pdf.directive';
import { PdfStatement } from '../../../shared/models/pdf-viewer.model';
import { WithholdingFormatterService } from '../../../shared/services/withholding-formatter.service';
import { StepsService } from '../../../tax-withholding-management/shared/services/steps.service';
import { MaritalStatus } from '../../../tax-withholding-management/us/fed/models/fed-marital-status.enum';
import { FedWizard } from '../../../tax-withholding-management/us/fed/models/fed-wizard.model';
import { FedTWChangeEventService } from '../../../tax-withholding-management/us/fed/services/fed-tw-change-event.service';
import { FederalWithholdingHelperService } from '../../services/federal-withholding-helper.service';
import { StateWithholdingHelperService } from '../../services/state-withholding-helper.service';
import { TaxWithholdingManagementTileModule } from '../../tax-withholding-management-tile.module';
import { StartButtonComponent } from '../start-button/start-button.component';
import { StateSelfSelectComponent } from '../state-self-select/state-self-select.component';
import { SummaryViewComponent } from './summary-view.component';

describe('SummaryViewComponent', () => {
  let shallow: Shallow<SummaryViewComponent>;
  let mockFederalWithholding: WithholdingInfo;
  let mockStateWithholding: WithholdingInfo;
  let mockFederalChangePermission: boolean;
  let mockStateTaxWithholdingReadPermission: boolean;
  const federalSelector = 'adp-list-view[data-e2e="tw-panel-Federal"]';
  const alabamaSelector = 'adp-list-view[data-e2e="tw-panel-Alabama"]';
  const georgiaSelector = 'adp-list-view[data-e2e="tw-panel-Georgia"]';
  const pendingMessage = 'myadp-pay.TWM_WORKFLOW_PENDING_MESSAGE';
  const pendingNoEditMessage = 'common.WF_PENDING_ITEMS_EXIST_NO_CHANGES_ALLOWED';
  const pendingConfirmCancelMessage = 'myadp-pay.TWM_WORKFLOW_CONFIRM_CANCEL';
  const pendingPractitionerInitMessage = 'myadp-pay.TWM_WORKFLOW_PENDING_PRACTITIONER_INIT_MESSAGE';
  const mockRefreshTile = new BehaviorSubject<boolean>(null);
  const mockcloseModal = new BehaviorSubject<boolean>(null);
  const mockesignModal = new BehaviorSubject<boolean>(null);
  const mockwizardModalTitle = new BehaviorSubject<string>(null);
  const mockErrorModel: WithholdingInfo = { hasError: true };
  const mockFederalData: Partial<FedWizard> = {
    nonresidentAlien: { nonresidentAlien: false },
    maritalStatus: { maritalStatus: MaritalStatus.SINGLE_OR_MARRIED_FILING_SEPARATELY }
  };
  const mockNoIncomeInfo: Info = {
    type: 'success',
    title: 'noIncomeTaxMessageTitle',
    message: 'noIncomeTaxMessage'
  };
  const mockUnsupportedInfo: Info = {
    type: 'success',
    title: 'unsupportedTitle',
    message: 'unsupportedMessage'
  };
  const mockUneditableInfo: Info = {
    type: 'success',
    title: 'uneditableTitle',
    message: 'uneditableMessage'
  };
  const mockFlatRateInfo: Info = {
    type: 'success',
    title: 'fatRateTitle',
    message: 'flatRateMessage'
  };
  const mockPendingEvents: PendingEvent = {
    eventTypeId: PendingEventType.EMPLOYEE_INITIATED
  };

  beforeEach(() => {
    mockFederalWithholding = {
      type: WithholdingType.FEDERAL,
      withholdingItems: [
        {
          type: WithholdingType.FEDERAL,
          title: 'Federal',
          effectiveDate: '2020-01-01',
          state: FEDERAL,
          allowEdit: true,
          summaryItems: [{ displayName: 'mock name', displayValue: 'mock value' }],
          attachments: [{ gssUrl: '/gss/url' }]
        }
      ],
      hasElections: true
    };
    mockStateWithholding = {
      type: WithholdingType.STATE,
      withholdingItems: [
        {
          type: WithholdingType.STATE,
          title: 'Alabama',
          effectiveDate: '2020-01-01',
          state: { shortName: 'AL', longName: 'Alabama', countryCode: 'US' },
          allowEdit: true,
          summaryItems: [{ displayName: 'mock name', displayValue: 'mock value' }]
        },
        {
          type: WithholdingType.STATE,
          title: 'Georgia',
          effectiveDate: '2020-01-01',
          state: { shortName: 'GA', longName: 'Georgia', countryCode: 'US' },
          allowEdit: true,
          summaryItems: [{ displayName: 'mock name', displayValue: 'mock value' }]
        }
      ],
      hasElections: true
    };
    mockFederalChangePermission = true;
    mockStateTaxWithholdingReadPermission = true;
  });

  const withholdingPdfs: PdfStatement[] = [
    {
      title: 'myadp-pay.PDF_VIEWER_SLIDEIN_HEADER_TAX_WITHHOLDING',
      uri: 'mockPDF.pdf',
      statementDetails: [
        {
          label: 'myadp-pay.PDF_VIEWER_SLIDEIN_STATE',
          value: 'Georgia'
        },
        { label: 'myadp-pay.PDF_VIEWER_SLIDEIN_FORM_TYPE', value: 'G-4' }
      ]
    },
    {
      title: 'myadp-pay.PDF_VIEWER_SLIDEIN_HEADER_TAX_WITHHOLDING',
      uri: 'mockPDF.pdf',
      statementDetails: [
        {
          label: 'myadp-pay.PDF_VIEWER_SLIDEIN_STATE',
          value: 'Alabama'
        },
        { label: 'myadp-pay.PDF_VIEWER_SLIDEIN_FORM_TYPE', value: 'A-4' }
      ]
    }
  ];

  beforeEach(() => {
    shallow = new Shallow(SummaryViewComponent, TaxWithholdingManagementTileModule)
      .provide(LanguageService)
      .mockPipe(LanguagePipe, (key) => key)
      .mock(StepsService, {
        refreshTile: mockRefreshTile,
        wizardModalTitleSubject: mockwizardModalTitle,
        closeModalSubject: mockcloseModal,
        eSignModalSubject: mockesignModal,
        federalWizardData: {
          maritalStatus: {
            maritalStatus: MaritalStatus.SINGLE_OR_MARRIED_FILING_SEPARATELY
          }
        }
      })
      .mock(TaxWithholdingStore, {
        getActiveWithholdingItems: () => [
          ...mockFederalWithholding.withholdingItems,
          ...mockStateWithholding.withholdingItems
        ],
        getFederalWizard: () => mockFederalData,
        getInactiveWithholdingItems: (): WithholdingItem[] => [],
        getWithholdingForms: (): PdfStatement[] => withholdingPdfs
      })
      .mock(FederalWithholdingService, {
        getFederalWithholding: () => Promise.resolve<UsFederalTaxWithholdingElections>({})
      })
      .mock(StateWithholdingService, {
        getStateWithholding: () => Promise.resolve<UsStateTaxWithholdingElections>({}),
        recallWithholding: () => of({ wfStatusCode: 1000 })
      })
      .mock(FedTWChangeEventService, {
        createChangeEvent: () => {
          return { events: [] };
        }
      })
      .mock(LanguageService, { get: (key: string) => key })
      .mock(PayPermissionService, {
        hasFederalTaxWithholdingChangePermission: () => mockFederalChangePermission,
        hasStateTaxWithholdingReadPermission: () => mockStateTaxWithholdingReadPermission
      })
      .mock(FederalWithholdingHelperService, {
        getWithholdingModel: () => mockFederalWithholding
      })
      .mock(StateWithholdingHelperService, {
        getWithholdingModel: () => mockStateWithholding
      })
      .mock(WithholdingFormatterService, {
        getErrorModel: () => mockErrorModel
      })
      .mock(NativeHelperService, {
        compareContainerVersion: () => Promise.resolve(0)
      })
      .mock(ClientDeviceService, {
        isIOS: () => false,
        isNative: () => false
      })
      .mock(UserProfileService, {
        hasFeaturedForSOR: () => false
      })
      .dontMock(StartButtonComponent)
      .dontMock(TaxWithholdingSummaryDetailsComponent)
      .dontMock(StateSelfSelectComponent)
      .dontMock(ModalComponent);
  });

  it('should refresh tile when hcm call succeeds', async () => {
    mockRefreshTile.next(true);
    const { get } = await shallow.render();
    const mockFederalWithholdingService = get(FederalWithholdingService);
    const mockStateWithholdingService = get(StateWithholdingService);

    expect(mockFederalWithholdingService.getFederalWithholding).toHaveBeenCalled();
    expect(mockStateWithholdingService.getStateWithholding).toHaveBeenCalled();
  });

  it('should get federal and then get state withholding data in sequential order', fakeAsync(async () => {
    const fedPromise = new Promise((resolve) => {
      return new Promise(() => {
        setTimeout(() => {
          resolve(true);
        }, 50);
      });
    });
    const statePromise = new Promise((resolve) => {
      return resolve(true);
    });

    const { get } = await shallow
      .mock(FederalWithholdingService, {
        getFederalWithholding: () => fedPromise
      })
      .mock(StateWithholdingService, {
        getStateWithholding: () => statePromise
      })
      .render();
    const mockFederalWithholdingService = get(FederalWithholdingService);
    const mockStateWithholdingService = get(StateWithholdingService);

    expect(mockFederalWithholdingService.getFederalWithholding).toHaveBeenCalled();
    expect(mockStateWithholdingService.getStateWithholding).not.toHaveBeenCalled();
    tick(50);
    expect(mockStateWithholdingService.getStateWithholding).toHaveBeenCalled();
  }));

  it('should not load states when there is no state read permission', async () => {
    mockStateTaxWithholdingReadPermission = false;
    mockRefreshTile.next(true);
    const { get, instance } = await shallow.render();
    const mockFederalWithholdingService = get(FederalWithholdingService);
    const mockStateWithholdingService = get(StateWithholdingService);
    const emptyWithholdingInfo: WithholdingInfo = { withholdingItems: [] };

    expect(mockFederalWithholdingService.getFederalWithholding).toHaveBeenCalled();
    expect(mockStateWithholdingService.getStateWithholding).not.toHaveBeenCalled();
    expect(instance.withholdingData[1]).toEqual(emptyWithholdingInfo);
  });

  it('should show load error message', async () => {
    const { find, fixture, instance } = await shallow.render();
    instance.errorMessage = 'MY ERROR HERE';
    fixture.detectChanges();
    expectContent(find, '[data-e2e="error-message"]', instance.errorMessage);
  });

  describe('no income tax', () => {
    beforeEach(() => {
      mockStateWithholding.withholdingItems[0].allowEdit = false;
      mockStateWithholding.withholdingItems[0].info = mockNoIncomeInfo;
      mockStateWithholding.withholdingItems[0].isNoIncomeTax = true;
    });

    it('should show', async () => {
      const { find } = await shallow.render();

      expectSection(find, federalSelector, false, '', false, false, '', true, false, false);
      expectSection(
        find,
        alabamaSelector,
        false,
        '',
        false,
        false,
        mockNoIncomeInfo.message,
        false,
        false,
        false
      );
      expectSection(find, georgiaSelector, false, '', false, false, '', true, false, false);
    });

    it('should not show summary item when the state has no income tax', async () => {
      const component = await shallow.render();

      expect(component.element.nativeElement.innerHTML).not.toContain('pay-summary-view-item');
      expect(component.find('adp-alert')).toBeDefined();
    });
  });

  describe('unsupported', () => {
    beforeEach(() => {
      mockStateWithholding.withholdingItems[0].allowEdit = false;
      mockStateWithholding.withholdingItems[0].info = mockUnsupportedInfo;
      mockStateWithholding.withholdingItems[0].isUnsupported = true;
    });

    it('should show', async () => {
      const { find } = await shallow.render();
      expectSection(find, federalSelector, false, '', false, false, '', true, false, false);
      expectSection(
        find,
        alabamaSelector,
        false,
        '',
        false,
        false,
        mockUnsupportedInfo.message,
        false,
        false,
        false
      );
      expectSection(find, georgiaSelector, false, '', false, false, '', true, false, false);
    });
  });

  describe('uneditable', () => {
    beforeEach(() => {
      mockStateWithholding.withholdingItems[0].allowEdit = false;
      mockStateWithholding.withholdingItems[0].info = mockUneditableInfo;
      mockStateWithholding.withholdingItems[0].isUneditable = true;
    });

    it('should show', async () => {
      const { find } = await shallow.render();
      expectSection(find, federalSelector, false, '', false, false, '', true, false, false);
      expectSection(
        find,
        alabamaSelector,
        false,
        '',
        false,
        false,
        mockUneditableInfo.message,
        false,
        false,
        false
      );
      expectSection(find, georgiaSelector, false, '', false, false, '', true, false, false);
    });
  });

  describe('flat rate', () => {
    beforeEach(() => {
      mockStateWithholding.withholdingItems[0].allowEdit = false;
      mockStateWithholding.withholdingItems[0].info = mockFlatRateInfo;
      mockStateWithholding.withholdingItems[0].isFlatRate = true;
    });

    it('should show', async () => {
      const { find } = await shallow.render();
      expectSection(find, federalSelector, false, '', false, false, '', true, false, false);
      expectSection(
        find,
        alabamaSelector,
        false,
        '',
        false,
        false,
        mockFlatRateInfo.message,
        false,
        true,
        false
      );
      expectSection(find, georgiaSelector, false, '', false, false, '', true, false, false);
    });
  });

  describe('effective date', () => {
    it('should show when showEffectiveDate is true', async () => {
      mockStateWithholding.withholdingItems[0].showEffectiveDate = true;
      const { find } = await shallow.render();

      expect(find(`[data-e2e="effective-date-notice"]`)).toHaveFound(1);
    });

    it('should not show when showEffectiveDate is false', async () => {
      mockStateWithholding.withholdingItems[0].showEffectiveDate = false;
      const { find } = await shallow.render();

      expect(find(`[data-e2e="effective-date-notice"]`)).toHaveFound(0);
    });
  });

  describe('pending', () => {
    beforeEach(() => {
      mockStateWithholding.withholdingItems[1].pendingSummaryItems = [
        { displayName: 'mock name', displayValue: 'mock pending value' }
      ];
      mockStateWithholding.withholdingItems[1].pendingEvents = mockPendingEvents;
      mockStateWithholding.pendingEvents = mockPendingEvents;
    });

    it('should not show effective date when workflow changes are pending', async () => {
      const { find } = await shallow.render();

      expect(find(`[data-e2e="effective-date-notice"]`)).toHaveFound(0);
    });

    it('should show non-pending items', async () => {
      const { find } = await shallow.render();
      expectSection(
        find,
        federalSelector,
        false,
        '',
        false,
        false,
        pendingNoEditMessage,
        false,
        false,
        false
      );
      expectSection(
        find,
        alabamaSelector,
        false,
        '',
        false,
        false,
        pendingNoEditMessage,
        false,
        false,
        false
      );
    });

    it('pending info alert should supercede warning alerts', async () => {
      mockStateWithholding.withholdingItems.push({
        type: WithholdingType.STATE,
        title: 'Colorado',
        effectiveDate: '2020-01-01',
        invalidFederalDependency: true,
        allowEdit: false,
        state: { shortName: 'CO', longName: 'Colorado', countryCode: 'US' },
        summaryItems: [{ displayName: 'mock name', displayValue: 'mock value' }]
      });
      const { find } = await shallow.render();
      expectSection(
        find,
        'adp-list-view[data-e2e="tw-panel-Colorado"]',
        false,
        '',
        false,
        false,
        pendingNoEditMessage,
        false,
        false,
        false
      );
    });

    it('supplied message should supersede non-pending message', async () => {
      mockStateWithholding.withholdingItems[0].info = mockNoIncomeInfo;
      const { find } = await shallow.render();
      expectSection(
        find,
        federalSelector,
        false,
        '',
        false,
        false,
        pendingNoEditMessage,
        false,
        false,
        false
      );
      expectSection(
        find,
        alabamaSelector,
        false,
        '',
        false,
        false,
        mockNoIncomeInfo.message,
        false,
        false,
        false
      );
    });

    it('should show with difference', async () => {
      const { find } = await shallow.render();
      expectSection(
        find,
        georgiaSelector,
        true,
        pendingMessage,
        true,
        true,
        pendingConfirmCancelMessage,
        false,
        false,
        true
      );
    });

    it('should show without difference', async () => {
      mockStateWithholding.withholdingItems[1].pendingSummaryItems = undefined;
      const { find } = await shallow.render();

      expectSection(
        find,
        georgiaSelector,
        true,
        pendingMessage,
        false,
        false,
        pendingConfirmCancelMessage,
        false,
        false,
        true
      );
    });

    it('cancel success', async () => {
      const { find, fixture, instance } = await shallow.render();
      instance.openCancelConfirm(mockStateWithholding.withholdingItems[0]);
      expect(instance.showCancelConfirmModal).toBeTruthy();
      fixture.detectChanges();
      find(`${georgiaSelector} [data-e2e="cancel-button"]`).nativeElement.click();
      find(
        '[data-e2e="cancel-confirm-content"] [data-e2e="cancel-confirm-button"]'
      ).nativeElement.click();
      fixture.detectChanges();

      expectContent(
        find,
        '[data-e2e="cancel-success-message"]',
        'myadp-pay.TWM_WORKFLOW_CANCEL_SUCCESS'
      );
    });

    it('cancel fail', async () => {
      shallow.mock(StateWithholdingService, {
        recallWithholding: () => throwError({})
      });
      const { find, fixture, instance } = await shallow.render();
      instance.openCancelConfirm(mockStateWithholding.withholdingItems[0]);
      expect(instance.showCancelConfirmModal).toBeTruthy();
      fixture.detectChanges();
      find(`${georgiaSelector} [data-e2e="cancel-button"]`).nativeElement.click();
      find(
        '[data-e2e="cancel-confirm-content"] [data-e2e="cancel-confirm-button"]'
      ).nativeElement.click();
      fixture.detectChanges();

      expect(
        find('[data-e2e="cancel-confirm-content"] adp-message').nativeElement.textContent
      ).toContain('common.GENERAL_ERROR');
    });
  });

  describe('pending practitioner initiated', () => {
    beforeEach(() => {
      mockStateWithholding.pendingEvents = mockPendingEvents;
      mockStateWithholding.pendingEvents.eventTypeId = PendingEventType.PRACTITIONER_INITIATE;
    });

    it('should show messages', async () => {
      const { find } = await shallow.render();

      expectContent(find, '[data-e2e="pending-message"]', pendingPractitionerInitMessage);
      expectSection(find, federalSelector, false, '', false, false, '', false, false, false);
      expectSection(find, alabamaSelector, false, '', false, false, '', false, false, false);
      expectSection(find, georgiaSelector, false, '', false, false, '', false, false, false);
    });
  });

  describe('editable', () => {
    it('should show', async () => {
      const { find } = await shallow.render();
      expectSection(find, federalSelector, false, '', false, false, '', true, false, false);
      expectSection(find, alabamaSelector, false, '', false, false, '', true, false, false);
      expectSection(find, georgiaSelector, false, '', false, false, '', true, false, false);
    });
  });

  describe('start button', () => {
    it('should show start button if federal has no election', async () => {
      mockFederalWithholding.hasElections = false;
      const { find } = await shallow.render();

      expect(find('[data-e2e="start-button"]')).toHaveFound(1);
      expect(find('adp-list-view')).toHaveFound(0);
    });

    it('should show start button if federal is empty even if state api fails', async () => {
      mockFederalWithholding.hasElections = false;
      mockStateWithholding.hasError = true;
      const { find } = await shallow.render();

      expect(find('[data-e2e="start-button"]')).toHaveFound(1);
    });

    it('should show alert if user does not have edit permission and no tw setup', async () => {
      mockFederalWithholding.hasElections = false;
      mockFederalChangePermission = false;
      const { find } = await shallow.render();

      expect(find('[data-e2e="start-button-alert"]')).toHaveFound(1);
    });
  });

  describe('download signed form button', () => {
    it('should show download button when there are attachments', async () => {
      const { find, findDirective } = await shallow.render();

      expect(find('[data-e2e="gss-button"]')).toHaveFound(1);
      expect(findDirective(DownloadPdfDirective).useAudioEye).toBeFalse();
    });

    it('should hide download button when there are no attachements', async () => {
      delete mockFederalWithholding.withholdingItems[0].attachments;
      const { find } = await shallow.render();

      expect(find('[data-e2e="gss-button"]')).toHaveFound(0);
    });
  });

  // TEMP: see PIMYPI-10633
  describe('upgradeAppModal', () => {
    it('should open the upgrade app modal if on iOS native mobile and below v3.17.0', async () => {
      const { find, fixture, get, instance } = await shallow
        .mock(StepsService, {
          refreshTile: mockRefreshTile,
          setupWizard: () => undefined,
          federalWizardData: {
            maritalStatus: {
              maritalStatus: MaritalStatus.SINGLE_OR_MARRIED_FILING_SEPARATELY
            }
          }
        })
        .mock(NativeHelperService, {
          compareContainerVersion: () => Promise.resolve(1)
        })
        .mock(ClientDeviceService, {
          isIOS: () => true,
          isNative: () => true
        })
        .render();
      // only way this works is by calling it 2x 🙃
      find(`${federalSelector} [data-e2e="edit-button"]`).nativeElement.click();
      fixture.detectChanges();
      await fixture.whenStable();
      fixture.detectChanges();
      await fixture.whenStable();

      expect(instance.showUpgradeModal).toBe(true);
      expect(find('#upgrade-app-modal')).toHaveFound(1);
      expect(instance.showWizardModal).toBe(false);
      expect(get(StepsService).setupWizard).toHaveBeenCalledTimes(0);
    });

    it('should not open the upgrade app modal if not on iOS native mobile and below v3.17.0', async () => {
      const { find, fixture, get, instance } = await shallow
        .mock(StepsService, {
          refreshTile: mockRefreshTile,
          setupWizard: () => undefined
        })
        .mock(NativeHelperService, {
          compareContainerVersion: () => undefined
        })
        .mock(ClientDeviceService, {
          isIOS: () => false,
          isNative: () => false
        })
        .render();
      find(`${federalSelector} [data-e2e="edit-button"]`).nativeElement.click();
      fixture.detectChanges();
      await fixture.whenStable();

      expect(instance.showUpgradeModal).toBe(false);
      expect(find('#upgrade-app-modal')).toHaveFound(0);
      expect(instance.showWizardModal).toBe(true);
      expect(get(StepsService).setupWizard).toHaveBeenCalledTimes(1);
    });
  });

  describe('eSignModal', () => {
    it('should not show the esign modal', async () => {
      const { find } = await shallow.render();

      expect(find('#esign-modal').length).toBe(0);
    });

    it('should show the esign modal', async () => {
      const { find } = await shallow
        .mock(StepsService, {
          eSignModalSubject: new BehaviorSubject<boolean>(true)
        })
        .render();

      expect(find('#esign-modal').length).toBe(1);
    });
  });

  it('should update the Wizard modal title', async () => {
    const modalTitle = 'myadp-pay.FED_TAX_WITHHOLDING';
    const { instance } = await shallow
      .mock(StepsService, {
        wizardModalTitleSubject: new BehaviorSubject<string>(modalTitle)
      })
      .render();
    expect(instance.modalTitle).toEqual(modalTitle);
  });

  it('should set the title when open the modal', async () => {
    const modalTitle = 'myadp-pay.FED_TAX_WITHHOLDING';
    const { find, fixture } = await shallow
      .mock(StepsService, {
        wizardModalTitleSubject: new BehaviorSubject<string>(modalTitle),
        setupWizard: () => Mock.noop()
      })
      .render();
    const [editButton] = find('adp-button[data-e2e="edit-button"]');
    editButton.nativeElement.click();
    fixture.detectChanges();
    expect(find('.modal-title').nativeElement.textContent).toContain(modalTitle);
  });

  describe('stepup', () => {
    it('should enable stepup', async () => {
      const { instance } = await shallow.render();
      expect(instance.stepUpEnabled).toBeTruthy();
    });

    it('should not enable stepup', async () => {
      const { instance } = await shallow
        .mock(UserProfileService, {
          hasFeaturedForSOR: () => true
        })
        .render();
      expect(instance.stepUpEnabled).toBeFalsy();
    });
  });

  function expectSection(
    find: (cssOrDirective: string) => QueryMatch<DebugElement>,
    sectionSelector: string,
    isPending: boolean,
    topMessage: string,
    hasCurrentHeader: boolean,
    hasPending: boolean,
    bottomMessage: string,
    hasEditButton: boolean,
    hasFlatRateButton: boolean,
    hasCancelButton: boolean
  ) {
    expect(find(`${sectionSelector}[ng-reflect-status="warning"]`)).toHaveFound(isPending ? 1 : 0);
    expectContent(find, `${sectionSelector} .top-message`, topMessage);
    expect(find(`${sectionSelector} .current.has-pending .header`)).toHaveFound(
      hasCurrentHeader ? 1 : 0
    );
    expect(find(`${sectionSelector} .new`)).toHaveFound(hasPending ? 1 : 0);
    expectContent(find, `${sectionSelector} .bottom-message`, bottomMessage);
    expect(find(`${sectionSelector} [data-e2e="edit-button"]`)).toHaveFound(hasEditButton ? 1 : 0);
    expect(find(`${sectionSelector} [data-e2e="flat-rate-button"]`)).toHaveFound(
      hasFlatRateButton ? 1 : 0
    );
    expect(find(`${sectionSelector} [data-e2e="cancel-button"]`)).toHaveFound(
      hasCancelButton ? 1 : 0
    );
  }

  function expectContent(find: any, selector: string, content: string) {
    expect(find(selector).nativeElement.textContent.trim()).toEqual(content);
  }
});
