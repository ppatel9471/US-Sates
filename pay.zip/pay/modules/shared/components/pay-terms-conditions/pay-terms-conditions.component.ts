import { Component, Input } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FormGroupMessage } from '@synerg/components/form-group';

import { ExternalWindowService, LanguageService, PrintModalService } from '@myadp/common';

@Component({
  selector: 'pay-terms-conditions',
  templateUrl: './pay-terms-conditions.component.html',
  styleUrls: ['./pay-terms-conditions.component.scss']
})
export class PayTermsAndConditionsComponent {
  @Input() formGroupControlName: string;
  @Input() formGroupControl: FormGroup;
  @Input() controlName: string = 'terms';

  @Input() consentText: string;
  @Input() printedConsentText: string;
  @Input() consentTitle: string;

  @Input() privacyLink: string = 'https://privacy.adp.com/privacy.html';

  public displayText: string;

  public showTerms: boolean = false;
  public showTermsWithPrint: boolean = false;

  public errorMessages: Record<string, FormGroupMessage[]> = {
    termErrors: [
      {
        errorType: 'required',
        errorMessage: this.languageService.get('myadp-pay.DD_ERROR_TERMS_REQUIRED')
      }
    ]
  };

  constructor(
    private languageService: LanguageService,
    private printModalService: PrintModalService,
    private externalWindowService: ExternalWindowService
  ) {}

  public activateTermsModal(clickEvent: MouseEvent, linkType?: 'terms' | 'privacy'): void {
    clickEvent.preventDefault();
    clickEvent.stopImmediatePropagation();

    this.showTermsWithPrint = this.formGroupControl
      .get(this.formGroupControlName)
      .get(this.controlName).value;

    this.displayText = this.showTermsWithPrint ? this.printedConsentText : this.consentText;

    if (linkType === 'terms') {
      this.showTerms = true;
      return;
    }

    if (linkType === 'privacy') {
      this.externalWindowService.open({ uri: this.privacyLink });
      return;
    }

    if (!this.showTermsWithPrint) {
      this.showTerms = true;
    } else {
      this.formGroupControl.get(this.formGroupControlName).get(this.controlName).setValue(false);

      this.formGroupControl.get(this.formGroupControlName).get(this.controlName).markAsTouched();
    }
  }

  public handlePrint(): void {
    this.printModalService.printText(`
      <html>
        <head>
          <title>${this.consentTitle}</title>
        </head>
        <body>
          ${this.printedConsentText}
        </body>
      </html>`);
  }

  public handleAgree(): void {
    this.formGroupControl.get(this.formGroupControlName).get(this.controlName).setValue(true);
    this.showTerms = false;
  }

  public handleClose(): void {
    this.formGroupControl.get(this.formGroupControlName).get(this.controlName).markAsTouched();
    this.showTerms = false;
  }
}
