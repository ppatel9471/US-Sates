import { Shallow } from 'shallow-render';
import { LanguagePipe } from '@myadp/common';
import { Mock } from 'ts-mockery';
import { of } from 'rxjs';
import { ToggleSwitchComponent } from '@synerg/components/toggle-switch';

import { PrivacyModeSharedModule } from '../privacy-mode-shared.module';
import { PrivacyModeStore } from '../store/privacy-mode.store';
import { PrivacyModeToggleComponent } from './privacy-mode-toggle.component';

describe('PrivacyModeToggleComponent', () => {
  let shallow: Shallow<PrivacyModeToggleComponent>;

  beforeEach(() => {
    shallow = new Shallow(PrivacyModeToggleComponent, PrivacyModeSharedModule)
      .mock(PrivacyModeStore, {
        privacyMode$: of(true),
        setPrivacyMode: () => Mock.noop()
      })
      .mockPipe(LanguagePipe, (key: string) => key)
      .dontMock(ToggleSwitchComponent);
  });

  it('should switch on the toggle when privacy mode is enabled', async () => {
    const { find } = await shallow.render();
    const privacyModeToggle = find('adp-toggle-switch');

    expect(privacyModeToggle.componentInstance.checked).toBe(true);
  });

  it('should switch off the toggle when privacy mode is disabled', async () => {
    const { find } = await shallow
      .mock(PrivacyModeStore, {
        privacyMode$: of(false)
      })
      .render();
    const privacyModeToggle = find('adp-toggle-switch');

    expect(privacyModeToggle.componentInstance.checked).toBe(false);
  });

  it('should set privacy mode when toggling the toggle', async () => {
    const { find, get } = await shallow.render();
    const privacyModeToggle = find('adp-toggle-switch');
    privacyModeToggle.triggerEventHandler('valueChange', false);

    expect(get(PrivacyModeStore).setPrivacyMode).toHaveBeenCalledWith(false);
  });
});
