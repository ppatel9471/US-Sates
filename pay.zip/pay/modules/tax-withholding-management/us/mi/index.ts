import { MiIntroComponent } from './steps/intro/mi-intro.component';
import { PersonalInfoComponent } from './steps/personal-info/personal-info.component';
import { MiNewEmployeeComponent } from './steps/new-employee/mi-new-employee.component';
import { MiExemptionComponent } from './steps/exemption/mi-exemption.component';
import { MiAllowancesComponent } from './steps/allowances/mi-allowances.component';

export { MiStepNavigationService } from './services/mi-step-navigation.service';
export { MiTWChangeEventService } from './services/mi-tw-change-event.service';
export { MiSummaryMetaDataService } from './services/mi-summary-meta-data.service';

export const MI_COMPONENTS = [
  PersonalInfoComponent,
  MiNewEmployeeComponent,
  MiExemptionComponent,
  MiIntroComponent,
  MiAllowancesComponent
];

export { MISTEP_COMPONENT } from './models/steps-component.model';

export { MiAttachmentCodes } from './models/mi-tw-change-event';
