import { Shallow } from 'shallow-render';
import { Mock } from 'ts-mockery';

import { MyADPDirectDepositModule } from '../../direct-deposit.module';
import { StepsStoreActions } from '../../store/steps/steps.store';
import { DirectDepositListComponent } from './direct-deposit-list.component';
import { AccountListComponent } from '../shared/account-list/account-list.component';

describe('DirectDepositListComponent', () => {
  let shallow: Shallow<DirectDepositListComponent>;

  beforeEach(() => {
    shallow = new Shallow(DirectDepositListComponent, MyADPDirectDepositModule).mock(
      StepsStoreActions,
      {
        cancelPendingRequest: () => Mock.noop()
      }
    );
  });

  describe('Cancel request', () => {
    it('should call to cancel request', async () => {
      const { findComponent, instance, get } = await shallow.render();
      const stepsStoreActions = get(StepsStoreActions);
      const accountList = findComponent(AccountListComponent);

      expect(accountList).toHaveFound(1);
      instance.canceledRequest({ currentData: {} });

      expect(stepsStoreActions.cancelPendingRequest).toHaveBeenCalledWith(
        { currentData: {} },
        true
      );
    });
  });
});
