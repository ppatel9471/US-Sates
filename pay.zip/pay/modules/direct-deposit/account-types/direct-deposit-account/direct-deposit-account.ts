import { AccountDetailsComponent } from '../../components/steps/account-details/account-details.component';
import { DepositAmountComponent } from '../../components/steps/deposit-amount/deposit-amount.component';
import { AccountVerificationComponent } from '../../components/steps/account-verification/account-verification.component';
import { AccountReviewComponent } from '../../components/steps/account-review/account-review.component';
import { DepositDoneComponent } from '../../components/steps/deposit-done/deposit-done.component';

import { STEPS } from '../../models/steps.enum';

export const DIRECT_DEPOSIT_STEPS = {
  [STEPS.ACCOUNT_DETAILS]: AccountDetailsComponent,
  [STEPS.VERIFICATION]: AccountVerificationComponent,
  [STEPS.DEPOSIT_AMOUNT]: DepositAmountComponent,
  [STEPS.REVIEW]: AccountReviewComponent,
  [STEPS.DEPOSIT_DONE]: DepositDoneComponent
};

export const DIRECT_DEPOSIT_EDIT_STEPS = {
  [STEPS.ACCOUNT_DETAILS]: AccountDetailsComponent,
  [STEPS.VERIFICATION]: AccountVerificationComponent,
  [STEPS.REVIEW]: AccountReviewComponent,
  [STEPS.DEPOSIT_DONE]: DepositDoneComponent
};
