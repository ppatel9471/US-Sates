import { PayStatementsUI } from '../models/pay-statement-ui';
import { MOCK_TRANSFORMED_PAY_STATEMENT_DETAILS_RESPONSE } from '../../../../../../src/spec-helpers/pay/pay-statement/pay-statement-details';
import { transformDonut } from './donut.transform';

describe('transformDonut', () => {
  const mockDeductionCategories: PayStatementsUI.DeductionsCategory[] = [
    {
      id: 'taxes',
      name: 'myadp-pay.PAY_TAXES',
      amount: { amountValue: -199.64, currencyCode: 'USD' },
      amountYTD: { amountValue: 10449.62, currencyCode: 'USD' },
      deductions: [
        {
          name: 'Federal Income Tax',
          amount: { amountValue: -199.64, currencyCode: 'USD' },
          amountYTD: { amountValue: 5190.64, currencyCode: 'USD' },
          preTax: false
        }
      ],
      displayConfig: {
        rank: 3,
        color: 'accent-3',
        calculatorLink: {
          title: 'myadp-pay.PAY_CALCULATOR_TAXES_LINK_TITLE',
          link: 'https://www.irs.gov/individuals/tax-withholding-estimator'
        }
      }
    },
    {
      id: 'other',
      name: 'myadp-pay.PAY_OTHER',
      amount: { amountValue: 132, currencyCode: 'USD' },
      amountYTD: undefined,
      deductions: [
        {
          name: 'Positive Deduction',
          amount: { amountValue: 132, currencyCode: 'USD' },
          amountYTD: undefined,
          preTax: false
        }
      ],
      displayConfig: { rank: 14, color: 'accent-4', calculatorLink: undefined }
    }
  ];
  let mockDonutData: PayStatementsUI.PayDonutData;

  beforeEach(() => {
    mockDonutData = undefined;
  });

  it('should transform donut data', () => {
    mockDonutData = transformDonut(
      MOCK_TRANSFORMED_PAY_STATEMENT_DETAILS_RESPONSE.deductionsCategories,
      MOCK_TRANSFORMED_PAY_STATEMENT_DETAILS_RESPONSE.grossPay
    );

    expect(mockDonutData).toEqual(MOCK_TRANSFORMED_PAY_STATEMENT_DETAILS_RESPONSE.donutData);
  });

  it('should not have positive deductions message when inside tolerance', () => {
    mockDonutData = transformDonut(mockDeductionCategories, {
      amountValue: 331.7, // actual total: 331.64
      currencyCode: 'USD'
    });

    expect(mockDonutData).toEqual({
      hasPositiveDeductions: false,
      data: [
        {
          id: 'taxes',
          key: 'myadp-pay.PAY_TAXES',
          amount: { amountValue: -199.64, currencyCode: 'USD' },
          amountYTD: { amountValue: 10449.62, currencyCode: 'USD' },
          value: 199.64,
          valueYTD: 10449.62,
          color: 'accent-3'
        },
        {
          id: 'other',
          key: 'myadp-pay.PAY_OTHER',
          amount: { amountValue: 132, currencyCode: 'USD' },
          amountYTD: undefined,
          value: 132,
          valueYTD: NaN,
          color: 'accent-4'
        }
      ]
    });
  });

  it('should have positive deductions message when outside tolerance', () => {
    mockDonutData = transformDonut(mockDeductionCategories, {
      amountValue: 331.53,
      currencyCode: 'USD'
    });

    expect(mockDonutData).toEqual({
      hasPositiveDeductions: true,
      data: [
        {
          id: 'taxes',
          key: 'myadp-pay.PAY_TAXES',
          amount: { amountValue: -199.64, currencyCode: 'USD' },
          amountYTD: { amountValue: 10449.62, currencyCode: 'USD' },
          value: 199.64,
          valueYTD: 10449.62,
          color: 'accent-3'
        },
        {
          id: 'other',
          key: 'myadp-pay.PAY_OTHER',
          amount: { amountValue: 132, currencyCode: 'USD' },
          amountYTD: undefined,
          value: 132,
          valueYTD: NaN,
          color: 'accent-4'
        }
      ]
    });
  });
});
