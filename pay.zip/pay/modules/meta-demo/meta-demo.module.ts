import { NgModule } from '@angular/core';
import { MyAdpCommonModule } from '@myadp/common';
import { RouterModule, Routes } from '@angular/router';
import { TileModule } from '@espresso/tile';
import { DashboardModule } from '@myadp/common/components/dashboard';
import { TabsModule } from '@espresso/tabs';

import { MetaModule } from '../meta/meta.module';
import { ContentDemoComponent } from './components/content-demo/content-demo.component';
import { MetaDemoComponent } from './meta-demo.component';

const routes: Routes = [
  {
    path: '',
    pathMatch: 'full',
    component: MetaDemoComponent
  }
];

@NgModule({
  imports: [
    RouterModule.forChild(routes),
    MyAdpCommonModule,
    MetaModule,
    TileModule,
    DashboardModule,
    TabsModule
  ],
  declarations: [ContentDemoComponent, MetaDemoComponent],
  exports: [ContentDemoComponent, MetaDemoComponent]
})
export class PayMetaDemoModule {}
