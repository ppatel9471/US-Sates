import { TestBed } from '@angular/core/testing';
import { Mock } from 'ts-mockery';
import { CurrencyPipe } from '@angular/common';
import * as moment from 'moment';

import { LanguageService } from '@myadp/common';
import { Amount } from '@myadp/dto';

import { AdditionalTaxAmount } from '../../../models/tax-withholding.model';
import { ValueFormatterService, ValueFormatterType } from './value-formatter.service';

describe('ValueFormatterService', () => {
  let service: ValueFormatterService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        ValueFormatterService,
        CurrencyPipe,
        {
          provide: LanguageService,
          useValue: Mock.of<LanguageService>({ get: (key) => key })
        }
      ]
    });
  });
  beforeEach(() => {
    service = TestBed.inject(ValueFormatterService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  describe('Format Values', () => {
    it('should format booleans', () => {
      const formatter = ValueFormatterType.Boolean;
      expect(service.format(true, formatter)).toEqual('common.YES');
    });

    it('should format percentages', () => {
      const formatter = ValueFormatterType.Percentage;
      expect(service.format('18.1', formatter)).toEqual('18.1%');
    });

    it('should format currency', () => {
      const formatter = ValueFormatterType.Currency;
      const value: AdditionalTaxAmount = { amountValue: 10.1 };
      expect(service.format(value, formatter)).toEqual('$10.10');
    });

    it('should format currency with digits info', () => {
      const formatter = ValueFormatterType.Currency;
      const value: Amount = { amountValue: 10.1348, currencyCode: 'USD' };
      expect(service.format(value, formatter, '1.2-3')).toEqual('$10.135');
    });

    it('should format dates', () => {
      const formatter = ValueFormatterType.Date;
      const normalDate = '2020-01-12';
      const momentDate = moment('01/13/2020');
      const preformattedDate = 'January 14, 2020';
      const isoAltDate = '20200115';
      expect(service.format(undefined, formatter)).toEqual(undefined);
      expect(service.format(null, formatter)).toEqual(null);
      expect(service.format(normalDate, formatter)).toEqual(normalDate);
      expect(service.format(momentDate, formatter)).toEqual('2020-01-13');
      expect(service.format(preformattedDate, formatter)).toEqual('2020-01-14');
      expect(service.format(isoAltDate, formatter)).toEqual('2020-01-15');
    });

    it('should format unknowns', () => {
      expect(service.format('some value', 'bad')).toEqual('some value');
    });
  });
});
