import { HttpClient } from '@angular/common/http';
import { ClientService, UserIdentityService } from '../../common';
import { of } from 'rxjs';
import { Mock } from 'ts-mockery';
import { TransparencyService } from './transparency.service';
import { PaymentCalculationAnalysis } from '../models/payment-calculation-analysis.model';

const PCA_MOCK: PaymentCalculationAnalysis = {
  associateOid: 'G3FSRWQC0Z551ZV6',
  paymentCalculationId: '1eace21b-faad-0d8c-adb7-dda1c8da2b25',
  payPeriodId: '2020-10',
  insights: [],
  facts: []
};

describe('TransparencyService', () => {
  let service: TransparencyService;

  let httpClient: HttpClient;
  let userIdentityService: UserIdentityService;
  let clientService: ClientService;

  beforeEach(() => {
    httpClient = Mock.of<HttpClient>();
    userIdentityService = Mock.of<UserIdentityService>();
    clientService = Mock.of<ClientService>();
    service = new TransparencyService(
      httpClient,
      userIdentityService,
      clientService
    );
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });


  it('should detect if transparency is enabled for the client', async () => {

    Mock.extend(clientService).with({
      getClient: () => Promise.resolve({}),
      hasProductCode: () => true
    });

    const hasTransparency = await service.hasTransparency();
    expect(hasTransparency).toBeTrue();

  });

  it('should detect if transparency is NOT enabled for the client', async () => {

    Mock.extend(clientService).with({
      getClient: () => Promise.resolve({}),
      hasProductCode: () => false
    });

    const hasTransparency = await service.hasTransparency();
    expect(hasTransparency).toBeFalse();

  });

  it('should invoke payment calculation analysis API', async () => {

    Mock.extend(userIdentityService).with({
      getAoid: () => Promise.resolve('AOID')
    });

    Mock.extend(httpClient).with({
      get: () => of(PCA_MOCK)
    });

    const pca = await service.getPaymentCalculationAnalysis('doc-123');

    expect(pca).toBeDefined();

  });

});
