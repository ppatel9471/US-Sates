import { CurrencyPipe } from '@angular/common';
import { TestBed } from '@angular/core/testing';
import * as moment from 'moment';
import { Mock } from 'ts-mockery';

import { LanguageService } from '@myadp/common';
import { PayPermissionService } from '@myadp/pay-shared';

import { WithholdingItem } from '../../../models/formatted-tax-withholding.model';
import { FEDERAL } from '../../../models/states.model';
import { PendingEventType } from '../../../models/tax-withholding.model';
import { UsFederalTaxWithholdingElections } from '../../../models/us-federal-tax-withholding-election.model';
import { FederalWithholdingTransformService } from '../../../modules/shared/services/federal-withholding-transform.service';
import { ValueFormatterService } from '../../shared/services/value-formatter.service';
import { WithholdingFormatterService } from '../../shared/services/withholding-formatter.service';
import { FederalWithholdingHelperService } from './federal-withholding-helper.service';

describe('FederalWithholdingHelperService', () => {
  let service: FederalWithholdingHelperService;
  let mockWithholdingData: UsFederalTaxWithholdingElections;
  let payPermissionService: PayPermissionService;
  let mockWithholdingItems: WithholdingItem[];

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        FederalWithholdingHelperService,
        FederalWithholdingTransformService,
        WithholdingFormatterService,
        ValueFormatterService,
        CurrencyPipe,
        {
          provide: LanguageService,
          useValue: Mock.of<LanguageService>({ get: (key) => key })
        },
        {
          provide: PayPermissionService,
          useValue: Mock.of<PayPermissionService>({
            hasFederalTaxWithholdingChangePermission: () => true
          })
        }
      ]
    });
  });

  beforeEach(() => {
    service = TestBed.inject(FederalWithholdingHelperService);
    payPermissionService = TestBed.inject(PayPermissionService);
  });

  describe('editable', () => {
    beforeEach(() => {
      mockWithholdingItems = [
        {
          state: FEDERAL,
          isLocked: false
        }
      ];
    });

    it('federal is uneditable if federal is locked and has user permission', () => {
      mockWithholdingItems[0].isLocked = true;
      expect(service.isFederalEditable(mockWithholdingItems)).toEqual(false);
    });

    it('federal is editable if federal is not locked and has user permission', () => {
      mockWithholdingItems[0].isLocked = false;
      expect(service.isFederalEditable(mockWithholdingItems)).toEqual(true);
    });

    it('federal is uneditable if federal is locked and user has no change permission', () => {
      mockWithholdingItems[0].isLocked = true;
      Mock.extend(
        Mock.of<PayPermissionService>({
          hasFederalTaxWithholdingChangePermission: () => false
        })
      );
      expect(service.isFederalEditable(mockWithholdingItems)).toEqual(false);
    });

    it('federal is uneditable if federal is not locked user has no change permission', () => {
      mockWithholdingItems[0].isLocked = false;
      Mock.extend(payPermissionService).with({
        hasFederalTaxWithholdingChangePermission: () => false
      });
      expect(service.isFederalEditable(mockWithholdingItems)).toEqual(false);
    });
  });

  describe('withholding model', () => {
    beforeEach(() => {
      mockWithholdingData = {
        usFederalTaxWithholdingElections: [
          {
            usFederalIncomeTaxWithholdingElection: {
              taxWithholdingAllowanceQuantity: 1,
              taxFilingStatusCode: {
                codeValue: 'X',
                longName: 'Married Filing Jointly or Sep'
              },
              taxWithholdingStatus: {
                effectiveDate: moment().add(1, 'day').format('YYYY-MM-DD')
              },
              legalNameDiffersFromSSCardIndicator: false
            },
            workflowData: {
              pendingData: {
                usFederalTaxWithholdingElections: [
                  {
                    usFederalIncomeTaxWithholdingElection: {
                      taxWithholdingAllowanceQuantity: 2,
                      taxFilingStatusCode: {
                        codeValue: 'X',
                        longName: 'Married Filing Jointly or Sep'
                      },
                      legalNameDiffersFromSSCardIndicator: false
                    }
                  }
                ]
              },
              pendingEvents: {
                eventTypeId: PendingEventType.EMPLOYEE_INITIATED,
                history: [
                  {
                    assignedTo: 'Smith, Bob',
                    actionTaken: 'None',
                    actionDate: 12345,
                    comments: 'comment',
                    processStepID: 6789
                  }
                ]
              },
              confirmMessage: {
                resourceMessages: [
                  {
                    processMessages: [
                      {
                        userMessage: {
                          title: 'message title',
                          messageTxt: 'message text',
                          codeValue: ''
                        }
                      }
                    ]
                  }
                ]
              }
            }
          }
        ]
      };
    });

    it('should handle no elections', () => {
      delete mockWithholdingData.usFederalTaxWithholdingElections;
      const withholdingInfo = service.getWithholdingModel(mockWithholdingData);

      expect(withholdingInfo.hasElections).toBeFalsy();
      expect(withholdingInfo.withholdingItems[0].summaryItems).toBeDefined();
    });

    it('should handle missing data (federal start)', () => {
      const withholdingInfo = service.getWithholdingModel(null);

      expect(withholdingInfo.hasElections).toBeFalsy();
      expect(withholdingInfo.withholdingItems[0].summaryItems).toBeDefined();
    });

    it('should not populate pending events where there none', () => {
      delete mockWithholdingData.usFederalTaxWithholdingElections[0].workflowData;
      const withholdingInfo = service.getWithholdingModel(mockWithholdingData);

      expect(withholdingInfo.pendingEvents).toBeUndefined();
    });

    it('should populate pending events', () => {
      const withholdingInfo = service.getWithholdingModel(mockWithholdingData);

      expect(withholdingInfo.pendingEvents).toEqual(
        mockWithholdingData.usFederalTaxWithholdingElections[0].workflowData.pendingEvents
      );
    });

    it('should populate only w4 elections', () => {
      mockWithholdingData.usFederalTaxWithholdingElections.unshift({
        itemID: 'SOCIAL_SECURITY_DEFERMENT',
        usFederalIncomeTaxWithholdingElection: {}
      });
      const withholdingInfo = service.getWithholdingModel(mockWithholdingData);

      expect(withholdingInfo.pendingEvents).toEqual(
        mockWithholdingData.usFederalTaxWithholdingElections[0].workflowData.pendingEvents
      );
    });

    it('should populate the info message when federal is not editable', () => {
      Mock.extend(payPermissionService).with({
        hasFederalTaxWithholdingChangePermission: () => false
      });
      const withholdingInfo = service.getWithholdingModel(mockWithholdingData);

      expect(withholdingInfo.withholdingItems[0].info).toEqual({
        type: 'info',
        title: 'myadp-pay.TAXWITHHOLDING_CARD_NOEDIT_TITLE',
        message: 'myadp-pay.TAXWITHHOLDING_CARD_NOEDIT_MESSAGE'
      });
    });

    it('should populate the info message when federal is locked out', () => {
      mockWithholdingData.usFederalTaxWithholdingElections[0].usFederalIncomeTaxWithholdingElection.actions =
        [
          {
            operationID: 'worker.usFederal.taxWithholding.election.read',
            attestation: {
              messageTxt: 'TWT_1001'
            }
          }
        ];
      const withholdingInfo = service.getWithholdingModel(mockWithholdingData);

      expect(withholdingInfo.withholdingItems[0].info).toEqual({
        type: 'info',
        title: 'myadp-pay.TAXWITHHOLDING_CARD_NOEDIT_TITLE',
        message: 'myadp-pay.TAXWITHHOLDING_CARD_NOEDIT_TWT_1001_MESSAGE'
      });
    });

    it('should populate the info message when there is a userMessage', () => {
      const withholdingInfo = service.getWithholdingModel(mockWithholdingData);

      expect(withholdingInfo.withholdingItems[0].info).toEqual({
        type: 'pending',
        title: 'message title',
        message: 'message text'
      });
    });

    it('should set showEffectiveDate when there are pending workflow changes', () => {
      const withholdingInfo = service.getWithholdingModel(mockWithholdingData);

      expect(withholdingInfo.withholdingItems[0].showEffectiveDate).toBeFalse();
    });

    it('should set showEffectiveDate when effectiveDate is in the future', () => {
      delete mockWithholdingData.usFederalTaxWithholdingElections[0].workflowData;
      const withholdingInfo = service.getWithholdingModel(mockWithholdingData);

      expect(withholdingInfo.withholdingItems[0].showEffectiveDate).toBeTrue();
    });

    it('should set showEffectiveDate when effectiveDate is NOT in the future', () => {
      delete mockWithholdingData.usFederalTaxWithholdingElections[0].workflowData;
      mockWithholdingData.usFederalTaxWithholdingElections[0].usFederalIncomeTaxWithholdingElection.taxWithholdingStatus =
        {
          effectiveDate: moment().subtract(1, 'day').format('YYYY-MM-DD')
        };
      const withholdingInfo = service.getWithholdingModel(mockWithholdingData);

      expect(withholdingInfo.withholdingItems[0].showEffectiveDate).toBeFalse();
    });
  });
});
