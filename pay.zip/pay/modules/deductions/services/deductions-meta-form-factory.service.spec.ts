import { fakeAsync, flush, TestBed, tick } from '@angular/core/testing';
import { of } from 'rxjs';
import { Mock } from 'ts-mockery';
import { delay, tap } from 'rxjs/operators';

import { CodeListService, RawMetaObject } from '@myadp/forms';

import { DeductionsStoreActions } from '../store/deductions-store.actions';
import { PayDeductionsStoreSlice } from '../../pay-deductions-shared/models/pay-deductions-ui';
import { PayDeductionsStore } from '../../pay-deductions-shared/store/pay-deductions.store';
import { DeductionsSelectMetaForm } from '../models/deductions-select-meta-form.model';
import { DeductionsAddEditMetaForm } from '../models/deductions-add-edit-meta-form.model';
import { PayDeductionsStoreActions } from '../../pay-deductions-shared/store/pay-deductions-store.actions';
import { DeductionsMetaFormFactory } from './deductions-meta-form-factory.service';
import {
  MOCK_PAY_DEDUCTIONS_DEDUCTION_META,
  MOCK_PAY_DEDUCTIONS_START_META
} from '@specHelpers/pay/pay-deductions/pay-deductions';

describe('DeductionsMetaFormFactory', () => {
  let deductionsMetaFormFactory: DeductionsMetaFormFactory;
  let deductionsStoreActions: DeductionsStoreActions;
  let codeListService: CodeListService;
  let payDeductionsStore: PayDeductionsStore;
  const mockSelectedCodeValue: string = '40A';

  const mockStartMeta: RawMetaObject = MOCK_PAY_DEDUCTIONS_START_META;
  const mockRawDeductionMeta: RawMetaObject = MOCK_PAY_DEDUCTIONS_DEDUCTION_META;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        DeductionsMetaFormFactory,
        PayDeductionsStoreActions,
        DeductionsSelectMetaForm,
        {
          provide: DeductionsStoreActions,
          useValue: Mock.of<DeductionsStoreActions>({
            loadStartMeta: () => Mock.noop(),
            loadDeductionMeta: () => Mock.noop()
          })
        },
        {
          provide: PayDeductionsStore,
          useValue: Mock.of<PayDeductionsStore>({
            payDeductionsStartMeta$: of(mockStartMeta),
            payDeductionAddFormMeta$: () => of(mockRawDeductionMeta),
            payDeductionEditFormMeta$: () => of(mockRawDeductionMeta),
            payDeductionMetaItemSnapshot: () => null,
            hasDeductionMetaError: null,
            hasDeductionMetaError$: of(null),
            isPayDeductionsMetaLoading$: of(false),
            stateValue: {
              [PayDeductionsStoreSlice.PAY_DEDUCTIONS_META]: {
                loading: false,
                error: {}
              }
            }
          })
        },
        {
          provide: CodeListService,
          useValue: Mock.of<CodeListService>({
            getCodeList() {
              return Mock.noop();
            }
          })
        }
      ]
    });

    payDeductionsStore = TestBed.inject(PayDeductionsStore);
    deductionsStoreActions = TestBed.inject(DeductionsStoreActions);
    codeListService = TestBed.inject(CodeListService);
    deductionsMetaFormFactory = TestBed.inject(DeductionsMetaFormFactory);
  });

  describe('buildDeductionsSelectMetaForm', () => {
    it('should pass select meta form', (done: DoneFn) => {
      deductionsMetaFormFactory.buildDeductionsSelectMetaForm().subscribe((form) => {
        expect(form).toBeDefined();
        expect(form).toBeInstanceOf(DeductionsSelectMetaForm);
        expect(deductionsStoreActions.loadStartMeta).toHaveBeenCalled();
        expect(codeListService.getCodeList).toHaveBeenCalled();
        done();
      });
    });
  });

  describe('buildDeductionsAddEditMetaForm', () => {
    it('should pass add meta form and call loadDeductionMeta with isEdit set to false', (done: DoneFn) => {
      deductionsMetaFormFactory
        .buildDeductionsAddEditMetaForm(mockSelectedCodeValue)
        .subscribe((form) => {
          expect(form).toBeDefined();
          expect(form).toBeInstanceOf(DeductionsAddEditMetaForm);
          expect(deductionsStoreActions.loadDeductionMeta).toHaveBeenCalledWith('40A', false);
          done();
        });
    });

    it('should pass edit meta form and call loadDeductionMeta with isEdit set to true', (done: DoneFn) => {
      deductionsMetaFormFactory
        .buildDeductionsAddEditMetaForm(mockSelectedCodeValue, true)
        .subscribe((form) => {
          expect(form).toBeDefined();
          expect(form).toBeInstanceOf(DeductionsAddEditMetaForm);
          expect(deductionsStoreActions.loadDeductionMeta).toHaveBeenCalledWith('40A', true);
          done();
        });
    });

    it('should call payDeductionAddFormMeta$ when add meta form is built', (done: DoneFn) => {
      deductionsMetaFormFactory
        .buildDeductionsAddEditMetaForm(mockSelectedCodeValue)
        .subscribe((form) => {
          expect(form).toBeDefined();
          expect(form).toBeInstanceOf(DeductionsAddEditMetaForm);
          expect(payDeductionsStore.payDeductionAddFormMeta$).toHaveBeenCalledWith('40A');
          done();
        });
    });

    it('should call payDeductionEditFormMeta$ when edit meta form is built', (done: DoneFn) => {
      deductionsMetaFormFactory
        .buildDeductionsAddEditMetaForm(mockSelectedCodeValue, true)
        .subscribe((form) => {
          expect(form).toBeDefined();
          expect(form).toBeInstanceOf(DeductionsAddEditMetaForm);
          expect(payDeductionsStore.payDeductionEditFormMeta$).toHaveBeenCalledWith('40A');
          done();
        });
    });

    it('should not call deduction store to load deduction meta when add meta form is built', (done: DoneFn) => {
      Mock.extend(payDeductionsStore).with({
        payDeductionMetaItemSnapshot: () => mockRawDeductionMeta
      });
      deductionsMetaFormFactory
        .buildDeductionsAddEditMetaForm(mockSelectedCodeValue)
        .subscribe((form) => {
          expect(form).toBeDefined();
          expect(form).toBeInstanceOf(DeductionsAddEditMetaForm);
          expect(payDeductionsStore.payDeductionMetaItemSnapshot).toHaveBeenCalledWith('40A', false);
          expect(deductionsStoreActions.loadDeductionMeta).not.toHaveBeenCalled();
          done();
        });
    });

    it('should not call deduction store to load deduction meta when edit meta form is built', (done: DoneFn) => {
      Mock.extend(payDeductionsStore).with({
        payDeductionMetaItemSnapshot: () => mockRawDeductionMeta
      });
      deductionsMetaFormFactory
        .buildDeductionsAddEditMetaForm(mockSelectedCodeValue, true)
        .subscribe((form) => {
          expect(form).toBeDefined();
          expect(form).toBeInstanceOf(DeductionsAddEditMetaForm);
          expect(payDeductionsStore.payDeductionMetaItemSnapshot).toHaveBeenCalledWith('40A', true);
          expect(deductionsStoreActions.loadDeductionMeta).not.toHaveBeenCalled();
          done();
        });
    });

    it('should pass meta form after pay deductions meta loading state is false', fakeAsync(() => {
      Mock.extend(payDeductionsStore).with({
        isPayDeductionsMetaLoading$: of(false).pipe(
          delay(1),
          tap(() => {
            payDeductionsStore.stateValue.payDeductionsStartMeta.loading = false;
          })
        ),
        stateValue: {
          [PayDeductionsStoreSlice.PAY_DEDUCTIONS_META]: {
            loading: true
          }
        }
      });

      deductionsMetaFormFactory
        .buildDeductionsAddEditMetaForm(mockSelectedCodeValue)
        .subscribe((form) => {
          expect(form).toBeDefined();
          expect(form).toBeInstanceOf(DeductionsAddEditMetaForm);
          expect(payDeductionsStore.stateValue.payDeductionsStartMeta.loading).toBeFalse();
        });
      expect(payDeductionsStore.stateValue.payDeductionsStartMeta.loading).toBeTrue();
      tick(1);
      flush();
    }));

    it('should pass an error when unable to build the add edit meta form', () => {
      Mock.extend(payDeductionsStore).with({
        hasDeductionMetaError$: of(true)
      });
      expect(
        deductionsMetaFormFactory.buildDeductionsAddEditMetaForm.bind(mockSelectedCodeValue)
      ).toThrowError();
    });
  });
});
