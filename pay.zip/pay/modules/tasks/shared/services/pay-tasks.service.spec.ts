import { PendingEventDataHistory } from '@myadp/dto';

import { STATUS_CODE, STATUS_CODE_LABEL } from '@myadp/thingstodo-shared';

import { PayTasksService } from './pay-tasks.service';

describe('PayTasksService', () => {
  const mockApproved: PendingEventDataHistory = {
    actionDate: 123345,
    actionTaken: STATUS_CODE.approval,
    assignedTo: 'me',
    comments: 'my comment',
    processStepID: 9876
  };
  const mockWaitingForApproval: PendingEventDataHistory = {
    actionDate: 123345,
    actionTaken: 'Waiting for Approval',
    assignedTo: 'me',
    comments: 'my comment',
    processStepID: 9876
  };
  const mockCancelled: PendingEventDataHistory = {
    actionDate: 123345,
    actionTaken: STATUS_CODE.cancelled,
    assignedTo: 'me',
    comments: 'my comment',
    processStepID: 9876
  };
  const mockNotified: PendingEventDataHistory = {
    actionDate: 123345,
    actionTaken: STATUS_CODE.notified,
    assignedTo: 'me',
    comments: 'my comment',
    processStepID: 9876
  };
  const mockOld: PendingEventDataHistory = {
    actionDate: 1,
    actionTaken: STATUS_CODE.approval,
    assignedTo: 'me',
    comments: 'my comment',
    processStepID: 9876
  };

  it('should handle history from a notification', () => {
    const statusCodeLabel = PayTasksService.getStatusCodeLabel({
      history: [mockApproved]
    });
    expect(statusCodeLabel).toEqual(STATUS_CODE_LABEL.approved);
  });

  it('should handle history from a task', () => {
    const statusCodeLabel = PayTasksService.getStatusCodeLabel({
      pendingEvents: [
        {
          method: '',
          resourcePath: '',
          history: [mockCancelled]
        }
      ]
    });
    expect(statusCodeLabel).toEqual(STATUS_CODE_LABEL.rejected);
  });

  it('should handle history with filtering out notified items', () => {
    const statusCodeLabel = PayTasksService.getStatusCodeLabel({
      history: [mockNotified, mockApproved]
    });
    expect(statusCodeLabel).toEqual(STATUS_CODE_LABEL.approved);
  });

  it('should return based on the newest date', () => {
    const statusCodeLabel = PayTasksService.getStatusCodeLabel({
      history: [mockOld, mockApproved]
    });
    expect(statusCodeLabel).toEqual(STATUS_CODE_LABEL.approved);
  });

  it('should return error when a status cannot be found', () => {
    const statusCodeLabel = PayTasksService.getStatusCodeLabel({
      history: []
    });
    expect(statusCodeLabel).toEqual(STATUS_CODE_LABEL.error);
  });

  it('should return pending when action taken is waiting for approval', () => {
    const statusCodeLabel = PayTasksService.getStatusCodeLabel({
      history: [mockWaitingForApproval]
    });
    expect(statusCodeLabel).toEqual(STATUS_CODE_LABEL.pending);
  });
});
