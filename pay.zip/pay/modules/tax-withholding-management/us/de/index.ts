import { DeIntroComponent } from './steps/intro/de-intro.component';
import { DeMaritalStatusComponent } from './steps/marital-status/de-marital-status.component';
import { DeExemptionComponent } from './steps/exemption/de-exemption.component';
import { DeAllowancesComponent } from './steps/allowances/de-allowances.component';

export { DeTWChangeEventService } from './services/de-tw-change-event.service';
export { DeSummaryMetaDataService } from './services/de-summary-meta-data.service';
export { DeStepNavigationService } from './services/de-step-navigation.service';

export const DE_COMPONENTS = [
  DeIntroComponent,
  DeMaritalStatusComponent,
  DeExemptionComponent,
  DeAllowancesComponent
];

export { DESTEP_COMPONENT } from './models/steps-component.model';

export { DeAttachmentCodes } from './models/de-tw-change-event';
