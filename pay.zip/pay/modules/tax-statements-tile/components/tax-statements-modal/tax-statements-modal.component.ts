import { Component, OnInit } from '@angular/core';
import { GridData, GridRow, VanTableColumn, VanTableSort } from '@synerg/components/datagrid';
import { BreakpointMatches, BreakpointService } from '@synerg/components/shared';

import { LanguageService } from '@myadp/common';

import {
  ValueFormatterService,
  ValueFormatterType
} from '../../../shared/services/value-formatter.service';
import { RowDataProperties, RowDataPropertiesType } from '../../models/tax-statements-modal.model';
import { TaxStatementsStore } from '../../store/tax-statements.store';
import { TaxStatementsDownloadButtonRendererComponent } from './tax-statements-download-button-renderer/tax-statements-download-button-renderer.component';

@Component({
  selector: 'tax-statements-modal',
  templateUrl: 'tax-statements-modal.component.html',
  styleUrls: ['./tax-statements-modal.component.scss']
})
export class TaxStatementsModalComponent implements OnInit {
  public columns: VanTableColumn<string>[] = [];
  public dataGridStatements: GridData<RowDataProperties>;
  public showTaxStatementsModal: boolean = false;
  public formattedDataGridStatements: GridData<RowDataProperties>;
  public isDesktop: boolean;

  constructor(
    private languageService: LanguageService,
    private taxStatementsStore: TaxStatementsStore,
    private valueFormatterService: ValueFormatterService,
    private breakPointService: BreakpointService
  ) {}

  public ngOnInit() {
    this.taxStatementsStore.statementsByYear$().subscribe((statements) => {
      this.dataGridStatements = this.taxStatementsStore.dataGridStatements(statements);
      this.breakPointService.matches$.subscribe((breakPoint: BreakpointMatches) => {
        this.isDesktop = breakPoint.lg || breakPoint.xl || breakPoint.xxl;
        this.createColumns();
        this.formatDataGridStatements();
      });
    });
  }

  public createColumns() {
    this.columns = [];
    const fields = [
      RowDataPropertiesType.YEAR,
      RowDataPropertiesType.TYPE,
      RowDataPropertiesType.EMPLOYER
    ];
    if (this.isDesktop) {
      fields.push(RowDataPropertiesType.AMOUNT);
    }
    for (const field of fields) {
      this.columns.push({
        label: this.languageService.get(`myadp-pay.TAX_STATEMENTS_MODAL_COLUMN_${field}`),
        sort: true,
        id: `${field}`,
        propertySelector: `${field}`
      });
    }
    this.columns.push({
      label: '',
      sort: false,
      id: RowDataPropertiesType.DOWNLOAD,
      propertySelector: RowDataPropertiesType.DOWNLOAD,
      renderer: TaxStatementsDownloadButtonRendererComponent
    });
  }

  public performSort(sort: VanTableSort) {
    const sortedData: GridData<RowDataProperties> = this.dataGridStatements.slice(0);
    let selectedCol: VanTableColumn<string> | undefined;
    this.columns.forEach((column: VanTableColumn<string>) => {
      if (column.id === sort.columnId) {
        selectedCol = column;
      }
    });
    if (selectedCol) {
      if (selectedCol.propertySelector) {
        const propertySelector: string = selectedCol.propertySelector;
        sortedData.sort((a: GridRow<string>, b: GridRow<string>) => {
          if (a[propertySelector] < b[propertySelector]) {
            return sort.direction === 'DESC' ? 1 : -1;
          }
          if (a[propertySelector] > b[propertySelector]) {
            return sort.direction === 'DESC' ? -1 : 1;
          }
          return 0;
        });
        this.dataGridStatements = sortedData.slice(0);
      }
    }
    this.formatDataGridStatements();
  }

  public setShowTaxStatementsModal(show: boolean): void {
    this.showTaxStatementsModal = show;
  }

  private formatDataGridStatements() {
    this.formattedDataGridStatements = [];
    this.dataGridStatements.forEach((rowData: any) => {
      const data = {
        [RowDataPropertiesType.YEAR]:
          rowData[RowDataPropertiesType.YEAR] === '0'
            ? this.languageService.get('common.OTHER')
            : rowData[RowDataPropertiesType.YEAR],
        [RowDataPropertiesType.TYPE]: rowData[RowDataPropertiesType.TYPE],
        [RowDataPropertiesType.EMPLOYER]: rowData[RowDataPropertiesType.EMPLOYER],
        [RowDataPropertiesType.AMOUNT]:
          this.valueFormatterService.format(
            {
              amountValue: rowData[RowDataPropertiesType.AMOUNT],
              currencyCode: rowData[RowDataPropertiesType.CURRENCY]
            },
            ValueFormatterType.Currency
          ) || '--',
        [RowDataPropertiesType.CURRENCY]: rowData[RowDataPropertiesType.CURRENCY],
        [RowDataPropertiesType.DOWNLOAD]: rowData[RowDataPropertiesType.DOWNLOAD]
      };
      if (!this.isDesktop) {
        delete data[RowDataPropertiesType.AMOUNT];
      }
      this.formattedDataGridStatements.push(data);
    });
  }
}
