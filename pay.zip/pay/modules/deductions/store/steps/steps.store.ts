import { Injectable, ViewContainerRef } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { distinctUntilChanged, map } from 'rxjs/operators';

import { BaseStore, StoreState } from '@myadp/pay-shared';

import {
  ProgressProperties,
  STEPS,
  StepStateProps
} from '../../models/steps-navigation-helper.model';
import { PrevNext } from './steps-store.actions';

export { StepsStoreActions } from './steps-store.actions';

export interface StepsStoreState {
  steps?: StepsState;
}

export interface StepsState extends StepStateProps {
  step: {
    current?: number;
    outOf?: number;
    name?: string;
  };
}

@Injectable({
  providedIn: 'root'
})
export class StepsStore extends BaseStore<StepsStoreState> {
  public stepContainer: ViewContainerRef;
  public isSlideinOpen$: BehaviorSubject<boolean>;

  constructor() {
    super({
      steps: {
        data: null
      }
    });

    this.isSlideinOpen$ = new BehaviorSubject(false);
  }

  public get stepsStore$(): Observable<StepsState> {
    return this.getData$('steps', undefined, null);
  }

  public get stepsStoreData(): StepsState {
    return this.getData('steps');
  }

  public get showStepNavigation$(): Observable<boolean> {
    return this.state$.pipe(
      map((state: StoreState<StepsStoreState>) => {
        const store = state['steps']?.data;
        return !(store?.hideNavigation || store?.isLastStep);
      }),
      distinctUntilChanged()
    );
  }

  public get stepName$(): Observable<string> {
    return this.state$.pipe(
      map((state) => {
        const name = state['steps']?.data?.step?.name;

        return name === STEPS.DEDUCTION_DETAILS && this.isEditing
          ? 'myadp-pay.DEDUCTIONS_STEP_TITLE_EDIT_DEDUCTION'
          : `myadp-pay.DEDUCTIONS_STEP_TITLE_${name}`;
      }),
      distinctUntilChanged()
    );
  }

  public getPrevOrNextProperties$(dir: PrevNext): Observable<ProgressProperties> {
    return this.getData$('steps', dir, { disabled: false, hidden: false });
  }

  public get isSubmitStep$(): Observable<boolean> {
    return this.getData$('steps', 'isSubmitStep');
  }

  public get isEditing(): boolean {
    return this.getData('steps', 'isEditing', false);
  }

  public get isSlideinOpenObs$(): Observable<boolean> {
    return this.isSlideinOpen$.asObservable().pipe(distinctUntilChanged());
  }

  public get currentStepName(): string {
    return this.getData('steps', 'step')?.name;
  }
}
