import { AfterViewInit, Component, ViewChild, Input, OnInit, Optional } from '@angular/core';
import { TileService } from '@synerg/components/tile';

import { QueryParamsService } from '@myadp/common';
import { PAY_DEEP_LINKS } from '@myadp/pay-shared';
import { PageType } from '@myadp/pay-paperless-shared';
import { PaperlessViewWrapperComponent } from '../paperless-view-wrapper/paperless-view-wrapper.component';

@Component({
  selector: 'go-paperless-tile',
  templateUrl: './paperless-tile.component.html',
  styleUrls: ['./paperless-tile.component.scss']
})
export class PaperlessTileComponent implements AfterViewInit, OnInit {
  @Input() public pageType: PageType;
  @ViewChild('paperlessViewWrapper') public paperlessViewWrapper: PaperlessViewWrapperComponent;

  constructor(
    private queryParamsService: QueryParamsService,
    @Optional() private tileService: TileService
  ) {}

  ngOnInit() {
    this.tileService?.setIsLoading(false);
  }

  ngAfterViewInit() {
    this.autoOpenModalCheck();
  }

  public openSettings(): void {
    this.paperlessViewWrapper.setDisplaySettingsModal(true);
  }

  public autoOpenModalCheck(): void {
    const openVal = this.queryParamsService.getParameterValue('open');
    if (openVal === PAY_DEEP_LINKS.GoPaperless) {
      this.paperlessViewWrapper.setDisplaySettingsModal(true);
    }
  }
}
