import { Injectable } from '@angular/core';
import { get } from 'lodash';
import {
  MessageCenterNotificationDto,
  Notification,
  NOTIFICATION_CODE_TYPES,
  NotificationCodeType
} from '@myadp/thingstodo-shared';
import { DirectDepositTasksDetails } from '@myadp/dto';

import { DirectDepositDetails } from '../models/direct-deposit-details';
import { PayTasksService } from '../../shared/services/pay-tasks.service';

@Injectable({
  providedIn: 'root'
})
export class DirectDepositTaskService {
  constructor(private payTasksService: PayTasksService) {}

  public getDirectDepositDetails(task: Notification): Promise<DirectDepositDetails> {
    if (task.notificationType.code  === NOTIFICATION_CODE_TYPES.TASK) {
      return this.getDirectDepositTaskDetails(task);
    } else {
      return this.getDirectDepositNotificationDetails(task);
    }
  }

  private async getDirectDepositTaskDetails(task: Notification): Promise<DirectDepositDetails> {
    const taskData = await this.payTasksService.getTaskData(task.uri);
    const directDepositTasks = <DirectDepositTasksDetails>(
      await this.payTasksService.getTaskDetail(this.formatTaskUrl(taskData.notification))
    );
    return this.processDirectDepositTasks(directDepositTasks, NOTIFICATION_CODE_TYPES.TASK);
  }

  private async getDirectDepositNotificationDetails(task: Notification): Promise<DirectDepositDetails> {
    const directDepositTasks = <DirectDepositTasksDetails>(
      await this.payTasksService.getTaskDetail(this.formatNotificationUrl(task))
    );
    return this.processDirectDepositTasks(directDepositTasks, NOTIFICATION_CODE_TYPES.NOTIFICATION);
  }

  private processDirectDepositTasks(
    directDepositTasks: DirectDepositTasksDetails,
    notificationCodeType: NotificationCodeType
  ): DirectDepositDetails {
    return new DirectDepositDetails(directDepositTasks, notificationCodeType);
  }

  private formatTaskUrl(task: MessageCenterNotificationDto): string {
    const aoid = get<string>(task, 'relatedAssociateRef.associateOID');
    return `/wf/payroll/v2/workers/${aoid}/pay-distributions?taskId=${this.payTasksService.getTaskId(
      task
    )}`;
  }

  private formatNotificationUrl(task: Notification): string {
    const aoid = task.relatedAssociateRef.aoid;
    return `/wf/payroll/v2/workers/${aoid}/pay-distributions?notificationId=${task.notificationId}`;
  }
}
