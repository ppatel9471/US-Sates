export type CustomElementsTags = 'pwc-pcc-tile-mfe';

export const RegistryModel: Record<string, CustomElementsTags> = {
  PCC_TILE: 'pwc-pcc-tile-mfe'
};
