import { Component, OnInit } from '@angular/core';

import { PaperlessStoreActions, PageType } from '@myadp/pay-paperless-shared';

@Component({
  selector: 'paperless-tile-wrapper',
  template: `<go-paperless-tile [pageType]="pageType.PAY"></go-paperless-tile>`
})
export class PaperlessTileWrapperComponent implements OnInit {
  public pageType = PageType;

  constructor(private paperlessStoreActions: PaperlessStoreActions) {}

  public ngOnInit(): void {
    this.paperlessStoreActions.getPayPreferences();
  }
}
