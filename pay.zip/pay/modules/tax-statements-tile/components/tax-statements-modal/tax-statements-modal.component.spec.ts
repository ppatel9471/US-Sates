import { CurrencyPipe } from '@angular/common';
import { GridData, VanTableSort } from '@synerg/components/datagrid';
import { BreakpointMatches, BreakpointService } from '@synerg/components/shared';
import { of } from 'rxjs';
import { Shallow } from 'shallow-render';

import { LanguagePipe, LanguageService } from '@myadp/common';

import { ValueFormatterService } from '../../../shared/services/value-formatter.service';
import { RowDataProperties, RowDataPropertiesType } from '../../models/tax-statements-modal.model';
import { TaxStatementsStore } from '../../store/tax-statements.store';
import { TaxStatementsTileModule } from '../../tax-statements-tile.module';
import { TaxStatementsModalComponent } from './tax-statements-modal.component';

describe('TaxStatementsModalComponent', () => {
  let shallow: Shallow<TaxStatementsModalComponent>;
  const mockGridData: GridData<RowDataProperties> = [
    {
      YEAR: '2018',
      EMPLOYER: 'AUTOMATIC DATA PROCESSING',
      TYPE: 'W2',
      AMOUNT: 115000.56,
      CURRENCY: 'USD',
      DOWNLOAD: 'mockPDF.pdf'
    },
    {
      YEAR: '2019',
      EMPLOYER: 'AUTOMATIC DATA PROCESSING',
      TYPE: 'W2',
      AMOUNT: 126721.14,
      CURRENCY: 'USD',
      DOWNLOAD: 'mockPDF.pdf'
    },
    {
      YEAR: '2019',
      EMPLOYER: 'AUTOMATIC DATA PROCESSING',
      TYPE: 'W2',
      AMOUNT: 62672.14,
      CURRENCY: 'USD',
      DOWNLOAD: 'mockPDF.pdf'
    },
    {
      YEAR: '2018',
      EMPLOYER: 'AUTOMATIC DATA PROCESSING',
      TYPE: '1099-MISC',
      AMOUNT: null,
      CURRENCY: '',
      DOWNLOAD: 'mockPDF.pdf'
    }
  ];
  const mockSortedGridData: GridData<RowDataProperties> = [
    {
      YEAR: '2018',
      EMPLOYER: 'AUTOMATIC DATA PROCESSING',
      TYPE: '1099-MISC',
      AMOUNT: '--',
      CURRENCY: '',
      DOWNLOAD: 'mockPDF.pdf'
    },
    {
      YEAR: '2019',
      EMPLOYER: 'AUTOMATIC DATA PROCESSING',
      TYPE: 'W2',
      AMOUNT: '$62,672.14',
      CURRENCY: 'USD',
      DOWNLOAD: 'mockPDF.pdf'
    },
    {
      YEAR: '2018',
      EMPLOYER: 'AUTOMATIC DATA PROCESSING',
      TYPE: 'W2',
      AMOUNT: '$115,000.56',
      CURRENCY: 'USD',
      DOWNLOAD: 'mockPDF.pdf'
    },
    {
      YEAR: '2019',
      EMPLOYER: 'AUTOMATIC DATA PROCESSING',
      TYPE: 'W2',
      AMOUNT: '$126,721.14',
      CURRENCY: 'USD',
      DOWNLOAD: 'mockPDF.pdf'
    }
  ];
  const mockSorting: VanTableSort = {
    columnId: 'AMOUNT',
    direction: 'ASC'
  };

  const breakpoints: BreakpointMatches = {
    xs: false,
    sm: false,
    md: false,
    lg: false,
    xl: true,
    xxl: false
  };

  beforeEach(() => {
    shallow = new Shallow(TaxStatementsModalComponent, TaxStatementsTileModule)
      .provide(LanguageService, CurrencyPipe, ValueFormatterService)
      .mock(TaxStatementsStore, {
        statementsByYear$: () => of(null),
        dataGridStatements: () => mockGridData
      })
      .mock(LanguageService, { get: (key: string) => key })
      .mock(BreakpointService, {
        matches$: of(breakpoints)
      })
      .mockPipe(LanguagePipe, (key) => key)
      .dontMock(CurrencyPipe, ValueFormatterService);
  });

  describe('perform sort', () => {
    it('should perform sort by amount in ASC order', async () => {
      const { instance } = await shallow.render();
      instance.performSort(mockSorting);
      expect(instance.formattedDataGridStatements).toEqual(mockSortedGridData);
    });
  });

  describe('remove amount', () => {
    it('should not remove amount when it is desktop', async () => {
      const { instance } = await shallow.render();

      expect(
        Object.keys(instance.formattedDataGridStatements[0]).includes(RowDataPropertiesType.AMOUNT)
      ).toBeTruthy();
    });
  });

  it('should remove amount when it is not desktop', async () => {
    breakpoints.xs = true;
    breakpoints.xl = false;
    const { instance } = await shallow.render();
    expect(
      Object.keys(instance.formattedDataGridStatements[0]).includes(RowDataPropertiesType.AMOUNT)
    ).toBeFalsy();
  });
});
