import { CurrencyPipe } from '@angular/common';
import { TestBed } from '@angular/core/testing';
import { Mock } from 'ts-mockery';

import { LanguageService } from '@myadp/common';
import { MOCK_WORKFLOW_DEDUCTIONS } from '@specHelpers/pay/pay-deductions/pay-deductions';

import { DeductionsComparisonService } from './deductions-comparison.service';
import { WorkflowComparisonService } from './workflow-comparison.service';

describe('DeductionsComparisonService', () => {
  let service: DeductionsComparisonService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        DeductionsComparisonService,
        WorkflowComparisonService,
        CurrencyPipe,
        {
          provide: LanguageService,
          useValue: Mock.of<LanguageService>({ get: (key) => key })
        }
      ]
    });
    service = TestBed.inject(DeductionsComparisonService);
  });

  it('should get comparison data for a pending new deduction', () => {
    const [current, pending] = service.getComparisonData(MOCK_WORKFLOW_DEDUCTIONS[1]);

    expect(current).toEqual({
      addOrDeleteMsg: 'myadp-pay.DEDUCTIONS_WORKFLOW_COMPARISON_PENDING_ADD'
    });
    expect(pending).toEqual({
      ...MOCK_WORKFLOW_DEDUCTIONS[1].pendingData,
      displayAmount: '10%',
      goalDisplayAmount: '$0.00'
    });
  });

  describe('comparison data for a pending deduction edit', () => {
    it('should show deduction amount in pending column', () => {
      const [current, pending] = service.getComparisonData(MOCK_WORKFLOW_DEDUCTIONS[2]);

      expect(current).toEqual({
        ...MOCK_WORKFLOW_DEDUCTIONS[2].currentData,
        displayAmount: '$15.00',
        goalDisplayAmount: '$100.00'
      });
      expect(pending).toEqual({
        deductionRate: MOCK_WORKFLOW_DEDUCTIONS[2].pendingData.deductionRate,
        displayAmount: '$30.00',
        goalDisplayAmount: null
      });
    });

    it('should show goal amount in pending column', () => {
      const [current, pending] = service.getComparisonData(MOCK_WORKFLOW_DEDUCTIONS[6]);

      expect(current).toEqual({
        ...MOCK_WORKFLOW_DEDUCTIONS[6].currentData,
        displayAmount: '$15.00',
        goalDisplayAmount: '$20.00'
      });
      expect(pending).toEqual({
        deductionGoal: MOCK_WORKFLOW_DEDUCTIONS[6].pendingData.deductionGoal,
        displayAmount: null,
        goalDisplayAmount: '$200.00'
      });
    });

    it('should show deduction amount in pending column when changed deduction rate to null', () => {
      const [current, pending] = service.getComparisonData(MOCK_WORKFLOW_DEDUCTIONS[7]);

      expect(current).toEqual({
        ...MOCK_WORKFLOW_DEDUCTIONS[7].currentData,
        displayAmount: '$15.00',
        goalDisplayAmount: '$20.00'
      });
      expect(pending).toEqual({
        deductionRate: MOCK_WORKFLOW_DEDUCTIONS[7].pendingData.deductionRate,
        displayAmount: '$0.00',
        goalDisplayAmount: null
      });
    });

    it('should show goal amount in pending column when changed goal limit to null', () => {
      const [current, pending] = service.getComparisonData(MOCK_WORKFLOW_DEDUCTIONS[8]);

      expect(current).toEqual({
        ...MOCK_WORKFLOW_DEDUCTIONS[8].currentData,
        displayAmount: '$15.00',
        goalDisplayAmount: '$200.00'
      });
      expect(pending).toEqual({
        deductionGoal: MOCK_WORKFLOW_DEDUCTIONS[8].pendingData.deductionGoal,
        displayAmount: null,
        goalDisplayAmount: '$0.00'
      });
    });

    it('should show deduction amount in pending column when changed deduction rate from 0 to null ', async () => {
      const [current, pending] = service.getComparisonData(MOCK_WORKFLOW_DEDUCTIONS[4]);

      expect(current).toEqual({
        ...MOCK_WORKFLOW_DEDUCTIONS[4].currentData,
        displayAmount: '$0.00',
        goalDisplayAmount: '$0.00'
      });

      expect(pending).toEqual({
        deductionRate: MOCK_WORKFLOW_DEDUCTIONS[4].pendingData.deductionRate,
        displayAmount: '$0.00',
        goalDisplayAmount: null
      });
    });

    it('should show goal amount in pending column when changed goal limit from 0 to null', async () => {
      const [current, pending] = service.getComparisonData(MOCK_WORKFLOW_DEDUCTIONS[5]);

      expect(current).toEqual({
        ...MOCK_WORKFLOW_DEDUCTIONS[5].currentData,
        displayAmount: '$15.00',
        goalDisplayAmount: '$0.00'
      });

      expect(pending).toEqual({
        deductionGoal: MOCK_WORKFLOW_DEDUCTIONS[5].pendingData.deductionGoal,
        displayAmount: null,
        goalDisplayAmount: '$0.00'
      });
    });
  });

  it('should get comparison data for a pending deduction deletion', () => {
    const [current, pending] = service.getComparisonData(MOCK_WORKFLOW_DEDUCTIONS[3]);

    expect(current).toEqual({
      ...MOCK_WORKFLOW_DEDUCTIONS[3].currentData,
      displayAmount: '$0.00',
      goalDisplayAmount: '$0.00'
    });
    expect(pending).toEqual({
      addOrDeleteMsg: 'myadp-pay.DEDUCTIONS_WORKFLOW_COMPARISON_PENDING_DELETE'
    });
  });
});
