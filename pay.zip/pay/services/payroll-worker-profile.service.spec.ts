import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { fakeAsync, TestBed } from '@angular/core/testing';
import { tap } from 'rxjs/operators';
import { Mock } from 'ts-mockery';

import {
  ROLE,
  UserIdentityService,
  UserProfileService,
  WorkerLiteService,
  WorkerService
} from '@myadp/common';
import { Worker } from '@myadp/dto';
import { CodeListItem } from '@myadp/dto/common/code-list-item';

import { WorkerInfoStoreSlice } from '../modules/worker-info-shared/models/worker-info-state.model';
import { PayrollWorkerProfileService } from './payroll-worker-profile.service';

describe('PayrollWorkerProfileService', () => {
  let service: PayrollWorkerProfileService;
  let httpMock: HttpTestingController;

  const mockSsn = '123456789';
  const mockWorker: Worker = {
    associateOID: 'MockAOID',
    person: {
      governmentIDs: [
        {
          itemID: 'SSN',
          nameCode: <CodeListItem>{},
          idValue: mockSsn
        }
      ]
    }
  };

  let workerService: WorkerService;
  let workerLiteService: WorkerLiteService;
  let userProfileService: UserProfileService;

  const mockURI = 'wf/worker';
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        PayrollWorkerProfileService,
        {
          provide: UserProfileService,
          useValue: Mock.of<UserProfileService>({
            hasWorkerProfile: () => true,
            getLinkHref: () => mockURI,
            isRun: () => false
          })
        },
        {
          provide: UserIdentityService,
          useValue: Mock.of<UserIdentityService>({
            getAoid: () => Promise.resolve<string>('MockAOID')
          })
        },
        {
          provide: WorkerService,
          useValue: Mock.of<WorkerService>({
            getWfWorker: () => Promise.resolve({ current: mockWorker }),
            getWorker: () => Promise.resolve(mockWorker)
          })
        },
        {
          provide: WorkerLiteService,
          useValue: Mock.of<WorkerLiteService>({
            getWorkerLite: () => Promise.resolve(mockWorker)
          })
        }
      ]
    });

    service = TestBed.inject(PayrollWorkerProfileService);
    httpMock = TestBed.inject(HttpTestingController);
    workerService = TestBed.inject(WorkerService);
    workerLiteService = TestBed.inject(WorkerLiteService);
    userProfileService = TestBed.inject(UserProfileService);
  });
  it('should call worker profile service if user has permission', () => {
    service.getWorker().then((res) => {
      expect(workerService.getWfWorker).toHaveBeenCalled();
      expect(res).toEqual(mockWorker);
    });
  });

  it('should call payroll worker profile if user has no worker permission', () => {
    Mock.extend(userProfileService).with({
      hasWorkerProfile: () => false
    });
    service.getWorker().then((res) => {
      expect(workerService.getWfWorker).not.toHaveBeenCalled();
      expect(res).toEqual(mockWorker);
    });
    httpMock.expectOne(mockURI).flush({ workerProfiles: [mockWorker] });
  });

  describe('getPayrollWorkerProfile', () => {
    it('should not make payroll worker call if href is undefined', async () => {
      Mock.extend(userProfileService).with({
        getLinkHref: () => undefined
      });

      service.getPayrollWorkerProfile('baz').catch((worker) => {
        expect(worker).toBeNull();
      });
    });
  });

  describe('unmask SSN', () => {
    it('should provide an unmasked ssn, call worker profile service if user has worker profile, not RUN user', () => {
      Mock.extend(userProfileService).with({
        hasWorkerProfile: () => true,
        isRun: () => false
      });
      service.getUnmaskedDataFromWorker$(WorkerInfoStoreSlice.WORKER_SSN).pipe(
        tap((worker) => {
          expect(workerLiteService.getWorkerLite).toHaveBeenCalledWith(
            mockWorker.associateOID,
            'workers/person/governmentIDs',
            { masked: false, roleCode: ROLE.EMPLOYEE }
          );
          expect(worker).toEqual(mockWorker);
        })
      );
    });

    it('should provide an unmasked ssn, call worker profile service if user has worker profile, RUN user', () => {
      Mock.extend(userProfileService).with({
        hasWorkerProfile: () => true,
        isRun: () => true
      });
      service.getUnmaskedDataFromWorker$(WorkerInfoStoreSlice.WORKER_SSN).pipe(
        tap((worker) => {
          expect(workerLiteService.getWorkerLite).toHaveBeenCalledWith(
            mockWorker.associateOID,
            'person',
            { masked: false, roleCode: ROLE.EMPLOYEE }
          );
          expect(worker).toEqual(mockWorker);
        })
      );
    });

    it('should provide an unmasked ssn, call payroll worker profile service if user has no worker profile', () => {
      Mock.extend(userProfileService).with({
        hasWorkerProfile: () => false
      });
      service.getUnmaskedDataFromWorker$(WorkerInfoStoreSlice.WORKER_SSN).pipe(
        tap((worker) => {
          expect(workerLiteService.getWorkerLite).not.toHaveBeenCalled();
          expect(service.getPayrollWorkerProfile).toHaveBeenCalled();
          expect(worker).toEqual(mockWorker);
        })
      );
      httpMock
        .expectOne(`${mockURI}?$select=person/governmentIDs`)
        .flush({ workerProfiles: [mockWorker] });
    });
  });

  describe('getWorkerDatesFromWorker()', () => {
    it('should get worker dates from worker profile service if user has worker profile, not RUN user', fakeAsync(async () => {
      Mock.extend(userProfileService).with({
        hasWorkerProfile: () => true,
        isRun: () => false
      });

      const worker = await service.getWorkerDatesFromWorker();
      expect(worker).toEqual(mockWorker);
      expect(workerService.getWorker).toHaveBeenCalledWith(mockWorker.associateOID, false);
    }));

    it('should get worker dates from worker profile service if user has worker profile and is a RUN user', fakeAsync(async () => {
      Mock.extend(userProfileService).with({
        hasWorkerProfile: () => true,
        isRun: () => true
      });

      const worker = await service.getWorkerDatesFromWorker();
      expect(worker).toEqual(mockWorker);
      expect(workerService.getWorker).toHaveBeenCalledWith(mockWorker.associateOID, false);
    }));

    xit('should get worker dates from payroll worker profile service if user has no worker profile', () => {
      Mock.extend(userProfileService).with({
        hasWorkerProfile: () => false,
        isRun: () => false
      });

      service.getWorkerDatesFromWorker().then((worker: Worker) => {
        expect(workerLiteService.getWorkerLite).not.toHaveBeenCalled();
        expect(service.getPayrollWorkerProfile).toHaveBeenCalled();
        expect(worker).toEqual(mockWorker);
      });

      httpMock.expectOne(`${mockURI}?$select=workerDates`).flush({ workerProfiles: [mockWorker] });
    });

    it('should not request for masked data when getting worker dates from payroll worker profile service', fakeAsync(() => {
      Mock.extend(userProfileService).with({
        hasWorkerProfile: () => false,
        isRun: () => false
      });

      service.getWorkerDatesFromWorker();
      httpMock.expectOne(r => r.headers.get('Accept') === 'application/json').flush({ workerProfiles: [mockWorker] });
      httpMock.verify();
    }));
  });

  describe('getWorkAssignmentsFromWorker()', () => {
    it('should get worker assignments from worker profile service if user has worker profile, not RUN user', fakeAsync(async () => {
      Mock.extend(userProfileService).with({
        hasWorkerProfile: () => true,
        isRun: () => false
      });

      const worker = await service.getWorkAssignmentsFromWorker();
      expect(worker).toEqual(mockWorker);
      expect(workerService.getWorker).toHaveBeenCalledWith(mockWorker.associateOID, false);
    }));

    it('should get worker assignments from worker profile service if user has worker profile and is a RUN user', fakeAsync(async () => {
      Mock.extend(userProfileService).with({
        hasWorkerProfile: () => true,
        isRun: () => true
      });

      const worker = await service.getWorkAssignmentsFromWorker();
      expect(worker).toEqual(mockWorker);
      expect(workerService.getWorker).toHaveBeenCalledWith(mockWorker.associateOID, false);
    }));

    xit('should get worker assignments from payroll worker profile service if user has no worker profile', () => {
      Mock.extend(userProfileService).with({
        hasWorkerProfile: () => false,
        isRun: () => false
      });

      service.getWorkAssignmentsFromWorker().then((worker: Worker) => {
        expect(workerLiteService.getWorkerLite).not.toHaveBeenCalled();
        expect(service.getPayrollWorkerProfile).toHaveBeenCalled();
        expect(worker).toEqual(mockWorker);
      });

      httpMock
        .expectOne(`${mockURI}`)
        .flush({ workerProfiles: [mockWorker] });
    });
  });

  describe('getWorkedInState', () => {
    it('should return codeValue from state from regular worker', () => {
      const assignedWorkLocation = {
        assignedWorkLocations: [
          {
            address: {
              countrySubdivisionLevel1: {
                codeValue: 'GA',
                longName: 'Georgia'
              }
            }
          }
        ]
      };
      Mock.extend(workerService).with({
        getWorker: () =>
          Promise.resolve({
            workAssignments: [assignedWorkLocation]
          })
      });
      service.getWorkedInState().then((state) => {
        expect(state).toBe('GA');
      });
    });

    it('should return longName from state from regular worker', () => {
      const assignedWorkLocation = {
        assignedWorkLocations: [
          {
            address: {
              countrySubdivisionLevel1: {
                longName: 'Georgia'
              }
            }
          }
        ]
      };
      Mock.extend(workerService).with({
        getWorker: () =>
          Promise.resolve({
            workAssignments: [assignedWorkLocation]
          })
      });
      service.getWorkedInState().then((state) => {
        expect(state).toBe('Georgia');
      });
    });

    it('should return codeValue from state from payroll worker', () => {
      const assignedWorkLocation = {
        assignedWorkLocations: [
          {
            address: {
              countrySubdivisionLevel1: {
                codeValue: 'GA',
                longName: 'Georgia'
              }
            }
          }
        ]
      };
      Mock.extend(workerService).with({
        getWorker: () =>
          Promise.resolve({
            workAssignments: [assignedWorkLocation]
          })
      });
      service.getWorkedInState().then((state) => {
        expect(state).toBe('GA');
      });
    });

    it('should return longName from state from payroll worker', () => {
      const assignedWorkLocation = {
        assignedWorkLocations: [
          {
            address: {
              countrySubdivisionLevel1: {
                longName: 'Georgia'
              }
            }
          }
        ]
      };
      Mock.extend(workerService).with({
        getWorker: () =>
          Promise.resolve({
            workAssignments: [assignedWorkLocation]
          })
      });
      service.getWorkedInState().then((state) => {
        expect(state).toBe('Georgia');
      });
    });
  });

  describe('unmask birthDate', () => {
    it('should provide an unmasked birthDate, call worker profile service if user has worker profile, not RUN user', () => {
      Mock.extend(userProfileService).with({
        hasWorkerProfile: () => true,
        isRun: () => false
      });
      service.getUnmaskedDataFromWorker$(WorkerInfoStoreSlice.WORKER_BIRTHDATE).pipe(
        tap((worker) => {
          expect(workerLiteService.getWorkerLite).toHaveBeenCalledWith(
            mockWorker.associateOID,
            'workers/person/birthDate',
            { masked: false, roleCode: ROLE.EMPLOYEE }
          );
          expect(worker).toEqual(mockWorker);
        })
      );
    });

    it('should provide an unmasked birthDate, call worker profile service if user has worker profile, RUN user', () => {
      Mock.extend(userProfileService).with({
        hasWorkerProfile: () => true,
        isRun: () => true
      });
      service.getUnmaskedDataFromWorker$(WorkerInfoStoreSlice.WORKER_BIRTHDATE).pipe(
        tap((worker) => {
          expect(workerLiteService.getWorkerLite).toHaveBeenCalledWith(
            mockWorker.associateOID,
            'person',
            { masked: false, roleCode: ROLE.EMPLOYEE }
          );
          expect(worker).toEqual(mockWorker);
        })
      );
    });

    it('should provide an unmasked birthDate, call payroll worker profile service if user has no worker profile', () => {
      Mock.extend(userProfileService).with({
        hasWorkerProfile: () => false
      });
      service.getUnmaskedDataFromWorker$(WorkerInfoStoreSlice.WORKER_BIRTHDATE).pipe(
        tap((worker) => {
          expect(workerLiteService.getWorkerLite).not.toHaveBeenCalled();
          expect(service.getPayrollWorkerProfile).toHaveBeenCalled();
          expect(worker).toEqual(mockWorker);
        })
      );
      httpMock
        .expectOne(`${mockURI}?$select=person/birthDate`)
        .flush({ workerProfiles: [mockWorker] });
    });

    it('should request for masked data when calling getUnmaskedDataFromWorker', fakeAsync(() => {
      Mock.extend(userProfileService).with({
        hasWorkerProfile: () => false
      });

      service.getUnmaskedDataFromWorker$(WorkerInfoStoreSlice.WORKER_BIRTHDATE);
      httpMock.expectOne(r => r.headers.get('Accept') === 'application/json; masked=false').flush({ workerProfiles: [mockWorker] });
      httpMock.verify();
    }));
  });
});
