import { ComponentFactoryResolver, Injectable, ViewContainerRef } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Observable } from 'rxjs';
import { distinctUntilChanged, take } from 'rxjs/operators';

import { Worker } from '@myadp/dto';

import { PayDistributionStore } from '../../../pay-distributions-shared/store/pay-distribution.store';
import { WorkerInfoStoreActions } from '../../../worker-info-shared/store/worker-info-store.actions';
import { WorkerInfoStore } from '../../../worker-info-shared/store/worker-info.store';
import { DirectDepositAccount } from '../../models/direct-deposit-account.model';
import { FormDetails } from '../../models/form-details.model';
import { StepNavigationActions, STEPS } from '../../models/steps-navigation-helper.model';
import { DirectDepositStore, DirectDepositStoreActions } from '../direct-deposit.store';
import {
  navigationFlowStartingFromList,
  StepNavigation
} from './steps-navigation-utilities/steps-navigation-helper';
import { StepsStore, StepsStoreSlice } from './steps.store';

import { COUNTRY } from '../../../pay-distributions-shared/models/country';

export type PrevNext = 'prev' | 'next' | 'cancel';

@Injectable({
  providedIn: 'root'
})
export class StepsStoreActions {
  public payDistributions$: Observable<DirectDepositAccount[]>;
  public hasChangePermission$: Observable<boolean>;
  public hasExistingAccounts: boolean;
  public hasExistingWisely: boolean;
  public accountTypeComponents: object = {};
  public stepContainer: ViewContainerRef;

  public rootStep: StepNavigation;
  public currentStep: StepNavigation;
  public directDepositFormGroup: FormGroup;
  private excludedFormProps: string[] = null;

  constructor(
    private stepsStore: StepsStore,
    private resolver: ComponentFactoryResolver,
    private payDistributionStore: PayDistributionStore,
    private directDepositStore: DirectDepositStore,
    private workerInfoStore: WorkerInfoStore,
    private directDepositStoreActions: DirectDepositStoreActions,
    private workerInfoStoreActions: WorkerInfoStoreActions
  ) {
    this.payDistributions$ = this.payDistributionStore.payDistributions$;
    this.hasChangePermission$ = this.payDistributionStore.hasChangePermission$;
  }

  public init(stepContainer: ViewContainerRef): void {
    this.workerInfoStoreActions.getWorker();
    this.stepContainer = stepContainer;
    this.hasExistingAccounts = this.payDistributionStore.hasPayDistributions;

    this.rootStep = navigationFlowStartingFromList;
    this.currentStep = navigationFlowStartingFromList;

    if (this.hasExistingAccounts) {
      this.loadAccountListScreen();
    } else {
      this.loadAccountTypeStep();
    }
  }

  public checkExistingAccounts(): boolean {
    this.hasExistingAccounts =
      this.payDistributionStore.hasPayDistributions ||
      this.directDepositStore.getDDAccountsSnapshot()?.length > 0;

    return !!this.hasExistingAccounts;
  }

  public async getWorker(): Promise<Worker> {
    return await this.workerInfoStore.worker$().pipe(take(1)).toPromise();
  }

  public renderStep(): void {
    this.stepContainer.clear();
    this.updateCurrentStepStore();

    const factory = this.resolver.resolveComponentFactory<any>(this.currentStep.component);
    const componentRef = this.stepContainer.createComponent(factory);
    componentRef.instance.step = this.currentStep.current;
  }

  public loadSteps(stepAction: StepNavigationActions, account: DirectDepositAccount = null): void {
    if (stepAction.indexOf('edit') > -1 || stepAction.indexOf('add') > -1) {
      this.directDepositStoreActions.resetFormData();
      this.loadSelectedAccountIntoStep(account);
    }

    this.nextStep(stepAction);
  }

  public loadAccountListScreen(): void {
    this.renderStep();
  }

  public loadAccountTypeStep(): void {
    this.nextStep('add');
    this.renderStep();
  }

  public resetFormData(): void {
    this.directDepositStoreActions.resetFormData();
  }

  public resetModifiedAccounts(): void {
    this.directDepositStoreActions.resetModifiedAccounts();
  }

  public loadSelectedAccountIntoStep(account: DirectDepositAccount): void {
    this.directDepositStoreActions.updateFormData(
      account?.pendingData ?? account?.currentData,
      true
    );
  }

  public cancelStep(): void {
    this.directDepositStoreActions.resetFormData();

    if (this.currentStep.name === STEPS.REVIEW) {
      this.directDepositStoreActions.revertAllChanges();
    }

    this.currentStep = this.currentStep.cancel() as StepNavigation;

    this.directDepositFormGroup = undefined;
    this.renderStep();
  }

  public prevStep(): void {
    if (this.currentStep.name !== STEPS.ACCOUNT_DETAILS) {
      this.saveStepFormData();
    } else {
      this.directDepositFormGroup = undefined;
      this.directDepositStoreActions.resetFormData();
    }

    this.currentStep = this.currentStep.prev() as StepNavigation;
    this.checkToSkipGIACTScreen(false);

    this.renderStep();
  }

  public nextStep(stepAction?: StepNavigationActions): void {
    this.saveStepFormData();
    this.currentStep = this.currentStep.next(stepAction) as StepNavigation;

    this.checkToSkipGIACTScreen();

    this.renderStep();
  }

  public resetCurrentStep() {
    this.stepsStore.update(StepsStoreSlice.STEPS, {
      data: null
    });

    this.directDepositStoreActions.resetFormData();
    this.currentStep = this.rootStep;
  }

  public disablePrev(value: boolean): void {
    this.disable('prev', value);
  }

  public disableNext(value: boolean): void {
    this.disable('next', value);
  }

  public hidePrev(value: boolean): void {
    this.hidden('prev', value);
  }

  public hideNext(value: boolean): void {
    this.hidden('next', value);
  }

  public openSlidein(): void {
    this.stepsStore.isSlideinOpen$.next(true);
  }

  public closeSlidein(): void {
    this.directDepositStoreActions.revertAllChanges();
    this.excludedFormProps = null;
    this.directDepositFormGroup = undefined;
    this.stepsStore.isSlideinOpen$.next(false);
  }

  public submit(): Promise<void> {
    return this.directDepositStoreActions.postDirectDepositAccounts();
  }

  public loadAccounts(
    { getMeta = false, getMasked = false }: { getMeta?: boolean; getMasked?: boolean } = {
      getMeta: false,
      getMasked: false
    }
  ): void {
    this.directDepositStoreActions.loadDirectDepositAccounts(getMeta, getMasked);
  }

  public cancelPendingRequest(account: DirectDepositAccount, postChanges?: boolean): void {
    this.directDepositStoreActions.recallAccount(account, postChanges);
  }

  public setFormGroup(form: FormGroup, ...excludedFormProps: string[]): void {
    this.directDepositFormGroup = form;
    this.excludedFormProps = excludedFormProps?.length ? excludedFormProps : null;

    this.directDepositFormGroup?.statusChanges
      .pipe(distinctUntilChanged())
      .subscribe((status: string) => this.disableNext(status !== 'VALID'));
  }

  public deleteAccount(id: string): void {
    this.directDepositStoreActions.deleteAccount(id);
    this.directDepositFormGroup = undefined;
    this.currentStep =
      this.currentStep.tag === 'edit-wisely'
        ? (this.currentStep.next() as StepNavigation)
        : (this.currentStep.next().next() as StepNavigation); // skips verification and moves onto review
    this.renderStep();
  }

  public hasAccountChanges(): boolean {
    if (this.currentStep?.name === STEPS.DEPOSIT_DONE) {
      return false;
    }

    return (
      this.directDepositStore.hasChanges() ||
      this.currentStep?.name === STEPS.VERIFICATION ||
      !(this.directDepositFormGroup?.pristine ?? true)
    );
  }

  public startWiselyAddFlow(formDetails: FormDetails): void {
    this.resetFormData();
    this.directDepositStoreActions.updateFormData(formDetails);
    this.nextStep('add-wisely');
  }

  public updateAccountChanges(): DirectDepositAccount[] {
    return this.directDepositStoreActions.updateAccountChanges();
  }

  private hidden(dir: PrevNext, hidden: boolean): void {
    this.stepsStore.update(StepsStoreSlice.STEPS, {
      data: {
        [dir]: {
          hidden
        }
      }
    });
  }

  private disable(dir: PrevNext, value: boolean): void {
    this.stepsStore.update(StepsStoreSlice.STEPS, {
      data: {
        [dir]: { disabled: value }
      }
    });
  }

  private checkToSkipGIACTScreen(next: boolean = true): void {
    const { cachedValidationStatus } = this.directDepositStoreActions.accountValidationDetails();

    // Skip Account Verification step if we don't have GIACT permission
    // or if account routing and account number is already in cache
    if (
      this.currentStep.name === STEPS.VERIFICATION &&
      (!this.directDepositStore.hasPermission('GIACT') ||
        cachedValidationStatus ||
        !this.directDepositStore.isFromCountry(COUNTRY.US))
    ) {
      this.directDepositStoreActions.validateAccountFormDetails();

      this.currentStep = next
        ? (this.currentStep.next() as StepNavigation)
        : (this.currentStep.prev() as StepNavigation);
    }
  }

  private updateCurrentStepStore(): void {
    const currentValue = this.stepsStore.stepsStoreData;

    const updateStoreValue = {
      ...currentValue,
      step: {
        name: this.currentStep.name,
        current: this.currentStep.current,
        outOf: this.currentStep.outOf
      },
      ...this.currentStep.stepProps
    };

    this.stepsStore.update(StepsStoreSlice.STEPS, {
      data: updateStoreValue
    });
  }

  private saveFormData(): void {
    if (this.directDepositFormGroup) {
      const ddFormGroupValue: FormDetails = Object.values(
        this.directDepositFormGroup?.value
      ).reduce(
        (formGroupValue: FormDetails, value: object) => ({ ...formGroupValue, ...value }),
        {}
      );

      const filteredFormValue: FormDetails = this.excludedFormProps
        ? Object.keys(ddFormGroupValue)?.reduce((formValue: FormDetails, key) => {
          if (!this.excludedFormProps.includes(key)) {
            formValue[key] = ddFormGroupValue[key];
          }
          return formValue;
        }, {})
        : ddFormGroupValue;
      this.directDepositStoreActions.updateFormData(filteredFormValue);
    }

    this.directDepositFormGroup = undefined;
  }

  private saveStepFormData(): void {
    this.saveFormData();
    this.excludedFormProps = null;
    this.directDepositFormGroup = undefined;
  }
}
