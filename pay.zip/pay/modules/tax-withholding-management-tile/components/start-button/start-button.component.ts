import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'start-button',
  templateUrl: './start-button.component.html',
  styleUrls: ['./start-button.component.scss']
})
export class StartButtonComponent {
  @Input() public hasEditPermission: boolean;
  @Output() public clickStartButton: EventEmitter<void> = new EventEmitter();

  public clickStart(): void {
    this.clickStartButton.emit();
  }
}
