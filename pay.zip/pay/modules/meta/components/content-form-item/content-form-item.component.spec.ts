import { Shallow } from 'shallow-render';

import { LanguagePipe } from '@myadp/common';

import { ContentFormItemComponent } from './content-form-item.component';
import { MetaModule } from '../../meta.module';
import { FormItem } from '../../models/form-item.model';

describe('ContentFormItemComponent', () => {
  let shallow: Shallow<ContentFormItemComponent>;

  beforeEach(() => {
    shallow = new Shallow(ContentFormItemComponent, MetaModule).mockPipe(
      LanguagePipe,
      key => key
    );
  });

  it('should not be in a grid', async () => {
    const formItem: FormItem = {
      id: 'mock-form-item',
      content: [
        {
          textItem: {
            key: 'textItemKey'
          }
        },
        {
          textItem: {
            key: 'textItemKey2'
          }
        }
      ]
    };
    const { find, instance } = await shallow.render(
      '<twm-content-form-item [formItem]="formItem"></twm-content-form-item>',
      { bind: { formItem } }
    );

    expect(instance.formItem).toEqual(formItem);
    expect(instance.isGrid(formItem.content[0])).toBeFalsy();
    expect(find('.vdl-row')).toHaveFound(0);
  });

  it('should be in a grid', async () => {
    const formItem: FormItem = {
      id: 'mock-form-item',
      content: [
        {
          textItem: {
            key: 'textItemKey'
          },
          linkItem: {
            key: 'linkItemKey',
            url: 'linkItemUrl',
            icon: 'linkItemIcon'
          },
          tooltipItem: {
            key: 'tooltipItemKey',
            link: {
              key: 'tooltipItemLinkKey',
              url: 'tooltipItemLinkUrl'
            }
          }
        }
      ]
    };
    const { find, instance } = await shallow.render(
      '<twm-content-form-item [formItem]="formItem"></twm-content-form-item>',
      { bind: { formItem } }
    );

    expect(instance.formItem).toEqual(formItem);
    expect(instance.isGrid(formItem.content[0])).toBeTruthy();
    expect(find('.vdl-row')).toHaveFound(1);
  });
});
