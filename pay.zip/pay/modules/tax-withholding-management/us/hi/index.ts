import { HiIntroComponent } from './steps/intro/hi-intro.component';
import { HiMaritalStatusComponent } from './steps/marital-status/hi-marital-status.component';
import { HiAllowancesComponent } from './steps/allowances/hi-allowances.component';

export { HiTWChangeEventService } from './services/hi-tw-change-event.service';
export { HiStepNavigationService } from './services/hi-step-navigation.service';
export { HiSummaryMetaDataService } from './services/hi-summary-meta-data.service';

export const HI_COMPONENTS = [
  HiIntroComponent,
  HiMaritalStatusComponent,
  HiAllowancesComponent
];

export { HISTEP_COMPONENT } from './models/steps-component.model';

export { HiAttachmentCodes } from './models/hi-tw-change-event';
