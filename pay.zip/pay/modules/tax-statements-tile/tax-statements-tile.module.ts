import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { CoreModule } from '@synerg/angular-components';
import { AlertModule } from '@synerg/components/alert';
import { BusyIndicatorModule } from '@synerg/components/busy-indicator';
import { ButtonModule } from '@synerg/components/button';
import { DatagridModule } from '@synerg/components/datagrid';
import { IconModule } from '@synerg/components/icon';
import { ListViewModule } from '@synerg/components/list-view';
import { ModalModule } from '@synerg/components/modal';
import { SelectModule } from '@synerg/components/select';
import { TileModule } from '@synerg/components/tile';

import { MyAdpCommonModule } from '@myadp/common';

import { CustomContentSharedModule } from '../custom-content-shared/custom-content-shared.module';
import { PaperlessModule } from '../paperless/paperless.module';
import { SharedModule } from '../shared/shared.module';
import { TaxStatementsBannerComponent } from './components/tax-statements-banner/tax-statements-banner.component';
import { TaxStatementsDetailComponent } from './components/tax-statements-detail/tax-statements-detail.component';
import { TaxStatementsDownloadButtonRendererComponent } from './components/tax-statements-modal/tax-statements-download-button-renderer/tax-statements-download-button-renderer.component';
import { TaxStatementsModalComponent } from './components/tax-statements-modal/tax-statements-modal.component';
import { TaxStatementsTileComponent } from './components/tax-statements-tile/tax-statements-tile.component';

@NgModule({
  imports: [
    MyAdpCommonModule,
    CommonModule,
    SharedModule,
    AlertModule,
    ButtonModule,
    IconModule,
    ListViewModule,
    ModalModule,
    DatagridModule,
    BusyIndicatorModule,
    CustomContentSharedModule,
    SelectModule,
    TileModule,
    PaperlessModule,
    CoreModule
  ],
  declarations: [
    TaxStatementsTileComponent,
    TaxStatementsModalComponent,
    TaxStatementsDetailComponent,
    TaxStatementsBannerComponent,
    TaxStatementsDownloadButtonRendererComponent
  ],
  exports: [
    TaxStatementsTileComponent,
    TaxStatementsModalComponent,
    TaxStatementsDownloadButtonRendererComponent
  ]
})
export class TaxStatementsTileModule {
  static components = {
    default: TaxStatementsTileComponent
  };
}
