import { Pipe, PipeTransform } from '@angular/core';

@Pipe({ name: 'wiselyNameDisplay', pure: true })
export class WiselyNameDisplayPipe implements PipeTransform {
  public transform(accountNameOrTypeName: string): string {
    if (!accountNameOrTypeName) {
      return '';
    }

    return accountNameOrTypeName.toLowerCase().includes('wisely')
      ? 'Wisely® by ADP'
      : accountNameOrTypeName;
  }
}
