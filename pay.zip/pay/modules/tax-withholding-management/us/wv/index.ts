import { WvIntroComponent } from './steps/intro/wv-intro.component';
import { WvAllowancesComponent } from './steps/allowances/wv-allowances.component';
import { WvWithholdLowerRateComponent } from './steps/withhold-lower-rate/wv-withhold-lower-rate.component';

export { WvTWChangeEventService } from './services/wv-tw-change-event.service';
export { WvSummaryMetaDataService } from './services/wv-summary-meta-data.service';

export const WV_COMPONENTS = [
  WvIntroComponent,
  WvAllowancesComponent,
  WvWithholdLowerRateComponent
];

export { WVSTEP_COMPONENT } from './models/steps-component.model';

export { WvAttachmentCodes } from './models/wv-tw-change-event';
