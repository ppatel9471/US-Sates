import { TestBed } from '@angular/core/testing';

import { DistributionOptions } from '../../../pay-distributions-shared/models/pay-distributions-ui';
import { DirectDepositAccount } from '../../models/direct-deposit-account.model';
import { DirectDepositStore } from '../../store/direct-deposit.store';
import { AccountDetailsSelectorPipe } from './account-details-selector.pipe';

const accounts: DirectDepositAccount[] = [
  {
    isReadOnly: false,
    isWisely: false,
    isDailyPay: false,
    currentData: {
      distributionType: DistributionOptions.PERCENTAGE,
      percentageAmount: 32,
      flatAmount: null
    },
    pendingData: {
      distributionType: DistributionOptions.PERCENTAGE,
      percentageAmount: 25,
      flatAmount: null
    },
    pendingEvent: { changeType: 'edit' }
  },
  {
    isReadOnly: false,
    isWisely: false,
    isDailyPay: false,
    currentData: {
      distributionType: DistributionOptions.REMAINING,
      percentageAmount: null,
      flatAmount: null
    },
    pendingData: null,
    pendingEvent: null
  },
  {
    isReadOnly: false,
    isWisely: false,
    isDailyPay: false,
    currentData: {
      distributionType: DistributionOptions.FLAT,
      percentageAmount: null,
      flatAmount: { amountValue: 123.12, currencyCode: 'USD' }
    },
    pendingData: null,
    pendingEvent: { changeType: 'delete' }
  },
  {
    currentData: null,
    pendingData: null,
    pendingEvent: { changeType: null }
  },
  {
    isReadOnly: true,
    isWisely: false,
    isDailyPay: true,
    currentData: {
      distributionType: DistributionOptions.PERCENTAGE,
      percentageAmount: 13,
      flatAmount: null
    },
    pendingData: null,
    pendingEvent: null
  }
];

describe('AccountDetailsSelectorPipe', () => {
  let pipe: AccountDetailsSelectorPipe;
  let directDepositStore: DirectDepositStore;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AccountDetailsSelectorPipe],
      providers: [DirectDepositStore]
    });
    directDepositStore = TestBed.get(DirectDepositStore);
    pipe = new AccountDetailsSelectorPipe(directDepositStore);
  });

  it('should transform accounts for list mode', () => {
    expect(pipe.transform(accounts)).toEqual([
      {
        ...accounts[0].pendingData,
        isReadOnly: false,
        directDepositAccount: accounts[0],
        pendingEvent: { changeType: 'edit' },
        validationStatus: null,
        isWisely: false
      },
      {
        ...accounts[1].currentData,
        isReadOnly: false,
        directDepositAccount: accounts[1],
        pendingEvent: null,
        validationStatus: null,
        isWisely: false
      },
      {
        ...accounts[2].currentData,
        isReadOnly: true,
        directDepositAccount: accounts[2],
        pendingEvent: { changeType: 'delete' },
        validationStatus: null,
        isWisely: false
      },
      {
        ...accounts[4].currentData,
        isReadOnly: true,
        directDepositAccount: accounts[4],
        pendingEvent: null,
        validationStatus: null,
        isWisely: false
      }
    ]);
  });

  it('should transform accounts for tile mode', () => {
    expect(pipe.transform(accounts, 'tile')).toEqual([
      {
        ...accounts[0].pendingData,
        isReadOnly: false,
        directDepositAccount: accounts[0],
        pendingEvent: { changeType: 'edit' },
        validationStatus: null,
        isWisely: false
      },
      {
        ...accounts[1].currentData,
        isReadOnly: false,
        directDepositAccount: accounts[1],
        pendingEvent: null,
        validationStatus: null,
        isWisely: false
      },
      {
        ...accounts[4].currentData,
        isReadOnly: true,
        directDepositAccount: accounts[4],
        pendingEvent: null,
        validationStatus: null,
        isWisely: false
      }
    ]);
  });
});
