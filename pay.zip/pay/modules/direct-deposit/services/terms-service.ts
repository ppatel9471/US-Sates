import { Injectable } from '@angular/core';
import { LanguageService } from '@myadp/common';
import { WorkerInfoStoreActions } from '../../worker-info-shared/store/worker-info-store.actions';
import { StepsStoreActions } from '../store/steps/steps.store';

@Injectable({
  providedIn: 'root'
})
export class TermsService {
  private workerName: string;
  private consentText: string;

  constructor(
    private languageService: LanguageService,
    private stepsStoreActions: StepsStoreActions,
    private workerInfoStoreActions: WorkerInfoStoreActions
  ) {}

  public get consent(): string {
    return this.consentText;
  }

  public get printedConsentText(): string {
    return this.workerName
      ? `${this.consentText} ${this.languageService.get(
        'myadp-pay.TERMS_AND_CONDITIONS_SIGNATURE',
        {
          workerName: this.workerName
        }
      )}`
      : this.consentText;
  }

  public get consentTitle(): string {
    return this.languageService.get('myadp-pay.TERMS_CONDITIONS');
  }

  public async init(hasWisely: boolean = false): Promise<void> {
    const worker = await this.stepsStoreActions.getWorker().catch(() => null);

    this.workerName = worker
      ? `${worker?.person?.legalName?.givenName} ${worker?.person?.legalName?.familyName1}`
      : null;
    const workedInState = await this.workerInfoStoreActions.getWorkedInState().catch(() => null);

    if (!worker || !workedInState) {
      this.consentText = this.languageService.get('myadp-pay.DD_TERMS_AND_CONDITIONS');
      return;
    }

    this.consentText = this.languageService.get(
      workedInState === 'NY'
        ? hasWisely
          ? 'myadp-pay.DD_TERMS_AND_CONDITIONS_NY_PAY'
          : 'myadp-pay.DD_TERMS_AND_CONDITIONS_NY'
        : 'myadp-pay.DD_TERMS_AND_CONDITIONS'
    );
  }
}
