import { Component, OnInit, Input } from '@angular/core';

import { PageType, PaperlessStoreActions } from '@myadp/pay-paperless-shared';

/**
 * This is an entry component to display Paperless toggles in an inline experience without the Paperless Tile
 */

@Component({
  selector: 'pay-paperless-view',
  template: `<paperless-view-wrapper [pageType]="pageType" [displaySettingsType]="'inline'" ></paperless-view-wrapper>`
})
export class PaperlessViewComponent implements OnInit {
  @Input() public pageType: PageType;

  constructor(private paperlessStoreActions: PaperlessStoreActions) {}

  public ngOnInit() {
    this.paperlessStoreActions.getAllPreferences();
  }
}
