import { ChangeDetectionStrategy, Component, Input } from '@angular/core';

@Component({
  selector: 'pay-text-format',
  templateUrl: './text-format.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class TextFormatComponent {
  @Input() public value: string;
}
