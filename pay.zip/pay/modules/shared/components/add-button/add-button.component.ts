import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'pay-add-button',
  templateUrl: './add-button.component.html'
})
export class AddButtonComponent {
  @Input() public text: string;
  @Input() public disableAdd: boolean = false;
  @Output() public added: EventEmitter<void> = new EventEmitter();

  public addClicked() {
    this.added.emit();
  }
}
