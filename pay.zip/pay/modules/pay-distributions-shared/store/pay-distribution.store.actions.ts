import {
  HttpClient,
  HttpErrorResponse,
  HttpHeaders,
  HttpParams,
  HttpResponse
} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { LoggerFactory } from '@espresso/core';
import * as log4javascript from 'log4javascript';

import { BaseHttpClient, MyAdpToggles, ROLE, UserIdentityService } from '@myadp/common';
import { PayDistributionsDTO } from '@myadp/dto';
import { FindSffoService, FoundPermission, PAY_SFFO } from '@myadp/pay-shared';

import { WorkerInfoStoreActions } from '../../worker-info-shared/store/worker-info-store.actions';
import { PayDistributionsStoreSlice, PayDistributionsUI } from '../models/pay-distributions-ui';
import { transformDistributionsMeta } from '../transforms/pay-distributions-meta.transform';
import { transformDistributions } from '../transforms/pay-distributions.transform';
import { PayDistributionStore } from './pay-distribution.store';
import { COUNTRY, CountryDetails, COUNTRY_CONFIG } from '../models/country';
import { countryDTOtransforms } from '../transforms/country-mappings/country-transforms';

export const CODE_LIST_URI: string =
  '/codelists/payroll/v3/payroll-instruction-management/directdepositdeductioncodevalues';

@Injectable({
  providedIn: 'root'
})
export class PayDistributionStoreActions {
  private logger: log4javascript.Logger;

  constructor(
    private httpClient: HttpClient,
    private baseHttpClient: BaseHttpClient,
    private loggerFactory: LoggerFactory,
    private findSffoService: FindSffoService,
    private workerInfoStoreActions: WorkerInfoStoreActions,
    private payDistributionStore: PayDistributionStore,
    private userIdentityService: UserIdentityService,
    private myAdpToggles: MyAdpToggles
  ) {
    this.logger = this.loggerFactory.getLogger(
      'myadp.pay.pay-distributions-shared.PayDistributionStoreActions'
    );
  }

  public loadDistributions(getPayDistributionsMeta: boolean = false, masked: boolean = true): void {
    if (getPayDistributionsMeta) {
      this.loadDistributionsMeta();
    }

    this.payDistributionStore.update(PayDistributionsStoreSlice.PAY_DISTRIBUTIONS, {
      loading: true,
      error: null
    });

    this.workerInfoStoreActions.getEffectiveDate().then((effectiveDate: string) => {
      const { sffo, href } = this.findSffoService.findSffo([
        PAY_SFFO.DIRECT_DEPOSIT_READ,
        PAY_SFFO.DIRECT_DEPOSIT_READ_WORKER
      ]);

      if (sffo && !!href) {
        const headers = new HttpHeaders()
          .set('Accept', `application/json; masked=${masked}`)
          .set('roleCode', ROLE.EMPLOYEE);
        const params: HttpParams = new HttpParams().append('effectiveDate', effectiveDate);
        this.httpClient
          .get<PayDistributionsDTO.WfResponse>(`/wf${href}`, {
          params,
          headers,
          observe: 'response'
        })
          .toPromise()
          .then(async (res) => {
            const country = this.myAdpToggles.canadianDirectDeposit
              ? this.getCountryConfig(res)
              : COUNTRY_CONFIG[COUNTRY.US];
            if (res?.body) {
              const distributions: PayDistributionsUI.PayDistribution[] = transformDistributions(
                country,
                res.body
              );

              // WFN needs this itemID sent back in the POST
              const itemID = res.body?.currentData?.payDistributions?.[0]?.itemID;

              this.payDistributionStore.update(PayDistributionsStoreSlice.PAY_DISTRIBUTIONS, {
                data: {
                  distributions,
                  itemID,
                  country
                },
                loading: false
              });
            } else {
              this.payDistributionStore.update(PayDistributionsStoreSlice.PAY_DISTRIBUTIONS, {
                data: {
                  country
                },
                loading: false
              });
            }
          })
          .catch((error: HttpErrorResponse) => {
            this.payDistributionStore.update(PayDistributionsStoreSlice.PAY_DISTRIBUTIONS, {
              loading: false,
              error: {
                distributionsError: true
              }
            });
            this.logger.error(`loadDistributions() error: ${error.message}`);
          });
      } else {
        this.payDistributionStore.update(PayDistributionsStoreSlice.PAY_DISTRIBUTIONS, {
          loading: false
        });
        this.logger.error('Distribution READ Permission or URL not found!');
      }
    });
  }

  public loadDistributionsMeta(): void {
    const hasMeta =
      this.payDistributionStore.stateValue[PayDistributionsStoreSlice.PAY_DISTRIBUTIONS_META]?.data
        ?.meta;

    if (hasMeta) {
      return;
    }

    const { sffo, href } = this.getMetaPermission();

    if (sffo && !!href) {
      let callCodeListAPI = false;

      this.payDistributionStore.update(PayDistributionsStoreSlice.PAY_DISTRIBUTIONS_META, {
        loading: true
      });

      this.getPayDistributionsMeta(href)
        .then((response) => {
          const metaResponse = (response?.body ?? {}) as PayDistributionsDTO.MetaResponse;

          const country = this.myAdpToggles.canadianDirectDeposit
            ? this.getCountryConfig(response)
            : COUNTRY_CONFIG[COUNTRY.US];

          const transformedMeta = transformDistributionsMeta(metaResponse, country.shortName);
          this.payDistributionStore.update(PayDistributionsStoreSlice.PAY_DISTRIBUTIONS_META, {
            data: {
              meta: transformedMeta
            }
          });

          // Need to make codeList call if we didn't get codeList form within meta response
          if (!transformedMeta.accountTypeList && transformedMeta.codeListHref) {
            callCodeListAPI = true;
            this.getCodeList();
          } else {
            this.logger.info(
              'loadDistributionsMeta() - codeList and href were not provided within the meta'
            );
          }
        })
        .catch(() => {
          this.payDistributionStore.update(PayDistributionsStoreSlice.PAY_DISTRIBUTIONS_META, {
            loading: false,
            error: {
              distributionsMetaError: true
            }
          });
        })
        .finally(() => {
          if (!callCodeListAPI) {
            this.payDistributionStore.update(PayDistributionsStoreSlice.PAY_DISTRIBUTIONS_META, {
              loading: false
            });
          }
        });
    } else {
      this.logger.info(
        'Could not make distribution meta call. Distribution CHANGE or READ Permission not found!'
      );
    }
  }

  public getPayDistributionsMeta(
    href: string
  ): Promise<HttpResponse<PayDistributionsDTO.MetaResponse>> {
    const headers = new HttpHeaders().set('roleCode', ROLE.EMPLOYEE);
    return this.httpClient.get<PayDistributionsDTO.MetaResponse>(`${href}/meta`, {
      observe: 'response',
      headers
    })
      .toPromise();
  }

  public getCodeList(): void {
    this.workerInfoStoreActions
      .getPayrollGroupCode()
      .then((payrollGroupCode: string) => {
        if (payrollGroupCode) {
          const headers = new HttpHeaders().set('roleCode', ROLE.EMPLOYEE);
          const params: HttpParams = new HttpParams().append(
            '$filter',
            `paygroup+eq+'${payrollGroupCode.replace(/'/g, `''`)}'`
          );

          this.httpClient.get<PayDistributionsDTO.PayDistributionCodeListRaw>(CODE_LIST_URI, {
            params,
            headers
          })
            .toPromise()
            .then((codeListResponse) => {
              const currentMeta =
                this.payDistributionStore.stateValue[
                  PayDistributionsStoreSlice.PAY_DISTRIBUTIONS_META
                ]?.data?.meta;

              this.payDistributionStore.update(PayDistributionsStoreSlice.PAY_DISTRIBUTIONS_META, {
                data: {
                  meta: {
                    ...currentMeta,
                    ...{ accountTypeList: codeListResponse?.codeLists?.[0]?.listItems }
                  }
                },
                loading: false
              });
            })
            .finally(() => {
              this.payDistributionStore.update(PayDistributionsStoreSlice.PAY_DISTRIBUTIONS_META, {
                loading: false
              });
            });
        } else {
          this.payDistributionStore.update(PayDistributionsStoreSlice.PAY_DISTRIBUTIONS_META, {
            loading: false
          });
          this.logger.error(
            'getCodeList() - could not get payrollGroupCode from worker to make codeList call'
          );
        }
      })
      .catch((e) => {
        this.logger.error(`this.workerInfoStoreActions.getPayrollGroupCode() - error: ${e}`);

        this.payDistributionStore.update(PayDistributionsStoreSlice.PAY_DISTRIBUTIONS_META, {
          loading: false
        });
      });
  }

  public getMetaPermission(): FoundPermission {
    let permission;

    // Check for CHANGE permission first
    permission = this.findSffoService.findSffo([{ sffo: PAY_SFFO.DIRECT_DEPOSIT_CHANGE.sffo }]);

    const hasChangePermission = permission.sffo && !!permission.href;

    if (hasChangePermission) {
      this.updateHasChangePermission(true);
    } else {
      // If we do not have the CHANGE permission set to READ permission
      permission = this.findSffoService.findSffo([
        { sffo: PAY_SFFO.DIRECT_DEPOSIT_READ.sffo },
        { sffo: PAY_SFFO.DIRECT_DEPOSIT_READ_WORKER.sffo }
      ]);
    }

    return permission;
  }

  public async postDistributions(
    distributions: PayDistributionsUI.PayDistribution[],
    usesNonCompliantSchema = false,
    includePrenoteBypassIndicator = true
  ): Promise<void> {
    const effectiveDate = await this.workerInfoStoreActions.getEffectiveDate();
    const aoid = await this.userIdentityService.getAoid();
    const itemID: string = this.payDistributionStore.itemId;

    return this.baseHttpClient.post<void>({
      userPermission: PAY_SFFO.DIRECT_DEPOSIT_CHANGE,
      payload: countryDTOtransforms[this.payDistributionStore.payDistributionCountry?.shortName](
        { effectiveDate, aoid, distributions, itemID },
        usesNonCompliantSchema,
        includePrenoteBypassIndicator
      ),
      useWorkflow: true
    });
  }

  public async recallDistributions(): Promise<void> {
    return this.baseHttpClient.post<void>({
      userPermission: PAY_SFFO.DIRECT_DEPOSIT_CHANGE,
      urlTransform: (url: string) => `/wf/recall${url}`
    });
  }

  private getCountryConfig(res: HttpResponse<any>): CountryDetails {
    const context = res?.headers
      .get('adp-context-expressionid')
      ?.replace('country=', '')
      ?.toUpperCase();

    const country: CountryDetails = COUNTRY_CONFIG[context];
    if (!country) {
      this.logger.warn(
        `getCountryConfig() - no configuration found for country ${context}, defaulting to US`
      );
    }

    return country ?? COUNTRY_CONFIG[COUNTRY.US];
  }

  private updateHasChangePermission(hasChangePermission: boolean): void {
    this.payDistributionStore.update(PayDistributionsStoreSlice.PAY_DISTRIBUTIONS, {
      data: {
        hasChangePermission
      }
    });

    this.logger.info(`Distribution CHANGE Permission found: ${hasChangePermission}`);
  }
}
