import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CoreModule } from '@synerg/angular-components';
import { AlertModule } from '@synerg/components/alert';
import { BusyIndicatorModule } from '@synerg/components/busy-indicator';
import { ButtonModule } from '@synerg/components/button';
import { FormGroupConfig, FormGroupModule } from '@synerg/components/form-group';
import { IconModule } from '@synerg/components/icon';
import { ModalModule } from '@synerg/components/modal';
import { PopoverModule } from '@synerg/components/popover';
import { SelectModule } from '@synerg/components/select';
import { SnackbarModule } from '@synerg/components/snackbar';
import { TextboxModule } from '@synerg/components/textbox';
import { TileModule } from '@synerg/components/tile';
import { ToggleSwitchModule } from '@synerg/components/toggle-switch';

import { MyAdpCommonModule } from '@myadp/common';

import { SharedModule } from '../shared/shared.module';
import { ForcedDialogConsentComponent } from './components/forced-dialog/forced-dialog-consent/forced-dialog-consent.component';
import { ForcedDialogDoneComponent } from './components/forced-dialog/forced-dialog-done/forced-dialog-done.component';
import { ForcedDialogEmailComponent } from './components/forced-dialog/forced-dialog-email/forced-dialog-email.component';
import { ForcedDialogIntroComponent } from './components/forced-dialog/forced-dialog-intro/forced-dialog-intro.component';
import { ForcedDialogLogoutComponent } from './components/forced-dialog/forced-dialog-logout/forced-dialog-logout.component';
import { ForcedDialogComponent } from './components/forced-dialog/forced-dialog.component';
import { PaperlessConsentModalComponent } from './components/paperless-consent/paperless-consent-modal/paperless-consent-modal.component';
import { PaperlessConsentTextComponent } from './components/paperless-consent/paperless-consent-text/paperless-consent-text.component';
import { PaperlessPrintConsentModalComponent } from './components/paperless-consent/paperless-print-consent-modal/paperless-print-consent-modal.component';
import { PaperlessSettingsComponent } from './components/paperless-settings/paperless-settings.component';
import { SettingOptionsComponent } from './components/paperless-settings/setting-options/setting-options.component';
import { SettingSectionHeaderComponent } from './components/paperless-settings/setting-section-header/setting-section-header.component';
import { PaperlessTileWrapperComponent } from './components/paperless-tile-wrapper/paperless-tile-wrapper.component';
import { PaperlessTileComponent } from './components/paperless-tile/paperless-tile.component';
import { RetirementPaperlessTileComponent } from './components/paperless-tile/retirement-paperless-tile.component';
import { PaperlessViewWrapperComponent } from './components/paperless-view-wrapper/paperless-view-wrapper.component';
import { PaperlessViewComponent } from './components/paperless-view/paperless-view.component';

export { PaperlessTileComponent };

@NgModule({
  imports: [
    MyAdpCommonModule,
    AlertModule,
    ButtonModule,
    IconModule,
    ToggleSwitchModule,
    BusyIndicatorModule,
    SnackbarModule,
    ModalModule,
    SelectModule,
    TextboxModule,
    TileModule,
    FormGroupModule,
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
    PopoverModule,
    CoreModule
  ],
  declarations: [
    PaperlessTileComponent,
    PaperlessSettingsComponent,
    PaperlessConsentTextComponent,
    PaperlessConsentModalComponent,
    PaperlessPrintConsentModalComponent,
    PaperlessViewComponent,
    PaperlessViewWrapperComponent,
    PaperlessTileWrapperComponent,
    SettingOptionsComponent,
    ForcedDialogComponent,
    ForcedDialogIntroComponent,
    ForcedDialogConsentComponent,
    ForcedDialogEmailComponent,
    ForcedDialogDoneComponent,
    ForcedDialogLogoutComponent,
    RetirementPaperlessTileComponent,
    SettingSectionHeaderComponent
  ],
  exports: [
    PaperlessTileComponent,
    PaperlessViewComponent,
    PaperlessViewWrapperComponent,
    PaperlessTileWrapperComponent,
    ForcedDialogComponent,
    RetirementPaperlessTileComponent
  ],
  providers: [FormGroupConfig]
})
export class PaperlessModule {
  static components = {
    default: PaperlessTileComponent,
    paperlessTileWrapper: PaperlessTileWrapperComponent,
    retirmentPaperlessTileComponent: RetirementPaperlessTileComponent
  };
}
