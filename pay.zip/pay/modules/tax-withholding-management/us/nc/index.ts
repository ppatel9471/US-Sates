import { NcIntroComponent } from './steps/intro/nc-intro.component';
import { NcMaritalStatusComponent } from './steps/marital-status/nc-marital-status.component';
import { NcAllowancesComponent } from './steps/allowances/nc-allowances.component';

export { NcTWChangeEventService } from './services/nc-tw-change-event.service';
export { NcSummaryMetaDataService } from './services/nc-summary-meta-data.service';

export const NC_COMPONENTS = [NcIntroComponent, NcMaritalStatusComponent, NcAllowancesComponent];

export { NCSTEP_COMPONENT } from './models/steps-component.model';

export { NcAttachmentCodes } from './models/nc-tw-change-event';
