import { Injectable } from '@angular/core';

import { BaseHttpClient } from '@myadp/common';
import { FindSffoService, PAY_SFFO } from '@myadp/pay-shared';

import { PayStatementsDTO } from '../models/pay-statement.model';
import { PayDashboardTileBaseService } from './pay-dashboard-tile-base.service';

@Injectable({
  providedIn: 'root'
})
export class PayDashboardTileService extends PayDashboardTileBaseService {
  constructor(
    private baseHttpClient: BaseHttpClient,
    public findSffoService: FindSffoService) {
    super();
  }

  getPayStatements(): Promise<PayStatementsDTO> {
    const { sffo } = this.findSffoService.findSffo([
      PAY_SFFO.PAY_STATEMENTS_READ,
      PAY_SFFO.PAY_STATEMENTS_READ_LEGACY
    ]);

    if (!sffo) {
      return Promise.reject('Pay Permission not found!');
    }

    return this.baseHttpClient.get<PayStatementsDTO>({
      userPermission: sffo,
      urlTransform: (url) =>  url.split('?')[0],
      query: { numberoflastpaydates: '26' }
    });
  }

}
