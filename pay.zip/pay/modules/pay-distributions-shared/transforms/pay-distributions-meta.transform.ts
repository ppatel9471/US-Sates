import { LegacyCodeType, PayDistributionsDTO } from '@myadp/dto';

import { PayDistributionsUI } from '../models/pay-distributions-ui';

const EMAIL_NOT_CONFIGURED = 'Email not configured.'.toUpperCase();

export function transformDistributionsMeta(
  res: PayDistributionsDTO.MetaResponse,
  countryName: string = 'US'
): PayDistributionsUI.PayDistributionMeta {
  const meta = res?.meta || {};
  const {
    dataTransforms,
    distributionInstructions,
    distributionPercentage,
    prenoteBypassIndicator,
    remainingBalanceIndicator,
    distributionAmountValue,
    accountName,
    eventContext,
    associateOID,
    typeCode,
    banks,
    paymentMethodCode
  } = PayDistributionsDTO.metaKey;
  const dataTransformsMeta = meta[dataTransforms]?.[0] || {};
  const distributionInstructionsItems = dataTransformsMeta?.[distributionInstructions];
  const forceRemainingBalanceIndicatorMsg =
    dataTransformsMeta?.[remainingBalanceIndicator]?.helperMessage?.messageTxt;

  return {
    ...(countryName === 'CA' && { banks: getCodeList(dataTransformsMeta[banks]?.codeList) }),
    maxAccounts: distributionInstructionsItems?.maxItems,
    minAccounts: distributionInstructionsItems?.minItems,
    termsAgreementMsg: distributionInstructionsItems?.helperMessage?.messageTxt,
    showDistributionPercentage: !!dataTransformsMeta[distributionPercentage],
    canValidateBankInfo: !!prenoteBypassIndicator,
    forceRemaining: {
      enabled: !!forceRemainingBalanceIndicatorMsg,
      msg: forceRemainingBalanceIndicatorMsg
    },
    distributionAmount: {
      min: dataTransformsMeta[distributionAmountValue]?.minAmountValue
    },
    accountName: {
      enabled: !!dataTransformsMeta[accountName],
      maxLength: dataTransformsMeta[accountName]?.maxLength ?? 30
    },
    accountTypeList: getCodeList(
      dataTransformsMeta[typeCode]?.codeList as PayDistributionsDTO.CodeListItems
    ),
    codeListHref: getCodeListHref(
      dataTransformsMeta[typeCode]?.codeList as PayDistributionsDTO.CodeListLinks
    ),
    isEmailConfigured:
      meta[eventContext]?.[0]?.[associateOID]?.helperMessage?.messageTxt?.toUpperCase() !==
      EMAIL_NOT_CONFIGURED,
    paymentMethodCodes: {
      codeList: getCodeList(dataTransformsMeta[paymentMethodCode]?.codeList),
      readOnly: dataTransformsMeta[paymentMethodCode]?.readOnly
    }
  };
}

function getCodeList(codeList: PayDistributionsDTO.CodeListItems): LegacyCodeType[] {
  const codeListItems = codeList?.listItems;
  return codeListItems ?? null;
}

function getCodeListHref(codeList: PayDistributionsDTO.CodeListLinks): string {
  return codeList?.links?.[0]?.href;
}
