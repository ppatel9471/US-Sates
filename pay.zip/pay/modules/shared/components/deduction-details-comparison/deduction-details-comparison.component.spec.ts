import { CurrencyPipe } from '@angular/common';
import { DebugElement } from '@angular/core';
import { Shallow } from 'shallow-render';

import { LanguagePipe, LanguageService } from '@myadp/common';
import { TaskDetailsItemComponent } from '@myadp/thingstodo-shared';

import { DeductionsComparisonService } from '../../services/deductions-comparison.service';
import { ValueFormatterService } from '../../services/value-formatter.service';
import { WorkflowComparisonService } from '../../services/workflow-comparison.service';
import { SharedModule } from '../../shared.module';
import { WorkflowDetailsComparisonComponent } from '../workflow-details-comparison/workflow-details-comparison.component';
import { DeductionDetailsComparisonComponent } from './deduction-details-comparison.component';
import { DeductionDetailsComponent } from './deduction-details/deduction-details.component';

describe('DeductionDetailsComparisonComponent', () => {
  let shallow: Shallow<DeductionDetailsComparisonComponent>;

  const currentColumnItems = 'vded-details.wf-current-data task-details-item';
  const pendingColumnItems = 'vded-details.wf-pending-data task-details-item';

  beforeEach(() => {
    shallow = new Shallow<DeductionDetailsComparisonComponent>(
      DeductionDetailsComparisonComponent,
      SharedModule
    )
      .provide(CurrencyPipe, LanguageService, ValueFormatterService)
      .dontMock(
        CurrencyPipe,
        ValueFormatterService,
        TaskDetailsItemComponent,
        WorkflowComparisonService,
        DeductionDetailsComponent,
        DeductionsComparisonService,
        WorkflowDetailsComparisonComponent
      )
      .mockPipe(LanguagePipe, (key) => key);
  });

  describe('Pending add', () => {
    it('PIMYPI-T881 should show current column with add message and pending column with flat rate amount', async () => {
      const mockDetails = {
        itemID: 'AB',
        deductionCode: { codeValue: 'AB', longName: 'Allowance 1' },
        deductionRate: { rateValue: 10, currencyCode: 'USD' }
      };
      const { find } = await shallow.render({
        bind: {
          data: {
            currentData: null,
            pendingData: mockDetails,
            pendingEvent: { approver: 'Sanchez, Richard', changeType: 'add' }
          }
        }
      });
      const [addMsg] = getTextFromColumnItems(find, currentColumnItems);
      const [pendingRate] = getTextFromColumnItems(find, pendingColumnItems);

      expect(find(currentColumnItems)).toHaveFound(1);
      expect(addMsg).toContain('myadp-pay.DEDUCTIONS_WORKFLOW_COMPARISON_PENDING_ADD');
      expect(addMsg).not.toContain('myadp-pay.DEDUCTION_DEDUCTION_AMOUNT');
      expect(addMsg).not.toContain('myadp-pay.DEDUCTION_GOAL_AMOUNT');

      expect(find(pendingColumnItems)).toHaveFound(1);
      expect(pendingRate).toContain('myadp-pay.DEDUCTION_DEDUCTION_AMOUNT  $10.00');
      expect(pendingRate).not.toContain('myadp-pay.DEDUCTION_GOAL_AMOUNT');
    });

    it('PIMYPI-T882 should show current column with add message and pending column with percent rate amount', async () => {
      const mockDetails = {
        itemID: 'AB',
        deductionCode: { codeValue: 'AB', longName: 'Allowance 1' },
        deductionRate: { rateValue: 10, unitCode: { codeValue: 'percent' } }
      };
      const { find } = await shallow.render({
        bind: {
          data: {
            currentData: null,
            pendingData: mockDetails,
            pendingEvent: { approver: 'Sanchez, Richard', changeType: 'add' }
          }
        }
      });
      const [addMsg] = getTextFromColumnItems(find, currentColumnItems);
      const [pendingRate] = getTextFromColumnItems(find, pendingColumnItems);

      expect(find(currentColumnItems)).toHaveFound(1);
      expect(addMsg).toContain('myadp-pay.DEDUCTIONS_WORKFLOW_COMPARISON_PENDING_ADD');
      expect(addMsg).not.toContain('myadp-pay.DEDUCTION_DEDUCTION_AMOUNT');
      expect(addMsg).not.toContain('myadp-pay.DEDUCTION_GOAL_AMOUNT');

      expect(find(pendingColumnItems)).toHaveFound(1);
      expect(pendingRate).toContain('myadp-pay.DEDUCTION_DEDUCTION_AMOUNT  10%');
      expect(pendingRate).not.toContain('myadp-pay.DEDUCTION_GOAL_AMOUNT');
    });

    it('PIMYPI-T883 should show current column with add message and pending column with $0 goal amount', async () => {
      const mockDetails = {
        itemID: 'AB',
        deductionCode: { codeValue: 'AB', longName: 'Allowance 1' },
        deductionRate: { rateValue: 10, currencyCode: 'USD' },
        deductionGoal: { goalLimitAmount: { amountValue: 0, currencyCode: 'USD' } }
      };
      const { find } = await shallow.render({
        bind: {
          data: {
            currentData: null,
            pendingData: mockDetails,
            pendingEvent: { approver: 'Sanchez, Richard', changeType: 'add' }
          }
        }
      });
      const [addMsg] = getTextFromColumnItems(find, currentColumnItems);
      const [pendingRate, pendingGoal] = getTextFromColumnItems(find, pendingColumnItems);

      expect(find(currentColumnItems)).toHaveFound(1);
      expect(addMsg).toContain('myadp-pay.DEDUCTIONS_WORKFLOW_COMPARISON_PENDING_ADD');
      expect(addMsg).not.toContain('myadp-pay.DEDUCTION_DEDUCTION_AMOUNT');
      expect(addMsg).not.toContain('myadp-pay.DEDUCTION_GOAL_AMOUNT');

      expect(find(pendingColumnItems)).toHaveFound(2);
      expect(pendingRate).toContain('myadp-pay.DEDUCTION_DEDUCTION_AMOUNT  $10.00');
      expect(pendingGoal).toContain('myadp-pay.DEDUCTION_GOAL_AMOUNT  $0.00');
    });

    it('PIMYPI-T884 should show current column with add message and pending column with $0 rate and goal amounts', async () => {
      const mockDetails: any = {
        itemID: 'AB',
        deductionCode: { codeValue: 'AB', longName: 'Allowance 1' },
        deductionRate: { rateValue: null },
        deductionGoal: { goalLimitAmount: { amountValue: 0, currencyCode: 'USD' } }
      };
      const { find } = await shallow.render({
        bind: {
          data: {
            currentData: null,
            pendingData: mockDetails,
            pendingEvent: { approver: 'Sanchez, Richard', changeType: 'add' }
          }
        }
      });
      const [addMsg] = getTextFromColumnItems(find, currentColumnItems);
      const [pendingRate, pendingGoal] = getTextFromColumnItems(find, pendingColumnItems);

      expect(find(currentColumnItems)).toHaveFound(1);
      expect(addMsg).toContain('myadp-pay.DEDUCTIONS_WORKFLOW_COMPARISON_PENDING_ADD');
      expect(addMsg).not.toContain('myadp-pay.DEDUCTION_DEDUCTION_AMOUNT');
      expect(addMsg).not.toContain('myadp-pay.DEDUCTION_GOAL_AMOUNT');

      expect(find(pendingColumnItems)).toHaveFound(2);
      expect(pendingRate).toContain('myadp-pay.DEDUCTION_DEDUCTION_AMOUNT  $0.00');
      expect(pendingGoal).toContain('myadp-pay.DEDUCTION_GOAL_AMOUNT  $0.00');
    });
  });

  describe('Pending edit', () => {
    it('PIMYPI-T888 should have rate and goal in current column and rate amount in pending column', async () => {
      const currentMockDetails = {
        itemID: 'AB',
        deductionCode: { codeValue: 'AB', longName: 'Allowance 1' },
        deductionRate: { rateValue: 23, currencyCode: 'USD' },
        deductionGoal: { goalLimitAmount: { amountValue: 100, currencyCode: 'USD' } }
      };
      const pendingMockDetails = {
        ...currentMockDetails,
        deductionRate: { rateValue: 10, currencyCode: 'USD' }
      };
      const { find } = await shallow.render({
        bind: {
          data: {
            currentData: currentMockDetails,
            pendingData: pendingMockDetails,
            pendingEvent: { approver: 'Sanchez, Richard', changeType: 'edit' }
          }
        }
      });
      const [currentRate, currentGoal] = getTextFromColumnItems(find, currentColumnItems);
      const [pendingRate] = getTextFromColumnItems(find, pendingColumnItems);

      expect(find(currentColumnItems)).toHaveFound(2);
      expect(currentRate).toContain('myadp-pay.DEDUCTION_DEDUCTION_AMOUNT  $23.00');
      expect(currentGoal).toContain('myadp-pay.DEDUCTION_GOAL_AMOUNT  $100.00');

      expect(find(pendingColumnItems)).toHaveFound(1);
      expect(pendingRate).toContain('myadp-pay.DEDUCTION_DEDUCTION_AMOUNT  $10.00');
      expect(pendingRate).not.toContain('myadp-pay.DEDUCTION_GOAL_AMOUNT');
    });

    it('PIMYPI-T889 should have rate and goal in current column and goal amount in pending column', async () => {
      const currentMockDetails = {
        itemID: 'AB',
        deductionCode: { codeValue: 'AB', longName: 'Allowance 1' },
        deductionRate: { rateValue: 23, currencyCode: 'USD' },
        deductionGoal: { goalLimitAmount: { amountValue: 100, currencyCode: 'USD' } }
      };
      const pendingMockDetails = {
        ...currentMockDetails,
        deductionGoal: { goalLimitAmount: { amountValue: 200, currencyCode: 'USD' } }
      };
      const { find } = await shallow.render({
        bind: {
          data: {
            currentData: currentMockDetails,
            pendingData: pendingMockDetails,
            pendingEvent: { approver: 'Sanchez, Richard', changeType: 'edit' }
          }
        }
      });
      const [currentRate, currentGoal] = getTextFromColumnItems(find, currentColumnItems);
      const [pendingGoal] = getTextFromColumnItems(find, pendingColumnItems);

      expect(find(currentColumnItems)).toHaveFound(2);
      expect(currentRate).toContain('myadp-pay.DEDUCTION_DEDUCTION_AMOUNT  $23.00');
      expect(currentGoal).toContain('myadp-pay.DEDUCTION_GOAL_AMOUNT  $100.00');

      expect(find(pendingColumnItems)).toHaveFound(1);
      expect(pendingGoal).not.toContain('myadp-pay.DEDUCTION_DEDUCTION_AMOUNT');
      expect(pendingGoal).toContain('myadp-pay.DEDUCTION_GOAL_AMOUNT  $200.00');
    });

    it('PIMYPI-T890 should have rate and goal amounts in both current and pending columns', async () => {
      const currentMockDetails = {
        itemID: 'AB',
        deductionCode: { codeValue: 'AB', longName: 'Allowance 1' },
        deductionRate: { rateValue: 23, currencyCode: 'USD' },
        deductionGoal: { goalLimitAmount: { amountValue: 100, currencyCode: 'USD' } }
      };
      const pendingMockDetails = {
        ...currentMockDetails,
        deductionRate: { rateValue: 10, currencyCode: 'USD' },
        deductionGoal: { goalLimitAmount: { amountValue: 200, currencyCode: 'USD' } }
      };
      const { find } = await shallow.render({
        bind: {
          data: {
            currentData: currentMockDetails,
            pendingData: pendingMockDetails,
            pendingEvent: { approver: 'Sanchez, Richard', changeType: 'edit' }
          }
        }
      });
      const [currentRate, currentGoal] = getTextFromColumnItems(find, currentColumnItems);
      const [pendingRate, pendingGoal] = getTextFromColumnItems(find, pendingColumnItems);

      expect(find(currentColumnItems)).toHaveFound(2);
      expect(currentRate).toContain('myadp-pay.DEDUCTION_DEDUCTION_AMOUNT  $23.00');
      expect(currentGoal).toContain('myadp-pay.DEDUCTION_GOAL_AMOUNT  $100.00');

      expect(find(pendingColumnItems)).toHaveFound(2);
      expect(pendingRate).toContain('myadp-pay.DEDUCTION_DEDUCTION_AMOUNT  $10.00');
      expect(pendingGoal).toContain('myadp-pay.DEDUCTION_GOAL_AMOUNT  $200.00');
    });
  });

  describe('Pending delete', () => {
    it('PIMYPI-T885 should show current column with rate and goal amounts and pending column with delete message', async () => {
      const mockDetails: any = {
        itemID: 'AB',
        deductionCode: { codeValue: 'AB', longName: 'Allowance 1' },
        deductionRate: { rateValue: 23, currencyCode: 'USD' },
        deductionGoal: { goalLimitAmount: { amountValue: 100, currencyCode: 'USD' } }
      };
      const { find } = await shallow.render({
        bind: {
          data: {
            currentData: mockDetails,
            pendingData: null,
            pendingEvent: { approver: 'Sanchez, Richard', changeType: 'delete' }
          }
        }
      });
      const [currentRate, currentGoal] = getTextFromColumnItems(find, currentColumnItems);
      const [deleteMsg] = getTextFromColumnItems(find, pendingColumnItems);

      expect(find(currentColumnItems)).toHaveFound(2);
      expect(currentRate).toContain('myadp-pay.DEDUCTION_DEDUCTION_AMOUNT  $23.00');
      expect(currentGoal).toContain('myadp-pay.DEDUCTION_GOAL_AMOUNT  $100.00');

      expect(find(pendingColumnItems)).toHaveFound(1);
      expect(deleteMsg).toContain('myadp-pay.DEDUCTIONS_WORKFLOW_COMPARISON_PENDING_DELETE');
      expect(deleteMsg).not.toContain('myadp-pay.DEDUCTION_DEDUCTION_AMOUNT');
      expect(deleteMsg).not.toContain('myadp-pay.DEDUCTION_GOAL_AMOUNT');
    });

    it('PIMYPI-T886 should show current column with $0 goal amount and pending column with delete message', async () => {
      const mockDetails: any = {
        itemID: 'AB',
        deductionCode: { codeValue: 'AB', longName: 'Allowance 1' },
        deductionRate: { rateValue: 23, currencyCode: 'USD' },
        deductionGoal: { goalLimitAmount: { amountValue: 0, currencyCode: 'USD' } }
      };
      const { find } = await shallow.render({
        bind: {
          data: {
            currentData: mockDetails,
            pendingData: null,
            pendingEvent: { approver: 'Sanchez, Richard', changeType: 'delete' }
          }
        }
      });
      const [currentRate, currentGoal] = getTextFromColumnItems(find, currentColumnItems);
      const [deleteMsg] = getTextFromColumnItems(find, pendingColumnItems);

      expect(find(currentColumnItems)).toHaveFound(2);
      expect(currentRate).toContain('myadp-pay.DEDUCTION_DEDUCTION_AMOUNT  $23.00');
      expect(currentGoal).toContain('myadp-pay.DEDUCTION_GOAL_AMOUNT  $0.00');

      expect(find(pendingColumnItems)).toHaveFound(1);
      expect(deleteMsg).toContain('myadp-pay.DEDUCTIONS_WORKFLOW_COMPARISON_PENDING_DELETE');
      expect(deleteMsg).not.toContain('myadp-pay.DEDUCTION_DEDUCTION_AMOUNT');
      expect(deleteMsg).not.toContain('myadp-pay.DEDUCTION_GOAL_AMOUNT');
    });

    it('PIMYPI-T887 should show current column with $0 rate and goal amounts and pending column with delete message', async () => {
      const mockDetails: any = {
        itemID: 'AB',
        deductionCode: { codeValue: 'AB', longName: 'Allowance 1' },
        deductionRate: { rateValue: null },
        deductionGoal: { goalLimitAmount: { amountValue: 0, currencyCode: 'USD' } }
      };
      const { find } = await shallow.render({
        bind: {
          data: {
            currentData: mockDetails,
            pendingData: null,
            pendingEvent: { approver: 'Sanchez, Richard', changeType: 'delete' }
          }
        }
      });
      const [currentRate, currentGoal] = getTextFromColumnItems(find, currentColumnItems);
      const [deleteMsg] = getTextFromColumnItems(find, pendingColumnItems);

      expect(find(currentColumnItems)).toHaveFound(2);
      expect(currentRate).toContain('myadp-pay.DEDUCTION_DEDUCTION_AMOUNT  $0.00');
      expect(currentGoal).toContain('myadp-pay.DEDUCTION_GOAL_AMOUNT  $0.00');

      expect(find(pendingColumnItems)).toHaveFound(1);
      expect(deleteMsg).toContain('myadp-pay.DEDUCTIONS_WORKFLOW_COMPARISON_PENDING_DELETE');
      expect(deleteMsg).not.toContain('myadp-pay.DEDUCTION_DEDUCTION_AMOUNT');
      expect(deleteMsg).not.toContain('myadp-pay.DEDUCTION_GOAL_AMOUNT');
    });
  });

  function getTextFromColumnItems(find: any, columnItems: string): [string, string] {
    return find(columnItems).map((item: DebugElement) => item?.nativeElement.textContent.trim());
  }
});
