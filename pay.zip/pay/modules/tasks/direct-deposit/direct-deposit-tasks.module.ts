import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { CoreModule } from '@synerg/angular-components';
import { AlertModule } from '@synerg/components/alert';
import { CarouselModule } from '@synerg/components/carousel';

import { MyAdpCommonModule } from '@myadp/common';
import {
  NOTIFICATION_EVENT_NAME_CODES,
  NotificationsService,
  ThingsToDoSharedModule
} from '@myadp/thingstodo-shared';
import { TaskModule } from '@myadp/thingstodo-shared/modules/task/task.module';

import { SharedModule } from '../../shared/shared.module';
import { DirectDepositDetailsAccountComponent } from './components/direct-deposit-tasks-details-account/direct-deposit-tasks-details-account.component';
import { DirectDepositDetailsComponent } from './components/direct-deposit-tasks-details/direct-deposit-tasks-details.component';

@NgModule({
  imports: [
    CommonModule,
    MyAdpCommonModule,
    ThingsToDoSharedModule,
    TaskModule,
    CarouselModule,
    AlertModule,
    SharedModule,
    CoreModule
  ],
  declarations: [DirectDepositDetailsComponent, DirectDepositDetailsAccountComponent]
})
export class DirectDepositTasksModule {
  constructor(private notificationsService: NotificationsService) {
    [NOTIFICATION_EVENT_NAME_CODES.pay.worker_payDistribution_change].forEach((event) =>
      this.notificationsService.setTaskDetailsRoute(event, DirectDepositDetailsComponent)
    );
  }
}
