import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { ClientDeviceService, NativeResourceService } from '@espresso/core';
import { NativeOCRService, ObjectHelperService as objHlpr } from '@myadp/common';
import { OCR_CONSTANTS } from '../../config/ocr-constants';

export interface OCRData {
  routingNumber: string;
  accountNumber: string;
}

@Component({
  selector: 'pay-ocr-trigger-button',

  styleUrls: ['ocr-trigger-button.component.scss'],
  template: `
    <div *ngIf="isOCRFeatureSupported" class="ocr-trigger">
      <button
        id="espressoOcrTriggerButton"
        icon="camera"
        (click)="captureImage()"
        espresso-primary-button
      >
        {{ 'myadp-pay.TAKE_A_PICTURE' | lang }}
      </button>
      <div class="line-break-ocr">
        <span class="line-break-text">{{ 'common.OR' | lang }}</span>
      </div>
    </div>
  `
})
export class OCRTriggerButtonComponent implements OnInit {
  isOCRFeatureSupported: boolean = false;

  @Output() captureInitiated = new EventEmitter<void>();
  @Output() captureCompleted = new EventEmitter<OCRData>();
  @Output() captureFailed = new EventEmitter<any>();
  @Output() captureCancelled = new EventEmitter<void>();

  private ignoreStatus = [OCR_CONSTANTS.CAMERA_ACCESS_PROHIBITTED, OCR_CONSTANTS.CAMERA_CANCELLED];

  constructor(
    private clientDeviceService: ClientDeviceService,
    private nativeResourceService: NativeResourceService,
    private nativeOCRService: NativeOCRService
  ) {}

  ngOnInit() {
    if (!this.clientDeviceService.isNative()) {
      return;
    }

    this.nativeResourceService.getAppContext().then(appContext => {
      this.isOCRFeatureSupported = objHlpr.get(appContext, 'ocrServices.bankRoutingServiceEnabled');
    });
  }

  captureImage() {
    this.captureInitiated.emit();
    this.nativeOCRService
      .getBankAccountInformation()
      .then(data => {
        this.captureCompleted.emit(data.result);
      })
      .catch(err => {
        if (this.ignoreStatus.includes(objHlpr.get(err, 'status.code'))) {
          this.captureCancelled.emit();
        } else {
          this.captureFailed.emit(err);
        }
      });
  }
}
