import { cloneDeep, find, get } from 'lodash';

import { WizardMeta } from '../../tax-withholding-management/shared/models/steps-type.model';
import { FormItem, ListItem } from '../models/form-item.model';

export function getMetaFormItem(meta: WizardMeta, id: string): FormItem {
  return cloneDeep(find(meta.formItems, { id: id }));
}

export function getMetaFormListItem(meta: WizardMeta, id: string): ListItem[] {
  const formItem: FormItem = getMetaFormItem(meta, id);
  return cloneDeep(get(formItem, 'list'));
}

export function getMetaListItem(formItem: FormItem): ListItem[] {
  return cloneDeep(get(formItem, 'list'));
}
