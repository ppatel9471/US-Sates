import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Observable } from 'rxjs';

import { BarbecueService } from '@myadp/common';
import {
  PageType,
  PaperlessStore,
  PaperlessStoreActions,
  PaperlessType,
  SaveSuccess,
  StatementSettings,
  TAX_FORM_CODES
} from '@myadp/pay-paperless-shared';

@Component({
  selector: 'pay-paperless-settings',
  templateUrl: './paperless-settings.component.html',
  styleUrls: ['./paperless-settings.component.scss']
})
export class PaperlessSettingsComponent implements OnInit {
  @Input() public isNative?: boolean = false;
  @Input() public pageType: PageType;
  @Output() public displayConsentModal: EventEmitter<boolean> = new EventEmitter<boolean>();
  @Output() public displayPrintConsentModal?: EventEmitter<boolean> = new EventEmitter<boolean>();
  @Output() public typeChanged: EventEmitter<PaperlessType> = new EventEmitter<PaperlessType>();
  public isLoading$: Observable<boolean>;
  public paySettings$: Observable<StatementSettings>;
  public taxSettings$: Observable<StatementSettings>;
  public healthSettings$: Observable<StatementSettings>;
  public retirementSettings$: Observable<StatementSettings>;
  public saveSuccess$: Observable<SaveSuccess>;
  public allLoadError$: Observable<boolean>;
  public payLoadError$: Observable<boolean>;
  public retirementLoadError$: Observable<boolean>;
  public type: PaperlessType;
  public paperlessType = PaperlessType;
  public canViewPayStatementSection$: Observable<boolean>;
  public canViewTaxStatementSection$: Observable<boolean>;
  public canViewHealthStatementSection$: Observable<boolean>;
  public canViewRetirementSection$: Observable<boolean>;
  public pageHasPaySection: boolean;
  public pageHasRetirementSection: boolean;
  public pageHasRedirectPay: boolean;
  public pageHasRedirectSettings: boolean;
  public isBbq: boolean;
  public taxFormCodes = TAX_FORM_CODES;

  constructor(
    private paperlessStore: PaperlessStore,
    private paperlessStoreActions: PaperlessStoreActions,
    private bbqService: BarbecueService
  ) {}

  public savePayPaperlessSetting(value: boolean): void {
    this.setType(PaperlessType.PAY);
    value
      ? this.emitDisplayConsentModal(true)
      : this.paperlessStoreActions.savePayStatementPaperless(value);
  }

  public savePayNotificationSetting(value: boolean): void {
    this.paperlessStoreActions.savePayStatementNotification(value);
  }

  public saveTaxPaperlessSetting(value: boolean, formType: TAX_FORM_CODES): void {
    const type =
      formType === TAX_FORM_CODES.W2_CODE
        ? PaperlessType.TAX
        : PaperlessType.TAX_COVERAGE_INSURANCE;
    this.setType(type);
    value
      ? this.emitDisplayConsentModal(true)
      : this.paperlessStoreActions.saveTaxStatementPaperless(value, formType);
  }

  public saveTaxNotificationSetting(value: boolean): void {
    this.paperlessStoreActions.saveTaxStatementNotification(value);
  }

  public saveRetirementNotificationSetting(value: boolean): void {
    this.setType(PaperlessType.RETIREMENT);
    value
      ? this.emitDisplayConsentModal(true)
      : this.paperlessStoreActions.saveRetirementNotification(value);
  }

  public displayPayPrintConsentModal(): void {
    this.setType(PaperlessType.PAY);
    this.emitDisplayPrintConsentModal(true);
  }

  public displayTaxPrintConsentModal(): void {
    this.setType(PaperlessType.TAX);
    this.emitDisplayPrintConsentModal(true);
  }

  public displayHealthPrintConsentModal(): void {
    this.setType(PaperlessType.TAX_COVERAGE_INSURANCE);
    this.emitDisplayPrintConsentModal(true);
  }

  public displayRetirementPrintConsentModal(): void {
    this.setType(PaperlessType.RETIREMENT);
    this.emitDisplayPrintConsentModal(true);
  }

  public emitDisplayConsentModal(display: boolean): void {
    this.displayConsentModal.emit(display);
  }

  public emitDisplayPrintConsentModal(display: boolean): void {
    this.displayPrintConsentModal.emit(display);
  }

  public ngOnInit() {
    this.isBbq = this.bbqService.isBarbecue();
    this.pageHasPaySection = this.paperlessStore.pageHasPaySection(this.pageType);
    this.pageHasRetirementSection = this.paperlessStore.pageHasRetirementSection(this.pageType);
    this.pageHasRedirectSettings = this.paperlessStore.pageHasRedirectSettings(
      this.isNative,
      this.isBbq,
      this.pageType
    );
    this.pageHasRedirectPay = this.paperlessStore.pageHasRedirectPay(
      this.isNative,
      this.isBbq,
      this.pageType
    );

    this.isLoading$ = this.paperlessStore.isLoading$();
    this.paySettings$ = this.paperlessStore.paySettings$();
    this.taxSettings$ = this.paperlessStore.taxSettings$();
    this.healthSettings$ = this.paperlessStore.healthSettings$();
    this.retirementSettings$ = this.paperlessStore.retirementSettings$();
    this.saveSuccess$ = this.paperlessStore.saveSuccess$();
    this.allLoadError$ = this.paperlessStore.allLoadError$();
    this.payLoadError$ = this.paperlessStore.payLoadError$();
    this.retirementLoadError$ = this.paperlessStore.retirementLoadError$();

    this.canViewPayStatementSection$ = this.paperlessStore.canViewStatementSection$(
      PaperlessType.PAY,
      this.isNative
    );
    this.canViewTaxStatementSection$ = this.paperlessStore.canViewStatementSection$(
      PaperlessType.TAX,
      this.isNative
    );
    this.canViewHealthStatementSection$ = this.paperlessStore.canViewStatementSection$(
      PaperlessType.TAX_COVERAGE_INSURANCE,
      this.isNative
    );
    this.canViewRetirementSection$ = this.paperlessStore.canViewStatementSection$(
      PaperlessType.RETIREMENT,
      this.isNative
    );
  }

  private setType(paperlessType: PaperlessType): void {
    this.typeChanged.emit(paperlessType);
    this.type = paperlessType;
  }
}
