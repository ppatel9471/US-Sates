import { WorkerTaxStatementsDTO } from '@myadp/dto';

export enum TaxStatementsStoreSlice {
  TAX_STATEMENTS = 'taxStatements'
}

export interface TaxStatementsStoreState {
  [TaxStatementsStoreSlice.TAX_STATEMENTS]: WorkerTaxStatementsDTO.WorkerTaxStatement[];
}
