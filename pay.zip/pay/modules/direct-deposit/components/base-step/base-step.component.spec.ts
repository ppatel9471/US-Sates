import { FormBuilder } from '@angular/forms';
import { EMPTY } from 'rxjs';
import { Shallow } from 'shallow-render';
import { Mock } from 'ts-mockery';

import { DistributionOptions } from '../../../pay-distributions-shared/models/pay-distributions-ui';
import { MyADPDirectDepositModule } from '../../direct-deposit.module';
import { StepsStore, StepsStoreActions } from '../../store/steps/steps.store';
import { BaseStepComponent } from './base-step.component';

describe('BaseStepComponent', () => {
  let shallow: Shallow<BaseStepComponent>;

  beforeEach(() => {
    shallow = new Shallow(BaseStepComponent, MyADPDirectDepositModule)
      .mock(StepsStore, {
        directDepositAccounts$: EMPTY,
        hasChangePermission$: EMPTY,
        state$: EMPTY,
        isEditing: false
      })
      .mock(StepsStoreActions, {
        disableNext: () => Mock.noop(),
        setFormGroup: () => Mock.noop()
      });
  });

  describe('disableNext()', () => {
    it('should call step store action to set next button to disable', async () => {
      const { instance, get } = await shallow.render();
      const stepsStoreActions = get(StepsStoreActions);
      instance.disableNext();

      expect(stepsStoreActions.disableNext).toHaveBeenCalledWith(true);
    });

    it('should call step store action to set next button to enabled', async () => {
      const { instance, get } = await shallow.render();
      const stepsStoreActions = get(StepsStoreActions);
      instance.disableNext(false);

      expect(stepsStoreActions.disableNext).toHaveBeenCalledWith(false);
    });
  });

  describe('setFormGroup()', () => {
    it('should call step store action to set form group', async () => {
      const { instance, get } = await shallow.render();
      const stepsStoreActions = get(StepsStoreActions);
      const newFormGroup = new FormBuilder().group({
        SOME_FORM: {
          depositType: [DistributionOptions.REMAINING]
        }
      });
      instance.setFormGroup(newFormGroup);

      expect(stepsStoreActions.setFormGroup).toHaveBeenCalledWith(newFormGroup);
    });

    it('should call step store action to set form group and excluded form properties', async () => {
      const { instance, get } = await shallow.render();
      const stepsStoreActions = get(StepsStoreActions);
      const newFormGroup = new FormBuilder().group({
        FORM: {
          depositType: [DistributionOptions.REMAINING],
          removeMe: [DistributionOptions.REMAINING]
        }
      });
      instance.setFormGroup(newFormGroup, 'removeMe');

      expect(stepsStoreActions.setFormGroup).toHaveBeenCalledWith(newFormGroup, 'removeMe');
    });
  });

  describe('isEditing', () => {
    it('should set isEditing to true when editing', async () => {
      const { instance } = await shallow
        .mock(StepsStore, {
          isEditing: true,
          stepFormDetails: {
            id: 'id3'
          }
        })
        .render();

      expect(instance.isEditing).toBe(true);
    });

    it('should set isEditing false when not editing', async () => {
      const { instance } = await shallow
        .mock(StepsStore, {
          isEditing: false,
          stepFormDetails: {
            id: undefined
          }
        })
        .render();

      expect(instance.isEditing).toBe(false);
    });
  });
});
