import { TestBed } from '@angular/core/testing';

import { MOCK_DEDUCTIONS } from '@specHelpers/pay/pay-deductions/pay-deductions';

import {
  PayDeductionsStoreSlice,
  PayDeductionsUI
} from '../../pay-deductions-shared/models/pay-deductions-ui';
import { PayDeductionsStore } from '../../pay-deductions-shared/store/pay-deductions.store';
import { DeductionForm } from '../models/deduction-form.model';
import { DeductionsStore } from './deductions.store';

describe('DeductionsStore', () => {
  let deductionsStore: DeductionsStore;
  let payDeductionsStore: PayDeductionsStore;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        PayDeductionsStore
      ]
    });

    deductionsStore = TestBed.inject(DeductionsStore);
    payDeductionsStore = TestBed.inject(PayDeductionsStore);
  });

  it('should create the deductions store with an initial state', () => {
    const initialState: Record<string, object> = {
      formData: {
        data: undefined
      },
      changedDeductionDetails: {
        data: undefined
      },
      changes: {
        data: undefined
      },
      permissions: {
        data: undefined
      }
    };

    expect(deductionsStore).toBeTruthy();
    expect(deductionsStore.stateValue).toEqual(initialState);
  });

  it('should get the form details based on step', () => {
    deductionsStore.update('formData', {
      data: {
        deductionCode: {
          codeValue: '40A'
        },
        terms: false
      }
    });
    const formData: DeductionForm = deductionsStore.formData;

    expect(formData).toEqual({
      deductionCode: {
        codeValue: '40A'
      },
      terms: false
    });
  });

  it('should get changes', () => {
    deductionsStore.update('changes', {
      data: { changeType: 'delete', deductionDetails: MOCK_DEDUCTIONS[0].currentData }
    });
    expect(deductionsStore.changes).toEqual({
      changeType: 'delete',
      deductionDetails: MOCK_DEDUCTIONS[0].currentData
    });
  });

  it('should get the deduction that is currently being modified', () => {
    deductionsStore.update('changedDeductionDetails', {
      data: {
        itemID: 'ABA',
        deductionCode: {
          codeValue: 'ABA',
          longName: 'Banking Allowance'
        },
        deductionRate: {
          rateValue: 3,
          unitCode: { codeValue: 'percent' }
        },
        deductionGoal: {
          goalLimitAmount: {
            amountValue: 13,
            currencyCode: 'USD'
          }
        }
      }
    });

    expect(deductionsStore.changedDeductionDetails).toEqual({
      itemID: 'ABA',
      deductionCode: {
        codeValue: 'ABA',
        longName: 'Banking Allowance'
      },
      deductionRate: {
        rateValue: 3,
        unitCode: { codeValue: 'percent' }
      },
      deductionGoal: {
        goalLimitAmount: {
          amountValue: 13,
          currencyCode: 'USD'
        }
      }
    });
  });

  it('should get a deduction by the itemID', () => {
    const mockDeduction: PayDeductionsUI.Deduction = {
      currentData: null,
      pendingData: {
        itemID: 'ABA',
        deductionCode: {
          codeValue: 'ABA',
          longName: 'Banking Allowance'
        },
        deductionRate: {
          rateValue: 3,
          unitCode: { codeValue: 'percent' }
        },
        deductionGoal: {
          goalLimitAmount: {
            amountValue: 13,
            currencyCode: 'USD'
          }
        }
      },
      pendingEvent: { approver: 'Guy, Some', changeType: 'add' }
    };
    payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS, {
      data: [
        {
          currentData: {
            itemID: 'BAB',
            deductionCode: {
              codeValue: 'BAB',
              longName: 'Allowance Banking'
            },
            deductionRate: {
              rateValue: 15,
              currencyCode: 'USD'
            },
            deductionGoal: {
              goalLimitAmount: {
                amountValue: 45,
                currencyCode: 'USD'
              }
            }
          },
          pendingData: null,
          pendingEvent: null
        },
        mockDeduction
      ]
    });

    expect(deductionsStore.getDeductionByID('ABA')).toEqual(mockDeduction);
  });

  describe('hasPermission', () => {
    it('should return true when user has delete permission ', () => {
      deductionsStore.update('permissions', {
        data: {
          delete: true
        }
      });

      const hasPermission = deductionsStore.hasPermission('delete');
      expect(hasPermission).toBe(true);
    });

    it('should return false when user does not have delete permission', () => {
      deductionsStore.update('permissions', {
        data: {
          delete: false
        }
      });

      const hasPermission = deductionsStore.hasPermission('delete');
      expect(hasPermission).toBe(false);
    });
  });

  describe('hasStartMetaError$', () => {
    it('should return true when there is an error with startMeta', (done: DoneFn) => {
      payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS_META, {
        error: { startMetaError: true }
      });

      deductionsStore.hasStartMetaError$.subscribe((hasError) => {
        expect(hasError).toBe(true);
        done();
      });
    });

    it('should return false when there is no error with startMeta', (done: DoneFn) => {
      deductionsStore.hasStartMetaError$.subscribe((hasError) => {
        expect(hasError).toBe(false);
        done();
      });
    });
  });

  describe('hasWorkerError$', () => {
    it('should return true when there is an error with getting the worker', (done: DoneFn) => {
      payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS_META, {
        error: { startMetaError: true, payrollGroupCodeError: true }
      });

      deductionsStore.hasWorkerError$.subscribe((hasError) => {
        expect(hasError).toBe(true);
        done();
      });
    });

    it('should return false when there is no error with getting the worker', (done: DoneFn) => {
      payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS_META, {
        error: { startMetaError: true }
      });

      deductionsStore.hasWorkerError$.subscribe((hasError) => {
        expect(hasError).toBe(false);
        done();
      });
    });
  });

  describe('hasSaveError$', () => {
    it('should return false when there is no Recall or POST error', (done: DoneFn) => {
      deductionsStore.hasSaveError$.subscribe((hasError) => {
        expect(hasError).toBe(false);
        done();
      });
    });

    it('should return true when there is an error with Recall', (done: DoneFn) => {
      payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS, {
        error: { recallError: true }
      });

      deductionsStore.hasSaveError$.subscribe((hasError) => {
        expect(hasError).toBe(true);
        done();
      });
    });

    it('should return true when there is an error with POST', (done: DoneFn) => {
      payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS, {
        error: { postError: true }
      });

      deductionsStore.hasSaveError$.subscribe((hasError) => {
        expect(hasError).toBe(true);
        done();
      });
    });
  });

  describe('maxDeductionsReached$', () => {
    it('should return true when max deductions are reached', (done: DoneFn) => {
      payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS_META, {
        data: { maxDeductionsReached: true }
      });

      deductionsStore.maxDeductionsReached$.subscribe((maxReached) => {
        expect(maxReached).toBe(true);
        done();
      });
    });

    it('should return false when max deductions have not been reached', (done: DoneFn) => {
      payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS_META, {
        data: { maxDeductionsReached: false }
      });

      deductionsStore.maxDeductionsReached$.subscribe((maxReached) => {
        expect(maxReached).toBe(false);
        done();
      });
    });
  });

  describe('hasUnsavedAdd', () => {
    it('should return true when there is an unsaved add', () => {
      deductionsStore.update('changes', {
        data: {
          changeType: 'add',
          deductionDetails: MOCK_DEDUCTIONS[0].currentData
        }
      });

      expect(deductionsStore.hasUnsavedAdd).toBe(true);
    });

    it('should return false when there is not an unsaved add', () => {
      deductionsStore.update('changes', {
        data: {
          changeType: 'edit',
          deductionDetails: MOCK_DEDUCTIONS[0].currentData
        }
      });

      expect(deductionsStore.hasUnsavedAdd).toBe(false);
    });
  });

  describe('isLoading$', () => {
    it('should return true when deductions and meta is loading', (done: DoneFn) => {
      payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS, {
        loading: true
      });
      payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS_META, {
        loading: true
      });

      deductionsStore.isLoading$.subscribe((loading) => {
        expect(loading).toBeTrue();
        done();
      });
    });

    it('should return true when meta is loading and deductions is not', (done: DoneFn) => {
      payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS, {
        loading: false
      });
      payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS_META, {
        loading: true
      });

      deductionsStore.isLoading$.subscribe((loading) => {
        expect(loading).toBeTrue();
        done();
      });
    });

    it('should return false when deductions and meta are not loading', (done: DoneFn) => {
      payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS, {
        loading: false
      });
      payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS_META, {
        loading: false
      });

      deductionsStore.isLoading$.subscribe((loading) => {
        expect(loading).toBeFalse();
        done();
      });
    });
  });

  describe('isDeductionsLoading$', () => {
    it('should return true when pay deductions is loading', (done: DoneFn) => {
      payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS, {
        loading: true
      });

      deductionsStore.isDeductionsLoading$.subscribe((loading) => {
        expect(loading).toBeTrue();
        done();
      });
    });

    it('should return false when pay deductions is not loading', (done: DoneFn) => {
      payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS, {
        loading: false
      });

      deductionsStore.isDeductionsLoading$.subscribe((loading) => {
        expect(loading).toBeFalse();
        done();
      });
    });
  });
});
