import { fakeAsync, flush, TestBed } from '@angular/core/testing';
import { LoggerFactory } from '@espresso/core';
import { Mock } from 'ts-mockery';

import {
  BaseHttpClient,
  LanguageService,
  ROLE,
  UserIdentityService,
  WorkflowRecallService
} from '@myadp/common';
import { CodeListService, Meta, MetaService, UrlTransform } from '@myadp/forms';
import { PAY_SFFO } from '@myadp/pay-shared';
import { MockLoggerFactory } from '@specHelpers';
import {
  MOCK_DEDUCTIONS,
  MOCK_PAY_DEDUCTIONS_DEDUCTION_META,
  MOCK_PAY_DEDUCTIONS_DEDUCTION_META_CURRENCY,
  MOCK_PAY_DEDUCTIONS_DEDUCTIONS_STOP_META,
  MOCK_PAY_DEDUCTIONS_DEDUCTIONS_STOP_META_NESTED_ITEM,
  MOCK_PAY_DEDUCTIONS_START_META,
  MOCK_WORKFLOW_DEDUCTIONS
} from '@specHelpers/pay/pay-deductions/pay-deductions';

import { PayrollWorkerProfileService } from '../../../services/payroll-worker-profile.service';
import { PayDeductionsStoreSlice, PayDeductionsUI } from '../models/pay-deductions-ui';
import { PayDeductionsStoreActions } from './pay-deductions-store.actions';
import { PayDeductionsStore } from './pay-deductions.store';

describe('PayDeductionsStoreActions', () => {
  let payDeductionsStoreActions: PayDeductionsStoreActions;
  let payDeductionsStore: PayDeductionsStore;
  let wfRecallService: WorkflowRecallService;
  let payrollWorkerProfileService: PayrollWorkerProfileService;
  let userIdentityService: UserIdentityService;
  let metaService: MetaService;
  let codeListService: CodeListService;
  let baseHttpClient: BaseHttpClient;

  const aoid: string = 'ABCD1337';

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        PayDeductionsStoreActions,
        PayDeductionsStore,
        {
          provide: BaseHttpClient,
          useValue: Mock.of<BaseHttpClient>({
            get: () => Promise.resolve(),
            post: () => Promise.resolve()
          })
        },
        {
          provide: MetaService,
          useValue: Mock.of<MetaService>({
            get: () => Promise.resolve(new Meta(MOCK_PAY_DEDUCTIONS_DEDUCTIONS_STOP_META)),
            getRaw: () => Promise.resolve(MOCK_PAY_DEDUCTIONS_START_META)
          })
        },
        {
          provide: LanguageService,
          useValue: Mock.of<LanguageService>({ get: (key) => key })
        },
        {
          provide: UserIdentityService,
          useValue: Mock.of<UserIdentityService>({
            getAoid: () => Promise.resolve(aoid)
          })
        },
        {
          provide: CodeListService,
          useValue: Mock.of<CodeListService>({
            getCodeListItems: () => Promise.resolve([{}])
          })
        },
        {
          provide: WorkflowRecallService,
          useValue: Mock.of<WorkflowRecallService>({
            recallEvent: () => Promise.resolve()
          })
        },
        {
          provide: PayrollWorkerProfileService,
          useValue: Mock.of<PayrollWorkerProfileService>({
            getWorker: () =>
              Promise.resolve({
                workAssignments: [
                  {
                    payrollGroupCode: 'AX9'
                  }
                ]
              })
          })
        },
        { provide: LoggerFactory, useClass: MockLoggerFactory }
      ]
    });

    payDeductionsStore = TestBed.inject(PayDeductionsStore);
    payDeductionsStoreActions = TestBed.inject(PayDeductionsStoreActions);
    wfRecallService = TestBed.inject(WorkflowRecallService);
    payrollWorkerProfileService = TestBed.inject(PayrollWorkerProfileService);
    userIdentityService = TestBed.inject(UserIdentityService);
    metaService = TestBed.inject(MetaService);
    codeListService = TestBed.inject(CodeListService);
    baseHttpClient = TestBed.inject(BaseHttpClient);
  });

  describe('loadDeductions()', () => {
    const mockDeductionsDTO = {
      currentData: {
        workerGeneralDeductionInstructions: [
          {
            generalDeductionInstructions: [
              MOCK_DEDUCTIONS[0].currentData,
              MOCK_DEDUCTIONS[1].currentData
            ]
          }
        ]
      }
    };

    it('should an make API call to get pay deductions and update the store', fakeAsync(() => {
      Mock.extend(baseHttpClient).with({
        get: () => Promise.resolve(mockDeductionsDTO)
      });
      const getSpy = baseHttpClient.get as jasmine.Spy;
      payDeductionsStoreActions.loadDeductions();
      flush();

      expect(getSpy.calls.first().args[0].useWorkflow).toBe(true);
      expect(getSpy).toHaveBeenCalledTimes(1);
      expect(payDeductionsStore.stateValue).toEqual({
        [PayDeductionsStoreSlice.PAY_DEDUCTIONS]: {
          data: [MOCK_DEDUCTIONS[0], MOCK_DEDUCTIONS[1]],
          loading: false,
          error: null
        },
        [PayDeductionsStoreSlice.PAY_DEDUCTIONS_INITIAL]: {
          data: [MOCK_DEDUCTIONS[0], MOCK_DEDUCTIONS[1]]
        },
        [PayDeductionsStoreSlice.PAY_DEDUCTIONS_META]: {
          data: {
            rawStartMeta: null
          },
          loading: false,
          error: {}
        }
      });
    }));

    it('should handle errors and updating the store when loading pay deductions', fakeAsync(() => {
      Mock.extend(baseHttpClient).with({
        get: () => Promise.reject()
      });
      const getSpy = baseHttpClient.get as jasmine.Spy;
      payDeductionsStoreActions.loadDeductions();
      flush();

      expect(getSpy).toHaveBeenCalledTimes(1);
      expect(payDeductionsStore.stateValue).toEqual(
        jasmine.objectContaining({
          [PayDeductionsStoreSlice.PAY_DEDUCTIONS]: {
            data: null,
            loading: false,
            error: {
              deductionsError: true
            }
          }
        })
      );
      expect(payDeductionsStore.stateValue).toEqual(
        jasmine.objectContaining({
          [PayDeductionsStoreSlice.PAY_DEDUCTIONS_INITIAL]: {
            data: null
          }
        })
      );
    }));

    it('should reset existing deductions error when call is  made to load deductions', fakeAsync(() => {
      Mock.extend(baseHttpClient).with({
        get: () => Promise.resolve(mockDeductionsDTO)
      });
      payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS, {
        error: {
          deductionsError: true
        }
      });

      payDeductionsStoreActions.loadDeductions();
      flush();

      expect(
        payDeductionsStore.stateValue[PayDeductionsStoreSlice.PAY_DEDUCTIONS].error
      ).toBeNull();
    }));
  });

  describe('loadStartMeta()', () => {
    it('should an make API call to get pay deductions start meta and update the store', fakeAsync(() => {
      payDeductionsStoreActions.loadStartMeta();
      flush();

      expect(codeListService.getCodeListItems).toHaveBeenCalledWith(
        '/codelists/payroll/v3/payroll-instruction-management/unused-ess-general-deduction-code-values?aoid=ABCD1337&paygroup=AX9',
        ROLE.EMPLOYEE,
        false
      );
      expect(metaService.getRaw).toHaveBeenCalledWith(
        PAY_SFFO.DEDUCTIONS_START_PERMISSION,
        undefined
      );
      expect(payrollWorkerProfileService.getWorker).toHaveBeenCalled();
      expect(userIdentityService.getAoid).toHaveBeenCalled();
      expect(payDeductionsStore.stateValue).toEqual(
        jasmine.objectContaining({
          [PayDeductionsStoreSlice.PAY_DEDUCTIONS_META]: {
            data: {
              rawStartMeta: MOCK_PAY_DEDUCTIONS_START_META,
              maxDeductionsReached: false
            },
            loading: false,
            error: null
          }
        })
      );
    }));

    it('should handle errors when there is an error getting the codeList', fakeAsync(() => {
      Mock.extend(codeListService).with({
        getCodeListItems: () => Promise.reject()
      });
      payDeductionsStoreActions.loadStartMeta();
      flush();

      expect(codeListService.getCodeListItems).toHaveBeenCalledWith(
        '/codelists/payroll/v3/payroll-instruction-management/unused-ess-general-deduction-code-values?aoid=ABCD1337&paygroup=AX9',
        ROLE.EMPLOYEE,
        false
      );
      expect(
        payDeductionsStore.hasError(PayDeductionsStoreSlice.PAY_DEDUCTIONS_META, 'startMetaError')
      ).toBe(true);
      expect(
        payDeductionsStore.hasError(
          PayDeductionsStoreSlice.PAY_DEDUCTIONS_META,
          'payrollGroupCodeError'
        )
      ).toBe(false);
      expect(
        payDeductionsStore.getData(
          PayDeductionsStoreSlice.PAY_DEDUCTIONS_META,
          'maxDeductionsReached'
        )
      ).toBeUndefined();
    }));

    it('should handle errors and updating the store when error with meta service', fakeAsync(() => {
      Mock.extend(metaService).with({
        getRaw: () => Promise.reject()
      });

      payDeductionsStoreActions.loadStartMeta();
      flush();

      expect(payDeductionsStore.stateValue).toEqual(
        jasmine.objectContaining({
          [PayDeductionsStoreSlice.PAY_DEDUCTIONS_META]: {
            data: {
              rawStartMeta: null
            },
            loading: false,
            error: {
              startMetaError: true
            }
          }
        })
      );
    }));

    it('should handle errors and updating the store when error with payrollWorkerProfileService', fakeAsync(() => {
      Mock.extend(payrollWorkerProfileService).with({
        getWorker: () => Promise.reject()
      });

      payDeductionsStoreActions.loadStartMeta();
      flush();

      expect(payDeductionsStore.stateValue).toEqual(
        jasmine.objectContaining({
          [PayDeductionsStoreSlice.PAY_DEDUCTIONS_META]: {
            data: {
              rawStartMeta: null
            },
            loading: false,
            error: {
              startMetaError: true,
              payrollGroupCodeError: true
            }
          }
        })
      );
    }));

    it('should handle errors and updating the store when error with UserIdentityService getting aoid', fakeAsync(() => {
      Mock.extend(userIdentityService).with({
        getAoid: () => Promise.reject()
      });

      payDeductionsStoreActions.loadStartMeta();
      flush();

      expect(metaService.getRaw).toHaveBeenCalledWith(
        PAY_SFFO.DEDUCTIONS_START_PERMISSION,
        undefined
      );
      expect(payDeductionsStore.stateValue).toEqual(
        jasmine.objectContaining({
          [PayDeductionsStoreSlice.PAY_DEDUCTIONS_META]: {
            data: {
              rawStartMeta: null
            },
            loading: false,
            error: {
              startMetaError: true
            }
          }
        })
      );
    }));

    it('should reset existing deductions start meta error when call is made to load start meta', fakeAsync(() => {
      payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS_META, {
        error: {
          deductionsError: true
        }
      });

      payDeductionsStoreActions.loadStartMeta();
      flush();

      expect(
        payDeductionsStore.stateValue[PayDeductionsStoreSlice.PAY_DEDUCTIONS_META].error
      ).toBeNull();
    }));
  });

  describe('loadCodeList', () => {
    it('should set maxDeductionsReached to false when codeList has unused codes', fakeAsync(() => {
      Mock.extend(codeListService).with({
        getCodeListItems: () => Promise.resolve([{}])
      });
      payDeductionsStoreActions.loadCodeList(MOCK_PAY_DEDUCTIONS_START_META);
      flush();

      expect(codeListService.getCodeListItems).toHaveBeenCalledWith(
        '/codelists/payroll/v3/payroll-instruction-management/unused-ess-general-deduction-code-values?aoid=ABCD1337&paygroup=AX9',
        ROLE.EMPLOYEE,
        false
      );
      expect(
        payDeductionsStore.getData(
          PayDeductionsStoreSlice.PAY_DEDUCTIONS_META,
          'maxDeductionsReached'
        )
      ).toBe(false);
    }));

    it('should set maxDeductionsReached to true when codeList is empty', fakeAsync(() => {
      Mock.extend(codeListService).with({
        getCodeListItems: () => Promise.resolve([])
      });
      payDeductionsStoreActions.loadCodeList(MOCK_PAY_DEDUCTIONS_START_META);
      flush();

      expect(codeListService.getCodeListItems).toHaveBeenCalledWith(
        '/codelists/payroll/v3/payroll-instruction-management/unused-ess-general-deduction-code-values?aoid=ABCD1337&paygroup=AX9',
        ROLE.EMPLOYEE,
        false
      );
      expect(
        payDeductionsStore.getData(
          PayDeductionsStoreSlice.PAY_DEDUCTIONS_META,
          'maxDeductionsReached'
        )
      ).toBe(true);
    }));

    it('should handle errors when there is an error getting the codeList', fakeAsync(() => {
      Mock.extend(codeListService).with({
        getCodeListItems: () => Promise.reject()
      });
      payDeductionsStoreActions.loadCodeList(MOCK_PAY_DEDUCTIONS_START_META);
      flush();

      expect(codeListService.getCodeListItems).toHaveBeenCalledWith(
        '/codelists/payroll/v3/payroll-instruction-management/unused-ess-general-deduction-code-values?aoid=ABCD1337&paygroup=AX9',
        ROLE.EMPLOYEE,
        false
      );
      expect(
        payDeductionsStore.hasError(PayDeductionsStoreSlice.PAY_DEDUCTIONS_META, 'startMetaError')
      ).toBe(true);
      expect(
        payDeductionsStore.hasError(
          PayDeductionsStoreSlice.PAY_DEDUCTIONS_META,
          'payrollGroupCodeError'
        )
      ).toBe(false);
      expect(
        payDeductionsStore.getData(
          PayDeductionsStoreSlice.PAY_DEDUCTIONS_META,
          'maxDeductionsReached'
        )
      ).toBeUndefined();
    }));

    it('should not get codeList when startMeta is missing', fakeAsync(() => {
      Mock.extend(codeListService).with({
        getCodeListItems: () => Promise.resolve()
      });
      payDeductionsStoreActions.loadCodeList(undefined, true);
      flush();

      expect(codeListService.getCodeListItems).not.toHaveBeenCalledWith(
        '/codelists/payroll/v3/payroll-instruction-management/unused-ess-general-deduction-code-values?aoid=ABCD1337&paygroup=AX9',
        ROLE.EMPLOYEE,
        true
      );
      expect(
        payDeductionsStore.getData(
          PayDeductionsStoreSlice.PAY_DEDUCTIONS_META,
          'maxDeductionsReached'
        )
      ).toBeUndefined();
    }));

    it('should bust codeList cache', fakeAsync(() => {
      Mock.extend(codeListService).with({
        getCodeListItems: () => Promise.resolve([{}])
      });
      payDeductionsStoreActions.loadCodeList(MOCK_PAY_DEDUCTIONS_START_META, true);
      flush();

      expect(codeListService.getCodeListItems).toHaveBeenCalledWith(
        '/codelists/payroll/v3/payroll-instruction-management/unused-ess-general-deduction-code-values?aoid=ABCD1337&paygroup=AX9',
        ROLE.EMPLOYEE,
        true
      );
      expect(
        payDeductionsStore.getData(
          PayDeductionsStoreSlice.PAY_DEDUCTIONS_META,
          'maxDeductionsReached'
        )
      ).toBe(false);
    }));
  });

  describe('loadDeductionMeta', () => {
    it('should make an API call to get deduction meta for adding a deduction and update the store', fakeAsync(() => {
      const itemID = '40A';
      Mock.extend(metaService).with({
        getRaw: (sffo, urlTransform: UrlTransform) => {
          expect(sffo).toEqual(PAY_SFFO.DEDUCTIONS_START_PERMISSION);
          expect(
            urlTransform('/events/payroll/v1/worker-general-deduction-instruction.start')
          ).toEqual(
            `/events/payroll/v1/worker-general-deduction-instruction.start/meta?associateOID=${aoid}&payrollGroupCode=AX9&deductionCode=40A`
          );
          return Promise.resolve(MOCK_PAY_DEDUCTIONS_DEDUCTION_META);
        }
      });
      payDeductionsStoreActions.loadDeductionMeta(itemID);
      flush();

      expect(payrollWorkerProfileService.getWorker).toHaveBeenCalled();
      expect(userIdentityService.getAoid).toHaveBeenCalled();
      expect(metaService.getRaw).toHaveBeenCalled();
      expect(payDeductionsStore.stateValue).toEqual(
        jasmine.objectContaining({
          [PayDeductionsStoreSlice.PAY_DEDUCTIONS_META]: {
            data: {
              rawStartMeta: null,
              addFormMeta: { [itemID]: MOCK_PAY_DEDUCTIONS_DEDUCTION_META }
            },
            loading: false,
            error: null
          }
        })
      );
    }));

    it('should make an API call to get deduction meta for editing a deduction and update the store', fakeAsync(() => {
      const itemID = '40A';
      Mock.extend(metaService).with({
        getRaw: (sffo, urlTransform: UrlTransform) => {
          expect(sffo).toEqual(PAY_SFFO.DEDUCTIONS_CHANGE_PERMISSION);
          expect(
            urlTransform('/events/payroll/v1/worker-general-deduction-instruction.change')
          ).toEqual(
            `/events/payroll/v1/worker-general-deduction-instruction.change/meta?associateOID=${aoid}`.concat(
              `&payrollGroupCode=AX9&deductionCode=40A`
            )
          );
          return Promise.resolve(MOCK_PAY_DEDUCTIONS_DEDUCTION_META_CURRENCY);
        }
      });
      payDeductionsStoreActions.loadDeductionMeta(itemID, true);
      flush();

      expect(payrollWorkerProfileService.getWorker).toHaveBeenCalled();
      expect(userIdentityService.getAoid).toHaveBeenCalled();
      expect(metaService.getRaw).toHaveBeenCalled();
      expect(payDeductionsStore.stateValue).toEqual(
        jasmine.objectContaining({
          [PayDeductionsStoreSlice.PAY_DEDUCTIONS_META]: {
            data: {
              rawStartMeta: null,
              editFormMeta: { [itemID]: MOCK_PAY_DEDUCTIONS_DEDUCTION_META_CURRENCY }
            },
            loading: false,
            error: null
          }
        })
      );
    }));

    it('should handle errors and updating the store when error with meta service', fakeAsync(() => {
      const itemID = '40A';
      Mock.extend(metaService).with({
        getRaw: () => Promise.reject()
      });
      payDeductionsStoreActions.loadDeductionMeta(itemID);
      flush();

      expect(payDeductionsStore.stateValue).toEqual(
        jasmine.objectContaining({
          [PayDeductionsStoreSlice.PAY_DEDUCTIONS_META]: {
            data: {
              rawStartMeta: null
            },
            loading: false,
            error: {
              deductionMetaError: true
            }
          }
        })
      );
    }));

    it('should handle errors when getting a 204 response', fakeAsync(() => {
      const itemID = '40A';
      Mock.extend(metaService).with({
        getRaw: () => Promise.resolve(null)
      });
      payDeductionsStoreActions.loadDeductionMeta(itemID);
      flush();

      expect(payDeductionsStore.stateValue).toEqual(
        jasmine.objectContaining({
          [PayDeductionsStoreSlice.PAY_DEDUCTIONS_META]: {
            data: {
              rawStartMeta: null
            },
            loading: false,
            error: {
              deductionMetaError: true
            }
          }
        })
      );
    }));

    it('should handle errors and updating the store when error with payrollWorkerProfileService', fakeAsync(() => {
      const itemID = '40A';
      Mock.extend(payrollWorkerProfileService).with({
        getWorker: () => Promise.reject()
      });
      payDeductionsStoreActions.loadDeductionMeta(itemID);
      flush();

      expect(payDeductionsStore.stateValue).toEqual(
        jasmine.objectContaining({
          [PayDeductionsStoreSlice.PAY_DEDUCTIONS_META]: {
            data: {
              rawStartMeta: null
            },
            loading: false,
            error: {
              deductionMetaError: true,
              payrollGroupCodeError: true
            }
          }
        })
      );
    }));

    it('should handle errors and updating the store when error with UserIdentityService getting aoid', fakeAsync(() => {
      const itemID = '40A';
      Mock.extend(userIdentityService).with({
        getAoid: () => Promise.reject()
      });
      payDeductionsStoreActions.loadDeductionMeta(itemID);
      flush();

      expect(payDeductionsStore.stateValue).toEqual(
        jasmine.objectContaining({
          [PayDeductionsStoreSlice.PAY_DEDUCTIONS_META]: {
            data: {
              rawStartMeta: null
            },
            loading: false,
            error: {
              deductionMetaError: true
            }
          }
        })
      );
    }));

    it('should reset any existing deduction meta error when call is made to load deduction meta', fakeAsync(() => {
      const itemID = '40A';
      payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS_META, {
        error: {
          deductionMetaError: true
        }
      });

      payDeductionsStoreActions.loadDeductionMeta(itemID);
      flush();

      expect(payDeductionsStore.stateValue.payDeductionsStartMeta).toEqual(
        jasmine.objectContaining({
          error: null
        })
      );
    }));
  });

  describe('recallDeduction', () => {
    it('should update deductions when recall was successful', fakeAsync(() => {
      spyOn(payDeductionsStoreActions, 'loadDeductions').and.callFake(() => Mock.noop());
      // [pendingEdit, nonPending]
      const mixedDeductions = [MOCK_WORKFLOW_DEDUCTIONS[2], MOCK_WORKFLOW_DEDUCTIONS[0]];
      payDeductionsStoreActions.updateDeductions(mixedDeductions);
      payDeductionsStoreActions.recallDeduction(mixedDeductions[0]);
      flush();

      expect(wfRecallService.recallEvent).toHaveBeenCalledWith(aoid, 'GENERAL_DEDUCTIONS_CHANGE');
      expect(payDeductionsStore.payDeductionsSnapshot).toEqual([
        {
          currentData: {
            itemID: '40A',
            deductionCode: { codeValue: '40A', longName: '401K PST-TX' },
            deductionRate: { rateValue: 15, currencyCode: 'USD' },
            deductionGoal: {
              goalBalanceAmount: { amountValue: 45, currencyCode: 'USD' },
              goalLimitAmount: { amountValue: 100, currencyCode: 'USD' }
            }
          },
          pendingData: null,
          pendingEvent: null
        },
        mixedDeductions[1]
      ]);
      expect(payDeductionsStoreActions.loadDeductions).toHaveBeenCalledTimes(1);
    }));

    it('should not update deductions when recall fails', fakeAsync(() => {
      spyOn(payDeductionsStoreActions, 'loadDeductions').and.callFake(() => Mock.noop());
      Mock.extend(wfRecallService).with({
        recallEvent: () => Promise.reject()
      });
      // [pendingEdit, nonPending]
      const mixedDeductions = [MOCK_WORKFLOW_DEDUCTIONS[2], MOCK_WORKFLOW_DEDUCTIONS[0]];
      payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS, {
        data: mixedDeductions
      });
      payDeductionsStoreActions.recallDeduction(mixedDeductions[0]);
      flush();

      expect(wfRecallService.recallEvent).toHaveBeenCalledWith(aoid, 'GENERAL_DEDUCTIONS_CHANGE');
      expect(payDeductionsStore.stateValue[PayDeductionsStoreSlice.PAY_DEDUCTIONS]).toEqual({
        data: mixedDeductions,
        loading: false,
        error: { recallError: true }
      });
      expect(payDeductionsStoreActions.loadDeductions).toHaveBeenCalledTimes(0);
    }));

    it('should recall a pending add', fakeAsync(() => {
      const pendingAddDeduction = MOCK_WORKFLOW_DEDUCTIONS[1];
      payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS, {
        data: [pendingAddDeduction]
      });
      payDeductionsStoreActions.recallDeduction(pendingAddDeduction);
      flush();

      expect(wfRecallService.recallEvent).toHaveBeenCalledWith(aoid, 'GENERAL_DEDUCTIONS_START');
    }));

    it('should recall a pending edit', fakeAsync(() => {
      const pendingEditDeduction = MOCK_WORKFLOW_DEDUCTIONS[2];
      payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS, {
        data: [pendingEditDeduction]
      });
      payDeductionsStoreActions.recallDeduction(pendingEditDeduction);
      flush();

      expect(wfRecallService.recallEvent).toHaveBeenCalledWith(aoid, 'GENERAL_DEDUCTIONS_CHANGE');
    }));

    it('should recall a pending delete', fakeAsync(() => {
      const pendingDeleteDeduction = MOCK_WORKFLOW_DEDUCTIONS[3];
      payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS, {
        data: [pendingDeleteDeduction]
      });
      payDeductionsStoreActions.recallDeduction(pendingDeleteDeduction);
      flush();

      expect(wfRecallService.recallEvent).toHaveBeenCalledWith(aoid, 'GENERAL_DEDUCTIONS_STOP');
    }));
  });

  describe('postDeduction', () => {
    const mockDeductionData: PayDeductionsUI.DeductionDetails = {
      deductionCode: {
        codeValue: '40A'
      },
      deductionRate: {
        rateValue: 2,
        currencyCode: 'USD'
      },
      deductionGoal: {
        goalLimitAmount: {
          amountValue: 4,
          currencyCode: 'USD'
        }
      }
    };

    it('should make a POST API call to add a deduction', fakeAsync(() => {
      const postSpy = baseHttpClient.post as jasmine.Spy;
      payDeductionsStoreActions.postDeduction(mockDeductionData, 'add');
      flush();

      expect(postSpy.calls.first().args[0].userPermission).toEqual(
        PAY_SFFO.DEDUCTIONS_START_PERMISSION
      );
      expect(postSpy.calls.first().args[0].payload).toEqual({
        events: [
          {
            data: {
              transform: {
                workerGeneralDeductionInstruction: {
                  generalDeductionInstruction: {
                    deductionCode: {
                      codeValue: '40A'
                    },
                    deductionRate: {
                      rateValue: 2,
                      currencyCode: 'USD'
                    },
                    deductionGoal: {
                      goalLimitAmount: {
                        amountValue: 4,
                        currencyCode: 'USD'
                      }
                    }
                  }
                }
              },
              eventContext: {
                worker: {
                  associateOID: aoid
                }
              }
            },
            actor: {
              associateOID: aoid
            },
            serviceCategoryCode: {
              codeValue: 'payrollManagement'
            },
            eventNameCode: {
              codeValue: 'workerGeneralDeductionInstruction.start'
            }
          }
        ]
      });
      expect(postSpy.calls.first().args[0].useWorkflow).toBe(true);
      expect(postSpy).toHaveBeenCalledTimes(1);
    }));

    it('should make a POST API call to change an existing deduction', fakeAsync(() => {
      const postSpy = baseHttpClient.post as jasmine.Spy;
      payDeductionsStoreActions.postDeduction(mockDeductionData, 'edit');
      flush();

      expect(postSpy.calls.first().args[0].userPermission).toEqual(
        PAY_SFFO.DEDUCTIONS_CHANGE_PERMISSION
      );
      expect(postSpy.calls.first().args[0].payload).toEqual({
        events: [
          {
            data: {
              transform: {
                workerGeneralDeductionInstruction: {
                  generalDeductionInstruction: {
                    deductionRate: {
                      rateValue: 2,
                      currencyCode: 'USD'
                    },
                    deductionGoal: {
                      goalLimitAmount: {
                        amountValue: 4,
                        currencyCode: 'USD'
                      }
                    }
                  }
                }
              },
              eventContext: {
                worker: {
                  associateOID: aoid
                },
                workerGeneralDeductionInstruction: {
                  generalDeductionInstruction: {
                    itemID: '40A'
                  }
                }
              }
            },
            actor: {
              associateOID: aoid
            },
            serviceCategoryCode: {
              codeValue: 'payrollManagement'
            },
            eventNameCode: {
              codeValue: 'workerGeneralDeductionInstruction.change'
            }
          }
        ]
      });
      expect(postSpy.calls.first().args[0].useWorkflow).toBe(true);
      expect(postSpy).toHaveBeenCalledTimes(1);
    }));

    it('should handle errors and updating the store when POST API call is made', fakeAsync(() => {
      Mock.extend(baseHttpClient).with({
        post: () => Promise.reject()
      });
      const postSpy = baseHttpClient.post as jasmine.Spy;
      payDeductionsStoreActions.postDeduction(mockDeductionData, 'add').catch(() => undefined);
      flush();

      expect(postSpy).toHaveBeenCalledTimes(1);
      expect(payDeductionsStore.stateValue).toEqual(
        jasmine.objectContaining({
          [PayDeductionsStoreSlice.PAY_DEDUCTIONS]: {
            data: null,
            loading: false,
            error: {
              postError: true
            }
          }
        })
      );
    }));

    it('should handle errors and updating the store when error with UserIdentityService getting aoid', fakeAsync(() => {
      Mock.extend(userIdentityService).with({
        getAoid: () => Promise.reject()
      });
      payDeductionsStoreActions.postDeduction(mockDeductionData, 'add').catch(() => undefined);
      flush();

      expect(payDeductionsStore.stateValue).toEqual(
        jasmine.objectContaining({
          [PayDeductionsStoreSlice.PAY_DEDUCTIONS]: {
            data: null,
            loading: false,
            error: {
              postError: true
            }
          }
        })
      );
    }));
  });

  describe('stopDeduction', () => {
    const mockStopDeductionData: PayDeductionsUI.DeductionDetails = {
      deductionCode: {
        codeValue: '40A'
      }
    };

    it('should make a stop meta and POST API call to stop a deduction when itemID is not nested', fakeAsync(() => {
      const postSpy = baseHttpClient.post as jasmine.Spy;
      payDeductionsStoreActions.stopDeduction(mockStopDeductionData);
      flush();

      expect(metaService.get).toHaveBeenCalledWith(PAY_SFFO.DEDUCTIONS_STOP_PERMISSION);
      expect(postSpy.calls.first().args[0].userPermission).toEqual(
        PAY_SFFO.DEDUCTIONS_STOP_PERMISSION
      );
      expect(postSpy.calls.first().args[0].payload).toEqual({
        events: [
          {
            data: {
              eventContext: {
                worker: {
                  associateOID: aoid
                },
                workerGeneralDeductionInstruction: {
                  itemID: '40A'
                }
              }
            },
            actor: {
              associateOID: aoid
            },
            serviceCategoryCode: {
              codeValue: 'payrollManagement'
            },
            eventNameCode: {
              codeValue: 'workerGeneralDeductionInstruction.stop'
            }
          }
        ]
      });
      expect(postSpy.calls.first().args[0].useWorkflow).toBe(true);
      expect(postSpy).toHaveBeenCalledTimes(1);
    }));

    it('should make a stop meta and POST API call to stop a deduction when itemID is nested', fakeAsync(() => {
      Mock.extend(metaService).with({
        get: () => Promise.resolve(new Meta(MOCK_PAY_DEDUCTIONS_DEDUCTIONS_STOP_META_NESTED_ITEM))
      });
      const postSpy = baseHttpClient.post as jasmine.Spy;
      payDeductionsStoreActions.stopDeduction(mockStopDeductionData);
      flush();

      expect(metaService.get).toHaveBeenCalledWith(PAY_SFFO.DEDUCTIONS_STOP_PERMISSION);
      expect(postSpy.calls.first().args[0].userPermission).toEqual(
        PAY_SFFO.DEDUCTIONS_STOP_PERMISSION
      );
      expect(postSpy.calls.first().args[0].payload).toEqual({
        events: [
          {
            data: {
              eventContext: {
                worker: {
                  associateOID: aoid
                },
                workerGeneralDeductionInstruction: {
                  generalDeductionInstruction: {
                    itemID: '40A'
                  }
                }
              }
            },
            actor: {
              associateOID: aoid
            },
            serviceCategoryCode: {
              codeValue: 'payrollManagement'
            },
            eventNameCode: {
              codeValue: 'workerGeneralDeductionInstruction.stop'
            }
          }
        ]
      });
      expect(postSpy.calls.first().args[0].useWorkflow).toBe(true);
      expect(postSpy).toHaveBeenCalledTimes(1);
    }));

    it('should handle errors and updating the store when error with metaService call is received', fakeAsync(() => {
      Mock.extend(metaService).with({
        get: () => Promise.reject()
      });
      const postSpy = baseHttpClient.post as jasmine.Spy;
      payDeductionsStoreActions.stopDeduction(mockStopDeductionData);
      flush();

      expect(postSpy).toHaveBeenCalledTimes(0);
      expect(payDeductionsStore.stateValue).toEqual(
        jasmine.objectContaining({
          [PayDeductionsStoreSlice.PAY_DEDUCTIONS]: {
            data: null,
            loading: false,
            error: {
              stopError: true
            }
          }
        })
      );
    }));

    it('should handle errors and updating the store when POST API call is made', fakeAsync(() => {
      Mock.extend(baseHttpClient).with({
        post: () => Promise.reject()
      });
      const postSpy = baseHttpClient.post as jasmine.Spy;
      payDeductionsStoreActions.stopDeduction(mockStopDeductionData);
      flush();

      expect(postSpy).toHaveBeenCalledTimes(1);
      expect(payDeductionsStore.stateValue).toEqual(
        jasmine.objectContaining({
          [PayDeductionsStoreSlice.PAY_DEDUCTIONS]: {
            data: null,
            loading: false,
            error: {
              stopError: true
            }
          }
        })
      );
    }));

    it('should handle errors and updating the store when error with UserIdentityService getting aoid', fakeAsync(() => {
      Mock.extend(userIdentityService).with({
        getAoid: () => Promise.reject()
      });
      payDeductionsStoreActions.stopDeduction(mockStopDeductionData);
      flush();

      expect(payDeductionsStore.stateValue).toEqual(
        jasmine.objectContaining({
          [PayDeductionsStoreSlice.PAY_DEDUCTIONS]: {
            data: null,
            loading: false,
            error: {
              stopError: true
            }
          }
        })
      );
    }));
  });

  describe('revertToInitialDeductions', () => {
    it('should revert deductions and meta slices to initial state', () => {
      payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS_INITIAL, {
        data: [MOCK_DEDUCTIONS[0]]
      });
      payDeductionsStoreActions.updateDeductions([MOCK_DEDUCTIONS[0], MOCK_DEDUCTIONS[1]]);
      payDeductionsStoreActions.revertToInitialDeductions();

      expect(payDeductionsStore.payDeductionsSnapshot).toEqual([MOCK_DEDUCTIONS[0]]);
      expect(
        payDeductionsStore.stateValue[PayDeductionsStoreSlice.PAY_DEDUCTIONS_META]?.loading
      ).toBeFalse();
      expect(
        payDeductionsStore.stateValue[PayDeductionsStoreSlice.PAY_DEDUCTIONS_META]?.error
      ).toBeNull();
    });

    it('should reset existing deduction errors when call is made to revert to initial deductions', () => {
      payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS, {
        error: {
          deductionsError: true
        }
      });

      payDeductionsStoreActions.revertToInitialDeductions();

      expect(
        payDeductionsStore.stateValue[PayDeductionsStoreSlice.PAY_DEDUCTIONS].error
      ).toBeNull();
      expect(
        payDeductionsStore.stateValue[PayDeductionsStoreSlice.PAY_DEDUCTIONS_META].error
      ).toBeNull();
    });
  });
});
