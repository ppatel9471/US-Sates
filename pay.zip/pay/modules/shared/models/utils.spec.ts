import { formatDate } from './utils';

describe('formatDate', () => {
  it('should format date from YYYY-MM-DD to ll by default', () => {
    expect(formatDate('2019-06-27')).toBe('Jun 27, 2019');
  });

  it('should format date from YYYY-MM-DD to YYYY-MM-DD', () => {
    expect(formatDate('2019-06-27', 'YYYY-MM-DD')).toBe('2019-06-27');
  });

  it('should format date from YYYY-MM-DD to MM-DD-YYYY', () => {
    expect(formatDate('2019-06-27', 'MM-DD-YYYY')).toBe('06-27-2019');
  });

  it('should return null if source date is invalid or has invalid format', () => {
    expect(formatDate('2019-06-2')).toBeNull();
    expect(formatDate('06-27-2019')).toBeNull();
    expect(formatDate('')).toBeNull();
    expect(formatDate(null)).toBeNull();
    expect(formatDate(undefined)).toBeNull();
  });
});
