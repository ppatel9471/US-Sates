import { TestBed } from '@angular/core/testing';
import { cloneDeep } from 'lodash';
import { Mock } from 'ts-mockery';

import { LanguageService } from '@myadp/common';

import { WithholdingItem } from '../models/formatted-tax-withholding.model';
import { TaxWithholdingStore } from './tax-withholding.store';

describe('TaxWithholdingStore', () => {
  let store: TaxWithholdingStore;

  const FedWithholdingItem: WithholdingItem = {
    state: {
      shortName: 'FED',
      longName: 'Federal',
      countryCode: 'US'
    },
    attachments: [{ gssUrl: 'gss url federal' }]
  };
  const StateWithholdingItems: WithholdingItem[] = [
    {
      state: {
        shortName: 'GA',
        longName: 'Georgia',
        countryCode: 'US'
      },
      effectiveDate: '12/01/2019',
      rawData: {
        attachments: [{ shortName: 'L-4', gssUrl: 'gss url 1' }]
      },
      attachments: [{ shortName: 'L-4', gssUrl: 'gss url 1' }]
    },
    {
      state: {
        shortName: 'NY',
        longName: 'New York',
        countryCode: 'US'
      },
      effectiveDate: null,
      rawData: {
        attachments: []
      },

      attachments: [{ shortName: 'G-4', gssUrl: 'gss url 2' }]
    },
    {
      state: {
        shortName: 'OR',
        longName: 'Oregon',
        countryCode: 'US'
      },
      effectiveDate: null,
      isUneditable: true,
      rawData: {
        attachments: []
      }
    },
    {
      state: {
        shortName: 'FL',
        longName: 'Florida',
        countryCode: 'US'
      },
      rawData: {
        attachments: []
      },
      effectiveDate: null,
      isNoIncomeTax: true
    },
    {
      state: {
        shortName: 'PA',
        longName: 'Pennsylvania',
        countryCode: 'US'
      },
      rawData: {
        attachments: []
      },
      effectiveDate: null,
      isFlatRate: true
    },
    {
      state: {
        shortName: 'AL',
        longName: 'Alabama',
        countryCode: 'US'
      },
      rawData: {
        attachments: []
      },
      effectiveDate: null,
      pendingSummaryItems: [
        {
          displayName: 'test heading',
          displayValue: 'test value'
        }
      ]
    },
    {
      state: {
        shortName: 'GU',
        longName: 'Guam',
        countryCode: 'GA'
      },
      rawData: {
        attachments: []
      },
      effectiveDate: null,
      isUnsupported: true
    }
  ];

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        TaxWithholdingStore,
        {
          provide: LanguageService,
          useValue: Mock.of<LanguageService>({
            get: (key, placeholder) => {
              placeholder = placeholder ? JSON.stringify(placeholder) : '';
              return `${key}${placeholder}`;
            }
          })
        }
      ]
    });
    store = TestBed.inject(TaxWithholdingStore);

    store.federalWithholding = {
      withholdingItems: [FedWithholdingItem]
    };
    store.stateWithholding = {
      withholdingItems: StateWithholdingItems
    };
  });

  it('should find federal withholding item', () => {
    const item = store.findWithholdingItem('Federal');
    expect(item).toEqual(FedWithholdingItem);
  });

  it('should find state withholding item by state long name', () => {
    const item = store.findWithholdingItem('Georgia');
    expect(item).toEqual(StateWithholdingItems[0]);
  });

  it('method should only get state withholding items based on active items filter', () => {
    const withholdingItems = store.getActiveWithholdingItems();
    expect(withholdingItems.length).toEqual(6);
    expect(withholdingItems[1].state.shortName).toEqual(StateWithholdingItems[0].state.shortName);
    expect(withholdingItems[2].state.shortName).toEqual(StateWithholdingItems[3].state.shortName);
    expect(withholdingItems[3].state.shortName).toEqual(StateWithholdingItems[4].state.shortName);
    expect(withholdingItems[4].state.shortName).toEqual(StateWithholdingItems[5].state.shortName);
    expect(withholdingItems[5].state.shortName).toEqual(StateWithholdingItems[6].state.shortName);
  });

  it('method should getWithholdingForms', () => {
    const pdfStatements = store.getWithholdingForms();
    expect(pdfStatements.length).toEqual(2);
    expect(pdfStatements[1].uri).toEqual(StateWithholdingItems[0].attachments[0].gssUrl);
    // doesn't include form type
    expect(pdfStatements[0].title).toEqual(
      'myadp-pay.PDF_VIEWER_SLIDEIN_HEADER_TAX_WITHHOLDING{"state":"Federal","form":""}'
    );
    expect(pdfStatements[0].statementDetails[0].value).toEqual('myadp-pay.FEDERAL');
    // include form type
    expect(pdfStatements[1].title).toEqual(
      'myadp-pay.PDF_VIEWER_SLIDEIN_HEADER_TAX_WITHHOLDING{"state":"Georgia","form":"L-4"}'
    );
    expect(pdfStatements[1].statementDetails[0].value).toEqual('myadp-pay.STATE');
  });

  it('method should getWithholdingForms when having no attachments', () => {
    const stateWithholdingWithNoPdf = cloneDeep(StateWithholdingItems);
    stateWithholdingWithNoPdf[0].attachments = undefined;
    stateWithholdingWithNoPdf[1].attachments = undefined;
    FedWithholdingItem.attachments = undefined;
    store.stateWithholding = {
      withholdingItems: stateWithholdingWithNoPdf
    };
    const pdfStatements = store.getWithholdingForms();
    expect(pdfStatements.length).toEqual(0);
  });

  it('method should only get state withholding items based on inactive items filter', () => {
    const withholdingItems = store.getInactiveWithholdingItems();
    expect(withholdingItems.length).toEqual(2);
    expect(withholdingItems[0].state.shortName).toEqual(StateWithholdingItems[1].state.shortName);
    expect(withholdingItems[1].state.shortName).toEqual(StateWithholdingItems[2].state.shortName);
  });

  it('method should return null if no livedIn state is set', () => {
    expect(store.getLivedInState()).toEqual(null);
  });

  it('method should get livedIn state when set', () => {
    StateWithholdingItems[0].livedIn = true;
    expect(store.getLivedInState()).toEqual('Georgia');
  });
});
