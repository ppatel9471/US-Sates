import { Injectable } from '@angular/core';
import { CurrencyPipe } from '@angular/common';
import { CURRENCY, LanguageService } from '@myadp/common';

import { Amount } from '@myadp/dto';
import * as moment from 'moment';

import { AdditionalTaxAmount } from '../../../models/tax-withholding.model';

export const enum ValueFormatterType {
  Boolean = 'boolean',
  Currency = 'currency',
  Percentage = 'percentage',
  Date = 'date'
}

@Injectable({
  providedIn: 'root'
})
export class ValueFormatterService {
  private formatterLookup: Record<
  ValueFormatterType,
  (value: boolean | string | Amount | AdditionalTaxAmount, digitsInfo?: string) => string
  > = {
    [ValueFormatterType.Boolean]: (value: boolean) => this.formatBoolean(value),
    [ValueFormatterType.Percentage]: (value: string) => `${value}%`,
    [ValueFormatterType.Currency]: (value: Amount | AdditionalTaxAmount, digitsInfo?: string) =>
      this.formatCurrency(value, digitsInfo),
    [ValueFormatterType.Date]: (value: string) => this.formatDate(value)
  };

  constructor(private currencyPipe: CurrencyPipe,
    private languageService: LanguageService) {}

  /**
   * @param value Value to format
   * @param formatter Formatter type to use (Boolean, Percentage, or Currency)
   * @param digitsInfo Angular's CurrencyPipe digitsInfo format: `{minIntegerDigits}.{minFractionDigits}-{maxFractionDigits}`
   */
  public format(
    value: any,
    formatter: ValueFormatterType | string,
    digitsInfo?: string
  ): string | any {
    if (Object.keys(this.formatterLookup).includes(formatter)) {
      return this.formatterLookup[formatter](value, digitsInfo);
    }

    return value;
  }

  private formatBoolean(value: boolean): string {
    return value ? this.languageService.get('common.YES') : this.languageService.get('common.NO');
  }

  private formatCurrency(value: Amount | AdditionalTaxAmount, digitsInfo?: string): string {
    const currencyCode = value?.currencyCode ?? CURRENCY.CODE.USD;

    return this.currencyPipe.transform(value?.amountValue, currencyCode, 'symbol', digitsInfo);
  }

  private formatDate(value: string): string {
    return (value && moment(value).isValid()) ? moment(value).format('YYYY-MM-DD') : value;
  }
}
