import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import * as moment from 'moment';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { Notification, NotificationCodeType } from '@myadp/thingstodo-shared';
import { FederalWithholdingTransformService } from '../../../shared/services/federal-withholding-transform.service';
import { StateWithholdingTransformService } from '../../../shared/services/state-withholding-transform.service';

import { UsFederalTaxWithholdingElections } from '../../../../models/us-federal-tax-withholding-election.model';
import { UsStateTaxWithholdingElections } from '../../../../models/us-state-tax-withholding-election.model';
import { WithholdingItem } from '../../../../models/formatted-tax-withholding.model';
import { TaxWithholdingDetails } from '../models/tax-withholding-details.model';

@Injectable({
  providedIn: 'root'
})
export class TaxWithholdingService {
  EVENT_NAME_CODE_STATE = 'worker.usState.taxWithholding.election.change';

  constructor(
    private http: HttpClient,
    private federalWithholdingTransformService: FederalWithholdingTransformService,
    private stateWithholdingTransformService: StateWithholdingTransformService
  ) {}

  public getWithholding(task: Notification): Observable<TaxWithholdingDetails> {
    const url = this.getDetailsUrl(task, task.notificationType.code);
    const headers = this.getHeaders(task);

    return this.http.get(url, { headers }).pipe(map(election => this.transform(election)));
  }

  private getDetailsUrl(task: Notification, notificationType: NotificationCodeType): string {
    const effectiveDate = moment().format('YYYY-MM-DD');
    const taskId = this.getTaskId(task);
    const jurisdiction = this.getJurisdiction(task);

    return (
      `/payroll/v2/workers/${task.relatedAssociateRef.aoid}/us-${jurisdiction}-tax-withholding-elections` +
      `?remoteid=${task.remoteId}` +
      `&effectiveDate=${effectiveDate}` +
      `&${notificationType}id=${taskId}`
    );
  }

  private getHeaders(task: Notification): HttpHeaders {
    return new HttpHeaders().set('workflowId', String(task.remoteId));
  }

  private getTaskId(task: Notification): string {
    return task.uri.split('/')[5];
  }

  private getJurisdiction(task: Notification): 'state' | 'federal' {
    return task.eventNameCode === this.EVENT_NAME_CODE_STATE ? 'state' : 'federal';
  }

  private transform(
    elections: UsFederalTaxWithholdingElections | UsStateTaxWithholdingElections
  ): TaxWithholdingDetails {
    const taxWithholdingDetails = new TaxWithholdingDetails(elections);
    let withholdingItems: WithholdingItem[];

    if (taxWithholdingDetails.isFederal()) {
      withholdingItems = this.federalWithholdingTransformService.getWithholdingItems(
        <UsFederalTaxWithholdingElections>elections
      );
    } else {
      withholdingItems = this.stateWithholdingTransformService.getWithholdingItems(
        <UsStateTaxWithholdingElections>elections
      );
    }

    taxWithholdingDetails.withholdingItem = withholdingItems.find(
      item => item.pendingEvents != null
    );

    return taxWithholdingDetails;
  }
}
