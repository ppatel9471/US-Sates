import { Component, Input } from '@angular/core';

import { STATUS_CODE_LABEL } from '@myadp/thingstodo-shared';

@Component({
  selector: 'pay-workflow-details-comparison',
  templateUrl: './workflow-details-comparison.component.html'
})
export class WorkflowDetailsComparisonComponent<DataType, ComparisonDetailsType> {
  @Input() data: DataType;
  @Input() statusCodeLabel?: string = STATUS_CODE_LABEL.pending;
  @Input() taskActionTaken?: string;
  public currentComparisonData: ComparisonDetailsType;
  public pendingComparisonData: ComparisonDetailsType;
}
