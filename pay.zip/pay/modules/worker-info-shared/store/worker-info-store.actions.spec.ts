import { DatePipe } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { fakeAsync, flush, TestBed } from '@angular/core/testing';
import { LoggerFactory } from '@espresso/core';
import * as moment from 'moment';
import { of, throwError } from 'rxjs';
import { Mock } from 'ts-mockery';

import { UserProfileService } from '@myadp/common';
import { CodeListItem, PayrollWorker, Worker, WorkerDates } from '@myadp/dto';
import { MockLoggerFactory } from '@specHelpers';

import {
  MOCK_PAYROLL_WORKER_WORK_ASSIGNMENTS,
  MOCK_WORK_ASSIGNMENTS
} from '../../../../../../src/spec-helpers/pay/pay-statement/pay-statement-details';
import { PayrollWorkerProfileService } from '../../../services/payroll-worker-profile.service';
import { EMPTY_WORKER_INFO_STORE, WorkerInfoStoreSlice } from '../models/worker-info-state.model';
import { WorkerInfo } from '../models/worker-info.model';
import { WorkerInfoStoreActions } from './worker-info-store.actions';
import { WorkerInfoStore } from './worker-info.store';

describe('WorkerInfoStoreActions', () => {
  let workerInfoStoreActions: WorkerInfoStoreActions;
  let workerInfoStore: WorkerInfoStore;
  let payrollWorkerProfileService: PayrollWorkerProfileService;
  let mockIsRun: boolean;
  let mockHasWorkerProfile: boolean;
  const today = moment().format('YYYY-MM-DD');

  const mockWorkerDates: WorkerDates = {
    originalHireDate: '2011-11-11',
    rehireDate: null,
    adjustedServiceDate: null
  };

  const mockWorker: Worker = {
    associateOID: '1',
    workAssignments: MOCK_WORK_ASSIGNMENTS,
    person: {
      communication: {
        mobiles: [{ formattedNumber: '1234567890' }],
        landlines: [{ formattedNumber: '9876543210' }]
      },
      legalName: {
        givenName: 'Rachel',
        familyName1: 'Melony',
        middleName: 'Lisa',
        generationAffixCode: { longName: 'Jr', codeValue: '1' }
      },
      legalAddress: {
        lineOne: '123 Westside Pkwy'
      },
      governmentIDs: [
        {
          idValue: 'XXXXX6789',
          itemID: 'SSN',
          nameCode: {
            codeValue: 'SSN',
            shortName: 'SSN',
            longName: 'Social Security Number'
          }
        }
      ],
      birthDate: 'XXXX-12-01'
    },
    workerDates: mockWorkerDates
  };

  const mockWorkerProfile: PayrollWorker = {
    associateOID: '2',
    person: {
      governmentIDs: [
        {
          itemID: 'SSN',
          idValue: 'XXXXX1234',
          nameCode: { codeValue: 'SSN', shortName: 'SSN', longName: 'Social Security Number' },
          statusCode: { codeValue: 'VALID', longName: 'Valid' }
        }
      ],
      legalName: { givenName: 'Jasmine', familyName1: 'Wilson', formattedName: 'Wilson,Jasmine' },
      legalAddress: {
        lineOne: '2816 Woodstock Drive',
        cityName: 'Arcadia',
        countrySubdivisionLevel1: {
          subdivisionType: 'State',
          codeValue: 'CA',
          longName: 'California'
        },
        countryCode: 'US',
        postalCode: '91006'
      }
    },
    workerDates: { originalHireDate: '2014-11-11', adjustedServiceDate: null },
    workAssignment: MOCK_PAYROLL_WORKER_WORK_ASSIGNMENTS
  };

  const mockSSNWorker: Worker = {
    associateOID: 'MockAOID',
    person: {
      governmentIDs: [
        {
          itemID: 'SSN',
          idValue: '123456789',
          nameCode: <CodeListItem>{}
        }
      ]
    }
  };

  const mockBirthDate: Worker = {
    associateOID: 'MockAOID',
    person: {
      birthDate: '1980-12-01'
    }
  };

  const mockRunWorker: Worker = {
    associateOID: '1',
    person: {
      governmentIDs: [
        {
          idValue: '123456789',
          nameCode: {
            codeValue: 'SSN',
            shortName: 'Social Security Number'
          }
        }
      ],
      birthDate: '1980-12-01'
    }
  };

  const mockWorkerInfo: WorkerInfo = {
    legalName: {
      givenName: 'Rachel',
      familyName1: 'Melony',
      middleName: 'Lisa',
      generationAffixCode: { longName: 'Jr', codeValue: '1' }
    },
    legalAddress: { lineOne: '123 Westside Pkwy' },
    birthDate: 'XXXX-12-01',
    associateOID: '1'
  };

  const mockWorkerProfileWorkerInfo: WorkerInfo = {
    legalName: { givenName: 'Jasmine', familyName1: 'Wilson', formattedName: 'Wilson,Jasmine' },
    legalAddress: {
      lineOne: '2816 Woodstock Drive',
      cityName: 'Arcadia',
      countrySubdivisionLevel1: {
        subdivisionType: 'State',
        codeValue: 'CA',
        longName: 'California'
      },
      countryCode: 'US',
      postalCode: '91006'
    },
    birthDate: null,
    associateOID: '2'
  };

  beforeEach(() => {
    mockIsRun = false;
    mockHasWorkerProfile = true;

    TestBed.configureTestingModule({
      providers: [
        WorkerInfoStoreActions,
        DatePipe,
        WorkerInfoStore,
        {
          provide: PayrollWorkerProfileService,
          useValue: Mock.of<PayrollWorkerProfileService>({
            getWorker: () => Promise.resolve(mockWorker),
            getWorkAssignmentsFromWorker: () =>
              Promise.resolve({ workAssignments: MOCK_WORK_ASSIGNMENTS }),
            getWorkerDatesFromWorker: () => Promise.resolve(mockWorker),
            getUnmaskedDataFromWorker$: (type: string) => {
              if (mockIsRun) {
                return of(mockRunWorker);
              }
              if (type === WorkerInfoStoreSlice.WORKER_BIRTHDATE) {
                return of(mockBirthDate);
              }
              return of(mockSSNWorker);
            }
          })
        },
        {
          provide: LoggerFactory,
          useClass: MockLoggerFactory
        },
        {
          provide: UserProfileService,
          useValue: Mock.of<UserProfileService>({
            isRun: () => mockIsRun,
            hasWorkerProfile: () => mockHasWorkerProfile
          })
        }
      ]
    });

    workerInfoStoreActions = TestBed.inject(WorkerInfoStoreActions);
    workerInfoStore = TestBed.inject(WorkerInfoStore);
    payrollWorkerProfileService = TestBed.inject(PayrollWorkerProfileService);
  });

  it('should get worker', fakeAsync(() => {
    spyOn(workerInfoStore, 'update').and.callThrough();
    workerInfoStoreActions.getWorker(true);
    flush();

    expect(payrollWorkerProfileService.getWorker).toHaveBeenCalledWith(true);
    expect(workerInfoStore.update).toHaveBeenCalledWith(WorkerInfoStoreSlice.WORKER, {
      loading: true
    });
    expect(workerInfoStore.update).toHaveBeenCalledWith(WorkerInfoStoreSlice.WORKER, {
      loading: false
    });
    expect(workerInfoStore.stateValue[WorkerInfoStoreSlice.WORKER].data).toEqual(mockWorker);
    expect(workerInfoStore.stateValue[WorkerInfoStoreSlice.WORKER_INFO].data).toEqual(
      mockWorkerInfo
    );
    expect(workerInfoStore.stateValue[WorkerInfoStoreSlice.WORKER_WORK_ASSIGNMENTS].data).toEqual(
      MOCK_WORK_ASSIGNMENTS
    );
  }));

  it('should get worker-profile', fakeAsync(() => {
    Mock.extend(payrollWorkerProfileService).with({
      getWorker: () => Promise.resolve(mockWorkerProfile)
    });
    spyOn(workerInfoStore, 'update').and.callThrough();
    workerInfoStoreActions.getWorker(true);
    flush();

    expect(payrollWorkerProfileService.getWorker).toHaveBeenCalledWith(true);
    expect(workerInfoStore.update).toHaveBeenCalledWith(WorkerInfoStoreSlice.WORKER, {
      loading: true
    });
    expect(workerInfoStore.update).toHaveBeenCalledWith(WorkerInfoStoreSlice.WORKER, {
      loading: false
    });
    expect(workerInfoStore.stateValue[WorkerInfoStoreSlice.WORKER].data).toEqual(mockWorkerProfile);
    expect(workerInfoStore.stateValue[WorkerInfoStoreSlice.WORKER_INFO].data).toEqual(
      mockWorkerProfileWorkerInfo
    );
    expect(workerInfoStore.stateValue[WorkerInfoStoreSlice.WORKER_WORK_ASSIGNMENTS].data).toEqual(
      MOCK_PAYROLL_WORKER_WORK_ASSIGNMENTS
    );
  }));

  it('should not call getWorker again if there is already a worker in the store', fakeAsync(() => {
    spyOn(workerInfoStore, 'update').and.callThrough();
    workerInfoStoreActions.getWorker(true);
    flush();

    expect(payrollWorkerProfileService.getWorker).toHaveBeenCalledWith(true);
    expect(workerInfoStore.update).toHaveBeenCalledWith(WorkerInfoStoreSlice.WORKER, {
      loading: true
    });
    expect(workerInfoStore.update).toHaveBeenCalledWith(WorkerInfoStoreSlice.WORKER, {
      loading: false
    });
    expect(workerInfoStore.stateValue[WorkerInfoStoreSlice.WORKER].data).toEqual(mockWorker);
    expect(workerInfoStore.stateValue[WorkerInfoStoreSlice.WORKER_INFO].data).toEqual(
      mockWorkerInfo
    );
    expect(workerInfoStore.stateValue[WorkerInfoStoreSlice.WORKER_WORK_ASSIGNMENTS].data).toEqual(
      MOCK_WORK_ASSIGNMENTS
    );
    workerInfoStoreActions.getWorker();
    flush();

    expect(payrollWorkerProfileService.getWorker).toHaveBeenCalledTimes(1);
    expect(workerInfoStore.stateValue[WorkerInfoStoreSlice.WORKER].data).toEqual(mockWorker);
    expect(workerInfoStore.stateValue[WorkerInfoStoreSlice.WORKER_INFO].data).toEqual(
      mockWorkerInfo
    );
    expect(workerInfoStore.stateValue[WorkerInfoStoreSlice.WORKER_WORK_ASSIGNMENTS].data).toEqual(
      MOCK_WORK_ASSIGNMENTS
    );
  }));

  it('cache busting should be observed for the worker profile', fakeAsync(() => {
    mockHasWorkerProfile = true;
    workerInfoStoreActions.getWorker(true);
    flush();
    workerInfoStoreActions.getWorker(true);
    flush();

    expect(payrollWorkerProfileService.getWorker).toHaveBeenCalledTimes(2);
  }));

  it('cache busting should not be observed for the payroll worker profile', fakeAsync(() => {
    mockHasWorkerProfile = false;
    workerInfoStoreActions.getWorker(true);
    flush();
    workerInfoStoreActions.getWorker(true);
    flush();

    expect(payrollWorkerProfileService.getWorker).toHaveBeenCalledTimes(1);
  }));

  it('should have get worker error', fakeAsync(() => {
    Mock.extend(payrollWorkerProfileService).with({
      getWorker: () => Promise.reject('error')
    });
    workerInfoStoreActions.getWorker();
    flush();
    expect(
      workerInfoStore.stateValue[WorkerInfoStoreSlice.WORKER].error.loadWorkerError
    ).toBeTruthy();
  }));

  it('should clear store', fakeAsync(() => {
    workerInfoStoreActions.clearCache();
    expect(workerInfoStore.stateValue).toEqual(EMPTY_WORKER_INFO_STORE);
  }));

  describe('unmask SSN', () => {
    it('should unmaskSsn', fakeAsync(() => {
      workerInfoStoreActions.unmaskSsn();
      flush();
      expect(workerInfoStore.stateValue[WorkerInfoStoreSlice.WORKER_SSN].data.formattedSSN).toEqual(
        '123-45-6789'
      );
    }));

    it('should show APPLIED FOR when the SSN status code is equaled with APPLIED and the SSN is in the correct format', fakeAsync(() => {
      mockSSNWorker.person.governmentIDs[0].statusCode = { codeValue: 'APPLIED' };
      workerInfoStoreActions.unmaskSsn();
      flush();
      expect(workerInfoStore.stateValue[WorkerInfoStoreSlice.WORKER_SSN].data.formattedSSN).toEqual(
        'APPLIED FOR'
      );
    }));

    it('should show SSN and find the format as the validateReason when SSN is in the wrong format', fakeAsync(() => {
      mockSSNWorker.person.governmentIDs[0].idValue = '12345678';
      workerInfoStoreActions.unmaskSsn();
      flush();
      expect(workerInfoStore.stateValue[WorkerInfoStoreSlice.WORKER_SSN].data.formattedSSN).toEqual(
        '12345678'
      );
      expect(workerInfoStore.getData(WorkerInfoStoreSlice.WORKER_SSN, 'isValid')).toEqual(false);
      expect(
        workerInfoStore.stateValue[WorkerInfoStoreSlice.WORKER_SSN].data.validateReason
      ).toEqual('format');
    }));

    it('should show MISSING when SSN is empty', fakeAsync(() => {
      mockSSNWorker.person.governmentIDs[0].idValue = '';
      workerInfoStoreActions.unmaskSsn();
      flush();
      expect(workerInfoStore.stateValue[WorkerInfoStoreSlice.WORKER_SSN].data.formattedSSN).toEqual(
        'MISSING'
      );
      expect(workerInfoStore.getData(WorkerInfoStoreSlice.WORKER_SSN, 'isValid')).toEqual(false);
      expect(
        workerInfoStore.stateValue[WorkerInfoStoreSlice.WORKER_SSN].data.validateReason
      ).toEqual('empty');
    }));

    it('should show unmasked SSN when SSN is still masked by X', fakeAsync(() => {
      mockSSNWorker.person.governmentIDs[0].idValue = 'XXXXX6789';
      workerInfoStoreActions.unmaskSsn();
      flush();
      expect(workerInfoStore.stateValue[WorkerInfoStoreSlice.WORKER_SSN].data.formattedSSN).toEqual(
        'XXX-XX-6789'
      );
      expect(workerInfoStore.getData(WorkerInfoStoreSlice.WORKER_SSN, 'isValid')).toEqual(false);
      expect(
        workerInfoStore.stateValue[WorkerInfoStoreSlice.WORKER_SSN].data.validateReason
      ).toEqual('unmask');
    }));

    it('should show unmasked SSN when SSN is still masked by *', fakeAsync(() => {
      mockSSNWorker.person.governmentIDs[0].idValue = '*****6789';
      workerInfoStoreActions.unmaskSsn();
      flush();
      expect(workerInfoStore.stateValue[WorkerInfoStoreSlice.WORKER_SSN].data.formattedSSN).toEqual(
        '***-**-6789'
      );
      expect(workerInfoStore.getData(WorkerInfoStoreSlice.WORKER_SSN, 'isValid')).toEqual(false);
      expect(
        workerInfoStore.stateValue[WorkerInfoStoreSlice.WORKER_SSN].data.validateReason
      ).toEqual('unmask');
    }));

    it('should unmaskSsn error', fakeAsync(() => {
      Mock.extend(payrollWorkerProfileService).with({
        getUnmaskedDataFromWorker$: () => throwError(new HttpErrorResponse({}))
      });
      workerInfoStoreActions.unmaskSsn();
      flush();
      expect(
        workerInfoStore.stateValue[WorkerInfoStoreSlice.WORKER_SSN].error.loadWorkerSsnError
      ).toBeTruthy();
    }));

    it('should reset existing unmaskSsn error when call is made to unmask ssn', fakeAsync(() => {
      workerInfoStore.update(WorkerInfoStoreSlice.WORKER_SSN, {
        error: {
          loadWorkerSsnError: true
        }
      });

      workerInfoStoreActions.unmaskSsn();
      flush();

      expect(workerInfoStore.stateValue[WorkerInfoStoreSlice.WORKER_SSN].error).toBeNull();
    }));
  });

  describe('unmask birthDate', () => {
    it('should unmaskBirthDate', fakeAsync(() => {
      workerInfoStoreActions.unmaskBirthDate();
      flush();
      expect(workerInfoStore.stateValue[WorkerInfoStoreSlice.WORKER_BIRTHDATE].data).toEqual(
        '1980-12-01'
      );
    }));

    it('should unmaskBirthDate error', fakeAsync(() => {
      Mock.extend(payrollWorkerProfileService).with({
        getUnmaskedDataFromWorker$: () => throwError(new HttpErrorResponse({}))
      });
      workerInfoStoreActions.unmaskBirthDate();
      flush();
      expect(
        workerInfoStore.stateValue[WorkerInfoStoreSlice.WORKER_BIRTHDATE].error
          .loadWorkerBirthDateError
      ).toBeTruthy();
    }));

    it('should reset existing unmaskBirthDate error when call is made to unmask birthdate', fakeAsync(() => {
      workerInfoStore.update(WorkerInfoStoreSlice.WORKER_BIRTHDATE, {
        error: {
          loadWorkerBirthDateError: true
        }
      });

      workerInfoStoreActions.unmaskBirthDate();
      flush();

      expect(workerInfoStore.stateValue[WorkerInfoStoreSlice.WORKER_BIRTHDATE].error).toBeNull();
    }));
  });

  describe('getEffectiveDate', () => {
    it('should get effective date from worker and update store', fakeAsync(async () => {
      const effectiveDate = await workerInfoStoreActions.getEffectiveDate();
      expect(effectiveDate).toEqual(today);
      expect(payrollWorkerProfileService.getWorkerDatesFromWorker).toHaveBeenCalled();
      expect(workerInfoStore.stateValue[WorkerInfoStoreSlice.WORKER_DATES].data).toEqual(
        mockWorkerDates
      );
    }));

    it('should set effective date to todays date if worker call fails', fakeAsync(async () => {
      Mock.extend(payrollWorkerProfileService).with({
        getWorkerDatesFromWorker: () => Promise.reject()
      });
      const effectiveDate = await workerInfoStoreActions.getEffectiveDate();
      expect(effectiveDate).toEqual(today);
    }));

    describe('future hire', () => {
      let mockedFutureWorkerDates: WorkerDates;
      const dates = {
        rehireDate: moment().add(2, 'day').format('YYYY-MM-DD'),
        adjustedServiceDate: moment().add(3, 'day').format('YYYY-MM-DD'),
        originalHireDate: moment().add(1, 'day').format('YYYY-MM-DD')
      };

      beforeEach(() => {
        mockedFutureWorkerDates = {
          rehireDate: dates.rehireDate,
          adjustedServiceDate: dates.adjustedServiceDate,
          originalHireDate: dates.originalHireDate
        };
      });

      it('should set effective date to rehireDate future date', fakeAsync(async () => {
        const mockedWorkerDatesWorker = {
          ...mockWorker,
          ...{ workerDates: mockedFutureWorkerDates }
        };
        Mock.extend(payrollWorkerProfileService).with({
          getWorkerDatesFromWorker: () => Promise.resolve(mockedWorkerDatesWorker)
        });

        const effectiveDate = await workerInfoStoreActions.getEffectiveDate();
        expect(effectiveDate).toEqual(dates.rehireDate);
      }));

      it('should set effective date to adjustedServiceDate future date', fakeAsync(async () => {
        mockedFutureWorkerDates.rehireDate = null;
        const mockedWorkerDatesWorker = {
          ...mockWorker,
          ...{ workerDates: mockedFutureWorkerDates }
        };
        Mock.extend(payrollWorkerProfileService).with({
          getWorkerDatesFromWorker: () => Promise.resolve(mockedWorkerDatesWorker)
        });

        const effectiveDate = await workerInfoStoreActions.getEffectiveDate();
        expect(effectiveDate).toEqual(dates.adjustedServiceDate);
      }));

      it('should set effective date to originalHireDate future date', fakeAsync(async () => {
        mockedFutureWorkerDates.rehireDate = null;
        mockedFutureWorkerDates.adjustedServiceDate = null;
        const mockedWorkerDatesWorker = {
          ...mockWorker,
          ...{ workerDates: mockedFutureWorkerDates }
        };

        Mock.extend(payrollWorkerProfileService).with({
          getWorkerDatesFromWorker: () => Promise.resolve(mockedWorkerDatesWorker)
        });

        const effectiveDate = await workerInfoStoreActions.getEffectiveDate();
        expect(effectiveDate).toEqual(dates.originalHireDate);
      }));

      it('should set effective date to todays date if rehireDate is NOT a future date but others are in the future', fakeAsync(async () => {
        mockedFutureWorkerDates.rehireDate = moment().subtract(1, 'day').format('YYYY-MM-DD');
        const mockedWorkerDatesWorker = {
          ...mockWorker,
          ...{ workerDates: mockedFutureWorkerDates }
        };
        Mock.extend(payrollWorkerProfileService).with({
          getWorkerDatesFromWorker: () => Promise.resolve(mockedWorkerDatesWorker)
        });

        const effectiveDate = await workerInfoStoreActions.getEffectiveDate();
        expect(effectiveDate).toEqual(today);
      }));
    });
  });

  describe('getPayrollGroupCode', () => {
    it('should return payrollGroupCode from regular Worker', async () => {
      const payrollGroupCode = await workerInfoStoreActions.getPayrollGroupCode();
      expect(payrollGroupCode).toBe('baz');
    });

    it('should return payrollGroupCode from PayrollWorker', async () => {
      Mock.extend(payrollWorkerProfileService).with({
        getWorkAssignmentsFromWorker: () =>
          Promise.resolve({ workAssignments: MOCK_PAYROLL_WORKER_WORK_ASSIGNMENTS })
      });

      const payrollGroupCode = await workerInfoStoreActions.getPayrollGroupCode();
      expect(payrollGroupCode).toBe('foo');
    });

    it('should return undefined if worker call fails', async () => {
      Mock.extend(payrollWorkerProfileService).with({
        getWorkAssignmentsFromWorker: () => Promise.reject()
      });
      const payrollGroupCode = await workerInfoStoreActions.getPayrollGroupCode();
      expect(payrollGroupCode).toBeUndefined();
    });
  });

  describe('isRun', () => {
    it('should unmaskBirthDate and unmaskSSN when click unmaskBirthDate', fakeAsync(() => {
      mockIsRun = true;
      workerInfoStoreActions.unmaskBirthDate();
      flush();
      expect(workerInfoStore.stateValue[WorkerInfoStoreSlice.WORKER_BIRTHDATE].data).toEqual(
        '1980-12-01'
      );
      expect(workerInfoStore.stateValue[WorkerInfoStoreSlice.WORKER_SSN].data.formattedSSN).toEqual(
        '123-45-6789'
      );
    }));

    it('should unmaskBirthDate and unmaskSSN when click unmaskSsn', fakeAsync(() => {
      mockIsRun = true;
      workerInfoStoreActions.unmaskSsn();
      flush();
      expect(workerInfoStore.stateValue[WorkerInfoStoreSlice.WORKER_BIRTHDATE].data).toEqual(
        '1980-12-01'
      );
      expect(workerInfoStore.stateValue[WorkerInfoStoreSlice.WORKER_SSN].data.formattedSSN).toEqual(
        '123-45-6789'
      );
    }));
  });

  describe('getWorkedInState', () => {
    it('should call payrollWorkerProfileService to get worked in state', async () => {
      Mock.extend(payrollWorkerProfileService).with({
        getWorkedInState: () => Promise.resolve('GA')
      });
      const state = await workerInfoStoreActions.getWorkedInState();
      expect(state).toBe('GA');
      expect(payrollWorkerProfileService.getWorkedInState).toHaveBeenCalled();
    });
  });

  describe('getWorkAssignments', () => {
    it('should reset any worker work assignments error when call is made to get work assignments', async () => {
      workerInfoStore.update(WorkerInfoStoreSlice.WORKER_WORK_ASSIGNMENTS, {
        error: {
          loadWorkAssignmentsError: true
        }
      });

      await workerInfoStoreActions.getWorkAssignments();
      expect(
        workerInfoStore.stateValue[WorkerInfoStoreSlice.WORKER_WORK_ASSIGNMENTS].error
      ).toBeNull();
    });
  });

  describe('getWorkerDates', () => {
    it('should reset existing worker dates error when call is made to get worker dates', async () => {
      workerInfoStore.update(WorkerInfoStoreSlice.WORKER_DATES, {
        error: {
          loadWorkerDatesError: true
        }
      });

      await workerInfoStoreActions.getWorkerDates();
      expect(workerInfoStore.stateValue[WorkerInfoStoreSlice.WORKER_DATES].error).toBeNull();
    });
  });
});
