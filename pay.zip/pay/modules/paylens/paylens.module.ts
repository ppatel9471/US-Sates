import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AlertModule } from '@synerg/components/alert';
import { BadgeModule } from '@synerg/components/badge';
import { BusyIndicatorModule } from '@synerg/components/busy-indicator';
import { ButtonModule } from '@synerg/components/button';
import { CheckboxModule } from '@synerg/components/checkbox';
import { DonutModule } from '@synerg/components/donut';
import { HeaderBarModule } from '@synerg/components/header-bar';
import { IconModule } from '@synerg/components/icon';
import { ListViewModule } from '@synerg/components/list-view';
import { ModalModule } from '@synerg/components/modal';
import { PopoverModule } from '@synerg/components/popover';
import { QuickstatModule } from '@synerg/components/quickstat';
import { SelectModule } from '@synerg/components/select';
import { SlideinModule } from '@synerg/components/slidein';
import { SnackbarModule } from '@synerg/components/snackbar';
import { TabsModule } from '@synerg/components/tabs';
import { TileModule } from '@synerg/components/tile';

import { CoreModule } from '@synerg/angular-components';

import { AnalyticsModule } from '@myadp/analytics';
import { MyAdpCommonModule } from '@myadp/common';
import { FeedbackModule } from '@myadp/feedback';

import { PaperlessModule } from '../paperless/paperless.module';
import { SharedModule } from '../shared/shared.module';
import { PaylensMobileHeroComponent } from './components/mobile/mobile-hero/mobile-hero.component';
import { MobilePaylensTileComponent } from './components/mobile/mobile-paylens-tile/mobile-paylens-tile.component';
import { MobileStatementsActivityTileComponent } from './components/mobile/mobile-statements-activity-tile/mobile-statements-activity-tile.component';
import { PaylensContainerComponent } from './components/paylens-container/paylens-container.component';
import { PaylensStatementDetailsTabsComponent } from './components/statement-details-tabs/statement-details-tabs.component';
import { PaylensExpandAllToggleComponent } from './components/statement-details/expand-all-toggle/expand-all-toggle.component';
import { InsightsAlertComponent } from './components/statement-details/insights-alert/insights-alert.component';
import { PaylensNoStatementDetailsComponent } from './components/statement-details/no-statement-details/no-statement-details.component';
import { PaylensPayDonutComponent } from './components/statement-details/pay-donut/pay-donut.component';
import { CalculatorLinkConfirmComponent } from './components/statement-details/statement-details-deductions/calculator-link-confirmation/calculator-link-confirm.component';
import { PaylensStatementDetailsDeductionsComponent } from './components/statement-details/statement-details-deductions/statement-details-deductions.component';
import { PaylensStatementDetailsEarningsComponent } from './components/statement-details/statement-details-earnings/statement-details-earnings.component';
import { MemoComponent } from './components/statement-details/statement-details-memos/memo/memo.component';
import { PaylensStatementDetailsMemosComponent } from './components/statement-details/statement-details-memos/statement-details-memos.component';
import { PaylensStatementDetailsSummaryComponent } from './components/statement-details/statement-details-summary/statement-details-summary.component';
import { PaylensSummaryHeaderComponent } from './components/statement-details/statement-details-summary/summary-header/summary-header.component';
import { PaylensStatementDetailsComponent } from './components/statement-details/statement-details.component';
import { PaylensStatementInsightsCompareDetailsComponent } from './components/statement-details/statement-insights/statement-insights-compare-details/statement-insights-compare-details.component';
import { PaylensStatementInsightsComponent } from './components/statement-details/statement-insights/statement-insights.component';
import { PayStatementsDownloadAlertComponent } from './components/statements-batch-download/download-alert/download-alert.component';
import { PayStatementsDownloadCheckboxComponent } from './components/statements-batch-download/download-checkbox/download-checkbox.component';
import { PayStatementsDownloadSnackbarComponent } from './components/statements-batch-download/download-snackbar/download-snackbar.component';
import { PaylensNoStatementsComponent } from './components/statements-list/no-statements/no-statements.component';
import { PaylensStatementsFilterComponent } from './components/statements-list/statements-filter/statements-filter.component';
import { PaylensStatementsListComponent } from './components/statements-list/statements-list.component';
import { DeductionsDataSelectorPipe } from './pipes/deductions-data-selector.pipe';
import { EarningsDataSelectorPipe } from './pipes/earnings-data-selector.pipe';
import { MemosDataSelectorPipe } from './pipes/memos-data-selector.pipe';
import { PayDonutDataSelectorPipe } from './pipes/pay-donut-data-selector.pipe';

const PAYLENS_COMPONENTS = [
  PaylensContainerComponent,
  PaylensStatementsListComponent,
  PaylensStatementsFilterComponent,
  PayStatementsDownloadCheckboxComponent,
  PayStatementsDownloadSnackbarComponent,
  PayStatementsDownloadAlertComponent,
  PaylensStatementDetailsComponent,
  PaylensStatementDetailsSummaryComponent,
  PaylensSummaryHeaderComponent,
  PaylensStatementDetailsEarningsComponent,
  PaylensStatementDetailsDeductionsComponent,
  PaylensNoStatementsComponent,
  PaylensNoStatementDetailsComponent,
  PaylensStatementDetailsMemosComponent,
  PaylensStatementDetailsTabsComponent,
  PaylensPayDonutComponent,
  MemoComponent,
  PaylensMobileHeroComponent,
  CalculatorLinkConfirmComponent,
  PaylensStatementInsightsComponent,
  PaylensStatementInsightsCompareDetailsComponent,
  PaylensExpandAllToggleComponent,
  InsightsAlertComponent,
  MobilePaylensTileComponent,
  MobileStatementsActivityTileComponent,
  PayDonutDataSelectorPipe,
  EarningsDataSelectorPipe,
  MemosDataSelectorPipe,
  DeductionsDataSelectorPipe
];

@NgModule({
  imports: [
    FormsModule,
    CommonModule,
    CoreModule,
    MyAdpCommonModule,
    SharedModule,
    ButtonModule,
    DonutModule,
    CheckboxModule,
    QuickstatModule,
    SelectModule,
    ListViewModule,
    PopoverModule,
    SnackbarModule,
    BadgeModule,
    BusyIndicatorModule,
    AlertModule,
    TabsModule,
    SlideinModule,
    TileModule,
    IconModule,
    HeaderBarModule,
    ModalModule,
    FeedbackModule,
    AnalyticsModule,
    PaperlessModule
  ],
  declarations: PAYLENS_COMPONENTS,
  exports: PAYLENS_COMPONENTS
})
export class PaylensModule {
  static components = {
    default: PaylensContainerComponent,
    // mobile paylens tile
    paylensMobileTile: MobilePaylensTileComponent,
    // mobile statements activities tile
    statementsActivityMobileTile: MobileStatementsActivityTileComponent
  };
}
