import { CurrencyPipe } from '@angular/common';
import { AlertComponent } from '@synerg/components/alert';
import { BehaviorSubject, of } from 'rxjs';
import { Shallow } from 'shallow-render';
import { Mock } from 'ts-mockery';

import { LanguagePipe, LanguageService, QueryParamsService } from '@myadp/common';
import { PAY_DEEP_LINKS, StoreState } from '@myadp/pay-shared';

import { DistributionOptions } from '../../../pay-distributions-shared/models/pay-distributions-ui';
import { PayDistributionStore } from '../../../pay-distributions-shared/store/pay-distribution.store';
import { PayDistributionStoreActions } from '../../../pay-distributions-shared/store/pay-distribution.store.actions';
import { PrivacyModeStore } from '../../../privacy-mode-shared/store/privacy-mode.store';
import { CurrencyFormatComponent } from '../../../shared/components/currency-format/currency-format.component';
import { HasWorkflowChangesPipe } from '../../../shared/pipes/has-workflow-changes/has-workflow-changes.pipe';
import { ValueFormatterService } from '../../../shared/services/value-formatter.service';
import { MyADPDirectDepositModule } from '../../direct-deposit.module';
import { DirectDepositAccount } from '../../models/direct-deposit-account.model';
import { AccountDetailsSelectorPipe } from '../../pipes/account-details-selector/account-details-selector.pipe';
import { MaskNumberPipe } from '../../pipes/mask-number/mask-number.pipe';
import { WiselyNameDisplayPipe } from '../../pipes/wisely-name-display/wisely-name-display.pipe';
import { DirectDepositStoreActions } from '../../store/direct-deposit-store.actions';
import {
  DirectDepositStore,
  DirectDepositStoreSlice,
  DirectDepositStoreState
} from '../../store/direct-deposit.store';
import { StepsStore, StepsStoreActions } from '../../store/steps/steps.store';
import { DepositAmountFormatComponent } from '../shared/deposit-amount-format/deposit-amount-format.component';
import { DirectDepositTileComponent } from './direct-deposit-tile.component';
import { DirectDepositNoDistributionsComponent } from './no-direct-deposits/no-direct-deposits.component';

import { COUNTRY, COUNTRY_CONFIG } from './../../../pay-distributions-shared/models/country';
import { SdfShimmer } from '@synerg/angular-components';

describe('DirectDepositTileComponent', () => {
  let shallow: Shallow<DirectDepositTileComponent>;
  let mockShowSlidein$: BehaviorSubject<boolean>;

  const accounts: DirectDepositAccount[] = [
    {
      currentData: {
        id: 'Checking11',
        precedence: '1',
        accountTypeName: 'Checking 1',
        accountNumber: 'X123456P7',
        routingNumber: '021000021',
        distributionType: DistributionOptions.FLAT,
        flatAmount: { amountValue: 123, currencyCode: 'USD' }
      }
    },
    {
      currentData: {
        id: 'Checking22',
        precedence: '2',
        accountTypeName: 'Checking 2',
        accountNumber: '123-45678',
        routingNumber: '021000021',
        distributionType: DistributionOptions.PERCENTAGE,
        percentageAmount: 25
      }
    },
    {
      currentData: {
        id: 'Checking33',
        precedence: '3',
        accountName: 'My Account Name',
        accountTypeName: 'Checking 3',
        accountNumber: '12345',
        routingNumber: '021000021',
        distributionType: DistributionOptions.REMAINING
      }
    }
  ];

  const state: StoreState<DirectDepositStoreState> = {
    [DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS]: {
      data: accounts,
      loading: false
    },
    [DirectDepositStoreSlice.DIRECT_DEPOSIT_COUNTRY]: {
      data: COUNTRY_CONFIG[COUNTRY.US],
      loading: false
    }
  };

  const ddSlideinElm = 'direct-deposit-slidein';

  beforeEach(() => {
    mockShowSlidein$ = new BehaviorSubject<boolean>(false);

    shallow = new Shallow(DirectDepositTileComponent, MyADPDirectDepositModule)
      .mock(QueryParamsService, {
        getParameterValue: () => null
      })
      .provide(CurrencyPipe)
      .provide(LanguageService)
      .provide(ValueFormatterService)
      .provide(DirectDepositStore)
      .dontMock(CurrencyPipe)
      .dontMock(ValueFormatterService)
      .dontMock(CurrencyFormatComponent)
      .dontMock(AlertComponent)
      .dontMock(MaskNumberPipe)
      .dontMock(HasWorkflowChangesPipe)
      .dontMock(DepositAmountFormatComponent)
      .dontMock(DirectDepositNoDistributionsComponent)
      .mockPipe(AccountDetailsSelectorPipe, () => [
        {
          ...accounts[0].currentData,
          isReadOnly: false,
          directDepositAccount: accounts[0],
          pendingEvent: null
        },
        {
          ...accounts[1].currentData,
          isReadOnly: false,
          directDepositAccount: accounts[1],
          pendingEvent: null
        },
        {
          ...accounts[2].currentData,
          isReadOnly: false,
          directDepositAccount: accounts[2],
          pendingEvent: null
        }
      ])
      .mock(StepsStore, {
        showStepNavigation$: of(true)
      })
      .mock(DirectDepositStore, {
        state$: of(state),
        update: Mock.noop(),
        getValidationStatus: Mock.noop()
      })
      .mock(DirectDepositStoreActions, {
        resetFormData: () => Mock.noop()
      })
      .mock(PrivacyModeStore, {
        showMaskedValue$: of(false)
      })
      .mock(StepsStoreActions, {
        loadAccounts: () => Mock.noop(),
        resetCurrentStep: () => Mock.noop(),
        openSlidein: () => mockShowSlidein$.next(true),
        closeSlidein: () => mockShowSlidein$.next(false),
        hasAccountChanges: () => false
      })
      .mock(PayDistributionStore, {
        payDistributions$: Mock.noop(),
        payDistributionMeta$: Mock.noop(),
        hasChangePermission$: Mock.noop(),
        hasPayDistributions: true,
        hasDistributionError$: of(false),
        isPayDistributionsLoading$: of(false)
      })
      .mock(PayDistributionStoreActions, {
        loadDistributions: () => Mock.noop()
      })
      .mockPipe(LanguagePipe, (key) => key)
      .mockPipe(WiselyNameDisplayPipe, (name: string) => name);
  });

  it('should show custom content', async () => {
    const { find } = await shallow.render();
    expect(find('pay-custom-content')).toHaveFoundOne();
  });

  it('should make call to load pay distributions', async () => {
    const { get } = await shallow.render();
    const stepsStoreActions = get(StepsStoreActions);
    expect(stepsStoreActions.loadAccounts).toHaveBeenCalledWith({ getMeta: true, getMasked: true });
  });

  describe('direct deposit views', () => {
    it('should show no pay distributions message', async () => {
      const { instance, find, findComponent, fixture } = await shallow.render();
      instance.state$ = of({
        [DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS]: {
          data: [],
          loading: false
        }
      });
      fixture.detectChanges();

      expect(find('.distribution-summary-item')).toHaveFound(0);
      expect(findComponent(SdfShimmer)).toHaveFound(0);
      expect(findComponent(DirectDepositNoDistributionsComponent)).toHaveFoundOne();
    });

    it('should show pending changes alert if there are pending changes', async () => {
      const { find } = await shallow
        .mock(DirectDepositStore, {
          state$: of({
            [DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS]: {
              data: [
                { ...accounts[0], pendingData: null, pendingEvent: { changeType: 'delete' } },
                accounts[1]
              ],
              loading: false
            }
          } as StoreState<DirectDepositStoreState>)
        })
        .render();

      expect(find('adp-alert')).toHaveFound(1);
      expect(find('adp-alert').nativeElement.textContent).toContain(
        'myadp-pay.WORKFLOW_PENDING_APPROVAL'
      );
    });
  });

  describe('loading shimmer', () => {
    it('should show the loading shimmer when fetching distributions', async () => {
      const { instance, find, findComponent, fixture } = await shallow.render();
      instance.state$ = of({
        [DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS]: {
          data: [],
          loading: true
        }
      });
      fixture.detectChanges();

      expect(find('.distribution-summary-item')).toHaveFound(0);
      expect(findComponent(DirectDepositNoDistributionsComponent)).toHaveFound(0);
      expect(findComponent(SdfShimmer)).toHaveFoundOne();
    });
  });

  describe('error', () => {
    it('should show the error message', async () => {
      const { instance, find, findComponent, fixture } = await shallow.render();
      instance.state$ = of({
        [DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS]: {
          data: [],
          loading: false,
          error: {
            ddAccountsLoadError: true
          }
        }
      });
      fixture.detectChanges();

      expect(find('.direct-deposit-no-distributions-error').nativeElement.textContent).toContain(
        'common.GENERAL_ERROR'
      );
      expect(find('.distribution-summary-item')).toHaveFound(0);
      expect(findComponent(SdfShimmer)).toHaveFound(0);
    });
  });

  describe('direct deposit slidein component', () => {
    it('should show direct deposit slidein component', async () => {
      const { find, fixture, instance, get } = await shallow.render();

      expect(find(ddSlideinElm)).toHaveFound(0);
      const stepStoreActions = get(StepsStoreActions);

      find('adp-button').nativeElement.click();
      fixture.detectChanges();

      expect(instance.unmaskError).toBeFalse();
      expect(stepStoreActions.openSlidein).toHaveBeenCalled();
      expect(find(ddSlideinElm)).toHaveFoundOne();
    });

    it('should show error message if error emitted and not open slidein if unmasked call fails', async () => {
      const { find, fixture } = await shallow.render();

      find('adp-button').nativeElement.click();
      fixture.detectChanges();

      find(ddSlideinElm).triggerEventHandler('error', true);
      fixture.detectChanges();

      expect(find('.direct-deposit-unmasked-error').nativeElement.textContent).toContain(
        'common.GENERAL_ERROR'
      );
    });

    it('should not show direct deposit slidein component when slidein closed', async () => {
      const { find, fixture } = await shallow.render();

      find('adp-button').nativeElement.click();
      fixture.detectChanges();

      expect(find(ddSlideinElm)).toHaveFoundOne();

      find(ddSlideinElm).triggerEventHandler('closed', null);
      fixture.detectChanges();

      expect(find(ddSlideinElm)).toHaveFound(0);
    });

    it('should refresh data when the slide in has been closed', async () => {
      const { find, fixture, get } = await shallow.render();

      find('adp-button').nativeElement.click();
      fixture.detectChanges();

      find(ddSlideinElm).triggerEventHandler('closed', null);

      fixture.detectChanges();

      expect(get(StepsStoreActions).closeSlidein).toHaveBeenCalled();
      expect(get(StepsStoreActions).loadAccounts).toHaveBeenCalled();
    });
  });

  describe('Auto open direct deposit slidein', () => {
    it('should call to open when deprecated openDirectDeposit query param is "true"', async () => {
      const { find, get } = await shallow
        .mock(QueryParamsService, {
          getParameterValue: (param) => (param === 'openDirectDeposit' ? 'true' : '')
        })
        .render();

      const stepStoreActions = get(StepsStoreActions);

      expect(stepStoreActions.openSlidein).toHaveBeenCalled();
      expect(find(ddSlideinElm)).toHaveFoundOne();
    });

    it('should not open when deprecated openDirectDeposit query param is anything other than "true"', async () => {
      const { find, instance } = await shallow
        .mock(QueryParamsService, {
          getParameterValue: (param) => (param === 'openDirectDeposit' ? 'false' : '')
        })
        .render();

      spyOn(instance, 'openSlidein');
      instance.ngOnInit();

      expect(instance.openSlidein).not.toHaveBeenCalled();
      expect(find(ddSlideinElm)).not.toHaveFoundOne();
    });

    it('should handle when open is direct-deposit', async () => {
      const { find, get } = await shallow
        .mock(QueryParamsService, {
          getParameterValue: (param) => (param === 'open' ? PAY_DEEP_LINKS.DirectDeposit : '')
        })
        .render();

      const stepStoreActions = get(StepsStoreActions);

      expect(stepStoreActions.openSlidein).toHaveBeenCalled();
      expect(find(ddSlideinElm)).toHaveFoundOne();
    });

    it('should not open for non direct-deposit', async () => {
      const { find, instance } = await shallow
        .mock(QueryParamsService, {
          getParameterValue: (param) => (param === 'open' ? PAY_DEEP_LINKS.MyPayDetails : '')
        })
        .render();

      spyOn(instance, 'openSlidein');
      instance.ngOnInit();

      expect(instance.openSlidein).not.toHaveBeenCalled();
      expect(find(ddSlideinElm)).not.toHaveFoundOne();
    });

    it('should open if defaultOpenSlidein is set to true', async () => {
      const { find, get } = await shallow
        .mock(QueryParamsService, {
          getParameterValue: (param) => (param === 'openDirectDeposit' ? 'false' : '')
        })
        .render({ bind: { defaultOpenSlidein: true } });

      const stepStoreActions = get(StepsStoreActions);

      expect(stepStoreActions.openSlidein).toHaveBeenCalled();
      expect(find(ddSlideinElm)).toHaveFoundOne();
    });

    it('should not open if defaultOpenSlidein is set to false', async () => {
      const { find, instance } = await shallow.render({ bind: { defaultOpenSlidein: false } });

      spyOn(instance, 'openSlidein');
      instance.ngOnInit();

      expect(instance.openSlidein).not.toHaveBeenCalled();
      expect(find(ddSlideinElm)).not.toHaveFoundOne();
    });
  });
});
