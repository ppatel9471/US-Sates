import { KsAllowancesComponent } from './steps/allowances/ks-allowances.component';
import { KsExemptionComponent } from './steps/exemption/ks-exemption.component';
import { KsIntroComponent } from './steps/intro/ks-intro.component';
import { KsMaritalStatusComponent } from './steps/marital-status/ks-marital-status.component';

export { KsStepNavigationService } from './services/ks-step-navigation.service';
export { KsTWChangeEventService } from './services/ks-tw-change-event.service';
export { KsSummaryMetaDataService } from './services/ks-summary-meta-data.service';

export const KS_COMPONENTS = [
  KsAllowancesComponent,
  KsIntroComponent,
  KsExemptionComponent,
  KsMaritalStatusComponent
];

export { KSSTEP_COMPONENT } from './models/steps-component.model';

export { KsAttachmentCodes } from './models/ks-tw-change-event';
