import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { combineLatest, EMPTY } from 'rxjs';
import { catchError, skipWhile, take, tap } from 'rxjs/operators';

import { FilteredUserProfileService } from '@myadp/common';
import { FindSffoService, PAY_SFFO, PayPermissionService } from '@myadp/pay-shared';

import {
  PayDistributionsStoreSlice,
  PayDistributionsUI
} from '../../pay-distributions-shared/models/pay-distributions-ui';
import { PayDistributionStore } from '../../pay-distributions-shared/store/pay-distribution.store';
import { PayDistributionStoreActions } from '../../pay-distributions-shared/store/pay-distribution.store.actions';
import { WorkflowUI } from '../../shared/models/workflow-ui.model';
import { AccountDetailsForm } from '../models/account-details-form.model';
import {
  GIACTValidationError,
  GIACTValidationResponse,
  ValidationStatus,
  ValidationStatusObj
} from '../models/deposit-account.model';
import { DirectDepositAccount } from '../models/direct-deposit-account.model';
import { FormDetails } from '../models/form-details.model';
import { WiselyTypes } from '../models/wisely.model';
import {
  transformDirectDepositAccounts,
  transformFormDetails
} from '../transforms/direct-deposit-account.transform';
import { transformToFormDetails } from '../transforms/form-details.transform';
import { DirectDepositStore, DirectDepositStoreSlice } from './direct-deposit.store';

export enum ValidationStatusCodes {
  VALID = 'VALID',
  INVALID = 'INVALID',
  INVALID_ROUTING_NUMBER = 'INVALID_ROUTING_NUMBER',
  INVALID_ACCOUNT_NUMBER = 'INVALID_ACCOUNT_NUMBER',
  INVALID_REQUEST = 'INVALID_REQUEST',
  NOT_SUPPORTED = 'NOT_SUPPORTED', // Bank currently not under coverage - Needs pre-note
  UNKNOWN = 'UNKNOWN' // GIACT can validate the presence of the Bank but has no information on the account - Needs pre-note
}

const validationStatusMap = {
  [ValidationStatusCodes.VALID]: ValidationStatus.SUCCESS,
  [ValidationStatusCodes.NOT_SUPPORTED]: ValidationStatus.WARN,
  [ValidationStatusCodes.INVALID_ROUTING_NUMBER]: ValidationStatus.INVALID,
  [ValidationStatusCodes.INVALID_ACCOUNT_NUMBER]: ValidationStatus.INVALID,
  [ValidationStatusCodes.INVALID_REQUEST]: ValidationStatus.INVALID,
  [ValidationStatusCodes.INVALID]: ValidationStatus.INVALID,
  [ValidationStatusCodes.UNKNOWN]: ValidationStatus.WARN
};

@Injectable({
  providedIn: 'root'
})
export class DirectDepositStoreActions {
  public applicationId: string;

  private accountValidationHrefV2 = '/money-movement/v2/deposit-account-validations';

  constructor(
    private httpClient: HttpClient,
    private findSffoService: FindSffoService,
    private directDepositStore: DirectDepositStore,
    private payPermissionService: PayPermissionService,
    private payDistributionStore: PayDistributionStore,
    private userProfileService: FilteredUserProfileService,
    private payDistributionStoreActions: PayDistributionStoreActions
  ) {
    this.init();
  }

  public init(): void {
    this.setFeatureProviderOptions();
  }

  public revertAllChanges(): void {
    this.directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS, {
      loading: false,
      data: this.directDepositStore.ddAccountsInitialSnapshot,
      error: null
    });
    this.resetModifiedAccounts(); // modifications are essentially bound to the accounts
  }

  public loadDirectDepositAccounts(
    getPayDistributionsMeta: boolean = false,
    masked: boolean = true
  ): void {
    const existingPayDistributions: PayDistributionsUI.PayDistribution[] =
      this.directDepositStore.getDDAccountsSnapshot();

    this.directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS, {
      loading: true,
      error: null
    });

    this.payDistributionStoreActions.loadDistributions(getPayDistributionsMeta, masked);

    combineLatest([
      this.payDistributionStore.payDistributions$,
      this.payDistributionStore.payDistributionMeta$,
      this.payDistributionStore.hasDistributionError$,
      this.payDistributionStore.isLoading$,
      this.payDistributionStore.hasChangePermission$
    ])
      .pipe(
        skipWhile(
          ([payDistributions, _meta, hasError, isLoading]: [
            PayDistributionsUI.PayDistribution[],
            PayDistributionsUI.PayDistributionMeta,
            boolean,
            boolean,
            boolean
          ]) => !hasError && (payDistributions === null || isLoading)
        ),
        take(1),
        tap(([payDistributions, meta, hasError, , hasChangePermission]) => {
          const payload = {
            data:
              !hasError && payDistributions
                ? transformDirectDepositAccounts(
                  payDistributions,
                  meta,
                  this.directDepositStore.sorProvider,
                  hasChangePermission
                )
                : existingPayDistributions,
            loading: false,
            error: hasError ? { ddAccountsLoadError: true } : null
          };

          this.setPermissions();

          if (payload.data) {
            const cachedAccounts: Record<string, ValidationStatusObj> = payload.data.reduce(
              (cache, { currentData }) => {
                if (!currentData) {
                  return cache;
                }

                const accountKey = `${currentData.routingNumber}${currentData.accountNumber}`;

                if (currentData.prenoteIndicator === true) {
                  cache[accountKey] = { status: ValidationStatus.WARN };
                }

                if (currentData.prenoteIndicator === false) {
                  cache[accountKey] = { status: ValidationStatus.SUCCESS };
                }

                return cache;
              },
              {}
            );

            this.directDepositStore.update(DirectDepositStoreSlice.ACCOUNT_VERIFICATION, {
              data: cachedAccounts
            });
          }

          this.directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS, payload);
          this.directDepositStore.update(
            DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS_INITIAL,
            payload
          );

          this.directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_COUNTRY, {
            data: this.payDistributionStore.payDistributionCountry
          });
        }),
        catchError(() => {
          this.directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS, {
            loading: false,
            error: { ddAccountsLoadError: true }
          });
          return EMPTY;
        })
      )
      .subscribe();
  }

  public async postDirectDepositAccounts(isWfRecalling: boolean = false): Promise<void> {
    const allAccounts = this.directDepositStore.getDDAccountsSnapshot({
      filterDeleted: false
    });
    const initialAccounts = this.directDepositStore.ddAccountsInitialSnapshot;
    const usesNonCompliantSchema = this.directDepositStore.usesNonCompliantSchema;
    const pendingWfAccounts: DirectDepositAccount[] = [];

    const accountsToPOST: DirectDepositAccount[] = allAccounts
      ?.map((account) => {
        if (account?.pendingEvent && !account?.hasAltWorkflow) {
          pendingWfAccounts.push(account);
          const {
            currentData,
            pendingEvent: { changeType }
          } = account;

          // keep pending adds/edits, canceled edits/deletes
          return (currentData || changeType !== null) && !['delete', 'pruned'].includes(changeType)
            ? account
            : null;
        } else {
          // non-pending accounts
          return account;
        }
      })
      .filter((a) => a);

    /**
     * NOTE: 4 reasons a POST is needed:
     * 1) when adding or deleting an account:
     * (initalAccounts.length != allAccounts.length), or,
     * 2) when a Workflow add/edit has been edited, or,
     * 3) when a Workflow edit has been deleted, or,
     * 4) when there is more than 1 Workflow change (see pendingWfAccounts above)
     */
    // if all accounts are canceled WF events, then Recall w/o POST
    const allAccountsCanceled: boolean =
      allAccounts?.length > 0 &&
      allAccounts.every(
        ({ pendingEvent }: DirectDepositAccount) => pendingEvent?.changeType === null
      );
    const hasDeletedPendingEdits = this.directDepositStore
      .getModifications('delete')
      .some(({ pendingEvent }) => pendingEvent?.changeType === 'edit');
    const hasAccountEdits = allAccounts?.some(
      (account) => !!account?.pendingData && !account?.pendingEvent?.changeType
    );

    const wfRecallRequired = pendingWfAccounts.length > 0;
    const wfPostRequired = isWfRecalling
      ? pendingWfAccounts.length > 1
      : !allAccountsCanceled &&
        (pendingWfAccounts.length > 1 ||
          hasAccountEdits ||
          hasDeletedPendingEdits ||
          initialAccounts?.length !== allAccounts?.length);

    this.directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS, {
      loading: true,
      error: null
    });

    return this.saveAccounts(
      accountsToPOST,
      wfRecallRequired,
      wfPostRequired,
      usesNonCompliantSchema
    ).catch(() => {
      this.directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS, {
        loading: false,
        error: { ddAccountsPostError: true }
      });
      return Promise.reject();
    });
  }

  public recallAccount(recalledAccount: DirectDepositAccount, postChanges: boolean = false): void {
    const accounts = this.directDepositStore.getDDAccountsSnapshot();
    const cancelledPendingAccount: DirectDepositAccount = {
      ...recalledAccount,
      pendingData: null,
      pendingEvent: { changeType: null }
    };

    const updatedAccounts: DirectDepositAccount[] = accounts.map((account) =>
      (account?.pendingData ?? account?.currentData)?.id ===
      (recalledAccount?.pendingData ?? recalledAccount?.currentData)?.id
        ? cancelledPendingAccount
        : account
    );

    this.directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS, {
      data: updatedAccounts
    });

    if (postChanges) {
      this.postDirectDepositAccounts(true)
        .then(() => this.loadDirectDepositAccounts(false, false))
        .catch(() => Promise.resolve());
    }
  }

  public accountValidationDetails() {
    const formData: AccountDetailsForm = this.directDepositStore.formDetails;
    const routingAccountKey = `${formData?.routingNumber}${formData?.accountNumber}`;
    const cachedValidationStatus = this.directDepositStore.getValidationStatus(routingAccountKey);
    return {
      formData,
      routingAccountKey,
      cachedValidationStatus
    };
  }

  public async validateAccountFormDetails(): Promise<void> {
    let validationResult: ValidationStatusObj = { setByVendor: true };

    await this.setPermissions();

    const { formData, routingAccountKey, cachedValidationStatus } = this.accountValidationDetails();
    const hasGIACT: boolean = this.directDepositStore.hasPermission('GIACT');

    const canValidateBankInfo: boolean =
      this.directDepositStore.stateValue[DirectDepositStoreSlice.PERMISSIONS]?.data
        ?.canValidateBankInfo;

    const { href } = this.findSffoService.findSffo([
      PAY_SFFO.DIRECT_DEPOSIT_BANK_VALIDATION
    ]);
    const headers = {
      rolecode: 'employee'
    };
    const payload = {
      accountValidationRequest: {
        depositAccount: {
          accountNumber: formData.accountNumber,
          routingTransitID: {
            id: formData.routingNumber
          }
        }
      }
    };

    if (cachedValidationStatus || !href || !hasGIACT) {
      validationResult =
        cachedValidationStatus ||
        (canValidateBankInfo
          ? { ...validationResult, status: ValidationStatus.WARN }
          : { ...validationResult, status: ValidationStatus.ERROR });
    } else {
      validationResult = await this.httpClient
        .post<GIACTValidationResponse>(`${this.accountValidationHrefV2}`, payload, { headers })
        .toPromise()
        .then((response: GIACTValidationResponse) => {
          const responseCode = response.accountValidationResponse?.responseMessage?.messageCode;

          return !responseCode || !validationStatusMap[responseCode]
            ? {
              ...validationResult,
              status: validationStatusMap[ValidationStatusCodes.INVALID_REQUEST]
            }
            : { ...validationResult, status: validationStatusMap[responseCode] };
        })
        .catch((errorResponse: GIACTValidationError) => {
          const responseCode = errorResponse?.error?._confirmMessage?.messages?.[0]?.messageCode;
          const status = validationStatusMap[responseCode] || ValidationStatus.WARN;
          return { ...validationResult, status };
        });
    }

    this.directDepositStore.update(DirectDepositStoreSlice.ACCOUNT_VERIFICATION, {
      data: {
        [routingAccountKey]: validationResult
      }
    });

    this.updateFormData({
      validationStatus: validationResult.status,
      prenoteIndicator: validationResult.status !== ValidationStatus.SUCCESS
    });
  }

  public resetFormData() {
    this.directDepositStore.update(DirectDepositStoreSlice.FORM_DETAILS, {
      data: null
    });
  }

  public resetModifiedAccounts(): void {
    this.directDepositStore.update(DirectDepositStoreSlice.MODIFIED_ACCOUNTS, {
      data: null
    });
  }

  public updateFormData(
    formDetails: FormDetails | Partial<PayDistributionsUI.PayDistributionDetails>,
    editingAccount: boolean = false
  ): void {
    // if editing, we need to transform from PayDistributionDetails => FormDetails
    this.directDepositStore.update(DirectDepositStoreSlice.FORM_DETAILS, {
      data: !editingAccount
        ? (formDetails as FormDetails)
        : transformToFormDetails(formDetails as Partial<PayDistributionsUI.PayDistributionDetails>)
    });
  }

  public deleteAccount(id: string): void {
    const snapshot = this.directDepositStore
      .getDDAccountsSnapshot()
      .map((account) => {
        if ((account?.pendingData ?? account?.currentData)?.id === id) {
          this.updateModifiedAccounts('delete', account);
          return !!account?.pendingEvent && !account?.hasAltWorkflow
            ? ({
              currentData: null,
              pendingData: null,
              pendingEvent: { changeType: 'pruned' }
            } as DirectDepositAccount)
            : null;
        } else {
          return account;
        }
      })
      .filter((a) => a);

    this.directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS, {
      data: snapshot
    });
    this.resetFormData();
  }

  public updateAccountChanges(): DirectDepositAccount[] {
    const directDepositAccounts = this.directDepositStore.getDDAccountsSnapshot();
    const accountChanges = this.directDepositStore.formDetails;
    const isNewAccount = !accountChanges?.id;

    if (accountChanges) {
      const updatedAccount: DirectDepositAccount = transformFormDetails(
        isNewAccount,
        accountChanges,
        directDepositAccounts
      );

      isNewAccount
        ? this.updateModifiedAccounts('add', updatedAccount)
        : this.updateModifiedAccounts('edit', updatedAccount);

      const updatedAccounts = isNewAccount
        ? directDepositAccounts.concat(updatedAccount)
        : directDepositAccounts.map((account) =>
          (account?.pendingData ?? account?.currentData)?.id === updatedAccount.pendingData?.id
            ? updatedAccount
            : account
        );

      this.directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS, {
        data: updatedAccounts
      });
    }

    return this.directDepositStore.getDDAccountsSnapshot();
  }

  private updateModifiedAccounts(
    typeOfChange: WorkflowUI.ChangeType,
    account: DirectDepositAccount
  ): void {
    const allModifications = this.directDepositStore.allModifications;
    let alreadyModifiedAccount: boolean = false;
    let recentlyAdded: boolean = false;

    Object.keys(allModifications ?? {})?.forEach((changeType) => {
      alreadyModifiedAccount = allModifications?.[changeType]?.some(
        (_account: DirectDepositAccount) => {
          if (
            changeType === 'add' &&
            (_account?.pendingData ?? _account?.currentData)?.id ===
              (account?.pendingData ?? account?.currentData)?.id
          ) {
            recentlyAdded = true;
          }

          return (
            (_account?.pendingData ?? _account?.currentData)?.id ===
            (account?.pendingData ?? account?.currentData)?.id
          );
        }
      );
    });

    if (typeOfChange === 'delete' && recentlyAdded) {
      this.directDepositStore.update(DirectDepositStoreSlice.MODIFIED_ACCOUNTS, {
        data: {
          add: [
            ...this.directDepositStore
              .getModifications('add')
              .filter(
                (_account: DirectDepositAccount) =>
                  (_account?.pendingData ?? _account?.currentData)?.id !==
                  (account?.pendingData ?? account?.currentData)?.id
              )
          ]
        }
      });
    }

    if (!alreadyModifiedAccount) {
      ({
        add: () =>
          this.directDepositStore.update(DirectDepositStoreSlice.MODIFIED_ACCOUNTS, {
            data: {
              add: [...this.directDepositStore.getModifications('add'), account]
            }
          }),
        edit: () =>
          this.directDepositStore.update(DirectDepositStoreSlice.MODIFIED_ACCOUNTS, {
            data: {
              edit: [...this.directDepositStore.getModifications('edit'), account]
            }
          }),
        delete: () =>
          this.directDepositStore.update(DirectDepositStoreSlice.MODIFIED_ACCOUNTS, {
            data: {
              delete: [...this.directDepositStore.getModifications('delete'), account]
            }
          })
      }[typeOfChange]());
    }
  }

  private async saveAccounts(
    accountsToPOST: DirectDepositAccount[],
    wfRecallRequired: boolean,
    wfPostRequired: boolean,
    usesNonCompliantSchema: boolean
  ): Promise<void> {
    const includePrenoteBypassIndicator = this.directDepositStore.hasPermission('GIACT');

    if (wfRecallRequired) {
      await this.payDistributionStoreActions.recallDistributions();

      if (wfPostRequired) {
        await this.payDistributionStoreActions.postDistributions(
          accountsToPOST,
          usesNonCompliantSchema,
          includePrenoteBypassIndicator
        );
      }
    } else {
      await this.payDistributionStoreActions.postDistributions(
        accountsToPOST,
        usesNonCompliantSchema,
        includePrenoteBypassIndicator
      );
    }
  }

  private async setFeatureProviderOptions(): Promise<void> {
    const sorProvider: string = (
      await this.userProfileService
        .getApplicationId('MobileESSPayDistribution')
        .pipe(take(1))
        .toPromise()
    ).toUpperCase();

    this.directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_CONFIG, {
      data: {
        sorProvider: sorProvider
      }
    });
  }

  private async setPermissions(): Promise<void> {
    const wiselyDirect = await this.payPermissionService.hasWiselyDirectPermissionPromise();
    const wiselyPay = await this.payPermissionService.hasWiselyPayPermissionPromise();

    const canValidateBankInfo = await this.payDistributionStore.stateValue[
      PayDistributionsStoreSlice.PAY_DISTRIBUTIONS_META
    ].data?.meta?.canValidateBankInfo;

    const GIACT = await this.payPermissionService
      .hasDirectDepositAccountManagementPermissionPromise()
      .then((hasDepositAccountValidate: boolean) => {
        return canValidateBankInfo && hasDepositAccountValidate;
      });

    this.directDepositStore.update(DirectDepositStoreSlice.PERMISSIONS, {
      data: {
        [WiselyTypes.WISELY_DIRECT]: wiselyDirect,
        [WiselyTypes.WISELY_PAY]: wiselyPay,
        GIACT,
        canValidateBankInfo
      }
    });
  }
}
