import { Component } from '@angular/core';
import { ContentDemo } from '../../models/content-demo.model';

@Component({
  selector: 'twm-content-demo',
  templateUrl: './content-demo.component.html',
  styleUrls: ['./content-demo.component.scss']
})
export class ContentDemoComponent {
  public formItems = ContentDemo;
}
