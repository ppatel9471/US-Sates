import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { StatementBehaviorSubject } from '../models/pdf-viewer.model';

@Injectable({
  providedIn: 'root'
})
export class DownloadPdfService {
  public pdfSlideinData$: BehaviorSubject<StatementBehaviorSubject>;

  constructor(private http: HttpClient) {
    this.pdfSlideinData$ = new BehaviorSubject(null);
  }

  public getPdf(url: string): Observable<ArrayBuffer> {
    return this.http.get(url, { responseType: 'arraybuffer' });
  }
}
