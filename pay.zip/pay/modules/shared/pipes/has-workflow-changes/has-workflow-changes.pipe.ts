import { Pipe, PipeTransform } from '@angular/core';

import { WorkflowUI } from '../../models/workflow-ui.model';

@Pipe({ name: 'hasWorkflowChanges', pure: true })
export class HasWorkflowChangesPipe implements PipeTransform {
  public transform<WorkflowData extends { pendingEvent?: WorkflowUI.PendingEvent }>(
    workflowData: WorkflowData[]
  ): boolean {
    return workflowData?.some((data) => data?.pendingEvent !== null);
  }
}
