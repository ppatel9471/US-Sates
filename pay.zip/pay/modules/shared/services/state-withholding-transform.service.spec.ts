import { CurrencyPipe } from '@angular/common';
import { TestBed } from '@angular/core/testing';
import { merge } from 'lodash';
import { Mock } from 'ts-mockery';

import { CURRENCY, LanguageService } from '@myadp/common';

import { WithholdingType } from '../../../models/formatted-tax-withholding.model';
import { getState } from '../../../models/states.model';
import { PendingEventType } from '../../../models/tax-withholding.model';
import { StateIncomeTaxWithholdingElection, UsStateTaxWithholdingElections } from '../../../models/us-state-tax-withholding-election.model';
import { FederalStateVersionService } from './federal-state-version.service';
import { StateWithholdingTransformService } from './state-withholding-transform.service';
import { ValueFormatterService } from './value-formatter.service';
import { WithholdingFormatterService } from './withholding-formatter.service';

describe('StateWithholdingTransformService', () => {
  let service: StateWithholdingTransformService;
  let mockWithholdingData: UsStateTaxWithholdingElections;
  let mockStateElection: StateIncomeTaxWithholdingElection;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        StateWithholdingTransformService,
        WithholdingFormatterService,
        ValueFormatterService,
        CurrencyPipe,
        {
          provide: LanguageService,
          useValue: Mock.of<LanguageService>({ get: (key) => key })
        },
        {
          provide: FederalStateVersionService,
          useValue: Mock.of<FederalStateVersionService>({ getYearState: (s) => getState(s) })
        }
      ]
    });
  });

  beforeEach(() => {
    service = TestBed.inject(StateWithholdingTransformService);
  });

  describe('summary items', () => {
    beforeEach(() => {
      mockStateElection = {
        stateCode: { codeValue: 'GA', longName: 'Georgia' }
      };
      mockWithholdingData = {
        usStateTaxWithholdingElections: [
          {
            stateIncomeTaxWithholdingElections: [
              mockStateElection,
              {
                stateCode: { codeValue: 'AL', longName: 'Alabama' },
                taxWithholdingAllowanceQuantity: 1
              }
            ]
          }
        ]
      };
    });

    it('should show allowances when it is >=0', () => {
      merge(mockStateElection, { taxWithholdingAllowanceQuantity: 0 });

      expectSummaryItemsToEqual(
        jasmine.arrayContaining([
          {
            displayName: 'TOTAL_ALLOWANCES',
            displayValue: 0
          }
        ])
      );
    });

    it('should hide allowances when it is not in the response or it is <0', () => {
      expectSummaryItemsToEqual([]);

      merge(mockStateElection, { taxWithholdingAllowanceQuantity: -1 });
      expectSummaryItemsToEqual([]);
    });

    it('should show withholding status when user is exempt', () => {
      merge(mockStateElection, {
        taxWithholdingStatus: { statusCode: { codeValue: 'X' } }
      });

      expectSummaryItemsToEqual(
        jasmine.arrayContaining([
          {
            displayName: 'WITHHOLDING_STATUS',
            displayValue: 'myadp-pay.EXEMPT'
          }
        ])
      );
    });

    it('should hide withholding status when user is non-exempt', () => {
      merge(mockStateElection, {
        taxWithholdingStatus: {}
      });
      expectSummaryItemsToEqual([]);
    });

    it('should show withhold lower rate yes', () => {
      merge(mockStateElection, {
        additionalStatutoryInputs: [
          {
            tagCode: 'LOWER_RATE',
            tagValues: ['true']
          }
        ]
      });
      expectSummaryItemsToEqual(
        jasmine.arrayContaining([
          {
            displayName: 'TWM_SHARED_SUMMARY_WITHHOLD_LOWER_RATE_HEADING',
            displayValue: 'common.YES'
          }
        ])
      );
    });

    it('should show withhold lower rate no', () => {
      merge(mockStateElection, {
        additionalStatutoryInputs: [
          {
            tagCode: 'LOWER_RATE',
            tagValues: ['false']
          }
        ]
      });
      expectSummaryItemsToEqual(
        jasmine.arrayContaining([
          {
            displayName: 'TWM_SHARED_SUMMARY_WITHHOLD_LOWER_RATE_HEADING',
            displayValue: 'common.NO'
          }
        ])
      );
    });

    it('should show annual allowance amount', () => {
      merge(mockStateElection, {
        additionalStatutoryInputs: [
          {
            tagCode: 'ANNUAL_WITHHOLDING_ALLOWANCE',
            tagValues: ['100']
          }
        ]
      });
      expectSummaryItemsToEqual(
        jasmine.arrayContaining([
          {
            displayName: 'TWM_CO2022_SUMMARY_ALLOWANCES_LABEL',
            displayValue: '$100.00'
          }
        ])
      );
    });

    it('should show total exemption amount', () => {
      merge(mockStateElection, {
        additionalStatutoryInputs: [
          {
            tagCode: 'TOTAL_EXEMPTION_AMOUNT',
            tagValues: ['100']
          }
        ]
      });
      expectSummaryItemsToEqual(
        jasmine.arrayContaining([
          {
            displayName: 'TWM_SHARED_SUMMARY_EXEMPTION_AMOUNT_HEADING',
            displayValue: '$100.00'
          }
        ])
      );
    });

    it('should show withholding code', () => {
      merge(mockStateElection, {
        additionalStatutoryInputs: [
          {
            tagCode: 'WITHHOLDING_CODE',
            tagValues: ['A']
          }
        ]
      });
      expectSummaryItemsToEqual(
        jasmine.arrayContaining([
          {
            displayName: 'TWM_CT_SUMMARY_WITHHOLDING_CODE_HEADING',
            displayValue: 'A'
          }
        ])
      );
    });

    it('should show reduced tax amount when it is >=0', () => {
      merge(mockStateElection, {
        reducedTaxAmount: {
          amountValue: 0,
          currencyCode: CURRENCY.CODE.USD
        }
      });
      expectSummaryItemsToEqual(
        jasmine.arrayContaining([
          {
            displayName: 'REDUCED_WITHHOLDING_AMOUNT',
            displayValue: '$0.00'
          }
        ])
      );
    });

    it('should hide reduced tax amount when it is not in the response or it is <0', () => {
      merge(mockStateElection, {
        reducedTaxAmount: {
          amountValue: -1,
          currencyCode: CURRENCY.CODE.USD
        }
      });
      expectSummaryItemsToEqual([]);
    });

    describe('Louisiana allowances', () => {
      it('should show total allowances if it is in the response', () => {
        merge(mockStateElection, {
          taxAllowances: [
            {
              allowanceTypeCode: { codeValue: 'PERSONAL' },
              taxAllowanceQuantity: 1
            }
          ]
        });

        expectSummaryItemsToEqual(
          jasmine.arrayContaining([
            {
              displayName: 'TOTAL_ALLOWANCES',
              displayValue: 1
            }
          ])
        );
      });

      it('should show number of dependents if it is in the response', () => {
        merge(mockStateElection, {
          taxAllowances: [
            {
              allowanceTypeCode: { codeValue: 'DEPENDENTS' },
              taxAllowanceQuantity: 3
            }
          ]
        });

        expectSummaryItemsToEqual(
          jasmine.arrayContaining([
            {
              displayName: 'TWM_LA_SUMMARY_NUMBER_OF_DEPENDENTS_HEADING',
              displayValue: 3
            }
          ])
        );
      });
    });

    describe('new york local', () => {
      it('should show new york city allowances if it is in the response', () => {
        merge(mockStateElection, {
          taxAllowances: [
            {
              allowanceTypeCode: { codeValue: 'NEW_YORK_CITY' },
              taxAllowanceQuantity: 2
            }
          ]
        });

        expectSummaryItemsToEqual(
          jasmine.arrayContaining([
            {
              displayName: 'TWM_NY_SUMMARY_NEW_YORK_CITY_ALLOWANCES_LABEL',
              displayValue: 2
            }
          ])
        );
      });

      it('should show new york city additional withholding if it is in the response', () => {
        merge(mockStateElection, {
          additionalStatutoryInputs: [
            {
              tagCode: 'NEW_YORK_CITY_ADDITIONAL_WITHHOLDING',
              tagValues: ['2']
            }
          ]
        });

        expectSummaryItemsToEqual(
          jasmine.arrayContaining([
            {
              displayName: 'TWM_NY_SUMMARY_NEW_YORK_CITY_ADDITIONAL_WITHHOLDING_LABEL',
              displayValue: '$2.00'
            }
          ])
        );
      });

      it('should show yonkers additional withholding if it is in the response', () => {
        merge(mockStateElection, {
          additionalStatutoryInputs: [
            {
              tagCode: 'YONKERS_ADDITIONAL_WITHHOLDING',
              tagValues: ['2']
            }
          ]
        });

        expectSummaryItemsToEqual(
          jasmine.arrayContaining([
            {
              displayName: 'TWM_NY_SUMMARY_YONKERS_ADDITIONAL_WITHHOLDING_LABEL',
              displayValue: '$2.00'
            }
          ])
        );
      });
    });
  });

  describe('withholding model', () => {
    beforeEach(() => {
      mockStateElection = {
        livedInJurisdictionIndicator: true,
        workedInJurisdictionIndicator: false,
        stateCode: { codeValue: 'GA', longName: 'Georgia' },
        taxWithholdingAllowanceQuantity: 1,
        taxFilingStatusCode: {
          codeValue: 'X',
          longName: 'Married Filing Jointly or Sep'
        },
        attachments: [
          {
            nameCode: {
              codeValue: 'TAX_WITHHOLDING',
              shortName: 'G-4'
            },
            attachmentLink: {
              payLoadArguments: [
                {
                  argumentPath: 'gssID',
                  argumentValue: '31cb9db9-4ffd-4f7d-9743-dd23b64c9e3c'
                }
              ]
            }
          }
        ]
      };
      mockWithholdingData = {
        usStateTaxWithholdingElections: [
          {
            stateIncomeTaxWithholdingElections: [
              mockStateElection,
              {
                stateCode: { codeValue: 'AL', longName: 'Alabama' },
                taxWithholdingAllowanceQuantity: 1
              }
            ],
            payrollGroupCode: {
              codeValue: 'myPayrollGroupCode'
            },
            payrollRegionCode: {
              codeValue: 'myPayrollRegionCode'
            },
            workflowData: {
              pendingData: {
                usStateTaxWithholdingElections: [
                  {
                    stateIncomeTaxWithholdingElections: [
                      {
                        stateCode: { codeValue: 'GA', longName: 'Georgia' },
                        taxWithholdingAllowanceQuantity: 2,
                        taxFilingStatusCode: {
                          codeValue: 'X',
                          longName: 'Married Filing Jointly or Sep'
                        }
                      }
                    ]
                  }
                ]
              },
              pendingEvents: {
                eventTypeId: PendingEventType.EMPLOYEE_INITIATED,
                history: [
                  {
                    assignedTo: 'Smith, Bob',
                    actionTaken: 'None',
                    actionDate: 12345,
                    comments: 'comment',
                    processStepID: 6789
                  }
                ]
              }
            }
          }
        ]
      };
    });

    it('should populate basic state information', () => {
      const mockPendingEvents =
        mockWithholdingData.usStateTaxWithholdingElections[0].workflowData.pendingEvents;
      const withholdingItems = service.getWithholdingItems(mockWithholdingData);

      expect(withholdingItems[1].type).toEqual(WithholdingType.STATE);
      expect(withholdingItems[1].state).toEqual(getState('GA'));
      expect(withholdingItems[1].title).toEqual('Georgia');
      expect(withholdingItems[1].payrollGroupCode).toEqual({ codeValue: 'myPayrollGroupCode' });
      expect(withholdingItems[1].payrollRegionCode).toEqual({ codeValue: 'myPayrollRegionCode' });
      expect(withholdingItems[1].rawData).toEqual(mockStateElection);
      expect(withholdingItems[1].pendingEvents).toEqual(mockPendingEvents);
      expect(withholdingItems[1].attachments.length).toEqual(1);
      expect(withholdingItems[1].livedIn).toEqual(true);
      expect(withholdingItems[1].workedIn).toEqual(false);
    });

    it('should handle effectiveDate scenarios', () => {
      // valid effectiveDate
      mockStateElection['taxWithholdingStatus'] = {
        effectiveDate: '2020-01-01'
      };
      const withholdingItemsOne = service.getWithholdingItems(mockWithholdingData);
      expect(withholdingItemsOne[1].effectiveDate).toEqual(
        mockStateElection.taxWithholdingStatus.effectiveDate
      );

      // invalid effectiveDate
      mockStateElection['taxWithholdingStatus'] = {
        effectiveDate: 'invalid'
      };
      const withholdingItemsTwo = service.getWithholdingItems(mockWithholdingData);
      expect(withholdingItemsTwo[1].effectiveDate).toEqual('invalid');
    });

    it('should not populate pending summary items when there is none', () => {
      delete mockWithholdingData.usStateTaxWithholdingElections[0].workflowData;
      const withholdingItems = service.getWithholdingItems(mockWithholdingData);

      expect(withholdingItems[1].pendingSummaryItems).toBeUndefined();
    });

    it('should populate pending summary items when this is the item that changed', () => {
      const withholdingItems = service.getWithholdingItems(mockWithholdingData);

      expect(withholdingItems[0].pendingSummaryItems).toBeUndefined();
      expect(withholdingItems[0].pendingEvents).toBeUndefined();

      expect(withholdingItems[1].pendingSummaryItems).toBeDefined();
      expect(withholdingItems[1].pendingEvents).toBeDefined();
    });
  });

  describe('is state locked', () => {
    beforeEach(() => {
      mockStateElection = {
        stateCode: { codeValue: 'GA', longName: 'Georgia' },
        actions: [
          {
            operationID: '',
            attestation: {
              messageTxt: ''
            }
          }
        ]
      };
      mockWithholdingData = {
        usStateTaxWithholdingElections: [
          {
            stateIncomeTaxWithholdingElections: [
              mockStateElection,
              {
                stateCode: { codeValue: 'AL', longName: 'Alabama' },
                taxWithholdingAllowanceQuantity: 1
              }
            ]
          }
        ]
      };
    });

    it('should return true if state is locked', () => {
      mockStateElection.actions[0].operationID = 'worker.usState.taxWithholding.election.read';
      const withholdingItems = service.getWithholdingItems(mockWithholdingData);
      expect(withholdingItems[1].isLocked).toEqual(true);
    });

    it('should return false if state is not locked', () => {
      mockStateElection.actions[0].operationID = 'worker.usState.taxWithholding.election.change';
      const withholdingItems = service.getWithholdingItems(mockWithholdingData);
      expect(withholdingItems[1].isLocked).toEqual(false);
    });

    it('should return messageTxt', () => {
      const mockMessageTxt = 'TWT_1001';
      mockStateElection.actions[0].operationID = 'worker.usState.taxWithholding.election.read';
      mockStateElection.actions[0].attestation.messageTxt = mockMessageTxt;
      const withholdingItems = service.getWithholdingItems(mockWithholdingData);
      expect(withholdingItems[1].lockedOutMessage).toEqual(mockMessageTxt);
    });

    it('should return state locked false if there is no actions field', () => {
      mockStateElection.actions = undefined;
      const withholdingItems = service.getWithholdingItems(mockWithholdingData);
      expect(withholdingItems[1].isLocked).toEqual(false);
    });
  });

  function expectSummaryItemsToEqual(expectedValue: any) {
    const withholdingItem = service.getWithholdingItems(mockWithholdingData);
    expect(withholdingItem[1].summaryItems).toEqual(expectedValue);
  }
});
