import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from '@synerg/components/button';
import { CheckboxModule } from '@synerg/components/checkbox';
import { FormGroupModule } from '@synerg/components/form-group';
import { IconModule } from '@synerg/components/icon';
import { PopoverModule } from '@synerg/components/popover';
import { RadioGroupModule } from '@synerg/components/radio-group';
import { TextboxModule } from '@synerg/components/textbox';

import { MyAdpCommonModule } from '@myadp/common';
import { MyAdpFormsModule } from '@myadp/forms';

// TODO deprecate once radio-group deprecates HelpTooltipComponent
import { SharedModule } from '../shared/shared.module';
import { ContentFormItemComponent } from './components/content-form-item/content-form-item.component';
import { ContentLinkItemComponent } from './components/content-form-item/content-link-item/content-link-item.component';
import { ContentTextItemComponent } from './components/content-form-item/content-text-item/content-text-item.component';
import { ContentTooltipItemComponent } from './components/content-form-item/content-tooltip-item/content-tooltip-item.component';
import { TwmCurrencyInputComponent } from './components/twm-currency-input/twm-currency-input.component';
import { TwmConfirmExemptComponent } from './components/twm-custom-inputs/twm-confirm-exempt/twm-confirm-exempt.component';
import { TwmCheckboxGroupComponent } from './components/twm-form-group/twm-checkbox-group/twm-checkbox-group.component';
import { TwmRadioGroupComponent } from './components/twm-form-group/twm-radios-group/twm-radio-group.component';

@NgModule({
  imports: [
    MyAdpCommonModule,
    FormGroupModule,
    FormsModule,
    MyAdpFormsModule,
    RadioGroupModule,
    PopoverModule,
    IconModule,
    ButtonModule,
    CheckboxModule,
    SharedModule,
    TextboxModule
  ],
  declarations: [
    TwmCheckboxGroupComponent,
    TwmRadioGroupComponent,
    ContentFormItemComponent,
    ContentTextItemComponent,
    ContentLinkItemComponent,
    ContentTooltipItemComponent,
    TwmConfirmExemptComponent,
    TwmCurrencyInputComponent
  ],
  exports: [
    TwmCheckboxGroupComponent,
    TwmRadioGroupComponent,
    ContentFormItemComponent,
    ContentTextItemComponent,
    ContentLinkItemComponent,
    ContentTooltipItemComponent,
    TwmConfirmExemptComponent,
    TwmCurrencyInputComponent
  ]
})
export class MetaModule {}
