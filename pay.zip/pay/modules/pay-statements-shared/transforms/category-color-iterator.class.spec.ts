import { CategoryColorIterator, buildColorIterator } from './category-color-iterator.class';

describe('CategoryColorIterator', () => {
  it('should construct a new CategoryColorIterator', () => {
    const categoryColorIterator = new CategoryColorIterator(['red', 'blue', 'green']);

    expect(categoryColorIterator.nextColor()).toBe('red');
    expect(categoryColorIterator.nextColor()).toBe('blue');
    expect(categoryColorIterator.nextColor()).toBe('green');
    expect(categoryColorIterator.nextColor()).toBe('red');
  });

  it('should iterate through the colors', () => {
    const colorIterator = buildColorIterator();

    expect(colorIterator).toBeTruthy();
    expect(colorIterator.nextColor()).toBe('#21a0c0');
    expect(colorIterator.nextColor()).toBe('#ea6f0b');
    expect(colorIterator.nextColor()).toBe('#dd57ff');
    expect(colorIterator.nextColor()).toBe('#21a0c0');
  });
});
