import {
  DistributionOptions,
  PayDistributionsUI
} from '../../pay-distributions-shared/models/pay-distributions-ui';
import { AccountDetailsControls } from '../models/account-details-form.model';
import { DepositAmountControls } from '../models/deposit-amount-form.model';
import { transformToFormDetails } from './form-details.transform';

describe('transformToFormDetails', () => {
  it('should transform PayDistributionDetails to FormDetails', () => {
    const depositAccountDetails: Partial<PayDistributionsUI.PayDistributionDetails> = {
      accountTypeName: 'Checking',
      codeValueData: {
        accountCode: '105',
        longName: 'Checking',
        shortName: null
      },
      distributionType: DistributionOptions.PERCENTAGE,
      flatAmount: { amountValue: 0, currencyCode: 'USD' },
      percentageAmount: 23
    };

    expect(transformToFormDetails(depositAccountDetails)).toEqual({
      codeValueData: {
        accountCode: '105',
        longName: 'Checking',
        shortName: null
      },
      [AccountDetailsControls.ACCOUNT_TYPE_CODE]: {
        label: 'Checking',
        value: '105',
        shortName: null,
        longName: 'Checking'
      },
      distributionType: DistributionOptions.PERCENTAGE,
      [DepositAmountControls.PERCENTAGE_AMOUNT]: '23',
      [DepositAmountControls.FLAT_AMOUNT]: null,
      accountTypeName: 'Checking'
    });
  });

  it('should transform PayDistributionDetails to FormDetails and handle nulls', () => {
    const depositAccountDetails: Partial<PayDistributionsUI.PayDistributionDetails> = {
      accountTypeName: 'Checking',
      codeValueData: {
        accountCode: '105',
        longName: 'Checking',
        shortName: null
      },
      distributionType: DistributionOptions.REMAINING,
      flatAmount: { amountValue: null, currencyCode: 'USD' },
      percentageAmount: null
    };

    expect(transformToFormDetails(depositAccountDetails)).toEqual({
      codeValueData: {
        accountCode: '105',
        longName: 'Checking',
        shortName: null
      },
      [AccountDetailsControls.ACCOUNT_TYPE_CODE]: {
        label: 'Checking',
        value: '105',
        longName: 'Checking',
        shortName: null
      },
      distributionType: DistributionOptions.REMAINING,
      [DepositAmountControls.PERCENTAGE_AMOUNT]: null,
      [DepositAmountControls.FLAT_AMOUNT]: null,
      accountTypeName: 'Checking'
    });
  });
});
