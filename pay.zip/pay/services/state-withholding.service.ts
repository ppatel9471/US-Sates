import { Injectable } from '@angular/core';
import { from, Observable } from 'rxjs';

import { BaseHttpClient } from '@myadp/common';
import { PAY_SFFO } from '@myadp/pay-shared';

import { WorkflowStatus } from '../models/tax-withholding.model';
import { UsStateTaxWithholdingElections } from '../models/us-state-tax-withholding-election.model';
import { WorkerUSWithholdingElectionChangeResponse } from '../modules/tax-withholding-management/us/shared/models/state-income-tw-election-event';

@Injectable({
  providedIn: 'root'
})
export class StateWithholdingService {
  constructor(private baseHttpClient: BaseHttpClient) {}

  public getStateWithholding(): Promise<UsStateTaxWithholdingElections> {
    return this.baseHttpClient.get<UsStateTaxWithholdingElections>({
      userPermission: PAY_SFFO.TAX_WITHHOLDING_STATE_READ
    });
  }

  public saveWithholding(body: Object): Observable<WorkerUSWithholdingElectionChangeResponse> {
    return from(
      this.baseHttpClient.post<WorkerUSWithholdingElectionChangeResponse>({
        userPermission: PAY_SFFO.TAX_WITHHOLDING_STATE_CHANGE,
        payload: body
      })
    );
  }

  public recallWithholding(): Observable<WorkflowStatus> {
    return from(
      this.baseHttpClient.post<WorkflowStatus>({
        userPermission: PAY_SFFO.TAX_WITHHOLDING_STATE_CHANGE,
        useWorkflow: true,
        urlTransform: (url: string) => `/recall${url}`
      })
    );
  }
}
