import { of } from 'rxjs';
import { Shallow } from 'shallow-render';

import { PrivacyModeStore } from '../../../privacy-mode-shared/store/privacy-mode.store';
import { SharedModule } from '../../shared.module';
import { NumberFormatComponent } from './number-format.component';

describe('NumberFormatComponent', () => {
  let shallow: Shallow<NumberFormatComponent>;

  beforeEach(() => {
    shallow = new Shallow(NumberFormatComponent, SharedModule).mock(PrivacyModeStore, {
      showMaskedValue$: of(false)
    });
  });

  it('should display the given text when the text is valid', async () => {
    const num: number = 1234;
    const { find } = await shallow.render({
      bind: {
        value: num
      }
    });

    expect(find('[data-e2e="value-section"]').nativeElement.innerHTML).toContain(num);
    expect(find('[data-e2e="double-dash-section"]')).toHaveFound(0);
  });

  it('should display the value zero', async () => {
    const num: number = 0;
    const { find } = await shallow.render({
      bind: {
        value: num
      }
    });

    expect(find('[data-e2e="value-section"]').nativeElement.innerHTML).toContain(num);
    expect(find('[data-e2e="double-dash-section"]')).toHaveFound(0);
  });

  it('should display two dashes when the given content is null', async () => {
    const { find } = await shallow.render({
      bind: {
        value: null
      }
    });

    expect(find('[data-e2e="value-section"]')).toHaveFound(0);
    expect(find('[data-e2e="double-dash-section"]').nativeElement.innerHTML).toContain('--');
  });

  it('should display two dashes when the given content is undefined', async () => {
    const { find } = await shallow.render({
      bind: {
        value: undefined
      }
    });

    expect(find('[data-e2e="value-section"]')).toHaveFound(0);
    expect(find('[data-e2e="double-dash-section"]').nativeElement.innerHTML).toContain('--');
  });

  it('should display the value if set to ignore privacy mode', async () => {
    const num: number = 123;
    const { find } = await shallow.render({
      bind: {
        value: num,
        hasPrivacyMode: false
      }
    });

    expect(find('[data-e2e="value-section"]').nativeElement.innerHTML).toContain(num);
  });

  describe('Privacy Mode', () => {
    it('should display obfuscated value when privacy mode is enabled', async () => {
      const { find } = await shallow
        .mock(PrivacyModeStore, {
          showMaskedValue$: of(true)
        })
        .render({
          bind: {
            value: 123,
            hasPrivacyMode: true
          }
        });

      expect(find('[data-e2e="value-section"]').nativeElement.innerHTML).toContain('XXXX');
    });

    it('should display the value if set to ignore privacy mode', async () => {
      const num: number = 123;
      const { find } = await shallow
        .mock(PrivacyModeStore, {
          showMaskedValue$: of(true)
        })
        .render({
          bind: {
            value: num,
            hasPrivacyMode: false
          }
        });

      expect(find('[data-e2e="value-section"]').nativeElement.innerHTML).toContain(num);
    });
  });
});
