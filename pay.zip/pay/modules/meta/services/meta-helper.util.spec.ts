import { WizardMeta } from '../../tax-withholding-management/shared/models/steps-type.model';
import { FormItem, ListItem } from '../models/form-item.model';
import { getMetaFormItem, getMetaFormListItem, getMetaListItem } from './meta-helper.util';

describe('Meta Helper Util', () => {
  const mockWizardMeta: WizardMeta = {
    formItems: [
      {
        id: 'id_A',
        list: [
          {
            label: 'label_AA',
            value: 'value_AA'
          }
        ]
      },
      {
        id: 'id_B',
        list: [
          {
            label: 'label_BA',
            value: 'value_BA'
          },
          {
            label: 'label_BB',
            value: 'value_BB'
          }
        ]
      },
      {
        id: 'id_D',
        instructions: 'Do a thing'
      }
    ]
  };

  describe('getMetaFormItem', () => {
    it('should get a form item', () => {
      expect(getMetaFormItem(mockWizardMeta, 'id_A')).toEqual(mockWizardMeta.formItems[0]);
    });

    it('should return undefined', () => {
      expect(getMetaFormItem(mockWizardMeta, 'id_C')).toBeUndefined();
    });
  });

  describe('getMetaFormListItem', () => {
    it('should get a list item', () => {
      const listItems: ListItem[] = getMetaFormListItem(mockWizardMeta, 'id_A');

      expect(listItems.length).toBe(1);
      expect(listItems).toEqual(mockWizardMeta.formItems[0].list);
    });

    it('should return undefined', () => {
      expect(getMetaFormListItem(mockWizardMeta, 'id_D')).toBeUndefined();
    });
  });

  describe('getMetaListItem', () => {
    it('should get list items', () => {
      const formItem: FormItem = getMetaFormItem(mockWizardMeta, 'id_B');
      const listItems: ListItem[] = getMetaListItem(formItem);

      expect(listItems.length).toBe(2);
      expect(listItems).toEqual(mockWizardMeta.formItems[1].list);
    });

    it('should return undefined', () => {
      const formItem: FormItem = getMetaFormItem(mockWizardMeta, 'id_D');
      const listItems: ListItem[] = getMetaListItem(formItem);

      expect(listItems).toBeUndefined();
    });
  });
});
