import { TestBed } from '@angular/core/testing';

import { PayDeductionsUI } from '../../pay-deductions-shared/models/pay-deductions-ui';
import { DeductionDetailsSelectorPipe } from './deduction-details-selector.pipe';

const deductions: PayDeductionsUI.Deduction[] = [
  {
    currentData: {
      itemID: 'A',
      deductionCode: {
        codeValue: 'A',
        longName: 'Medicare Surtax'
      },
      deductionRate: {
        rateValue: 100,
        currencyCode: 'USD'
      }
    },
    pendingData: null,
    pendingEvent: null
  },
  {
    currentData: {
      itemID: 'B',
      deductionCode: {
        codeValue: 'B',
        longName: 'B Ded'
      },
      deductionRate: {
        rateValue: 12,
        currencyCode: 'USD'
      }
    },
    pendingData: null,
    pendingEvent: { changeType: 'delete' }
  },
  {
    currentData: {
      itemID: 'C',
      deductionCode: {
        codeValue: 'C',
        longName: 'Company Ded'
      },
      deductionRate: {
        rateValue: 2,
        unitCode: { codeValue: 'percent' }
      }
    },
    pendingData: {
      itemID: 'C',
      deductionCode: {
        codeValue: 'C',
        longName: 'Company Ded'
      },
      deductionRate: {
        rateValue: 5,
        unitCode: { codeValue: 'percent' }
      }
    },
    pendingEvent: { changeType: 'edit' }
  }
];

describe('DeductionDetailsSelectorPipe', () => {
  let pipe: DeductionDetailsSelectorPipe;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DeductionDetailsSelectorPipe]
    });
    pipe = new DeductionDetailsSelectorPipe();
  });

  it('should transform deductions for list mode', () => {
    expect(pipe.transform(deductions)).toEqual([
      {
        ...deductions[0].currentData,
        deduction: deductions[0],
        pendingEvent: null
      },
      {
        ...deductions[1].currentData,
        deduction: deductions[1],
        pendingEvent: { changeType: 'delete' }
      },
      {
        ...deductions[2].pendingData,
        deduction: deductions[2],
        pendingEvent: { changeType: 'edit' }
      }
    ]);
  });

  it('should transform deductions for tile mode', () => {
    expect(pipe.transform(deductions, 'tile')).toEqual([
      {
        ...deductions[0].currentData,
        deduction: deductions[0],
        pendingEvent: null
      },
      {
        ...deductions[2].pendingData,
        deduction: deductions[2],
        pendingEvent: { changeType: 'edit' }
      }
    ]);
  });
});
