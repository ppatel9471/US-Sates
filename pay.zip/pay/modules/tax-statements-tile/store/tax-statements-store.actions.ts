import { Injectable } from '@angular/core';
import { Logger } from 'log4javascript';
import { LoggerFactory } from '@espresso/core';
import { WorkerTaxStatementsDTO } from '@myadp/dto';

import { TaxStatementsService } from '../services/tax-statements.service';
import { TaxStatementsStoreSlice } from '../models/tax-statements-state.model';
import { TaxStatementsStore } from './tax-statements.store';

@Injectable({
  providedIn: 'root'
})
export class TaxStatementsStoreActions {
  private logger: Logger;

  constructor(
    private taxStatementsService: TaxStatementsService,
    private taxStatementsStore: TaxStatementsStore,
    private loggerFactory: LoggerFactory
  ) {
    this.logger = this.loggerFactory.getLogger(
      'pay.modules.taxStatementsTile.store.taxStatementsStore'
    );
  }

  public getTaxStatements(): void {
    this.taxStatementsStore.update(TaxStatementsStoreSlice.TAX_STATEMENTS, {
      loading: true,
      error: null
    });

    this.taxStatementsService
      .getTaxStatements()
      .then((results: WorkerTaxStatementsDTO.APIResponse) => {
        const taxStatements = results?.workerTaxStatements;
        if (taxStatements) {
          taxStatements.map((statement: WorkerTaxStatementsDTO.WorkerTaxStatement) => {
            // if no tax year, default it to 0
            if (!statement.statementYear?.year) {
              statement.statementYear = { year: '0' };
            }
            return statement;
          });
        }
        this.taxStatementsStore.update(TaxStatementsStoreSlice.TAX_STATEMENTS, {
          data: taxStatements
        });
      })
      .catch((error) => {
        this.taxStatementsStore.update(TaxStatementsStoreSlice.TAX_STATEMENTS, {
          error: {
            loadTaxStatementsError: true,
            info: error
          }
        });
        this.logger.error('getTaxStatements', error);
      })
      .finally(() => {
        this.taxStatementsStore.update(TaxStatementsStoreSlice.TAX_STATEMENTS, {
          loading: false
        });
      });
  }
}
