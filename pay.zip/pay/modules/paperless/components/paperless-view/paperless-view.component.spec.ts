import { Shallow } from 'shallow-render';
import { Mock } from 'ts-mockery';

import { PageType, PaperlessStoreActions } from '@myadp/pay-paperless-shared';
import { PaperlessModule } from '../../paperless.module';
import { PaperlessViewComponent } from './paperless-view.component';

describe('PaperlessViewComponent', () => {
  let shallow: Shallow<PaperlessViewComponent>;

  beforeEach(() => {
    shallow = new Shallow(PaperlessViewComponent, PaperlessModule).mock(PaperlessStoreActions, {
      getAllPreferences: () => Mock.noop()
    });
  });

  it('should initialize', async () => {
    const { get } = await shallow.render({
      bind: {
        pageType: PageType.CAMPAIGN
      }
    });
    const mockPaperlessStoreActions = get(PaperlessStoreActions);

    expect(mockPaperlessStoreActions.getAllPreferences).toHaveBeenCalled();
  });
});
