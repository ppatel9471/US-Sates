import { Shallow } from 'shallow-render';
import { Mock } from 'ts-mockery';

import { MyADPDirectDepositModule } from '../../direct-deposit.module';
import { StepsStoreActions } from '../../store/steps/steps.store';
import { DirectDepositContainerComponent } from './direct-deposit-container.component';

describe('DirectDepositContainerComponent', () => {
  let shallow: Shallow<DirectDepositContainerComponent>;

  beforeEach(() => {
    shallow = new Shallow(DirectDepositContainerComponent, MyADPDirectDepositModule).mock(
      StepsStoreActions,
      {
        init: () => Mock.noop()
      }
    );
  });

  it('should call to init steps store', async () => {
    const { find, get } = await shallow.render();
    const stepsStoreActions = get(StepsStoreActions);

    expect(find('dd-steps-navigation')).toHaveFound(0);
    expect(stepsStoreActions.init).toHaveBeenCalled();
  });

  it('should show navigation if not in tile mode', async () => {
    const { find } = await shallow.render({
      bind: {
        tileMode: false
      }
    });

    expect(find('dd-steps-navigation')).toHaveFoundOne();
  });
});
