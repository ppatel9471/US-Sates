export { PayDashboardTileModule } from './modules/pay-dashboard-tile/pay-dashboard-tile.module';
export { PayDashboardTileComponent } from './modules/pay-dashboard-tile/components/pay-dashboard-tile.component';
export { PayDashboardTileUnmaskComponent } from './modules/pay-dashboard-tile/components/pay-dashboard-tile-unmask.component';
