import { Observable } from 'rxjs';
import { DonutConfig } from '@synerg/components/donut';

import { Amount } from '@myadp/dto';
import { BaseStore } from '@myadp/pay-shared';

import { DeductionCategoryItem, PAY_CATEGORY_CONSTANTS } from '../models/pay-category-constants';
import {
  PayDashboardTileStoreSlice,
  PayDashboardTileStoreState
} from '../models/pay-dashboard-tile-state';
import {
  PayStatementsDTO
} from '../models/pay-statement.model';

export abstract class PayDashboardTileBaseService extends BaseStore<PayDashboardTileStoreState> {
  constructor() {
    super({
      [PayDashboardTileStoreSlice.PAY_STATEMENTS]: {
        data: {
          payStatements: null
        },
        loading: false,
        error: {}
      }
    });
  }

  abstract getPayStatements(): Promise<PayStatementsDTO>;

  public loadPayStatements() {
    if (this.stateValue[PayDashboardTileStoreSlice.PAY_STATEMENTS].data?.payStatements) {
      return;
    }
    this.update(PayDashboardTileStoreSlice.PAY_STATEMENTS, {
      loading: true
    });
    this.getPayStatements()
      .then((response: PayStatementsDTO) => {
        this.update(PayDashboardTileStoreSlice.PAY_STATEMENTS, {
          data: {
            payStatements: response
          }
        });
      })
      .catch(() => {
        this.update(PayDashboardTileStoreSlice.PAY_STATEMENTS, {
          error: {
            payStatementsError: true
          }
        });
      })
      .finally(() => {
        this.update(PayDashboardTileStoreSlice.PAY_STATEMENTS, {
          loading: false
        });
      });
  }

  public get payStatements(): PayStatementsDTO {
    return this.stateValue[PayDashboardTileStoreSlice.PAY_STATEMENTS].data?.payStatements ?? null;
  }

  public get payStatementsError(): boolean {
    return (
      this.stateValue[PayDashboardTileStoreSlice.PAY_STATEMENTS].error?.payStatementsError ?? false
    );
  }

  public payStatementsIsLoading$(): Observable<boolean> {
    return this.isSliceLoading$(PayDashboardTileStoreSlice.PAY_STATEMENTS);
  }

  getPayDonutConfig(
    grossPay: Amount,
    takeHome: Amount
  ): DonutConfig {
    return {
      showTooltips: !!(grossPay.amountValue && takeHome.amountValue),
      transparentBackground: true,
      size: 'sm',
      borderWidth: 2
    };
  }

  getPayDonutData(
    grossPay: Amount,
    takeHome: Amount
  ): Array<DeductionCategoryItem> {
    const donutData: Array<DeductionCategoryItem> = [];

    if (grossPay.amountValue && takeHome.amountValue) {
      const deductionsAmountValue = grossPay.amountValue - takeHome.amountValue;

      donutData.push({
        ...PAY_CATEGORY_CONSTANTS.deductions,
        amount: {
          amountValue: deductionsAmountValue,
          currencyCode: takeHome.currencyCode
        }
      });

      donutData.push({
        ...PAY_CATEGORY_CONSTANTS.takeHome,
        amount: takeHome
      });

    } else {
      donutData.push({
        ...PAY_CATEGORY_CONSTANTS.disabled
      });
    }

    return donutData;
  }
}
