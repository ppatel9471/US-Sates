import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { LoggerFactory } from '@espresso/core';
import * as log4javascript from 'log4javascript';
import { combineLatest, EMPTY, Observable } from 'rxjs';
import { catchError, distinctUntilChanged, map, take, takeWhile, tap } from 'rxjs/operators';

import { BaseHttpClient, LanguageService, UserProfileService } from '@myadp/common';
import { PayrollWorker, PayrollWorkerWorkAssignment, PayStatementsDTO, WorkAssignment, Worker } from '@myadp/dto';
import { FindSffoService, PAY_SFFO } from '@myadp/pay-shared';

import { TransparencyService } from '../../../services/transparency.service';
import { PdfStatement } from '../../shared/models/pdf-viewer.model';
import { WorkerInfoStoreActions } from '../../worker-info-shared/store/worker-info-store.actions';
import { WorkerInfoStore } from '../../worker-info-shared/store/worker-info.store';
import { PayStatementsStoreSlice, PayStatementsUI } from '../models/pay-statement-ui';
import { transformInsights } from '../transforms/deduction-insights.transform';
import { transformStatementDetails } from '../transforms/pay-statement-details.transform';
import { TransformConfig, transformStatements } from '../transforms/pay-statements.transform';
import { transformPdf } from '../transforms/statements-pdf-viewer.transform';
import { PayStatementStore } from './pay-statement.store';

@Injectable({
  providedIn: 'root'
})
export class PayStatementStoreActions {
  private logger: log4javascript.Logger;

  constructor(
    private httpClient: HttpClient,
    private baseHttpClient: BaseHttpClient,
    private loggerFactory: LoggerFactory,
    private findSffoService: FindSffoService,
    private languageService: LanguageService,
    private workerInfoStore: WorkerInfoStore,
    private payStatementStore: PayStatementStore,
    private userProfileService: UserProfileService,
    private transparencyService: TransparencyService,
    private workerInfoStoreActions: WorkerInfoStoreActions
  ) {
    this.payStatementStore.update(PayStatementsStoreSlice.PAY_STATEMENTS, {
      data: {
        hasNotificationPermission: this.setNotificationPermission()
      }
    });

    this.logger = this.loggerFactory.getLogger(
      'myadp.pay.pay-statements-shared.PayStatementStoreActions'
    );
  }

  public loadPayStatements(): void {
    this.payStatementStore.update(PayStatementsStoreSlice.PAY_STATEMENTS, {
      loading: true
    });

    const { sffo } = this.findSffoService.findSffo([
      PAY_SFFO.PAY_STATEMENTS_READ,
      PAY_SFFO.PAY_STATEMENTS_READ_LEGACY
    ]);

    if (sffo) {
      this.baseHttpClient
        .get<PayStatementsDTO.APIResponse>({
        userPermission: sffo,
        urlTransform: (url) => url.split('?')[0],
        query: {
          adjustments: 'yes',
          numberoflastpaydates: '160'
        }
      })
        .then((res) => {
          if (res) {
            const config = this.getTransformConfig();
            const statements: PayStatementsUI.PayStatement[] = transformStatements(res, config);
            const statementsForPdfViewer: PdfStatement[] = transformPdf(statements).map(
              (statement) => {
                statement.title = this.languageService.get(
                  'myadp-pay.PDF_VIEWER_SLIDEIN_HEADER_STATEMENT',
                  {
                    value: statement.title
                  }
                );
                return statement;
              }
            );
            let heroStatement: PayStatementsUI.PayStatement;

            // we want to exclude adjustments from hero
            heroStatement = statements.find((payStatement) => !payStatement.payAdjustment);

            this.payStatementStore.update(PayStatementsStoreSlice.PAY_STATEMENTS, {
              data: {
                statements,
                statementsForPdfViewer
              }
            });

            this.loadStatementDetails(heroStatement, true);
          }
        })
        .catch((error: HttpErrorResponse) => {
          this.payStatementStore.update(PayStatementsStoreSlice.PAY_STATEMENTS, {
            error: {
              statementsError: true
            }
          });

          this.payStatementStore.update(PayStatementsStoreSlice.CURRENT_STATEMENT_DETAILS, {
            error: {
              statementsError: true
            }
          });
          this.logger.error(`loadPayStatements() error: ${error.message}`);
        })
        .finally(() => {
          if (
            !this.payStatementStore.stateValue[PayStatementsStoreSlice.PAY_STATEMENTS].data ||
            !this.payStatementStore.stateValue[PayStatementsStoreSlice.PAY_STATEMENTS].data
              ?.statements ||
            this.payStatementStore.stateValue[PayStatementsStoreSlice.PAY_STATEMENTS].data
              ?.statements?.length === 0
          ) {
            // call worker api if no pay statement
            this.getWorker$().subscribe();
          }

          this.payStatementStore.update(PayStatementsStoreSlice.PAY_STATEMENTS, {
            loading: false
          });
        });
    } else {
      this.logger.error('Pay Permission not found!');
    }
  }

  public loadStatementDetails(
    currentStatement: PayStatementsUI.PayStatement,
    setStatementAsCurrent: boolean = true
  ): void {
    const { id, statementImageUri, payDetailUri, statementFiscalYear } = currentStatement;
    const currentStatementCache =
      this.payStatementStore.stateValue[PayStatementsStoreSlice.STATEMENT_DETAILS_CACHE]?.data[id];
    const statementDetailError =
      this.payStatementStore.stateValue[PayStatementsStoreSlice.STATEMENT_DETAILS_CACHE]?.error[id]
        ?.detailsError;
    const statementData = {
      id,
      statementImageUri,
      payDetailUri,
      statementFiscalYear,
      statement: currentStatement
    };

    if (setStatementAsCurrent) {
      this.payStatementStore.update(PayStatementsStoreSlice.CURRENT_STATEMENT_DETAILS, {
        data: statementData,
        error: {
          detailsError: false
        },
        loading: true
      });
    }

    // if current statement is in cache and statement detail has no error, put statement detail into current statement slice
    if (currentStatementCache && !statementDetailError) {
      if (setStatementAsCurrent) {
        this.payStatementStore.update(PayStatementsStoreSlice.CURRENT_STATEMENT_DETAILS, {
          data: currentStatementCache,
          error: {
            detailsError: false
          },
          loading: false
        });
      }
      this.getInsights(id, payDetailUri, setStatementAsCurrent);
    } else {
      // not in cache or statement detail has error. need make api call to fetch detail
      this.payStatementStore.update(PayStatementsStoreSlice.STATEMENT_DETAILS_CACHE, {
        data: { [id]: statementData },
        error: {
          [id]: { detailsError: false }
        },
        loading: true
      });

      if (payDetailUri) {
        this.requestStatementDetails(payDetailUri, id, setStatementAsCurrent);
      } else {
        this.payStatementStore.update(PayStatementsStoreSlice.STATEMENT_DETAILS_CACHE, {
          data: {
            [id]: {
              ...this.payStatementStore.stateValue[PayStatementsStoreSlice.STATEMENT_DETAILS_CACHE]
                .data[id],
              statementDetails: null
            }
          },
          error: {
            [id]: { detailsError: false }
          },
          loading: false
        });

        if (setStatementAsCurrent) {
          this.payStatementStore.update(PayStatementsStoreSlice.CURRENT_STATEMENT_DETAILS, {
            data: {
              statementDetails: null
            },
            error: {
              detailsError: false
            },
            loading: false
          });
        }

        this.logger.error(`loadStatementDetails() error: payDetailUri was not provided`);
      }
    }
  }

  public resetCurrentStatement(): void {
    const firstStatement = this.payStatementStore.stateValue[
      PayStatementsStoreSlice.PAY_STATEMENTS
    ]?.data?.statements.find((payStatement) => !payStatement.payAdjustment);
    if (firstStatement) {
      this.loadStatementDetails(firstStatement, true);
    }
  }

  public getNonAdjustmentStatements(): PayStatementsUI.PayStatement[] {
    return this.payStatementStore.stateValue[
      PayStatementsStoreSlice.PAY_STATEMENTS
    ]?.data?.statements.filter((statement: PayStatementsUI.PayStatement) => {
      return !statement.payAdjustment;
    });
  }

  public loadCompareStatements(statement1Id: number, statement2Id: number) {
    if (statement1Id) {
      this.loadStatementDetails(this.getNonAdjustmentStatementById(statement1Id), false);
    }
    if (statement2Id) {
      this.loadStatementDetails(this.getNonAdjustmentStatementById(statement2Id), false);
    }
  }

  public getTransformConfig(): TransformConfig {
    const SOR = this.userProfileService.getApplicationId('MobileESSPayStatements') || '';
    return {
      SOR: SOR.toUpperCase(),
      TRANSLATIONS: {
        UNKNOWN_DATE: this.languageService.get('myadp-pay.PAY_UNKNOWN_DATE'),
        ADJUSTMENT: this.languageService.get('myadp-pay.PAY_ADJUSTMENT')
      }
    };
  }

  private getNonAdjustmentStatementById(statementId: number) {
    return this.getNonAdjustmentStatements().filter(
      (statement: PayStatementsUI.PayStatement) => statement.id === statementId
    )[0];
  }

  private setNotificationPermission(): boolean {
    const { sffo, href } = this.findSffoService.findSffo([
      PAY_SFFO.PAYROLL_STATEMENT_PREFERENCES_READ
    ]);

    return !!sffo && !!href;
  }

  private getWorkerAssignment(worker: Worker | PayrollWorker): PayStatementsUI.WorkerPayInfo {
    const workAssignment: WorkAssignment | PayrollWorkerWorkAssignment =
      (worker as Worker)?.workAssignments?.[0] ?? (worker as PayrollWorker)?.workAssignment ?? null;
    const {
      payPeriodRateAmount,
      hourlyRateAmount,
      dailyRateAmount,
      weeklyRateAmount,
      biweeklyRateAmount,
      monthlyRateAmount,
      annualRateAmount
    } = workAssignment?.baseRemuneration ?? {};
    const { shortName, longName } = workAssignment?.payCycleCode ?? {};

    return {
      rate:
        payPeriodRateAmount ??
        hourlyRateAmount ??
        dailyRateAmount ??
        weeklyRateAmount ??
        biweeklyRateAmount ??
        monthlyRateAmount ??
        annualRateAmount,
      frequency: longName ?? shortName
    };
  }

  private getWorker$(): Observable<Worker> {
    this.workerInfoStoreActions.getWorker();

    return combineLatest([
      this.workerInfoStore.worker$(),
      this.workerInfoStore.workerError$()
    ]).pipe(
      distinctUntilChanged(),
      takeWhile(([worker, hasError]: [Worker, boolean]) => !hasError && worker === null, true),
      tap(([worker, hasError]: [Worker, boolean]) => {
        if (hasError) {
          this.logger.error(`getWorker() error`);
        }

        this.payStatementStore.update(PayStatementsStoreSlice.PAY_STATEMENTS, {
          data: {
            workerPayInfo: this.getWorkerAssignment(worker)
          }
        });
      }),
      map(([worker]: [Worker, boolean]) => worker)
    );
  }

  private requestStatementDetails(
    payDetailUri: string,
    id: number,
    setStatementAsCurrent: boolean
  ): void {
    const headers: HttpHeaders = new HttpHeaders({
      roleCode: 'employee'
    });
    this.httpClient
      .get(payDetailUri, { headers })
      .pipe(
        take(1),
        catchError((error) => {
          if (setStatementAsCurrent) {
            this.payStatementStore.update(PayStatementsStoreSlice.CURRENT_STATEMENT_DETAILS, {
              data: {
                statementDetails: null
              },
              error: {
                detailsError: true
              },
              loading: false
            });
          }

          this.payStatementStore.update(PayStatementsStoreSlice.STATEMENT_DETAILS_CACHE, {
            data: {
              [id]: {
                ...this.payStatementStore.stateValue[
                  PayStatementsStoreSlice.STATEMENT_DETAILS_CACHE
                ].data[id],
                statementDetails: null
              }
            },
            error: {
              [id]: { detailsError: true }
            },
            loading: false
          });
          this.logger.error(`loadStatementDetails() error: ${error.message}`);
          return EMPTY;
        })
      )
      .pipe(take(1))
      .subscribe((detailsRaw: PayStatementsDTO.PayStatementDetailsRaw) => {
        this.getInsights(id, payDetailUri, setStatementAsCurrent);
        const transformedStatementDetails = transformStatementDetails(detailsRaw);

        if (setStatementAsCurrent) {
          this.payStatementStore.update(PayStatementsStoreSlice.CURRENT_STATEMENT_DETAILS, {
            data: {
              statementDetails: transformedStatementDetails
            },
            loading: false
          });
        }

        this.payStatementStore.update(PayStatementsStoreSlice.STATEMENT_DETAILS_CACHE, {
          data: {
            [id]: {
              ...this.payStatementStore.stateValue[PayStatementsStoreSlice.STATEMENT_DETAILS_CACHE]
                .data[id],
              statementDetails: transformedStatementDetails
            }
          },
          loading: false
        });
      });
  }

  private getInsights(id: number, payDetailUri?: string, setStatementAsCurrent?: boolean) {
    // Insights data load
    // TODO: need to cache this check
    this.transparencyService.hasTransparency().then((isTransparencyEnabled) => {
      if (isTransparencyEnabled) {
        const paymentCalcAnalysisCache =
          this.payStatementStore.stateValue[
            PayStatementsStoreSlice.PAYMENT_CALCULATION_ANALYSIS_CACHE
          ];
        // If data is cached, updates current state using cached data
        if (
          paymentCalcAnalysisCache?.data[id] &&
          !paymentCalcAnalysisCache?.error[id]?.detailsError
        ) {
          if (setStatementAsCurrent) {
            // clear old data before updating
            this.payStatementStore.update(
              PayStatementsStoreSlice.CURRENT_PAYMENT_CALCULATION_ANALYSIS,
              {
                data: null
              }
            );

            this.payStatementStore.update(
              PayStatementsStoreSlice.CURRENT_PAYMENT_CALCULATION_ANALYSIS,
              {
                data: paymentCalcAnalysisCache.data[id],
                error: {
                  detailsError: false
                }
              }
            );
          }
        } else {
          this.loadTransparencyPaymentCalcAnalysis(payDetailUri, id, setStatementAsCurrent);
        }
      }
    });
  }

  private async loadTransparencyPaymentCalcAnalysis(
    payDetailUri: string,
    id: number,
    setStatementAsCurrent: boolean
  ): Promise<void> {
    if (payDetailUri) {
      const documentId = /\/.+\/payStatement\/(.+)/.exec(payDetailUri)[1];

      try {
        if (setStatementAsCurrent) {
          this.payStatementStore.update(
            PayStatementsStoreSlice.CURRENT_PAYMENT_CALCULATION_ANALYSIS,
            {
              data: null,
              error: {
                detailsError: false
              },
              loading: true
            }
          );
        }

        const paymentCalcAnalysis = await this.transparencyService.getPaymentCalculationAnalysis(
          documentId
        );
        const deductionsCategories =
          this.payStatementStore.stateValue[PayStatementsStoreSlice.CURRENT_STATEMENT_DETAILS].data
            .statementDetails?.deductionsCategories;

        const categorizedInsights = transformInsights(
          paymentCalcAnalysis?.insights,
          deductionsCategories
        );

        // Caches data
        this.payStatementStore.update(PayStatementsStoreSlice.PAYMENT_CALCULATION_ANALYSIS_CACHE, {
          data: {
            [id]: {
              paymentCalcAnalysis: paymentCalcAnalysis,
              categorizedInsights: categorizedInsights
            }
          },
          error: {
            [id]: { detailsError: false }
          },
          loading: false
        });

        if (setStatementAsCurrent) {
          this.payStatementStore.update(
            PayStatementsStoreSlice.CURRENT_PAYMENT_CALCULATION_ANALYSIS,
            {
              data: {
                paymentCalcAnalysis: paymentCalcAnalysis,
                categorizedInsights: categorizedInsights
              },
              loading: false
            }
          );
        }
      } catch (e) {
        if (setStatementAsCurrent) {
          this.payStatementStore.update(
            PayStatementsStoreSlice.CURRENT_PAYMENT_CALCULATION_ANALYSIS,
            {
              error: {
                detailsError: true
              },
              loading: false
            }
          );
        }

        this.payStatementStore.update(PayStatementsStoreSlice.PAYMENT_CALCULATION_ANALYSIS_CACHE, {
          data: {
            [id]: null
          },
          error: {
            [id]: { detailsError: true }
          },
          loading: false
        });

        this.logger.error(
          `Failed to load Payment Calculation Analysis for pay statement ${documentId}.`,
          e
        );
      }
    } else {
      this.logger.warn(
        'loadStatementDetails() cannot load Transparency data since no pay statement URI is provided.'
      );
    }
  }
}
