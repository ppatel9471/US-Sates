import { Component, OnInit, Optional, ViewChild } from '@angular/core';
import { slideinAnimation, SlideinComponent } from '@synerg/components/slidein';
import { TileService } from '@synerg/components/tile';
import { Observable } from 'rxjs';

import { StoreState } from '@myadp/pay-shared';

import { PayDeductionsStoreState } from '../../../pay-deductions-shared/models/pay-deductions-ui';
import { PayDeductionsStore } from '../../../pay-deductions-shared/store/pay-deductions.store';
import { DeductionsStoreActions } from '../../store/deductions-store.actions';
import { StepsStore, StepsStoreActions } from '../../store/steps/steps.store';

@Component({
  selector: 'vded-deductions-tile',
  templateUrl: './deductions-tile.component.html',
  styleUrls: ['./deductions-tile.component.scss'],
  animations: [slideinAnimation]
})
export class DeductionsTileComponent implements OnInit {
  @ViewChild(SlideinComponent) slidein: SlideinComponent;
  public isSlideinOpen$: Observable<boolean>;
  public state$: Observable<StoreState<PayDeductionsStoreState>>;

  constructor(
    private stepsStore: StepsStore,
    private stepsStoreActions: StepsStoreActions,
    private payDeductionsStore: PayDeductionsStore,
    private deductionsStoreActions: DeductionsStoreActions,
    @Optional() private tileService: TileService
  ) {}

  public ngOnInit(): void {
    this.tileService?.setIsLoading(false);
    this.isSlideinOpen$ = this.stepsStore.isSlideinOpenObs$;
    this.state$ = this.payDeductionsStore?.state$;

    this.deductionsStoreActions.loadDeductions();
  }

  public openSlidein(): void {
    this.stepsStoreActions.openSlidein();
  }

  public onSlideinClose(): void {
    this.stepsStoreActions.closeSlidein();
  }
}
