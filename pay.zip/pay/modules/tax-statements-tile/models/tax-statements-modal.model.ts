export enum RowDataPropertiesType {
  YEAR = 'YEAR',
  EMPLOYER = 'EMPLOYER',
  TYPE = 'TYPE',
  AMOUNT = 'AMOUNT',
  CURRENCY = 'CURRENCY',
  DOWNLOAD = 'DOWNLOAD'
}

export type RowDataProperties =
  | RowDataPropertiesType.YEAR
  | RowDataPropertiesType.EMPLOYER
  | RowDataPropertiesType.TYPE
  | RowDataPropertiesType.AMOUNT
  | RowDataPropertiesType.CURRENCY
  | RowDataPropertiesType.DOWNLOAD;
