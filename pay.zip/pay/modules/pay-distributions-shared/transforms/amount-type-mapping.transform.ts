import { Amount } from '@myadp/dto';

import {
  DistributionOptions,
  DistributionType,
  PayDistributionsUI
} from '../models/pay-distributions-ui';

export function mapAmountType({
  type,
  percentage,
  amount
}: {
  type: DistributionType;
  percentage: number;
  amount: Amount;
}): Partial<PayDistributionsUI.PayDistributionDetails> {
  return {
    [DistributionOptions.REMAINING]: {
      distributionType: DistributionOptions.REMAINING,
      percentageAmount: null,
      flatAmount: null
    },
    [DistributionOptions.PERCENTAGE]: {
      distributionType: DistributionOptions.PERCENTAGE,
      percentageAmount: percentage,
      flatAmount: null
    },
    [DistributionOptions.FLAT]: {
      distributionType: DistributionOptions.FLAT,
      percentageAmount: null,
      flatAmount: amount
    }
  }[type];
}
