import { RadioGroupOption } from '@synerg/components/radio-group';

import { DistributionOptions } from '../../pay-distributions-shared/models/pay-distributions-ui';
import { AccountType } from './deposit-account.model';

export type StepMeta = Partial<AccountDetailsStepMeta & DepositAmountStepMeta>;

export interface AccountDetailsStepMeta {
  accountTypes: AccountType[];
  displayConfirm: boolean;
  accountNameEnabled: boolean;
  accountNameMaxLength: number;
  isEditing: boolean;
  banks?: AccountType[];
  disableRoutingAndAccountValidations: boolean;
}

export interface DepositAmountStepMeta {
  showRemainingLabel: boolean;
  hasExistingDeposits: boolean;
  isDepositingRemainder: boolean;
  showPercentageType: boolean;
  hasOneAccount: boolean;
  remainingPercentage: number;
  minFlatAmount: number;
  depositTypeOptions: RadioGroupOption[];
  defaultDepositType: DistributionOptions;
  maxPercentage: number;
  currentlyEditing?: DistributionOptions;
}
