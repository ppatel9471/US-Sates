import { Address, WorkerName } from '@myadp/dto';

export type ValidateReason = 'empty' | 'format' | 'unmask';

export interface WorkerInfo {
  legalName?: WorkerName;
  legalAddress?: Address;
  birthDate?: string;
  associateOID?: string;
}

export interface WorkerSsn {
  ssn?: string;
  formattedSSN?: string;
  isValid?: boolean;
  validateReason?: ValidateReason;
}

export interface AdditionalWorkerInfo {
  heading: string;
  value: string;
}
