import { fakeAsync, flush, TestBed } from '@angular/core/testing';
import { CurrencyPipe } from '@angular/common';
import { Mock } from 'ts-mockery';

import { WorkerTaxStatementsDTO } from '@myadp/dto';

import { TaxStatementsStoreActions } from './tax-statements-store.actions';
import { TaxStatementsStore } from './tax-statements.store';
import { TaxStatementsService } from '../services/tax-statements.service';
import { TaxStatementsStoreSlice } from '../models/tax-statements-state.model';
import { ValueFormatterService } from '../../shared/services/value-formatter.service';
import { LanguageService } from '@myadp/common';

describe('TaxStatementsStoreActions', () => {
  let taxStatementsStoreActions: TaxStatementsStoreActions;
  let taxStatementsStore: TaxStatementsStore;
  let taxStatementsService: TaxStatementsService;

  const mockStatement: WorkerTaxStatementsDTO.WorkerTaxStatement = {
    statementName: '2013 W-2',
    employerName: 'AUTOMATIC DATA PROCESSING',
    form: {
      code: '1095-C'
    },

    statementYear: {
      year: '2013'
    },
    summaryAmount: {
      amountValue: 20130,
      currencyCode: 'USD'
    },
    statementImageUri: {
      href: 'mockPDF.pdf'
    }
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        TaxStatementsStoreActions,
        TaxStatementsStore,
        ValueFormatterService,
        CurrencyPipe,
        {
          provide: TaxStatementsService,
          useValue: Mock.of<TaxStatementsService>({
            getTaxStatements: () => Promise.resolve({ workerTaxStatements: [mockStatement] })
          })
        },
        {
          provide: LanguageService,
          useValue: Mock.of<LanguageService>({ get: (key) => key })
        }
      ]
    });

    taxStatementsStoreActions = TestBed.inject(TaxStatementsStoreActions);
    taxStatementsStore = TestBed.inject(TaxStatementsStore);
    taxStatementsService = TestBed.inject(TaxStatementsService);
  });

  it('should set data in the store', fakeAsync(() => {
    taxStatementsStoreActions.getTaxStatements();
    expect(taxStatementsStore.stateValue[TaxStatementsStoreSlice.TAX_STATEMENTS].loading).toBe(
      true
    );
    flush();
    expect(taxStatementsStore.stateValue[TaxStatementsStoreSlice.TAX_STATEMENTS].loading).toBe(
      false
    );
    expect(taxStatementsStore.stateValue[TaxStatementsStoreSlice.TAX_STATEMENTS].error).toBeNull();
    expect(taxStatementsStore.stateValue[TaxStatementsStoreSlice.TAX_STATEMENTS].data).toEqual([
      mockStatement
    ]);
  }));

  it('should set error in the store', fakeAsync(() => {
    Mock.extend(taxStatementsService).with({
      getTaxStatements: () => Promise.reject()
    });
    taxStatementsStoreActions.getTaxStatements();
    expect(taxStatementsStore.stateValue[TaxStatementsStoreSlice.TAX_STATEMENTS].loading).toBe(
      true
    );
    flush();
    expect(taxStatementsStore.stateValue[TaxStatementsStoreSlice.TAX_STATEMENTS].loading).toBe(
      false
    );
    expect(
      taxStatementsStore.stateValue[TaxStatementsStoreSlice.TAX_STATEMENTS].error
        .loadTaxStatementsError
    ).toBeTruthy();
  }));

  it('should reset any tax statements error when call is made to get tax statements', fakeAsync(() => {
    taxStatementsStore.update(TaxStatementsStoreSlice.TAX_STATEMENTS, {
      error: {
        loadTaxStatementsError: true
      }
    });

    taxStatementsStoreActions.getTaxStatements();
    flush();

    expect(taxStatementsStore.stateValue[TaxStatementsStoreSlice.TAX_STATEMENTS].error).toBeNull();
  }));
});
