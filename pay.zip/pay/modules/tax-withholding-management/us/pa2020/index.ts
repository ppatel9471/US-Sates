import { Pa2020IntroComponent } from './steps/intro/pa2020-intro.component';

export const PA2020_COMPONENTS = [Pa2020IntroComponent];
export { PA2020STEP_COMPONENT } from './models/steps-component.model';
