import { HttpClientTestingModule } from '@angular/common/http/testing';
import { fakeAsync, flush, TestBed } from '@angular/core/testing';
import { of } from 'rxjs';
import { Mock } from 'ts-mockery';

import { FindSffoService, PAY_SFFO } from '@myadp/pay-shared';
import { MOCK_DEDUCTIONS, MOCK_FORM_DETAILS } from '@specHelpers/pay/pay-deductions/pay-deductions';

import {
  PayDeductionsStoreSlice,
  PayDeductionsUI
} from '../../pay-deductions-shared/models/pay-deductions-ui';
import { PayDeductionsStoreActions } from '../../pay-deductions-shared/store/pay-deductions-store.actions';
import { PayDeductionsStore } from '../../pay-deductions-shared/store/pay-deductions.store';
import { DeductionForm } from '../models/deduction-form.model';
import { DeductionsStoreActions } from './deductions-store.actions';
import { DeductionsStore } from './deductions.store';

describe('DeductionsStoreActions', () => {
  let deductionsStoreActions: DeductionsStoreActions;
  let deductionsStore: DeductionsStore;
  let payDeductionsStore: PayDeductionsStore;
  let payDeductionsStoreActions: PayDeductionsStoreActions;
  let findSffoService: FindSffoService;

  const addSffo = {
    sffo: {
      sffo: [
        'payrollManagement',
        'payrollInstructionManagement',
        'workerGeneralDeductionInstructionManagement',
        'workerGeneralDeductionInstruction.start'
      ]
    },
    href: '/start'
  };
  const editSffo = {
    sffo: {
      sffo: [
        'payrollManagement',
        'payrollInstructionManagement',
        'workerGeneralDeductionInstructionManagement',
        'workerGeneralDeductionInstruction.change'
      ]
    },
    href: '/change'
  };
  const deleteSffo = {
    sffo: {
      sffo: [
        'payrollManagement',
        'payrollInstructionManagement',
        'workerGeneralDeductionInstructionManagement',
        'workerGeneralDeductionInstruction.stop'
      ]
    },
    href: '/stop'
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        DeductionsStore,
        {
          provide: PayDeductionsStore,
          useValue: Mock.of<PayDeductionsStore>({
            payDeductions$: of(MOCK_DEDUCTIONS),
            payDeductionsSnapshot: MOCK_DEDUCTIONS,
            hasDeductionError$: of(false),
            isPayDeductionsLoading$: of(false),
            stateValue: {
              [PayDeductionsStoreSlice.PAY_DEDUCTIONS]: {
                data: MOCK_DEDUCTIONS
              }
            }
          })
        },
        {
          provide: PayDeductionsStoreActions,
          useValue: Mock.of<PayDeductionsStoreActions>({
            loadDeductions: () => Mock.noop(),
            loadStartMeta: () => Mock.noop(),
            loadCodeList: () => Mock.noop(),
            loadDeductionMeta: () => Mock.noop(),
            recallDeduction: () => Mock.noop(),
            postDeduction: () => Mock.noop(),
            stopDeduction: () => Mock.noop(),
            updateDeductions: () => Mock.noop(),
            revertToInitialDeductions: () => Mock.noop()
          })
        },
        {
          provide: FindSffoService,
          useValue: Mock.of<FindSffoService>({
            findSffo: (permissions) => {
              if (permissions[0].sffo === PAY_SFFO.DEDUCTIONS_START_PERMISSION.sffo) {
                return addSffo;
              } else if (permissions[0].sffo === PAY_SFFO.DEDUCTIONS_CHANGE_PERMISSION.sffo) {
                return editSffo;
              } else if (permissions[0].sffo === PAY_SFFO.DEDUCTIONS_STOP_PERMISSION.sffo) {
                return deleteSffo;
              }
            }
          })
        }
      ]
    });

    deductionsStore = TestBed.inject(DeductionsStore);
    deductionsStoreActions = TestBed.inject(DeductionsStoreActions);
    payDeductionsStore = TestBed.inject(PayDeductionsStore);
    payDeductionsStoreActions = TestBed.inject(PayDeductionsStoreActions);
    findSffoService = TestBed.inject(FindSffoService);
  });

  it('should reset form data', () => {
    const mockFormDetails = MOCK_FORM_DETAILS.unselected;
    deductionsStoreActions.updateFormData(mockFormDetails);
    deductionsStoreActions.resetFormData();

    expect(deductionsStore.formData).toBeNull();
  });

  describe('loadDeductions', () => {
    it('should call PayDeductionsStore to load deductions', fakeAsync(() => {
      deductionsStoreActions.loadDeductions();
      flush();

      expect(payDeductionsStoreActions.loadDeductions).toHaveBeenCalled();
    }));
  });

  describe('loadStartMeta', () => {
    it('should call PayDeductionsStore to load start meta', fakeAsync(() => {
      deductionsStoreActions.loadStartMeta();
      flush();

      expect(payDeductionsStoreActions.loadStartMeta).toHaveBeenCalled();
    }));
  });

  describe('loadCodeList', () => {
    it('should call PayDeductionsStore to load codeList and bust cache by default', fakeAsync(() => {
      deductionsStoreActions.loadCodeList();
      flush();

      expect(payDeductionsStoreActions.loadCodeList).toHaveBeenCalledWith(undefined, true);
    }));

    it('should call PayDeductionsStore to load codeList and not bust cache', fakeAsync(() => {
      deductionsStoreActions.loadCodeList(false);
      flush();

      expect(payDeductionsStoreActions.loadCodeList).toHaveBeenCalledWith(undefined, false);
    }));
  });

  describe('recallDeduction', () => {
    it('should call PayDeductionsStore to recall deduction', fakeAsync(() => {
      deductionsStoreActions.recallDeduction(null);
      flush();

      expect(payDeductionsStoreActions.recallDeduction).toHaveBeenCalledWith(null);
    }));
  });

  describe('postDeduction', () => {
    it('should call PayDeductionsStore to POST deduction', fakeAsync(() => {
      deductionsStoreActions.postDeduction(null, 'edit');
      flush();

      expect(payDeductionsStoreActions.postDeduction).toHaveBeenCalledWith(null, 'edit');
    }));
  });

  describe('deleteDeduction', () => {
    it('should stop deduction and update changes when deleting', fakeAsync(() => {
      const mockDeductionDetails = MOCK_DEDUCTIONS[0].currentData;
      deductionsStoreActions.deleteDeduction(mockDeductionDetails);
      flush();

      expect(deductionsStore.changes).toEqual({
        changeType: 'delete',
        deductionDetails: mockDeductionDetails
      });
      expect(payDeductionsStoreActions.stopDeduction).toHaveBeenCalledWith(mockDeductionDetails);
    }));

    it('should delete deduction locally', fakeAsync(() => {
      const mockDeductionDetails = MOCK_DEDUCTIONS[0].currentData;
      Mock.extend(payDeductionsStore).with({
        payDeductionsSnapshot: [
          { currentData: null, pendingData: mockDeductionDetails, pendingEvent: null }
        ]
      });
      deductionsStoreActions.updateChanges('add', MOCK_DEDUCTIONS[0]);
      deductionsStoreActions.deleteDeduction(mockDeductionDetails);
      flush();

      expect(deductionsStore.changes).toEqual({
        changeType: 'add',
        deductionDetails: mockDeductionDetails
      });
      expect(payDeductionsStoreActions.stopDeduction).not.toHaveBeenCalledWith(
        mockDeductionDetails
      );
    }));
  });

  describe('updateFormData', () => {
    it('should update formData', () => {
      const mockFormDetails = MOCK_FORM_DETAILS.selected;
      deductionsStoreActions.updateFormData(mockFormDetails);

      expect(deductionsStore.formData).toEqual(mockFormDetails);
    });

    it('should update formData when switching between currency and percent', () => {
      deductionsStoreActions.updateFormData({
        deductionCode: { codeValue: 'ABC', longName: 'AllowanceBank' }
      });

      expect(deductionsStore.formData).toEqual({
        deductionCode: { codeValue: 'ABC', longName: 'AllowanceBank' }
      });

      deductionsStoreActions.updateFormData({
        deductionRate: { rateValue: 5, currencyCode: 'USD' }
      });
      deductionsStoreActions.updateFormData({
        deductionRate: { rateValue: 7, unitCode: { codeValue: 'percent' } }
      });

      expect(deductionsStore.formData).toEqual({
        deductionCode: { codeValue: 'ABC', longName: 'AllowanceBank' },
        deductionRate: { rateValue: 7, currencyCode: null, unitCode: { codeValue: 'percent' } }
      });

      deductionsStoreActions.updateFormData({
        deductionRate: { rateValue: 9, currencyCode: 'USD' }
      });

      expect(deductionsStore.formData).toEqual({
        deductionCode: { codeValue: 'ABC', longName: 'AllowanceBank' },
        deductionRate: { rateValue: 9, currencyCode: 'USD', unitCode: null }
      });
    });
  });

  describe('loadStartMeta', () => {
    it('should call PayDeductionsStore to load start meta', () => {
      deductionsStoreActions.loadStartMeta();
      expect(payDeductionsStoreActions.loadStartMeta).toHaveBeenCalled();
    });

    it('should call PayDeductionsStore to load deduction meta for adding a deduction', () => {
      deductionsStoreActions.loadDeductionMeta('40A', false);
      expect(payDeductionsStoreActions.loadDeductionMeta).toHaveBeenCalledWith('40A', false);
    });

    it('should call PayDeductionsStore to load deduction meta for editing a deduction', () => {
      deductionsStoreActions.loadDeductionMeta('40A', true);
      expect(payDeductionsStoreActions.loadDeductionMeta).toHaveBeenCalledWith('40A', true);
    });
  });

  describe('changes', () => {
    it('should update the changes slice when adding', () => {
      const mockDeduction: PayDeductionsUI.Deduction = {
        currentData: null,
        pendingData: MOCK_DEDUCTIONS[0].currentData,
        pendingEvent: null
      };
      deductionsStoreActions.updateChanges('add', mockDeduction);

      expect(deductionsStore.changes).toEqual({
        changeType: 'add',
        deductionDetails: mockDeduction.pendingData
      });
    });

    it('should update the changes slice when editing', () => {
      const mockDeduction: PayDeductionsUI.Deduction = {
        currentData: MOCK_DEDUCTIONS[0].currentData,
        pendingData: {
          ...MOCK_DEDUCTIONS[0].currentData,
          deductionRate: { rateValue: 20, currencyCode: 'USD' }
        },
        pendingEvent: null
      };
      deductionsStoreActions.updateChanges('edit', mockDeduction);

      expect(deductionsStore.changes).toEqual({
        changeType: 'edit',
        deductionDetails: mockDeduction.pendingData
      });
    });

    it('should update the changes slice when deleting', () => {
      const mockDeduction: PayDeductionsUI.Deduction = MOCK_DEDUCTIONS[0];
      deductionsStoreActions.updateChanges('delete', mockDeduction);

      expect(deductionsStore.changes).toEqual({
        changeType: 'delete',
        deductionDetails: mockDeduction.currentData
      });
    });

    it('should update changes slice when deleting a deduction and deduction has already been changed', () => {
      const mockDeduction = MOCK_DEDUCTIONS[0];
      deductionsStoreActions.updateChanges('edit', mockDeduction);
      expect(deductionsStore.changes).toEqual({
        changeType: 'edit',
        deductionDetails: mockDeduction.currentData
      });

      deductionsStoreActions.updateChanges('add', mockDeduction);
      expect(deductionsStore.changes).toEqual({
        changeType: 'edit',
        deductionDetails: mockDeduction.currentData
      });

      deductionsStoreActions.updateChanges('delete', mockDeduction);
      expect(deductionsStore.changes).toEqual({
        changeType: 'delete',
        deductionDetails: mockDeduction.currentData
      });
    });

    it('should reset the changes slice', () => {
      const mockDeduction: PayDeductionsUI.Deduction = MOCK_DEDUCTIONS[0];
      deductionsStoreActions.updateChanges('delete', mockDeduction);

      expect(deductionsStore.changes).toEqual({
        changeType: 'delete',
        deductionDetails: mockDeduction.currentData
      });

      deductionsStoreActions.resetDeductionChanges();

      expect(deductionsStore.changes).toBeNull();
    });
  });

  describe('updateDeductionChanges', () => {
    it('should add a new deduction', () => {
      Mock.extend(payDeductionsStore).with({
        payDeductionsSnapshot: []
      });

      const mockDeductionDetails = MOCK_DEDUCTIONS[0].currentData;
      deductionsStore.update('changedDeductionDetails', {
        data: mockDeductionDetails
      });
      const changedDeduction = deductionsStoreActions.updateDeductionChanges();

      expect(changedDeduction).toEqual({
        currentData: null,
        pendingData: mockDeductionDetails,
        pendingEvent: null
      });
      expect(payDeductionsStoreActions.updateDeductions).toHaveBeenCalledWith([changedDeduction]);
    });

    it('should add a new deduction when another exists', () => {
      Mock.extend(payDeductionsStore).with({
        payDeductionsSnapshot: [MOCK_DEDUCTIONS[0]]
      });

      const mockDeductionDetails = MOCK_DEDUCTIONS[1].currentData;
      deductionsStore.update('changedDeductionDetails', {
        data: mockDeductionDetails
      });
      const changedDeduction = deductionsStoreActions.updateDeductionChanges();

      expect(changedDeduction).toEqual({
        currentData: null,
        pendingData: mockDeductionDetails,
        pendingEvent: null
      });
      expect(payDeductionsStoreActions.updateDeductions).toHaveBeenCalledWith([
        MOCK_DEDUCTIONS[0],
        changedDeduction
      ]);
    });

    it('should update an existing deduction', () => {
      const mockDeduction = MOCK_DEDUCTIONS[0];
      Mock.extend(payDeductionsStore).with({
        payDeductionsSnapshot: [mockDeduction]
      });

      const mockDeductionDetails = {
        ...mockDeduction.currentData,
        deductionGoal: { goalLimitAmount: { amountValue: 50, currency: 'USD' } }
      };
      deductionsStore.update('changedDeductionDetails', {
        data: mockDeductionDetails
      });

      const changedDeduction = deductionsStoreActions.updateDeductionChanges();
      const expectedDeduction: PayDeductionsUI.Deduction = {
        currentData: mockDeduction.currentData,
        pendingData: mockDeductionDetails,
        pendingEvent: null
      };

      expect(changedDeduction).toEqual(expectedDeduction);
      expect(payDeductionsStoreActions.updateDeductions).toHaveBeenCalledWith([expectedDeduction]);
    });
  });

  describe('updateChangedDeduction', () => {
    it('should update changedDeductionDetails when passing in deduction data', () => {
      const mockDeduction: PayDeductionsUI.Deduction = MOCK_DEDUCTIONS[2];
      deductionsStoreActions.updateChangedDeduction(mockDeduction);

      expect(deductionsStore.changedDeductionDetails).toEqual(mockDeduction.currentData);
    });

    it('should update changedDeductionDetails when passing in form data', () => {
      const mockDeductionDetails: DeductionForm = {
        ...MOCK_DEDUCTIONS[1].currentData,
        terms: true,
        formValid: true
      };
      deductionsStoreActions.updateChangedDeduction(mockDeductionDetails);

      expect(deductionsStore.changedDeductionDetails).toEqual(MOCK_DEDUCTIONS[1].currentData);
    });
  });

  describe('revertAllChanges', () => {
    it('should reset deductions and change slices', () => {
      deductionsStoreActions.updateChanges('add', MOCK_DEDUCTIONS[2]);
      deductionsStoreActions.revertAllChanges();

      expect(payDeductionsStoreActions.revertToInitialDeductions).toHaveBeenCalled();
      expect(deductionsStore.changes).toBeNull();
    });
  });

  describe('setPermissions', () => {
    it('should set add, edit, and delete permissions when loadDeductions is called', () => {
      deductionsStoreActions.loadDeductions();

      expect(deductionsStore.getData('permissions', 'add')).toBeTrue();
      expect(deductionsStore.getData('permissions', 'edit')).toBeTrue();
      expect(deductionsStore.getData('permissions', 'delete')).toBeTrue();
    });

    it('should be missing permissions when loadDeductions is called', () => {
      Mock.extend(findSffoService).with({
        findSffo: () => ({
          sffo: undefined,
          href: undefined
        })
      });
      deductionsStoreActions.loadDeductions();

      expect(deductionsStore.getData('permissions', 'add')).toBeFalse();
      expect(deductionsStore.getData('permissions', 'edit')).toBeFalse();
      expect(deductionsStore.getData('permissions', 'delete')).toBeFalse();
    });
  });
});
