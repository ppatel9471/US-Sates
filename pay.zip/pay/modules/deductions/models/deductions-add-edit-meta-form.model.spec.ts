import { Meta } from '@myadp/forms';
import {
  MOCK_PAY_DEDUCTIONS_DEDUCTION_META,
  MOCK_PAY_DEDUCTIONS_DEDUCTION_META_CURRENCY
} from '@specHelpers/pay/pay-deductions/pay-deductions';

import { DeductionsAddEditMetaForm } from './deductions-add-edit-meta-form.model';

describe('DeductionsAddEditMetaForm', () => {
  let meta: Meta;

  describe('deductionRateUnitCode', () => {
    it('should be null if deduction meta rate value is in currency format', () => {
      meta = new Meta(MOCK_PAY_DEDUCTIONS_DEDUCTION_META_CURRENCY, false);
      const metaForm = new DeductionsAddEditMetaForm(meta);

      expect(metaForm.deductionRateUnitCode).toBeNull();
    });

    it('should not be null if deduction meta rate value is in percentage format', () => {
      meta = new Meta(MOCK_PAY_DEDUCTIONS_DEDUCTION_META, false);
      const metaForm = new DeductionsAddEditMetaForm(meta);

      expect(metaForm.deductionRateUnitCode).toBeDefined();
    });

    it('should transform the form data with a unit code key', () => {
      meta = new Meta(MOCK_PAY_DEDUCTIONS_DEDUCTION_META, false);
      const metaForm = new DeductionsAddEditMetaForm(meta);

      expect(metaForm.deductionRateUnitCode).toBeDefined();
      const transformed = metaForm.transform();
      expect(transformed).toEqual({
        deductionRate: {
          rateValue: 4.62,
          unitCode: {
            codeValue: 'percent'
          }
        },
        deductionGoal: {
          goalLimitAmount: {
            amountValue: null,
            currencyCode: 'USD'
          }
        }
      });
    });
  });

  describe('currencyCode', () => {
    it('should transform the form data with a currencyCode key', () => {
      meta = new Meta(MOCK_PAY_DEDUCTIONS_DEDUCTION_META_CURRENCY, false);
      const metaForm = new DeductionsAddEditMetaForm(meta);

      expect(metaForm.deductionRateUnitCode).toBeDefined();
      const transformed = metaForm.transform();
      expect(transformed).toEqual({
        deductionRate: {
          rateValue: null,
          currencyCode: 'USD'
        },
        deductionGoal: {
          goalLimitAmount: {
            amountValue: null,
            currencyCode: 'USD'
          }
        }
      });
    });
  });
});
