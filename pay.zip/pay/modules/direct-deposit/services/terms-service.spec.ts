import { Mock } from 'ts-mockery';
import { TermsService } from './terms-service';
import { LanguageService } from '@myadp/common';
import { WorkerInfoStoreActions } from '../../worker-info-shared/store/worker-info-store.actions';
import { StepsStoreActions } from '../store/steps/steps.store';
import { TestBed } from '@angular/core/testing';

describe('TermsService', () => {
  let termsService: TermsService;
  let workerInfoStoreActions: WorkerInfoStoreActions;
  let stepsStoreActions: StepsStoreActions;
  let languageService: LanguageService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        {
          provide: LanguageService,
          useValue: Mock.of<LanguageService>({
            get: (key) => key
          })
        },
        {
          provide: WorkerInfoStoreActions,
          useValue: Mock.of<WorkerInfoStoreActions>({
            getWorkedInState: () => Promise.resolve('NY')
          })
        },
        {
          provide: StepsStoreActions,
          useValue: Mock.of<StepsStoreActions>({
            getWorker: () =>
              Promise.resolve({
                person: {
                  legalName: {
                    givenName: 'Bob',
                    familyName1: 'Bobbert'
                  }
                }
              })
          })
        }
      ]
    });

    termsService = TestBed.inject(TermsService);
    workerInfoStoreActions = TestBed.inject(WorkerInfoStoreActions);
    languageService = TestBed.inject(LanguageService);
    stepsStoreActions = TestBed.inject(StepsStoreActions);
  });

  it('should give terms for NY ', async () => {
    await termsService.init(false);

    expect(termsService.consent).toContain('myadp-pay.DD_TERMS_AND_CONDITIONS_NY');
  });

  it('should give terms for wisely specific terms and conditions', async () => {
    await termsService.init(true);

    expect(termsService.consent).toContain('myadp-pay.DD_TERMS_AND_CONDITIONS_NY_PAY');
  });

  it('should give terms for non NY', async () => {
    Mock.extend(workerInfoStoreActions).with({
      getWorkedInState: () => Promise.resolve('CA')
    });
    await termsService.init(true);

    expect(termsService.consent).toContain('myadp-pay.DD_TERMS_AND_CONDITIONS');
  });

  it('should give default terms when worker call fails', async () => {
    Mock.extend(stepsStoreActions).with({
      getWorker: () => Promise.reject(null)
    });

    await termsService.init(true);

    expect(termsService.consent).toContain('myadp-pay.DD_TERMS_AND_CONDITIONS');
  });

  it('should include the signature line when asked for the printed version of consent text', async () => {
    await termsService.init(false);

    expect(termsService.consent).toContain('myadp-pay.DD_TERMS_AND_CONDITIONS');

    expect(termsService.printedConsentText).toContain('myadp-pay.TERMS_AND_CONDITIONS_SIGNATURE');

    expect(languageService.get).toHaveBeenCalledWith('myadp-pay.TERMS_AND_CONDITIONS_SIGNATURE', {
      workerName: 'Bob Bobbert'
    });
  });
});
