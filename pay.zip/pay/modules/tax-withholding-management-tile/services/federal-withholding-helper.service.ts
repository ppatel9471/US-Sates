import { Injectable } from '@angular/core';
import { get } from 'lodash';
import * as moment from 'moment';

import { LanguageService } from '@myadp/common';
import { ApiError } from '@myadp/dto';
import { PayPermissionService } from '@myadp/pay-shared';

import { Info, WithholdingInfo, WithholdingItem, WithholdingType } from '../../../models/formatted-tax-withholding.model';
import { PendingEvent } from '../../../models/tax-withholding.model';
import { UsFederalTaxWithholdingElections } from '../../../models/us-federal-tax-withholding-election.model';
import { FederalWithholdingTransformService } from '../../../modules/shared/services/federal-withholding-transform.service';

@Injectable({
  providedIn: 'root'
})
export class FederalWithholdingHelperService {
  constructor(
    private federalWithholdingTransformService: FederalWithholdingTransformService,
    private payPermissionService: PayPermissionService,
    private languageService: LanguageService
  ) {}

  public getWithholdingModel(withholdingData: UsFederalTaxWithholdingElections): WithholdingInfo {
    this.filterW4Withholding(withholdingData);
    const withholdingItems =
      this.federalWithholdingTransformService.getWithholdingItems(withholdingData);
    const hasElections = !!withholdingItems[0].rawData;
    const pendingEvents = this.getPendingEvents(withholdingData);

    if (hasElections) {
      withholdingItems[0].allowEdit = this.isFederalEditable(withholdingItems);
      withholdingItems[0].info = this.getInfo(withholdingData, withholdingItems[0]);
      withholdingItems[0].showEffectiveDate =
        moment(withholdingItems[0].effectiveDate).isAfter(moment(), 'day') && !pendingEvents;
    }

    return <WithholdingInfo>{
      withholdingItems: withholdingItems,
      type: WithholdingType.FEDERAL,
      hasElections: hasElections,
      pendingEvents: pendingEvents
    };
  }

  public isFederalEditable(withholdingItems: WithholdingItem[]) {
    // federal is editable if federal is not locked and user has change permission
    return (
      !withholdingItems[0].isLocked &&
      this.payPermissionService.hasFederalTaxWithholdingChangePermission()
    );
  }

  private getPendingEvents(withholdingData: UsFederalTaxWithholdingElections): PendingEvent {
    return get(withholdingData, 'usFederalTaxWithholdingElections[0].workflowData.pendingEvents');
  }

  private getInfo(
    withholdingData: UsFederalTaxWithholdingElections,
    withholdingItem: WithholdingItem
  ): Info {
    const userMessage = this.getUserMessage(withholdingData);
    if (withholdingItem.lockedOutMessage) {
      return {
        type: 'info',
        title: 'myadp-pay.TAXWITHHOLDING_CARD_NOEDIT_TITLE',
        message: `myadp-pay.TAXWITHHOLDING_CARD_NOEDIT_${withholdingItem.lockedOutMessage}_MESSAGE`
      };
    } else if (!withholdingItem.allowEdit) {
      return {
        type: 'info',
        title: this.languageService.get('myadp-pay.TAXWITHHOLDING_CARD_NOEDIT_TITLE'),
        message: this.languageService.get('myadp-pay.TAXWITHHOLDING_CARD_NOEDIT_MESSAGE')
      };
    } else if (userMessage) {
      return {
        type: 'pending',
        title: userMessage.title,
        message: userMessage.messageTxt
      };
    }
    return null;
  }

  private getUserMessage(withholdingData: UsFederalTaxWithholdingElections): ApiError.UserMessage {
    return get(
      withholdingData,
      'usFederalTaxWithholdingElections[0].workflowData.confirmMessage.resourceMessages[0].processMessages[0].userMessage'
    );
  }

  // Primarily to remove ss-deduction items
  private filterW4Withholding(withholdingData: UsFederalTaxWithholdingElections): void {
    if (withholdingData?.usFederalTaxWithholdingElections) {
      withholdingData.usFederalTaxWithholdingElections =
        withholdingData.usFederalTaxWithholdingElections?.filter(
          (election) => election.itemID === 'W-4' || election.itemID === undefined
        );
    }
  }
}
