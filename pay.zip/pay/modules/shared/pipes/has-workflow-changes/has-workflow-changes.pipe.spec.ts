import { TestBed } from '@angular/core/testing';

import { HasWorkflowChangesPipe } from './has-workflow-changes.pipe';

describe('HasWorkflowChangesPipe', () => {
  let pipe: HasWorkflowChangesPipe;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [HasWorkflowChangesPipe]
    });

    pipe = new HasWorkflowChangesPipe();
  });

  it('should return true if there are pending changes', () => {
    expect(
      pipe.transform([
        { currentData: {}, pendingData: null, pendingEvent: null },
        { currentData: {}, pendingData: null, pendingEvent: { changeType: 'delete' } }
      ])
    ).toBe(true);
  });

  it('should return false if there are no pending changes', () => {
    expect(
      pipe.transform([
        { currentData: {}, pendingData: null, pendingEvent: null },
        { currentData: {}, pendingData: null, pendingEvent: null }
      ])
    ).toBe(false);
  });
});
