import { Injectable } from '@angular/core';
import { NativeResourceService } from '@espresso/core';
import { has } from 'lodash';

import { FindSffoService, PAY_SFFO } from '@myadp/pay-shared';

import { PayStatementsDTO } from '../models/pay-statement.model';
import { PayDashboardTileBaseService } from './pay-dashboard-tile-base.service';

interface NativeResponse {
  RESTResponse: {
    body: string;
  };
}

@Injectable({
  providedIn: 'root'
})
export class PayDashboardTileMobileService extends PayDashboardTileBaseService {
  constructor(
    private nativeResourceService: NativeResourceService,
    public findSffoService: FindSffoService
  ) {
    super();
  }

  getPayStatements(): Promise<PayStatementsDTO> {
    const { sffo, href } = this.findSffoService.findSffo([
      { sffo: PAY_SFFO.PAY_STATEMENTS_READ.sffo },
      { sffo: PAY_SFFO.PAY_STATEMENTS_READ_LEGACY.sffo }
    ]);

    if (!sffo || !href) {
      return Promise.reject('Pay Permission or URL not found!');
    }

    const payStatementUri = {
      RESTRequest: {
        method: 'GET',
        staleOk: false,
        headers: [{ name: 'roleCode', value: 'employee' }],
        URI: `${href.split('?')[0]}?numberoflastpaydates=26`
      }
    };

    return this.nativeResourceService
      .makeRestCall(payStatementUri)
      .then((response: NativeResponse) => {
        if (has(response, 'RESTResponse.body')) {
          try {
            return JSON.parse(response.RESTResponse.body);
          } catch {
            return false;
          }
        }
        return false;
      });
  }

}
