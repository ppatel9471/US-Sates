import { Injectable } from '@angular/core';
import { LoggerFactory } from '@espresso/core';
import { ClientDeviceService } from '@synerg/components/shared';
import * as log4javascript from 'log4javascript';
import { BehaviorSubject, Observable } from 'rxjs';
import { distinctUntilChanged, map } from 'rxjs/operators';

import { UserPreferenceKeys, UserPreferencesService } from '@myadp/common';

@Injectable({
  providedIn: 'root'
})
export class PrivacyModeStore {
  private readonly _privacyMode$: BehaviorSubject<boolean>;
  private logger: log4javascript.Logger;

  constructor(
    private userPrefsService: UserPreferencesService,
    private loggerFactory: LoggerFactory,
    private clientDeviceService: ClientDeviceService
  ) {
    this._privacyMode$ = new BehaviorSubject(null);

    this.logger = this.loggerFactory.getLogger('myadp.pay.privacy-mode-shared');

    this.userPrefsService
      .getPreferenceValue(UserPreferenceKeys.ENABLE_PAY_PRIVACY_MODE)
      .then((isPayPrivacyModeEnabled: boolean) => this.updatePrivacyMode(isPayPrivacyModeEnabled))
      .catch((error) =>
        this.logger.error('Failed to retrieve enablePayPrivacyMode preference', error)
      );
  }

  public get privacyMode$(): Observable<boolean> {
    return this._privacyMode$.asObservable().pipe(distinctUntilChanged());
  }

  public get showMaskedValue$(): Observable<boolean> {
    return this._privacyMode$.asObservable().pipe(
      map((privacyMode) => {
        return (
          privacyMode &&
          !(this.clientDeviceService.isNative() && this.clientDeviceService.isMobile())
        );
      }),
      distinctUntilChanged()
    );
  }

  public get privacyMode(): boolean {
    return this._privacyMode$.getValue();
  }

  public setPrivacyMode(isPayPrivacyModeEnabled: boolean): void {
    this.updatePrivacyMode(isPayPrivacyModeEnabled);
    this.userPrefsService
      .setPreference(UserPreferenceKeys.ENABLE_PAY_PRIVACY_MODE, isPayPrivacyModeEnabled)
      .catch((error) => this.logger.error('Failed to set payPrivacyMode user preference', error));
  }

  private updatePrivacyMode(isPayPrivacyModeEnabled: boolean): void {
    this._privacyMode$.next(isPayPrivacyModeEnabled);
  }
}
