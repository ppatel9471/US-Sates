export enum PayStatementType {
  ADJUSTMENT = 'adjustment'
}
