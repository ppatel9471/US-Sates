import { TestBed } from '@angular/core/testing';
import { Mock } from 'ts-mockery';
import { cloneDeep } from 'lodash';
import { CurrencyPipe } from '@angular/common';
import { LanguageService } from '@myadp/common';

import { AdditionalTaxAmount } from '../../../models/tax-withholding.model';
import { SummaryItem } from '../../../models/formatted-tax-withholding.model';
import { WithholdingFormatterService } from './withholding-formatter.service';
import { ValueFormatterService } from '../../shared/services/value-formatter.service';
import { StateIncomeTaxWithholdingElection } from '../../../models/us-state-tax-withholding-election.model';

describe('WithholdingFormatterService', () => {
  const GSS_URL = '/api/tax/v1/statutory-forms/file/';
  let service: WithholdingFormatterService;
  let mockAmount: AdditionalTaxAmount;
  let mockPercent: number;
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        WithholdingFormatterService,
        ValueFormatterService,
        CurrencyPipe,
        {
          provide: LanguageService,
          useValue: Mock.of<LanguageService>({ get: key => key })
        }
      ]
    });
  });
  beforeEach(() => {
    service = TestBed.inject(WithholdingFormatterService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should show amount when amount is 5 and percent is 5', () => {
    mockAmount = { amountValue: 5 };
    mockPercent = 5;
    expect(service.showAdditionalTaxAmount(mockAmount, mockPercent)).toEqual(true);
    expect(service.showAdditionalTaxPercentage(mockAmount, mockPercent)).toEqual(false);
  });

  it('should show amount when amount is 0 and percent is 5', () => {
    mockAmount = { amountValue: 0 };
    mockPercent = 5;
    expect(service.showAdditionalTaxAmount(mockAmount, mockPercent)).toEqual(false);
    expect(service.showAdditionalTaxPercentage(mockAmount, mockPercent)).toEqual(true);
  });

  it('should show amount when amount is 0 and percent is 0', () => {
    mockAmount = { amountValue: 0 };
    mockPercent = 0;
    expect(service.showAdditionalTaxAmount(mockAmount, mockPercent)).toEqual(true);
    expect(service.showAdditionalTaxPercentage(mockAmount, mockPercent)).toEqual(false);
  });

  it('should show amount when amount is 0 and percent is NA', () => {
    mockAmount = { amountValue: 0 };
    mockPercent = undefined;
    expect(service.showAdditionalTaxAmount(mockAmount, mockPercent)).toEqual(true);
    expect(service.showAdditionalTaxPercentage(mockAmount, mockPercent)).toEqual(false);
  });

  it('should show amount when amount is 5 and percent is NA', () => {
    mockAmount = { amountValue: 5 };
    mockPercent = undefined;
    expect(service.showAdditionalTaxAmount(mockAmount, mockPercent)).toEqual(true);
    expect(service.showAdditionalTaxPercentage(mockAmount, mockPercent)).toEqual(false);
  });

  it('should show amount when amount is NA and percent is 0', () => {
    mockAmount = undefined;
    mockPercent = 0;
    expect(service.showAdditionalTaxAmount(mockAmount, mockPercent)).toEqual(false);
    expect(service.showAdditionalTaxPercentage(mockAmount, mockPercent)).toEqual(true);
  });

  it('should show amount when amount is NA and percent is 5', () => {
    mockAmount = undefined;
    mockPercent = 5;
    expect(service.showAdditionalTaxAmount(mockAmount, mockPercent)).toEqual(false);
    expect(service.showAdditionalTaxPercentage(mockAmount, mockPercent)).toEqual(true);
  });

  it('should show amount when amount is NA and percent is NA', () => {
    mockAmount = undefined;
    mockPercent = undefined;
    expect(service.showAdditionalTaxAmount(mockAmount, mockPercent)).toEqual(false);
    expect(service.showAdditionalTaxPercentage(mockAmount, mockPercent)).toEqual(false);
  });

  it('should get AdditionalStatutoryInputs', () => {
    const mockWithholding: StateIncomeTaxWithholdingElection = {
      additionalStatutoryInputs: [
        {
          tagCode: 'LOWER_RATE',
          tagValues: ['true']
        }
      ]
    };
    expect(service.getAdditionalStatutoryInputs('LOWER_RATE', mockWithholding)).toEqual('true');
  });

  it('should get AdditionalStatutoryInputs undefined', () => {
    const mockWithholding: StateIncomeTaxWithholdingElection = {
      additionalStatutoryInputs: [
        {
          tagCode: 'LOWER_RATE',
          tagValues: ['true']
        }
      ]
    };
    expect(service.getAdditionalStatutoryInputs('TOTAL_ALLOWANCES', mockWithholding)).toEqual(
      undefined
    );
  });

  describe('Get attachments', () => {
    let mockWithholding: StateIncomeTaxWithholdingElection;
    const mockFullAttachment = {
      nameCode: {
        codeValue: 'TAX_WITHHOLDING',
        shortName: 'A4'
      },
      attachmentLink: {
        payLoadArguments: [
          {
            argumentPath: 'gssID',
            argumentValue: '31cb9db9-4ffd-4f7d-9743-dd23b64c9e3c'
          },
          {
            argumentPath: 'submittedDateTime',
            argumentValue: '2019-11-26T22:20:03.960Z'
          }
        ]
      }
    };

    beforeEach(() => {
      mockWithholding = {
        stateCode: { codeValue: 'AL', longName: 'Alabama' },
        attachments: []
      };
    });

    it('should not populate attachments when it is missing', () => {
      delete mockWithholding.attachments;
      const attachments = service.getAttachments(mockWithholding);

      expect(attachments.length).toEqual(0);
    });

    it('should not populate attachments when gssID is missing', () => {
      const mockAttachment = cloneDeep(mockFullAttachment);
      delete mockAttachment.attachmentLink.payLoadArguments[0].argumentPath;
      mockWithholding.attachments.push(mockAttachment);

      const attachments = service.getAttachments(mockWithholding);

      expect(attachments.length).toEqual(0);
    });

    it('should populate attachments', () => {
      mockWithholding.attachments.push(mockFullAttachment);

      const attachments = service.getAttachments(mockWithholding);

      expect(attachments).toEqual([{
        shortName: 'A4',
        gssUrl: GSS_URL + '31cb9db9-4ffd-4f7d-9743-dd23b64c9e3c',
        submittedDateTime: '2019-11-26T22:20:03.960Z'
      }]);
    });

    it('should populate attachments when shortName is missing', () => {
      const mockAttachment = cloneDeep(mockFullAttachment);
      delete mockAttachment.nameCode;
      mockWithholding.attachments.push(mockAttachment);

      const attachments = service.getAttachments(mockWithholding);

      expect(attachments).toEqual([{
        shortName: undefined,
        gssUrl: GSS_URL + '31cb9db9-4ffd-4f7d-9743-dd23b64c9e3c',
        submittedDateTime: '2019-11-26T22:20:03.960Z'
      }]);
    });

    it('should populate attachments sorted newest first', () => {
      const mockAttachment = cloneDeep(mockFullAttachment);
      const mockNewAttachment = cloneDeep(mockFullAttachment);
      mockNewAttachment.attachmentLink.payLoadArguments[1].argumentValue = '2020-11-26T22:20:03.960Z';
      mockWithholding.attachments.push(mockAttachment, mockNewAttachment, mockAttachment);

      const attachments = service.getAttachments(mockWithholding);

      expect(attachments[0].submittedDateTime).toEqual('2020-11-26T22:20:03.960Z');
      expect(attachments[1].submittedDateTime).toEqual('2019-11-26T22:20:03.960Z');
      expect(attachments[2].submittedDateTime).toEqual('2019-11-26T22:20:03.960Z');
    });
  });

  describe('Format Pending Items', () => {
    let currentItems: SummaryItem[];
    let pendingItems: SummaryItem[];

    beforeEach(() => {
      currentItems = [
        {
          displayName: 'TOTAL_ALLOWANCES',
          displayValue: 1
        },
        {
          displayName: 'FILING_STATUS',
          displayValue: 'Single'
        }
      ];
      pendingItems = [
        {
          displayName: 'TOTAL_ALLOWANCES',
          displayValue: 2
        },
        {
          displayName: 'FILING_STATUS',
          displayValue: 'Married'
        }
      ];
    });

    it('when both items has changed then lists should be sorted', () => {
      service.formatPendingItems(currentItems, pendingItems);

      expect(currentItems).toEqual([
        {
          displayName: 'FILING_STATUS',
          displayValue: 'Single'
        },
        {
          displayName: 'TOTAL_ALLOWANCES',
          displayValue: 1
        }
      ]);
      expect(pendingItems).toEqual([
        {
          displayName: 'FILING_STATUS',
          displayValue: 'Married'
        },
        {
          displayName: 'TOTAL_ALLOWANCES',
          displayValue: 2
        }
      ]);
    });

    it('when one item has changed', () => {
      pendingItems[0].displayValue = currentItems[0].displayValue;
      service.formatPendingItems(currentItems, pendingItems);

      expect(pendingItems).toEqual([
        {
          displayName: 'FILING_STATUS',
          displayValue: 'Married'
        }
      ]);
    });

    it('when no items have changed', () => {
      pendingItems[0].displayValue = currentItems[0].displayValue;
      pendingItems[1].displayValue = currentItems[1].displayValue;
      service.formatPendingItems(currentItems, pendingItems);

      expect(pendingItems).toEqual([]);
    });

    it('when filing status is removed', () => {
      pendingItems.pop();
      service.formatPendingItems(currentItems, pendingItems);

      expect(currentItems).toContain({
        displayName: 'FILING_STATUS',
        displayValue: 'Single'
      });

      expect(pendingItems).toContain({
        displayName: 'FILING_STATUS',
        displayValue: 'myadp-pay.REMOVED'
      });
    });

    it('when filing status is added', () => {
      currentItems.pop();
      service.formatPendingItems(currentItems, pendingItems);

      expect(currentItems).toContain({
        displayName: 'FILING_STATUS',
        displayValue: 'common.NONE'
      });

      expect(pendingItems).toContain({
        displayName: 'FILING_STATUS',
        displayValue: 'Married'
      });
    });

    it('when going from not exempt to exempt', () => {
      pendingItems.push({
        displayName: 'WITHHOLDING_STATUS',
        displayValue: 'myadp-pay.EXEMPT'
      });
      service.formatPendingItems(currentItems, pendingItems);

      expect(currentItems).toContain({
        displayName: 'WITHHOLDING_STATUS',
        displayValue: 'myadp-pay.NOT_EXEMPT'
      });

      expect(pendingItems).toContain({
        displayName: 'WITHHOLDING_STATUS',
        displayValue: 'myadp-pay.EXEMPT'
      });
    });

    it('when going from exempt to not exempt', () => {
      currentItems.push({
        displayName: 'WITHHOLDING_STATUS',
        displayValue: 'myadp-pay.EXEMPT'
      });
      service.formatPendingItems(currentItems, pendingItems);

      expect(currentItems).toContain({
        displayName: 'WITHHOLDING_STATUS',
        displayValue: 'myadp-pay.EXEMPT'
      });

      expect(pendingItems).toContain({
        displayName: 'WITHHOLDING_STATUS',
        displayValue: 'myadp-pay.NOT_EXEMPT'
      });
    });

    it('when going to a higher tax rate', () => {
      pendingItems.push({
        displayName: 'TWM_SHARED_SUMMARY_HIGHER_TAX_RATE_HEADING',
        displayValue: 'common.YES'
      });
      service.formatPendingItems(currentItems, pendingItems);

      expect(currentItems).toContain({
        displayName: 'TWM_SHARED_SUMMARY_HIGHER_TAX_RATE_HEADING',
        displayValue: 'common.NO'
      });

      expect(pendingItems).toContain({
        displayName: 'TWM_SHARED_SUMMARY_HIGHER_TAX_RATE_HEADING',
        displayValue: 'common.YES'
      });
    });

    it('when going away from a higher tax rate', () => {
      currentItems.push({
        displayName: 'TWM_SHARED_SUMMARY_HIGHER_TAX_RATE_HEADING',
        displayValue: 'common.YES'
      });
      service.formatPendingItems(currentItems, pendingItems);

      expect(currentItems).toContain({
        displayName: 'TWM_SHARED_SUMMARY_HIGHER_TAX_RATE_HEADING',
        displayValue: 'common.YES'
      });

      expect(pendingItems).toContain({
        displayName: 'TWM_SHARED_SUMMARY_HIGHER_TAX_RATE_HEADING',
        displayValue: 'common.NO'
      });
    });
  });
});
