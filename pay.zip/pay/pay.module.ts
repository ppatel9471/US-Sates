import { NgModule } from '@angular/core';
import { ButtonModule } from '@espresso/button';
import { TabsModule } from '@synerg/components/tabs';
import { TileModule } from '@synerg/components/tile';

import { MyAdpCommonModule } from '@myadp/common';
import { DashboardModule } from '@myadp/common/components/dashboard';

import { DirectDepositModule } from './direct-deposit/direct-deposit.module';
import { MyADPDirectDepositModule } from './modules/direct-deposit/direct-deposit.module';
import { MetaModule } from './modules/meta/meta.module';
import { PaperlessModule } from './modules/paperless/paperless.module';
import { PayDashboardTileModule } from './modules/pay-dashboard-tile/pay-dashboard-tile.module';
import { PaylensModule } from './modules/paylens/paylens.module';
import { SharedModule } from './modules/shared/shared.module';
import { PayTasksModule } from './modules/tasks/pay-tasks.module';
import { TaxStatementsTileModule } from './modules/tax-statements-tile/tax-statements-tile.module';
import { TaxWithholdingManagementTileModule } from './modules/tax-withholding-management-tile/tax-withholding-management-tile.module';
import { TaxWithholdingManagementModule } from './modules/tax-withholding-management/tax-withholding-management.module';
import { WebComponentWrappersModule } from './modules/web-component-wrappers/web-component-wrappers.module';
import { PayDashboardComponent } from './pay-dashboard.component';

@NgModule({
  imports: [
    DirectDepositModule,
    TaxWithholdingManagementTileModule,
    TileModule,
    TabsModule,
    DashboardModule,
    SharedModule,
    TaxWithholdingManagementModule,
    PaperlessModule,
    MyAdpCommonModule,
    PayTasksModule,
    MetaModule,
    ButtonModule,
    PaylensModule,
    PayDashboardTileModule,
    TaxStatementsTileModule,
    MyADPDirectDepositModule,
    WebComponentWrappersModule
  ],
  declarations: [PayDashboardComponent],
  exports: [PayTasksModule]
})
export class PayModule {}
