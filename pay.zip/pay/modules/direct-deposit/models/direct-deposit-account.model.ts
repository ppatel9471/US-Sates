import { PayDistributionsUI } from '../../pay-distributions-shared/models/pay-distributions-ui';

export interface DirectDepositAccount extends PayDistributionsUI.PayDistribution {
  isReadOnly?: boolean;
  isWisely?: boolean;
  isDailyPay?: boolean;
  hasAltWorkflow?: boolean;
}
