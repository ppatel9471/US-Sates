import { Component, EventEmitter, HostBinding, OnInit, Output } from '@angular/core';
import { slideinAnimation } from '@synerg/components/slidein';
import { Observable } from 'rxjs';

import { DeductionsStoreActions } from '../../store/deductions-store.actions';
import { DeductionsStore } from '../../store/deductions.store';
import { StepsState, StepsStore, StepsStoreActions } from '../../store/steps/steps.store';

@Component({
  selector: 'deductions-slidein',
  templateUrl: './deductions-slidein.component.html',
  animations: [slideinAnimation],
  styleUrls: ['./deductions-slidein.component.scss']
})
export class DeductionsSlideinComponent implements OnInit {
  @HostBinding('@slideinTransition') slideinTransition = 'slidein';
  @Output() closed: EventEmitter<void> = new EventEmitter<void>();
  public stepsStore$: Observable<StepsState>;
  public showFooter$: Observable<boolean>;
  public stepName$: Observable<string>;
  public showConfirmCancelModal: boolean = false;

  constructor(
    private stepsStore: StepsStore,
    private stepsStoreActions: StepsStoreActions,
    private deductionsStore: DeductionsStore,
    private deductionsStoreActions: DeductionsStoreActions
  ) {}

  public ngOnInit() {
    this.showFooter$ = this.stepsStore.showStepNavigation$;
    this.stepsStore$ = this.stepsStore.stepsStore$;
    this.stepName$ = this.stepsStore.stepName$;

    this.openSlidein();
  }

  public openSlidein() {
    this.stepsStoreActions.openSlidein();

    if (this.deductionsStore.hasDeductions) {
      this.deductionsStoreActions.loadStartMeta();
    }
  }

  public closeSlidein() {
    if (this.stepsStoreActions.hasFormDetailChanges()) {
      this.showConfirmCancelModal = true;
    } else {
      this.handleSlideinClose();
    }
  }

  public confirmClose() {
    this.showConfirmCancelModal = false;
    this.handleSlideinClose();
  }

  private handleSlideinClose() {
    this.stepsStoreActions.closeSlidein();
    this.stepsStoreActions.resetCurrentStep();
    this.closed.emit();
  }
}
