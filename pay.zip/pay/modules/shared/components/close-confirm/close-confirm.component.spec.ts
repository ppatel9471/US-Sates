import { Shallow } from 'shallow-render';

import { LanguagePipe } from '@myadp/common';

import { SharedModule } from '../../shared.module';
import { CloseConfirmComponent } from './close-confirm.component';

describe('CloseConfirmComponent', () => {
  let shallow: Shallow<CloseConfirmComponent>;

  beforeEach(() => {
    shallow = new Shallow(CloseConfirmComponent, SharedModule).mockPipe(LanguagePipe, (key) => key);
  });

  it('should display with defaults', async () => {
    const { find } = await shallow.render({
      bind: {
        content: 'Some content'
      }
    });
    const [cancelBtn, confirmBtn] = find('adp-button');

    expect(find('.modal-title').nativeElement.innerHTML).toContain('myadp-pay.SHARED_EXIT_TITLE');
    expect(find('.modal-body').nativeElement.innerHTML).toContain('Some content');
    expect(cancelBtn.nativeElement.innerHTML).toContain('common.CANCEL');
    expect(confirmBtn.nativeElement.innerHTML).toContain('common.EXIT');
    expect(find('adp-modal').componentInstance.closeable).toBe(true);
    expect(find('adp-modal').componentInstance.size).toBe('lg');
  });

  it('should display the given content', async () => {
    const { find } = await shallow.render({
      bind: {
        content: 'Some content'
      }
    });

    expect(find('.modal-title').nativeElement.innerHTML).toContain('myadp-pay.SHARED_EXIT_TITLE');
    expect(find('.modal-body').nativeElement.innerHTML).toContain('Some content');
  });

  it('should display the given title', async () => {
    const { find } = await shallow.render({
      bind: {
        content: 'Some content',
        title: 'Confirm'
      }
    });

    expect(find('.modal-title').nativeElement.innerHTML).toContain('Confirm');
  });

  it('should display the given button text', async () => {
    const { find } = await shallow.render({
      bind: {
        content: 'Some content',
        cancelText: 'No, keep request',
        confirmText: 'Yes, cancel'
      }
    });
    const [cancelBtn, confirmBtn] = find('.modal-footer adp-button');

    expect(cancelBtn.nativeElement.innerHTML).toContain('No, keep request');
    expect(confirmBtn.nativeElement.innerHTML).toContain('Yes, cancel');
  });

  it('should change the size of the modal', async () => {
    const { find } = await shallow.render({
      bind: {
        size: 'sm'
      }
    });

    expect(find('adp-modal').componentInstance.size).toBe('sm');
  });

  it('should make the modal closeable', async () => {
    const { find } = await shallow.render({
      bind: {
        closeable: true
      }
    });

    expect(find('adp-modal').componentInstance.closeable).toBe(true);
  });

  it('should make the modal non-closeable', async () => {
    const { find } = await shallow.render({
      bind: {
        closeable: false
      }
    });

    expect(find('adp-modal').componentInstance.closeable).toBe(false);
  });

  it('should emit on cancel', async () => {
    const { find, outputs } = await shallow.render({
      bind: {
        content: 'Something',
        size: 'sm'
      }
    });
    find('adp-button[id="cancel-button"]').nativeElement.click();

    expect(outputs.confirm.emit).not.toHaveBeenCalled();
    expect(outputs.cancel.emit).toHaveBeenCalled();
  });

  it('should emit on confirm', async () => {
    const { find, outputs } = await shallow.render({
      bind: {
        content: 'Something',
        size: 'sm'
      }
    });
    find('adp-button[id="confirm-button"]').nativeElement.click();

    expect(outputs.confirm.emit).toHaveBeenCalled();
    expect(outputs.cancel.emit).not.toHaveBeenCalled();
  });
});
