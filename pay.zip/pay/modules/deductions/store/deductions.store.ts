import { Injectable } from '@angular/core';
import { combineLatest, Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { BaseStore } from '@myadp/pay-shared';

import {
  PayDeductionsStoreSlice,
  PayDeductionsUI
} from '../../pay-deductions-shared/models/pay-deductions-ui';
import { PayDeductionsStore } from '../../pay-deductions-shared/store/pay-deductions.store';
import { WorkflowUI } from '../../shared/models/workflow-ui.model';
import { DeductionForm } from '../models/deduction-form.model';
import { DeductionChanges, DeductionsStoreState } from '../models/deductions-store.model';

@Injectable({
  providedIn: 'root'
})
export class DeductionsStore extends BaseStore<DeductionsStoreState> {
  constructor(private payDeductionsStore: PayDeductionsStore) {
    super({
      formData: {
        data: undefined
      },
      changedDeductionDetails: {
        data: undefined
      },
      changes: {
        data: undefined
      },
      permissions: {
        data: undefined
      }
    });
  }

  public get deductions$(): Observable<PayDeductionsUI.Deduction[]> {
    return this.payDeductionsStore.payDeductions$;
  }

  public get deductionsSnapshot(): PayDeductionsUI.Deduction[] {
    return this.payDeductionsStore.payDeductionsSnapshot;
  }

  public get hasDeductions(): boolean {
    return this.deductionsSnapshot?.length > 0;
  }

  public hasPermission(permission: WorkflowUI.ChangeType): boolean {
    return this.getData('permissions', permission, false);
  }

  public get isLoading$(): Observable<boolean> {
    return combineLatest([
      this.payDeductionsStore.isPayDeductionsLoading$,
      this.payDeductionsStore.isPayDeductionsMetaLoading$
    ]).pipe(map(([deductionsLoading, metaLoading]) => deductionsLoading || metaLoading));
  }

  public get isDeductionsLoading$(): Observable<boolean> {
    return this.payDeductionsStore.isPayDeductionsLoading$;
  }

  public get changes(): DeductionChanges {
    return this.getData('changes');
  }

  public get hasUnsavedAdd(): boolean {
    return this.getData('changes')?.changeType === 'add';
  }

  public get hasStartMetaError$(): Observable<boolean> {
    return this.payDeductionsStore.hasError$(
      PayDeductionsStoreSlice.PAY_DEDUCTIONS_META,
      'startMetaError'
    );
  }

  public get hasSaveError$(): Observable<boolean> {
    return combineLatest([
      this.payDeductionsStore.hasError$(PayDeductionsStoreSlice.PAY_DEDUCTIONS, 'postError'),
      this.payDeductionsStore.hasError$(PayDeductionsStoreSlice.PAY_DEDUCTIONS, 'recallError')
    ]).pipe(map(([postError, recallError]) => postError || recallError));
  }

  public get hasWorkerError$(): Observable<boolean> {
    return this.payDeductionsStore.hasError$(
      PayDeductionsStoreSlice.PAY_DEDUCTIONS_META,
      'payrollGroupCodeError'
    );
  }

  public get formData(): DeductionForm {
    return this.getData('formData', undefined, null);
  }

  public get changedDeductionDetails(): Partial<PayDeductionsUI.DeductionDetails> {
    return this.getData('changedDeductionDetails');
  }

  public getDeductionByID(itemID: string): PayDeductionsUI.Deduction {
    return this.deductionsSnapshot?.find(
      (deduction) => (deduction?.pendingData ?? deduction?.currentData)?.itemID === itemID
    );
  }

  public get maxDeductionsReached$(): Observable<boolean> {
    return this.payDeductionsStore.getData$(
      PayDeductionsStoreSlice.PAY_DEDUCTIONS_META,
      'maxDeductionsReached'
    );
  }

  public get permissions(): Record<WorkflowUI.ChangeType, boolean> {
    return this.getData('permissions', undefined);
  }
}
