import { isEmpty, cloneDeep } from 'lodash';

import { PayStatementsUI } from '../models/pay-statement-ui';
import {
  MOCK_PAY_STATEMENT_DETAILS_RESPONSE,
  MOCK_TRANSFORMED_PAY_STATEMENT_DETAILS_RESPONSE
} from '../../../../../../src/spec-helpers/pay/pay-statement/pay-statement-details';
import { buildOtherPayCategory } from './other-pay.transform';

describe('buildOtherPayCategory', () => {
  let otherPayCategory: PayStatementsUI.DeductionsCategory;

  beforeEach(() => {
    otherPayCategory = undefined;
  });

  it('should transform other pay', () => {
    otherPayCategory = buildOtherPayCategory(MOCK_PAY_STATEMENT_DETAILS_RESPONSE.payStatement);

    expect(otherPayCategory).toEqual(
      MOCK_TRANSFORMED_PAY_STATEMENT_DETAILS_RESPONSE.deductionsCategories[5]
    );
  });

  it('should not transform other pay', () => {
    const mockStatement = cloneDeep(MOCK_PAY_STATEMENT_DETAILS_RESPONSE.payStatement);
    mockStatement.otherPay[0].otherPayDetail = [];
    otherPayCategory = buildOtherPayCategory(mockStatement);

    expect(isEmpty(otherPayCategory)).toBeTruthy();
  });
});
