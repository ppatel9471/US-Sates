import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { map } from 'rxjs/operators';
import { get } from 'lodash';

@Injectable({
  providedIn: 'root'
})
export class CustomContentService {
  private readonly URL: string = '/myadpapi/client-content/v1/pay';
  private customContentCache: Object;
  constructor(private httpClient: HttpClient) {}

  public getCustomContent(featureKey: string, contentKey?: string): Observable<string> {
    contentKey = contentKey ? contentKey : 'message';
    if (!this.customContentCache) {
      return this.httpClient.get(this.URL).pipe(
        map((response) => {
          this.customContentCache = response;
          return this.parseCustomContent(featureKey, contentKey);
        })
      );
    }
    return of(this.parseCustomContent(featureKey, contentKey));
  }

  private parseCustomContent(featureKey: string, contentKey: string): string {
    return get(this.customContentCache, `${featureKey}.${contentKey}`);
  }
}
