import { COUNTRY } from '../../models/country';

import usTransform from './us/us-dd-transform';
import transformToUSDTO from './us/us-dto-transform';

import caTransform from './ca/ca-dd-transform';
import transformToCADTO from './ca/ca-dto-transform';

export const countryTransforms = {
  [COUNTRY.US]: usTransform,
  [COUNTRY.CA]: caTransform
};

export const countryDTOtransforms = {
  [COUNTRY.US]: transformToUSDTO,
  [COUNTRY.CA]: transformToCADTO
};
