import { CountryDetails } from './../../../pay-distributions-shared/models/country';
import { Injectable, ViewContainerRef } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { distinctUntilChanged, map } from 'rxjs/operators';

import { BaseStore, StoreState } from '@myadp/pay-shared';

import { PayDistributionsUI } from '../../../pay-distributions-shared/models/pay-distributions-ui';
import { PayDistributionStore } from '../../../pay-distributions-shared/store/pay-distribution.store';
import { DirectDepositAccount } from '../../models/direct-deposit-account.model';
import { FormDetails } from '../../models/form-details.model';
import { ProgressProperties, StepStateProps } from '../../models/steps-navigation-helper.model';
import { STEPS as DD_STEPS } from '../../models/steps.enum';
import { DirectDepositStore } from '../../store/direct-deposit.store';
import { PrevNext } from './steps-store.actions';

export { StepsStoreActions } from './steps-store.actions';

export enum StepsStoreSlice {
  STEPS = 'steps'
}

export interface StepsStoreState {
  [StepsStoreSlice.STEPS]?: StepsState;
}

export interface StepsState extends StepStateProps {
  step: {
    current?: number;
    outOf?: number;
    name?: string;
  };
}
@Injectable({
  providedIn: 'root'
})
export class StepsStore extends BaseStore<StepsStoreState> {
  public directDepositAccounts$: Observable<DirectDepositAccount[]>;
  public payDistributionsMeta$: Observable<PayDistributionsUI.PayDistributionMeta>;
  public hasChangePermission$: Observable<boolean>;
  public hasExistingAccounts: boolean;
  public accountTypeComponents: object = {};
  public stepContainer: ViewContainerRef;
  public isSlideinOpen$: BehaviorSubject<boolean>;

  constructor(
    private directDepositStore: DirectDepositStore,
    private payDistributionStore: PayDistributionStore
  ) {
    super({
      [StepsStoreSlice.STEPS]: {
        data: null
      }
    });

    this.isSlideinOpen$ = new BehaviorSubject(false);
    this.directDepositAccounts$ = this.directDepositStore.directDepositAccounts$;
    this.payDistributionsMeta$ = this.payDistributionStore.payDistributionMeta$;
    this.hasChangePermission$ = this.payDistributionStore.hasChangePermission$;
  }

  public get stepsStore$(): Observable<StepsState> {
    return this.getData$(StepsStoreSlice.STEPS, undefined, null);
  }

  public get showStepNavigation$(): Observable<boolean> {
    return this.state$.pipe(
      map((state: StoreState<StepsStoreState>) => {
        const store = state[StepsStoreSlice.STEPS]?.data;
        return !(store?.hideNavigation || store?.isLastStep);
      }),
      distinctUntilChanged()
    );
  }

  public get stepName$(): Observable<string> {
    return this.state$.pipe(
      map((state) => {
        const name = state[StepsStoreSlice.STEPS]?.data?.step?.name;
        return name === DD_STEPS.ACCOUNT_DETAILS && this.isEditing
          ? 'myadp-pay.DD_EDIT_ACCOUNT'
          : 'myadp-pay.DD_STEP_TITLE_' + name;
      }),
      distinctUntilChanged()
    );
  }

  public getPrevOrNextProperties$(dir: PrevNext): Observable<ProgressProperties> {
    return this.getData$(StepsStoreSlice.STEPS, dir, { disabled: false, hidden: false });
  }

  public get isSubmitStep$(): Observable<boolean> {
    return this.getData$(StepsStoreSlice.STEPS, 'isSubmitStep');
  }

  public get isSlideinOpenObs$(): Observable<boolean> {
    return this.isSlideinOpen$.asObservable().pipe(distinctUntilChanged());
  }

  public get stepsStoreData(): StepsState {
    return this.getData(StepsStoreSlice.STEPS);
  }

  public get stepFormDetails(): FormDetails {
    return this.directDepositStore.formDetails;
  }

  public get currentStepName(): string {
    return this.getData(StepsStoreSlice.STEPS, 'step')?.name;
  }

  public get isEditing(): boolean {
    return this.getData(StepsStoreSlice.STEPS, 'isEditing');
  }

  public get editingAccount(): DirectDepositAccount {
    return this.directDepositStore
      .getDDAccountsSnapshot()
      ?.find(
        (account) => (account?.pendingData ?? account?.currentData)?.id === this.stepFormDetails?.id
      );
  }

  public get country(): CountryDetails {
    return this.directDepositStore.directDepositCountry;
  }
}
