import { NjIntroComponent } from './steps/intro/nj-intro.component';
import { NjExemptionComponent } from './steps/exemption/nj-exemption.component';
import { NjMaritalStatusComponent } from './steps/marital-status/nj-marital-status.component';
import { NjWageChartComponent } from './steps/wage-chart/nj-wage-chart.component';
import { NjAllowancesComponent } from './steps/allowances/nj-allowances.component';

export { NjStepNavigationService } from './services/nj-step-navigation.service';
export { NjTWChangeEventService } from './services/nj-tw-change-event.service';
export { NjSummaryMetaDataService } from './services/nj-summary-meta-data.service';

export const NJ_COMPONENTS = [
  NjAllowancesComponent,
  NjIntroComponent,
  NjExemptionComponent,
  NjMaritalStatusComponent,
  NjWageChartComponent
];

export { NJSTEP_COMPONENT } from './models/steps-component.model';

export { NjAttachmentCodes } from './models/nj-tw-change-event';
