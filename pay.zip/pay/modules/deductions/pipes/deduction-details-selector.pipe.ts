import { Pipe, PipeTransform } from '@angular/core';

import { PayDeductionsUI } from '../../pay-deductions-shared/models/pay-deductions-ui';
import { WorkflowUI } from '../../shared/models/workflow-ui.model';

export type DeductionListDetails = PayDeductionsUI.DeductionDetails & {
  deduction: PayDeductionsUI.Deduction;
  pendingEvent: WorkflowUI.PendingEvent;
};

@Pipe({ name: 'deductionDetailsSelector', pure: true })
export class DeductionDetailsSelectorPipe implements PipeTransform {
  public transform(
    deductions: PayDeductionsUI.Deduction[],
    mode: 'list' | 'tile' = 'list'
  ): DeductionListDetails[] {
    return deductions
      ?.filter(({ currentData, pendingData, pendingEvent }) =>
        mode === 'tile'
          ? pendingEvent?.changeType !== 'delete' && (pendingData || currentData)
          : pendingData || currentData
      )
      ?.map((deduction) => {
        return {
          ...(deduction.pendingData ?? deduction.currentData),
          deduction,
          pendingEvent: deduction.pendingEvent
        } as DeductionListDetails;
      });
  }
}
