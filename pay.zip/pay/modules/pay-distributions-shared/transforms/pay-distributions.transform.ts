import { ConfirmMessage, PayDistributionsDTO } from '@myadp/dto';
import { CountryDetails } from '../models/country';

import { PayDistributionsUI } from '../models/pay-distributions-ui';

import { countryTransforms } from './country-mappings/country-transforms';

export function transformDistributions(
  country: CountryDetails,
  res: PayDistributionsDTO.WfResponse
): PayDistributionsUI.PayDistribution[] {
  return mapToPayDistribution(
    country,
    res?.currentData?.payDistributions?.[0]?.distributionInstructions,
    res?.pendingData?.payDistributions?.[0]?.distributionInstructions,
    res?.pendingEvents?.[0],
    res?.currentData?.confirmMessage
  );
}

function mapToPayDistribution(
  country: CountryDetails,
  currentData: PayDistributionsDTO.PayDistributionInstructionRaw[] = [],
  pendingData: PayDistributionsDTO.PayDistributionInstructionRaw[] = null,
  pendingEvent: PayDistributionsDTO.PendingEvent = null,
  confirmMessage: ConfirmMessage = null
): PayDistributionsUI.PayDistribution[] {
  const currentDists = currentData.map(
    (rawInstructions: PayDistributionsDTO.PayDistributionInstructionRaw) =>
      transformDistributionDetails(country, rawInstructions)
  );
  const pendingDists = pendingData?.map(
    (rawInstructions: PayDistributionsDTO.PayDistributionInstructionRaw) =>
      transformDistributionDetails(country, rawInstructions)
  );

  const approver = pendingEvent?.history?.find((person) => person?.actionTaken !== 'SUBMITTED');
  const event: PayDistributionsUI.PendingEvent = {
    approver: approver?.assignedTo ?? null
  };

  return findMatchingDistributions(currentDists, pendingDists, event, confirmMessage);
}

// creates an arbitrary, yet reproducible hash for a given distribution
export function generateDistributionID(
  codeValueData: Partial<PayDistributionsUI.CodeValueData>,
  precedence: string
): string {
  const { itemID, accountCode } = codeValueData;
  return `${accountCode || 'a'}${precedence || itemID || 'X'}`.replace(/\s/g, '');
}

export function transformDistributionDetails(
  country: CountryDetails,
  rawData: PayDistributionsDTO.PayDistributionInstructionRaw,
  withId: boolean = true
): PayDistributionsUI.PayDistributionDetails {
  let transformedPayDistribution = countryTransforms[country.shortName](rawData);

  transformedPayDistribution = {
    ...(withId && {
      id: generateDistributionID(
        transformedPayDistribution.codeValueData,
        transformedPayDistribution.precedence
      )
    }),
    ...transformedPayDistribution
  };

  return transformedPayDistribution;
}

function findMatchingDistributions(
  currentDists: PayDistributionsUI.PayDistributionDetails[],
  pendingDists: PayDistributionsUI.PayDistributionDetails[],
  event: PayDistributionsUI.PendingEvent,
  confirmMessage: ConfirmMessage
): PayDistributionsUI.PayDistribution[] {
  if (!pendingDists) {
    return currentDists.map((dist) => ({
      currentData: dist,
      pendingData: null,
      pendingEvent: confirmMessage
        ? setAltWorkflowMessage(dist?.codeValueData?.itemID, confirmMessage)
        : null
    }));
  } else {
    // if there are pendingDists we need to match them up
    const uniqueAccountCodes: string[] = [
      ...new Set(
        [...currentDists, ...pendingDists].map(({ codeValueData: { accountCode } }) => accountCode)
      )
    ];

    return uniqueAccountCodes.map((uAccountCode) => {
      const currentDist = currentDists.find(
        ({ codeValueData: { accountCode } }) => uAccountCode === accountCode
      );
      const pendingDist = pendingDists.find(
        ({ codeValueData: { accountCode } }) => uAccountCode === accountCode
      );
      const hasPendingDiff = hasPendingDifference(currentDist, pendingDist);

      return currentDist && pendingDist // no change / edit
        ? {
          currentData: currentDist,
          pendingData: hasPendingDiff ? pendingDist : null,
          pendingEvent: hasPendingDiff ? { ...event, changeType: 'edit' } : null
        }
        : !currentDist && pendingDist // add
          ? {
            currentData: null,
            pendingData: pendingDist,
            pendingEvent: { ...event, changeType: 'add' }
          }
          : currentDist && !pendingDist // delete
            ? {
              currentData: currentDist,
              pendingData: null,
              pendingEvent: { ...event, changeType: 'delete' }
            }
            : null;
    });
  }
}

function setAltWorkflowMessage(
  itemID: string,
  confirmMessage: ConfirmMessage
): PayDistributionsUI.PendingEvent {
  const {
    processMessages: [processMsg]
  } = confirmMessage?.resourceMessages?.find((resourceMsg) => {
    const hasAltWfMsg = ['WFN-WORKFLOW', 'ALT-WORKFLOW'].includes(
      resourceMsg?.processMessages?.[0]?.userMessage?.codeValue
    );

    if (hasAltWfMsg) {
      const link: string = resourceMsg?.processMessages?.[0]?.links?.[0]?.href;
      const linkItemID: string = link?.split('/')?.pop();
      return linkItemID === itemID;
    } else {
      return false;
    }
  }) ?? { processMessages: [] };

  return processMsg
    ? {
      altWorkflowMessage: processMsg?.userMessage?.messageTxt
    }
    : null;
}

function hasPendingDifference(
  currentData: PayDistributionsUI.PayDistributionDetails,
  pendingData: PayDistributionsUI.PayDistributionDetails
): boolean {
  const { accountNumber, routingNumber, flatAmount, percentageAmount, distributionType } =
    pendingData ?? {};

  return (
    accountNumber !== currentData?.accountNumber ||
    routingNumber !== currentData?.routingNumber ||
    distributionType !== currentData?.distributionType ||
    (percentageAmount ?? 0) !== (currentData?.percentageAmount ?? 0) ||
    (flatAmount?.amountValue ?? 0) !== (currentData?.flatAmount?.amountValue ?? 0)
  );
}
