import { fakeAsync, flush } from '@angular/core/testing';
import { of } from 'rxjs';
import { Shallow } from 'shallow-render';
import { Mock } from 'ts-mockery';

import { LanguagePipe } from '@myadp/common';

import { CloseConfirmComponent } from '../../../shared/components/close-confirm/close-confirm.component';
import { DeductionsModule } from '../../deductions.module';
import { PrevNext } from '../../store/steps/steps-store.actions';
import { StepsStore, StepsStoreActions } from '../../store/steps/steps.store';
import { StepsNavigationComponent } from './steps-navigation.component';

describe('StepsNavigationComponent', () => {
  let shallow: Shallow<StepsNavigationComponent>;

  beforeEach(() => {
    return (shallow = new Shallow(StepsNavigationComponent, DeductionsModule)
      .dontMock(CloseConfirmComponent)
      .mock(StepsStore, {
        getPrevOrNextProperties$: (dir: PrevNext) =>
          dir === 'next'
            ? of({ disabled: false, hidden: false })
            : of({ disabled: false, hidden: false }),
        stepsStoreData: {}
      })
      .mock(StepsStoreActions, {
        submit: () => Promise.resolve(),
        hasFormDetailChanges: () => true,
        nextStep: () => Mock.noop(),
        prevStep: () => Mock.noop(),
        cancelStep: () => Mock.noop()
      })
      .mockPipe(LanguagePipe, (key) => key));
  });

  it('should show both buttons', async () => {
    const { find } = await shallow.render();
    expect(find('adp-button')).toHaveFound(3);
  });

  describe('Next button', () => {
    it('should have Next button when not on submit step', async () => {
      const { find } = await shallow.render();
      const [nextBtn] = find('#next-btn');

      expect(nextBtn.nativeElement.innerHTML).toContain('common.NEXT');
    });

    it('should go to next step when clicking next', async () => {
      const { find, get } = await shallow.render();
      const [nextBtn] = find('#next-btn');
      nextBtn.nativeElement.click();

      expect(get(StepsStoreActions).nextStep).toHaveBeenCalledTimes(1);
    });

    describe('button state', () => {
      it('should not be disabled', async () => {
        const { find } = await shallow.render();
        const [nextBtn] = find('#next-btn');

        expect(nextBtn.componentInstance.disabled).toBeFalsy();
      });

      it('should be disabled', async () => {
        const { find } = await shallow
          .mock(StepsStore, {
            getPrevOrNextProperties$: () => of({ hidden: false, disabled: true })
          })
          .render();
        const [nextBtn] = find('#next-btn');

        expect(nextBtn.componentInstance.disabled).toBeTruthy();
      });

      it('should be hidden', async () => {
        const { find } = await shallow
          .mock(StepsStore, {
            getPrevOrNextProperties$: (dir: PrevNext) =>
              dir === 'next'
                ? of({ hidden: true, disabled: false })
                : of({ hidden: false, disabled: false })
          })
          .render();
        const [prevBtn] = find('#prev-btn');

        expect(find('#prev-btn')).toHaveFoundOne();
        expect(prevBtn.nativeElement.innerHTML).toContain('common.PREV');
      });
    });

    describe('Submit Step', () => {
      it('PIMYPI-T922 should change Next button to Submit button if on submit step and enable prev button', async () => {
        const { find } = await shallow
          .mock(StepsStore, {
            isSubmitStep$: of(true),
            stepsStoreData: { isSubmitStep: true }
          })
          .render();
        const [nextBtn, prevBtn] = [find('#next-btn'), find('#prev-btn')];

        expect(nextBtn.nativeElement.innerHTML).toContain('common.SUBMIT');
        expect(prevBtn.nativeElement.innerHTML).toContain('common.PREV');
        expect(prevBtn.componentInstance.disabled).toBeFalsy();
      });

      it('PIMYPI-T979/T1002 should POST and go to Done step when POST is successful', fakeAsync(async () => {
        const { find, get } = await shallow
          .mock(StepsStore, {
            isSubmitStep$: of(true),
            stepsStoreData: { isSubmitStep: true }
          })
          .render();
        find('#next-btn').nativeElement.click();
        flush();

        expect(get(StepsStoreActions).submit).toHaveBeenCalledTimes(1);
        expect(get(StepsStoreActions).nextStep).toHaveBeenCalledTimes(1);
      }));

      it('PIMYPI-T925 should call POST and not go to next step when POST fails and enable prev / submit buttons', async () => {
        const { find, get } = await shallow
          .mock(StepsStore, {
            isSubmitStep$: of(true),
            stepsStoreData: { isSubmitStep: true }
          })
          .mock(StepsStoreActions, {
            submit: () => Promise.reject()
          })
          .render();
        const [nextBtn, prevBtn] = [find('#next-btn'), find('#prev-btn')];
        nextBtn.nativeElement.click();

        expect(get(StepsStoreActions).submit).toHaveBeenCalledTimes(1);
        expect(get(StepsStoreActions).nextStep).not.toHaveBeenCalledTimes(1);
        expect(nextBtn.componentInstance.disabled).toBeFalsy();
        expect(prevBtn.componentInstance.disabled).toBeFalsy();
      });
    });
  });

  describe('Prev button', () => {
    it('should go to prev step when clicking prev', async () => {
      const { find, get } = await shallow.render();
      const [prevBtn] = find('#prev-btn');
      prevBtn.nativeElement.click();

      expect(get(StepsStoreActions).prevStep).toHaveBeenCalledTimes(1);
    });

    describe('button state', () => {
      it('PIMYPI-T863/T864/T865/T866/T867/T868/T869/T870/T871 should not be disabled', async () => {
        const { find } = await shallow.render();
        const [prevBtn] = find('#prev-btn');

        expect(prevBtn.componentInstance.disabled).toBeFalsy();
      });

      it('should be disabled', async () => {
        const { find } = await shallow
          .mock(StepsStore, {
            getPrevOrNextProperties$: () => of({ hidden: false, disabled: true })
          })
          .render();
        const [prevBtn] = find('#prev-btn');

        expect(prevBtn.componentInstance.disabled).toBeTruthy();
      });

      it('should be hidden', async () => {
        const { find } = await shallow
          .mock(StepsStore, {
            getPrevOrNextProperties$: (dir: PrevNext) =>
              dir === 'prev'
                ? of({ hidden: true, disabled: false })
                : of({ hidden: false, disabled: false })
          })
          .render();
        const [nextBtn] = find('#next-btn');

        expect(find('#next-btn')).toHaveFoundOne();
        expect(nextBtn.nativeElement.innerHTML).toContain('common.NEXT');
      });
    });
  });

  describe('Cancel button', () => {
    it('should go to cancel step when clicked', async () => {
      const { find, get } = await shallow
        .mock(StepsStoreActions, {
          hasFormDetailChanges: () => false
        })
        .render();
      const [cancelBtn] = find('#cancel-btn');
      cancelBtn.nativeElement.click();

      expect(get(StepsStoreActions).cancelStep).toHaveBeenCalledTimes(1);
    });

    describe('button state', () => {
      it('should not be disabled', async () => {
        const { find } = await shallow.render();
        const [cancelBtn] = find('#cancel-btn');

        expect(cancelBtn.componentInstance.disabled).toBeFalsy();
      });

      it('should be disabled', async () => {
        const { find } = await shallow
          .mock(StepsStore, {
            getPrevOrNextProperties$: () => of({ hidden: false, disabled: true })
          })
          .render();
        const [cancelBtn] = find('#cancel-btn');

        expect(cancelBtn.componentInstance.disabled).toBeTruthy();
      });

      it('should be hidden', async () => {
        const { find } = await shallow
          .mock(StepsStore, {
            getPrevOrNextProperties$: (dir: PrevNext) =>
              dir === 'cancel'
                ? of({ hidden: true, disabled: false })
                : of({ hidden: false, disabled: false })
          })
          .render();
        const [nextBtn] = find('#next-btn');

        expect(find('#next-btn')).toHaveFoundOne();
        expect(nextBtn.nativeElement.innerHTML).toContain('common.NEXT');
      });
    });

    describe('Confirm Cancel modal', () => {
      it('should display confirm cancel modal when cancel is hit and changes are made', async () => {
        const { find, fixture, get } = await shallow.render();
        find('#cancel-btn').nativeElement.click();
        fixture.detectChanges();

        expect(find('close-confirm')).toHaveFound(1);
        expect(get(StepsStoreActions).cancelStep).toHaveBeenCalledTimes(0);
      });

      it('should close modal and cancel step when confirming cancel', async () => {
        const { find, fixture, get } = await shallow.render();
        find('#cancel-btn').nativeElement.click();
        fixture.detectChanges();

        expect(find('close-confirm')).toHaveFound(1);

        find('close-confirm #confirm-button').nativeElement.click();
        fixture.detectChanges();

        expect(find('close-confirm')).toHaveFound(0);
        expect(get(StepsStoreActions).cancelStep).toHaveBeenCalledTimes(1);
      });

      it('should not display confirm cancel modal when cancel is hit and changes are made', async () => {
        const { find, get, fixture } = await shallow
          .mock(StepsStoreActions, {
            hasFormDetailChanges: () => false
          })
          .render();
        find('#cancel-btn').nativeElement.click();
        fixture.detectChanges();

        expect(find('close-confirm')).toHaveFound(0);
        expect(get(StepsStoreActions).cancelStep).toHaveBeenCalledTimes(1);
      });
    });
  });
});
