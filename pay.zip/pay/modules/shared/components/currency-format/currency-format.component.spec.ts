import { CurrencyPipe } from '@angular/common';
import { of } from 'rxjs';
import { Shallow } from 'shallow-render';

import { LanguageService } from '@myadp/common';

import { PrivacyModeStore } from '../../../privacy-mode-shared/store/privacy-mode.store';
import { ValueFormatterService } from '../../../shared/services/value-formatter.service';
import { SharedModule } from '../../shared.module';
import { CurrencyFormatComponent } from './currency-format.component';

describe('CurrencyFormatComponent', () => {
  let shallow: Shallow<CurrencyFormatComponent>;

  beforeEach(() => {
    shallow = new Shallow(CurrencyFormatComponent, SharedModule)
      .provide(CurrencyPipe)
      .provide(LanguageService)
      .provide(ValueFormatterService)
      .mock(PrivacyModeStore, {
        showMaskedValue$: of(false)
      })
      .dontMock(CurrencyPipe)
      .dontMock(ValueFormatterService);
  });

  it('should display formatted currency when the value is valid', async () => {
    const money: number = 1313.37;
    const { element } = await shallow.render({
      bind: {
        value: { amountValue: money, currencyCode: 'USD' }
      }
    });

    expect(element.nativeElement.innerText).toEqual('$1,313.37');
    expect(element.attributes['aria-label']).toEqual('$1313.37');
  });

  it('should display the currency formatted', async () => {
    const money: number = 13.37223;
    const { element } = await shallow.render({
      bind: {
        value: { amountValue: money, currencyCode: 'USD' },
        digitsInfo: '1.2-4'
      }
    });

    expect(element.nativeElement.innerText).toEqual('$13.3722');
    expect(element.attributes['aria-label']).toEqual('$13.3722');
  });

  it('should display two dashes when the given content is null', async () => {
    const { element } = await shallow.render({
      bind: {
        value: null
      }
    });

    expect(element.nativeElement.innerText).toEqual('--');
    expect(element.attributes['aria-label']).toEqual('--');
  });

  it('should display two dashes when the given content is undefined', async () => {
    const { element } = await shallow.render({
      bind: {
        value: undefined
      }
    });

    expect(element.nativeElement.innerText).toEqual('--');
    expect(element.attributes['aria-label']).toEqual('--');
  });

  describe('Privacy Mode', () => {
    it('should display obfuscated value when privacy mode is enabled', async () => {
      const { element } = await shallow
        .mock(PrivacyModeStore, {
          showMaskedValue$: of(true)
        })
        .render({
          bind: {
            value: { amountValue: 13.37, currencyCode: 'USD' }
          }
        });

      expect(element.nativeElement.innerText).toEqual('$X,XXX.XX');
      expect(element.attributes['aria-label']).toEqual('$XXXX.XX');
    });
  });

  describe('Disable privacy mode', () => {
    it('should mask values by default', async () => {
      const { element } = await shallow
        .mock(PrivacyModeStore, {
          showMaskedValue$: of(true)
        })
        .render({
          bind: {
            value: { amountValue: 13.37, currencyCode: 'USD' }
          }
        });

      expect(element.nativeElement.innerText).toEqual('$X,XXX.XX');
      expect(element.attributes['aria-label']).toEqual('$XXXX.XX');
    });

    it('should not mask values if mask input is false', async () => {
      const { element } = await shallow
        .mock(PrivacyModeStore, {
          showMaskedValue$: of(true)
        })
        .render({
          bind: {
            enablePrivacy: false,
            value: { amountValue: 1313.37, currencyCode: 'USD' }
          }
        });

      expect(element.nativeElement.innerText).toEqual('$1,313.37');
      expect(element.attributes['aria-label']).toEqual('$1313.37');
    });
  });

  describe('Downgraded usage', () => {
    it('should normalize values', async () => {
      const money: number = 13.37;
      const { element } = await shallow.render({
        bind: {
          value: { amount: money, currencyCode: 'USD' }
        }
      });

      expect(element.nativeElement.innerText).toEqual(`$${money}`);
    });
  });

  describe('Rate Value usage', () => {
    it('should normalize values', async () => {
      const money: number = 13.37;
      const { element } = await shallow.render({
        bind: {
          value: { rateValue: money, currencyCode: 'USD' }
        }
      });

      expect(element.nativeElement.innerText).toEqual(`$${money}`);
    });
  });

});
