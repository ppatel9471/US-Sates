import { Component, EventEmitter, Input, Output } from '@angular/core';
import { OCRData } from '../ocr-trigger-button/ocr-trigger-button.component';
import { OCR_CONSTANTS } from '../../config/ocr-constants';
import { NativeOCRService, ObjectHelperService as objHlpr } from '@myadp/common';

@Component({
  selector: 'pay-ocr-confirmation-step',
  styleUrls: ['ocr-confirmation-step.component.scss'],
  templateUrl: 'ocr-confirmation-step.component.html'
})
export class OCRConfirmationStepComponent {
  @Input('ocrData')
  set ocrData(ocrData: OCRData) {
    this.accountInfo = { ...ocrData };
  }

  @Output() confirmClick = new EventEmitter<OCRData>();
  @Output() cancelClick = new EventEmitter<void>();
  @Output() captureFailed = new EventEmitter<void>();

  accountInfo: OCRData;
  isProcessing = false;

  constructor(private nativeOCRService: NativeOCRService) {}

  handleConfirmClick() {
    this.confirmClick.emit(this.accountInfo);
  }

  handleCancelClick() {
    this.cancelClick.emit();
  }

  handleRetakeClick() {
    this.isProcessing = true;
    this.nativeOCRService
      .getBankAccountInformation()
      .then(data => {
        this.ocrData = data.result;
        this.isProcessing = false;
      })
      .catch(err => {
        if (objHlpr.get(err, 'status.code') !== OCR_CONSTANTS.CAMERA_CANCELLED) {
          this.captureFailed.emit();
        }
        this.isProcessing = false;
      });
  }
}
