import { CaIntroComponent } from './steps/intro/ca-intro.component';
import { CaExemptionComponent } from './steps/exemption/ca-exemption.component';
import { CaMaritalStatusComponent } from './steps/marital-status/ca-marital-status.component';
import { CaAdditionalWithholdingComponent } from './steps/additional-withholding/ca-additional-withholding.component';
import { CaAdditionalAllowancesComponent } from './steps/additional-allowances/ca-additional-allowances.component';

export { CaStepNavigationService } from './services/ca-step-navigation.service';
export { CaTWChangeEventService } from './services/ca-tw-change-event.service';
export { CaSummaryMetaDataService } from './services/ca-summary-meta-data.service';

export const CA_COMPONENTS = [
  CaIntroComponent,
  CaExemptionComponent,
  CaMaritalStatusComponent,
  CaAdditionalAllowancesComponent,
  CaAdditionalWithholdingComponent
];

export { CASTEP_COMPONENT } from './models/steps-component.model';

export { CaAttachmentCodes } from './models/ca-tw-change-event';
