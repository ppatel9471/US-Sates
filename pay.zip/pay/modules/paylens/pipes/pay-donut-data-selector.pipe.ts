import { Pipe, PipeTransform } from '@angular/core';
import { DonutData } from '@synerg/components/donut';

import { LanguageService } from '@myadp/common';
import { Amount } from '@myadp/dto';

import { PayStatementsUI } from '../../pay-statements-shared/models/pay-statement-ui';
import {
  ValueFormatterService,
  ValueFormatterType
} from '../../shared/services/value-formatter.service';

@Pipe({ name: 'payDonutDataSelector', pure: true })
export class PayDonutDataSelectorPipe implements PipeTransform {
  constructor(
    private languageService: LanguageService,
    private valueFormatterService: ValueFormatterService
  ) {}

  public transform(
    payDonutItems: PayStatementsUI.PayDonutItem[],
    showMaskedAmount: boolean = false
  ): DonutData {
    return payDonutItems?.map((donutItem: PayStatementsUI.PayDonutItem) => {
      const amount = donutItem?.amount;
      const value = donutItem?.value;

      return {
        key: this.languageService.get(donutItem.key),
        formatted: showMaskedAmount
          ? this.getMaskedAmount(amount)
          : this.valueFormatterService.format(amount || {}, ValueFormatterType.Currency),
        value: value,
        color: donutItem.color
      };
    });
  }

  private getMaskedAmount(amount: Amount): string {
    const formattedMaskedAmount: string = this.valueFormatterService.format(
      { amountValue: '1111.11', currencyCode: amount?.currencyCode },
      ValueFormatterType.Currency
    );
    return formattedMaskedAmount.replace(/[0-9]/g, 'X');
  }
}
