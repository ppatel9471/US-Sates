import { find, set } from 'lodash';
import { Mock } from 'ts-mockery';

import { DirectDepositTasksDetails } from '@myadp/dto';
import { NOTIFICATION_CODE_TYPES, STATUS_CODE } from '@myadp/thingstodo-shared';

import { DirectDepositDetails } from './direct-deposit-details';
import { DIRECT_DEPOSIT_EVENT_TYPE } from './direct-deposit-tasks-details.model';

describe('Direct Deposit Details', () => {
  const mockResponse: DirectDepositTasksDetails = {
    currentData: {
      // new schema
      payDistributions: [
        {
          payrollGroupCode: {
            codeValue: '21E'
          },
          distributionInstructions: [
            // change account
            {
              itemID: '101',
              paymentMethodCode: {
                codeValue: 'DD',
                longName: 'Direct Deposit'
              },
              depositAccount: {
                financialParty: {
                  routingTransitID: {
                    idValue: '122105278'
                  }
                },
                financialAccount: {
                  accountName: 'Savings',
                  accountNumber: '0000000001',
                  typeCode: {
                    codeValue: '101',
                    longName: 'DED1'
                  },
                  currencyCode: 'USD'
                }
              },
              distributionAmount: {
                amountValue: 2,
                currencyCode: 'USD'
              },
              remainingBalanceIndicator: false
            },
            // delete account
            {
              itemID: 'DD2',
              paymentMethodCode: {
                codeValue: 'DD',
                longName: 'Direct Deposit'
              },
              depositAccount: {
                financialParty: {
                  routingTransitID: {
                    idValue: '122105278'
                  }
                },
                financialAccount: {
                  accountName: 'Checking 1',
                  accountNumber: '0000000003',
                  typeCode: {
                    codeValue: 'DD2',
                    longName: 'CHECKING'
                  },
                  currencyCode: 'USD'
                }
              },
              distributionAmount: {
                amountValue: 12,
                currencyCode: 'USD'
              },
              remainingBalanceIndicator: false
            }
          ]
        }
      ]
    },
    pendingData: {
      // old schema
      payDistributions: [
        {
          distributionInstructions: [
            // change account
            {
              precedenceCode: {
                codeValue: '101',
                longName: 'DED1'
              },
              depositAccount: {
                BBAN: '0000000001',
                financialParty: {
                  routingTransitID: {
                    schemeCode: {
                      codeValue: '122105278'
                    }
                  }
                }
              },
              distributionAmount: {
                amountValue: 11,
                currencyCode: 'USD'
              },
              remainingBalanceIndicator: false,
              itemID: '101'
            },
            // add account
            {
              precedenceCode: {
                codeValue: 'DD4',
                shortName: 'Grocer',
                longName: 'Grocery Fund'
              },
              depositAccount: {
                BBAN: '0000000003',
                financialParty: {
                  routingTransitID: {
                    schemeCode: {
                      codeValue: '122105278'
                    }
                  }
                }
              },
              distributionAmount: {
                amountValue: 99,
                currencyCode: 'USD'
              },
              remainingBalanceIndicator: false
            }
          ]
        }
      ]
    },
    history: [
      {
        actionDate: 123345,
        actionTaken: STATUS_CODE.approval,
        assignedTo: 'me',
        comments: 'my comment',
        processStepID: 9876,
      }
    ]
  };
  const directDepositDetails = new DirectDepositDetails(mockResponse, NOTIFICATION_CODE_TYPES.TASK);

  it('should transform task structure', () => {
    expect(directDepositDetails.notificationCodeType).toEqual(NOTIFICATION_CODE_TYPES.TASK);
    expect(directDepositDetails.statusCode).toEqual('Approved');
    expect(directDepositDetails.comments.latestComment).toEqual('my comment');
    expect(directDepositDetails.comments.requesterComment).toBe(null);
    expect(directDepositDetails.payrollGroupCode.codeValue).toEqual('21E');
  });

  it('should transform account 101 (change account)', () => {
    const account = find(directDepositDetails.comparisonData, {
      accountType: {
        codeValue: '101',
        longName: 'DED1'
      }
    });
    expect(account.type).toBe(DIRECT_DEPOSIT_EVENT_TYPE.CHANGE);
    expect(account.comparisonData).toEqual({
      distributionAmount: {
        amountValue: 11,
        currencyCode: 'USD'
      },
      totalAccount: 2
    });
  });

  it('should transform account DD2 (delete account)', () => {
    const account = find(directDepositDetails.comparisonData, {
      accountType: {
        codeValue: 'DD2',
        longName: 'CHECKING'
      }
    });
    expect(account.type).toBe(DIRECT_DEPOSIT_EVENT_TYPE.DELETE);
    expect(account.pendingData).toBeUndefined();
    expect(account.currentData).toEqual({
      routingNumber: '122105278',
      accountNumber: '0000000003',
      accountType: {
        codeValue: 'DD2',
        longName: 'CHECKING'
      },
      distributionAmount: {
        amountValue: 12,
        currencyCode: 'USD'
      },
      remainingBalanceIndicator: false,
      distributionPercentage: undefined,
      totalAccount: 2,
      isPayCard: false
    });
  });

  it('should transform account DD4 (add account)', () => {
    const account = find(directDepositDetails.comparisonData, {
      accountType: {
        codeValue: 'DD4',
        shortName: 'Grocer',
        longName: 'Grocery Fund'
      }
    });
    expect(account.type).toBe(DIRECT_DEPOSIT_EVENT_TYPE.ADD);
    expect(account.currentData).toBeUndefined();
    expect(account.pendingData).toEqual({
      routingNumber: '122105278',
      accountNumber: '0000000003',
      accountType: {
        codeValue: 'DD4',
        shortName: 'Grocer',
        longName: 'Grocery Fund'
      },
      distributionAmount: {
        amountValue: 99,
        currencyCode: 'USD'
      },
      remainingBalanceIndicator: false,
      totalAccount: 2,
      isPayCard: false
    });
  });

  it('should transform notification data structure', () => {
    const mockNotificationResponse: DirectDepositTasksDetails = {
      oldData: mockResponse.currentData,
      newData: mockResponse.pendingData
    };
    const directDepositDetailsNotification = new DirectDepositDetails(
      mockNotificationResponse,
      NOTIFICATION_CODE_TYPES.NOTIFICATION
    );

    expect(directDepositDetailsNotification.currentData).toEqual(
      mockNotificationResponse.oldData.payDistributions[0].distributionInstructions
    );

    expect(directDepositDetailsNotification.pendingData).toEqual(
      mockNotificationResponse.newData.payDistributions[0].distributionInstructions
    );
  });

  it('should transform account 101 with percentage using new schema (change account)', () => {
    const currentAccount = mockResponse.currentData.payDistributions[0].distributionInstructions[0];
    set(currentAccount, 'distributionAmount.amountValue', 0);
    set(currentAccount, 'distributionPercentage', null);

    mockResponse.pendingData.payDistributions[0].distributionInstructions[0] = {
      itemID: '101',
      paymentMethodCode: {
        codeValue: 'DD',
        longName: 'Direct Deposit'
      },
      depositAccount: {
        financialParty: {
          routingTransitID: {
            idValue: '122105278'
          }
        },
        financialAccount: {
          accountName: null,
          accountNumber: '0000000001',
          typeCode: {
            codeValue: '101',
            longName: 'DED1'
          },
          currencyCode: 'USD'
        }
      },
      distributionPercentage: 55,
      distributionAmount: {
        amountValue: 0,
        currencyCode: 'USD'
      },
      remainingBalanceIndicator: false
    };

    const directDepositPercentDetails = new DirectDepositDetails(
      mockResponse,
      NOTIFICATION_CODE_TYPES.TASK
    );
    const account = find(directDepositPercentDetails.comparisonData, {
      accountType: {
        codeValue: '101',
        longName: 'DED1'
      }
    });
    expect(account.type).toBe(DIRECT_DEPOSIT_EVENT_TYPE.CHANGE);
    expect(account.comparisonData).toEqual({
      distributionPercentage: 55,
      totalAccount: 2
    });
  });

  it('should transform a Wisely account', () => {
    const directDepositPercentDetails = new DirectDepositDetails(
      {
        currentData: {
          payDistributions: [
            {
              payrollGroupCode: {
                codeValue: '21E'
              },
              distributionInstructions: [
                // change account
                {
                  itemID: '101',
                  paymentMethodCode: {
                    codeValue: 'DD',
                    longName: 'Direct Deposit'
                  },
                  depositAccount: {
                    financialParty: {
                      routingTransitID: {
                        idValue: '122105278'
                      }
                    },
                    financialAccount: {
                      accountName: 'Wisely',
                      accountNumber: '0000000001',
                      typeCode: {
                        codeValue: '101',
                        longName: 'CHK1'
                      },
                      currencyCode: 'USD'
                    }
                  },
                  distributionAmount: {
                    amountValue: 45,
                    currencyCode: 'USD'
                  },
                  remainingBalanceIndicator: false
                }
              ]
            }
          ]
        },
        pendingData: {
          payDistributions: [
            {
              payrollGroupCode: {
                codeValue: '21E'
              },
              distributionInstructions: [
                {
                  itemID: '101',
                  paymentMethodCode: {
                    codeValue: 'DD',
                    longName: 'Direct Deposit'
                  },
                  depositAccount: {
                    financialParty: {
                      routingTransitID: {
                        idValue: '122105278'
                      }
                    },
                    financialAccount: {
                      accountName: 'Wisely',
                      accountNumber: '0000000001',
                      typeCode: {
                        codeValue: '101',
                        longName: 'CHK1'
                      },
                      currencyCode: 'USD'
                    }
                  },
                  distributionPercentage: 5,
                  distributionAmount: {
                    amountValue: null,
                    currencyCode: 'USD'
                  },
                  remainingBalanceIndicator: false
                }
              ]
            }
          ]
        },
        history: [
          {
            actionDate: 123345,
            actionTaken: STATUS_CODE.approval,
            assignedTo: 'me',
            comments: 'my comment',
            processStepID: 9876
          }
        ]
      },
      NOTIFICATION_CODE_TYPES.TASK
    );
    const account = find(directDepositPercentDetails.comparisonData, {
      accountType: {
        codeValue: '101',
        longName: 'CHK1'
      }
    });

    expect(account.currentData.isPayCard).toBe(true);
    expect(account.pendingData.isPayCard).toBe(true);
    expect(account.type).toBe(DIRECT_DEPOSIT_EVENT_TYPE.CHANGE);
    expect(account.currentData).toHaveProperty('distributionAmount', {
      amountValue: 45,
      currencyCode: 'USD'
    });
    expect(account.pendingData).toHaveProperty('distributionPercentage', 5);
  });

  it('should return history object from taskDetails if it exists', () => {
    expect(directDepositDetails.pendingEventsHistory).toEqual(mockResponse.history);
  });

  it('should get the history from pendingEvents if the history in taskDetails does not exist', () => {
    Mock.extend(mockResponse).with({
      history: null,
      pendingEvents: [
        {
          history: [
            {
              actionDate: 56789,
              actionTaken: 'submitted',
              assignedTo: 'assigned',
              comments: 'comment',
              processStepID: 4321
            }
          ]
        }
      ]
    });
    const mockDetails = new DirectDepositDetails(mockResponse, NOTIFICATION_CODE_TYPES.TASK);
    expect(mockDetails.pendingEventsHistory).toEqual(mockResponse.pendingEvents[0].history);
  });
});
