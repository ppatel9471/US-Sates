import { Component, Input } from '@angular/core';
import { ControlContainer, NgForm } from '@angular/forms';

@Component({
  selector: 'twm-currency-input',
  templateUrl: './twm-currency-input.component.html',
  viewProviders: [{ provide: ControlContainer, useExisting: NgForm }],
  styleUrls: ['./twm-currency-input.component.scss']
})
export class TwmCurrencyInputComponent {
  @Input() name: string;
  @Input() model: Record<string, string>;
  @Input() disabled?: boolean = false;
  @Input() required?: boolean = false;
}
