import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { from, Observable } from 'rxjs';

import {
  ROLE,
  SFFO,
  UserIdentityService,
  UserProfileService,
  WorkerLiteRequestConfig,
  WorkerLiteService,
  WorkerService
} from '@myadp/common';
import { CodeListItem, Worker, PayrollWorker } from '@myadp/dto';

import { WorkerInfoStoreSlice } from '../modules/worker-info-shared/models/worker-info-state.model';

type CombinedWorkerType = Worker & PayrollWorker;

const lookUp = {
  [WorkerInfoStoreSlice.WORKER_SSN]: 'governmentIDs',
  [WorkerInfoStoreSlice.WORKER_BIRTHDATE]: 'birthDate'
};
@Injectable({
  providedIn: 'root'
})
export class PayrollWorkerProfileService {
  constructor(
    private userProfileService: UserProfileService,
    private httpClient: HttpClient,
    private userIdentityService: UserIdentityService,
    private workerService: WorkerService,
    private workerLiteService: WorkerLiteService
  ) {}

  public getUnmaskedDataFromWorker$(type: string): Observable<Worker> {
    const selector = lookUp[type];
    if (this.userProfileService.hasWorkerProfile()) {
      const selectUrl: string = this.userProfileService.isRun()
        ? 'person'
        : `workers/person/${selector}`;
      return from(
        this.userIdentityService.getAoid().then<Worker>((aoid) =>
          this.workerLiteService.getWorkerLite(aoid, selectUrl, {
            masked: false,
            roleCode: ROLE.EMPLOYEE
          } as WorkerLiteRequestConfig)
        )
      );
    } else {
      return from(this.getPayrollWorkerProfile(`person/${lookUp[type]}`, true));
    }
  }

  public async getWorkAssignmentsFromWorker(): Promise<Worker | PayrollWorker> {
    if (this.userProfileService.hasWorkerProfile()) {
      const aoid = await this.userIdentityService.getAoid();
      const worker: Worker = await this.workerService.getWorker(aoid, false);
      return worker;
    } else {
      return this.getPayrollWorkerProfile();
    }
  }

  public async getWorkedInState(): Promise<string> {
    const worker: CombinedWorkerType = await this.getWorkAssignmentsFromWorker();

    const state: CodeListItem =
      (worker as Worker)?.workAssignments?.[0]?.assignedWorkLocations?.[0]?.address?.countrySubdivisionLevel1 ??
      (worker as PayrollWorker)?.workAssignment?.assignedWorkLocations?.[0]?.address?.countrySubdivisionLevel1;

    return state?.codeValue || state?.longName;
  }

  public async getWorkerDatesFromWorker(): Promise<Worker> {
    if (this.userProfileService.hasWorkerProfile()) {
      const aoid = await this.userIdentityService.getAoid();
      const result: Worker = await this.workerService.getWorker(aoid, false);
      return result;
    } else {
      return this.getPayrollWorkerProfile('workerDates');
    }
  }

  public async getWorker(bustCache: boolean = false): Promise<Worker> {
    if (this.userProfileService.hasWorkerProfile()) {
      const aoid = await this.userIdentityService.getAoid();
      const res = await this.workerService.getWfWorker(aoid, false, bustCache, false);
      return res?.current;
    } else {
      return this.getPayrollWorkerProfile();
    }
  }

  public async getPayrollWorkerProfile(selector?: string, unmask: boolean = false): Promise<Worker> {
    let uri = this.userProfileService.getLinkHref({
      sffo: SFFO.payrollManagement.payrollWorkerProfileManagement.workerProfileManagement
        .workerProfile_read.sffo
    });

    if (uri) {
      uri = selector ? `${uri}?$select=${selector}` : uri;
      const headers = selector && unmask
        ? new HttpHeaders().set('Accept', 'application/json; masked=false')
        : new HttpHeaders().set('Accept', 'application/json');
      const res = await this.httpClient.get<{workerProfiles: PayrollWorker}>(uri, { headers: headers }).toPromise();
      return res?.workerProfiles?.[0];
    } else {
      return Promise.reject(null);
    }
  }
}
