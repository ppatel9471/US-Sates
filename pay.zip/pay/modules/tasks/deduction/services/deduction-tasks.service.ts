import { Injectable } from '@angular/core';
import { get } from 'lodash';
import {
  MessageCenterNotificationDto,
  Notification,
  NOTIFICATION_CODE_TYPES,
  NotificationCodeType
} from '@myadp/thingstodo-shared';
import { DeductionsDTO } from '@myadp/dto';

import { DeductionDetails } from '../models/deduction-details';
import { PayTasksService } from '../../shared/services/pay-tasks.service';

@Injectable({
  providedIn: 'root'
})
export class DeductionTaskService {
  constructor(private payTasksService: PayTasksService) {}

  public async getDeductionDetails(task: Notification): Promise<DeductionDetails> {
    return task.notificationType.code === NOTIFICATION_CODE_TYPES.TASK
      ? this.getDeductionTaskDetails(task)
      : this.getDeductionNotificationDetails(task);
  }

  private async getDeductionTaskDetails(task: Notification): Promise<DeductionDetails> {
    const taskData = await this.payTasksService.getTaskData(task.uri);
    const directDepositTasks = <DeductionsDTO.DeductionTasksDetails>(
      await this.payTasksService.getTaskDetail(this.formatTaskUrl(taskData.notification))
    );
    return this.processDeductionTasks(directDepositTasks, NOTIFICATION_CODE_TYPES.TASK);
  }

  private async getDeductionNotificationDetails(task: Notification): Promise<DeductionDetails> {
    const directDepositTasks = <DeductionsDTO.DeductionTasksDetails>(
      await this.payTasksService.getTaskDetail(this.formatNotificationUrl(task))
    );
    return this.processDeductionTasks(directDepositTasks, NOTIFICATION_CODE_TYPES.NOTIFICATION);
  }

  private processDeductionTasks(
    directDepositTasks: DeductionsDTO.DeductionTasksDetails,
    notificationCodeType: NotificationCodeType
  ): DeductionDetails {
    return new DeductionDetails(directDepositTasks, notificationCodeType);
  }

  private formatTaskUrl(task: MessageCenterNotificationDto): string {
    const aoid = get<string>(task, 'relatedAssociateRef.associateOID');
    return `/wf/payroll/v1/workers/${aoid}/worker-general-deduction-instructions?taskId=${this.payTasksService.getTaskId(
      task
    )}`;
  }

  private formatNotificationUrl(task: Notification): string {
    const aoid = task.relatedAssociateRef.aoid;
    return `/wf/payroll/v1/workers/${aoid}/worker-general-deduction-instructions?notificationId=${task.notificationId}`;
  }
}
