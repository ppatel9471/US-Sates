import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { DirectDepositSandboxWrapperComponent } from './direct-deposit-sandbox-wrapper.component';

describe('DirectDepositSandboxWrapperComponent', () => {

  let fixture: ComponentFixture<DirectDepositSandboxWrapperComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [DirectDepositSandboxWrapperComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();

    fixture = TestBed.createComponent(DirectDepositSandboxWrapperComponent);
    fixture.detectChanges();
  });

  describe('DOM', () => {
    it('should have upgraded direct deposit sandbox', () => {
      expect(fixture.nativeElement.querySelector('pay-direct-deposit-sandbox')).toBeTruthy();
    });
  });
});
