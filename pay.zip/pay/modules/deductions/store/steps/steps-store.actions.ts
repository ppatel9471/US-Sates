import { ComponentFactoryResolver, Injectable, ViewContainerRef } from '@angular/core';
import { take } from 'rxjs/operators';

import { Worker } from '@myadp/dto';

import { PayDeductionsUI } from '../../../pay-deductions-shared/models/pay-deductions-ui';
import { WorkerInfoStoreActions } from '../../../worker-info-shared/store/worker-info-store.actions';
import { WorkerInfoStore } from '../../../worker-info-shared/store/worker-info.store';
import { StepNavigationActions, STEPS } from '../../models/steps-navigation-helper.model';
import { DeductionsStoreActions } from '../deductions-store.actions';
import { DeductionsStore } from '../deductions.store';
import {
  navigationFlowStartingFromList,
  StepNavigation
} from './steps-navigation-utilities/steps-navigation-helper';
import { StepsStore } from './steps.store';

// TODO: can be shared with DD
export type PrevNext = 'prev' | 'next' | 'cancel';

@Injectable({
  providedIn: 'root'
})
export class StepsStoreActions {
  public stepContainer: ViewContainerRef;
  public rootStep: StepNavigation;
  public currentStep: StepNavigation;

  constructor(
    private stepsStore: StepsStore,
    private resolver: ComponentFactoryResolver,
    private deductionsStore: DeductionsStore,
    private workerInfoStore: WorkerInfoStore,
    private deductionsStoreActions: DeductionsStoreActions,
    private workerInfoStoreActions: WorkerInfoStoreActions
  ) {}

  public init(stepContainer: ViewContainerRef) {
    this.workerInfoStoreActions.getWorker();
    this.stepContainer = stepContainer;

    this.rootStep = navigationFlowStartingFromList;
    this.currentStep = navigationFlowStartingFromList;

    if (this.deductionsStore.hasDeductions) {
      this.loadListStep();
    } else {
      this.loadDeductionDetailsStep();
    }
  }

  public async getWorker(): Promise<Worker> {
    return await this.workerInfoStore.worker$().pipe(take(1)).toPromise();
  }

  public renderStep() {
    this.stepContainer.clear();
    this.updateCurrentStepStore();

    const factory = this.resolver.resolveComponentFactory<any>(this.currentStep.component);
    const componentRef = this.stepContainer.createComponent(factory);
    componentRef.instance.step = this.currentStep.current;
  }

  public loadEditStep(deduction: PayDeductionsUI.Deduction) {
    this.deductionsStoreActions.resetFormData();
    this.deductionsStoreActions.updateFormData(deduction?.pendingData ?? deduction?.currentData);
    this.deductionsStoreActions.updateChangedDeduction(deduction);

    this.nextStep('edit');
  }

  public cancelStep() {
    this.deductionsStoreActions.resetFormData();

    if (this.currentStep.name === STEPS.REVIEW) {
      this.deductionsStoreActions.revertAllChanges();
    }

    this.currentStep = this.currentStep.cancel() as StepNavigation;

    this.renderStep();
  }

  public prevStep() {
    this.currentStep = this.currentStep.prev() as StepNavigation;

    if (this.currentStep.name === STEPS.LIST) {
      this.deductionsStoreActions.resetFormData();
    }

    this.renderStep();
  }

  public nextStep(stepAction?: StepNavigationActions) {
    if (this.currentStep.name === STEPS.DEDUCTION_DETAILS) {
      this.deductionsStoreActions.updateChangedDeduction(this.deductionsStore.formData);
    }

    this.currentStep = this.currentStep.next(stepAction) as StepNavigation;

    this.renderStep();
  }

  public resetCurrentStep() {
    this.stepsStore.update('steps', {
      data: null
    });

    this.deductionsStoreActions.resetFormData();
    this.currentStep = this.rootStep;
  }

  public disablePrev(value: boolean) {
    this.disable('prev', value);
  }

  public disableNext(value: boolean) {
    this.disable('next', value);
  }

  public hidePrev(value: boolean) {
    this.hidden('prev', value);
  }

  public openSlidein() {
    this.stepsStore.isSlideinOpen$.next(true);
  }

  public closeSlidein() {
    this.deductionsStoreActions.revertAllChanges();
    this.deductionsStoreActions.resetFormData();
    this.stepsStore.isSlideinOpen$.next(false);
  }

  public cancelPendingRequest(deduction: PayDeductionsUI.Deduction) {
    this.deductionsStoreActions.recallDeduction(deduction);
  }

  public submit(): Promise<void> {
    return this.deductionsStoreActions.postDeduction(
      this.deductionsStore.changedDeductionDetails,
      this.deductionsStore.changes?.changeType
    );
  }

  public deleteDeduction() {
    const nextDisabledState = this.currentStep?.stepProps?.next?.disabled;
    const changedDeductionDetails = this.deductionsStore.changedDeductionDetails;

    // disable prev / next buttons while attempting delete
    this.disablePrevNext(true, true);

    this.deductionsStoreActions
      .deleteDeduction(changedDeductionDetails)
      .then(() =>
        this.deductionsStore.hasUnsavedAdd ? this.returnToListStep() : this.skipToDoneStep()
      )
      .catch(() => undefined)
      .finally(() => this.disablePrevNext(false, nextDisabledState));
  }

  public hasFormDetailChanges(): boolean {
    if (this.currentStep?.name === STEPS.DONE) {
      return false;
    }

    return !!this.deductionsStore.formData;
  }

  public returnToListStep() {
    this.currentStep = this.currentStep.next() as StepNavigation;
    this.cancelStep();
  }

  public skipToDoneStep() {
    this.currentStep = this.currentStep.next().next() as StepNavigation; // skips to Done step

    this.renderStep();
  }

  public loadListStep() {
    this.renderStep();
  }

  private loadDeductionDetailsStep() {
    this.nextStep('add');
    this.renderStep();
  }

  private hidden(dir: PrevNext, hidden: boolean) {
    this.stepsStore.update('steps', {
      data: {
        [dir]: {
          hidden
        }
      }
    });
  }

  private disablePrevNext(prev: boolean, next: boolean) {
    this.disablePrev(prev);
    this.disableNext(next);
  }

  private disable(dir: PrevNext, value: boolean) {
    this.stepsStore.update('steps', {
      data: {
        [dir]: { disabled: value }
      }
    });
  }

  private updateCurrentStepStore() {
    const currentValue = this.stepsStore.stepsStoreData;

    const updateStoreValue = {
      ...currentValue,
      step: {
        name: this.currentStep.name,
        current: this.currentStep.current,
        outOf: this.currentStep.outOf
      },
      ...this.currentStep.stepProps
    };

    this.stepsStore.update('steps', {
      data: updateStoreValue
    });
  }
}
