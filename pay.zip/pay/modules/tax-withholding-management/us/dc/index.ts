import { DcIntroComponent } from './steps/intro/dc-intro.component';
import { DcMaritalStatusComponent } from './steps/marital-status/dc-marital-status.component';
import { DcExemptionComponent } from './steps/exemption/dc-exemption.component';
import { DcAllowancesComponent } from './steps/allowances/dc-allowances.component';

export { DcStepNavigationService } from './services/dc-step-navigation.service';
export { DcTWChangeEventService } from './services/dc-tw-change-event.service';
export { DcSummaryMetaDataService } from './services/dc-summary-meta-data.service';

export const DC_COMPONENTS = [
  DcIntroComponent,
  DcMaritalStatusComponent,
  DcExemptionComponent,
  DcAllowancesComponent
];

export { DCSTEP_COMPONENT } from './models/steps-component.model';

export { DcAttachmentCodes } from './models/dc-tw-change-event';
