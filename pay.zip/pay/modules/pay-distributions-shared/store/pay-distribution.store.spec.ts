import { TestBed } from '@angular/core/testing';

import {
  DistributionOptions,
  PayDistributionsStoreSlice,
  PayDistributionsUI
} from '../models/pay-distributions-ui';
import { PayDistributionStore } from './pay-distribution.store';

import { COUNTRY, COUNTRY_CONFIG } from './../models/country';

const distributions: Partial<PayDistributionsUI.PayDistribution[]> = [
  {
    currentData: {
      codeValueData: {
        itemID: null,
        longName: 'Checking 1',
        shortName: null,
        accountCode: 'C1'
      },
      precedence: '1',
      accountTypeName: 'Checking 1',
      accountNumber: 'X123456P7',
      routingNumber: '021000021',
      accountName: null,
      distributionType: DistributionOptions.FLAT,
      flatAmount: { amountValue: 123, currencyCode: 'USD' }
    },
    pendingData: null,
    pendingEvent: null
  },
  {
    currentData: {
      codeValueData: {
        itemID: null,
        longName: 'Checking 2',
        shortName: null,
        accountCode: 'C2'
      },
      precedence: '2',
      accountTypeName: 'Checking 2',
      accountNumber: '123-45678',
      routingNumber: '021000021',
      accountName: null,
      distributionType: DistributionOptions.PERCENTAGE,
      percentageAmount: 25
    },
    pendingData: null,
    pendingEvent: null
  },
  {
    currentData: {
      codeValueData: {
        itemID: null,
        longName: 'Checking 3',
        shortName: null,
        accountCode: 'C3'
      },
      precedence: '3',
      accountTypeName: 'Checking 3',
      accountNumber: '1234567',
      routingNumber: '021000021',
      accountName: null,
      distributionType: DistributionOptions.REMAINING
    },
    pendingData: null,
    pendingEvent: null
  }
];

const distributionsWithWisely: Partial<PayDistributionsUI.PayDistribution[]> = [
  ...distributions,
  {
    currentData: {
      codeValueData: {
        itemID: null,
        longName: 'Checking 3',
        shortName: null,
        accountCode: 'C3'
      },
      precedence: '1',
      precedenceCode: 'WISELY DIRECT',
      accountTypeName: 'Checking 3',
      accountNumber: '1234567',
      routingNumber: '021000021',
      accountName: null,
      distributionType: DistributionOptions.REMAINING
    },
    pendingData: null,
    pendingEvent: null
  }
];

const meta: PayDistributionsUI.PayDistributionMeta = {
  maxAccounts: 4,
  minAccounts: 0,
  termsAgreementMsg: 'terms message',
  showDistributionPercentage: true,
  canValidateBankInfo: true,
  forceRemaining: {
    enabled: true,
    msg: 'force remaining balance msg'
  },
  distributionAmount: {
    min: 0
  },
  accountName: {
    enabled: true,
    maxLength: 30
  },
  accountTypeList: null,
  codeListHref:
    '/codelists/payroll/v3/payroll-instruction-management/directdepositdeductioncodevalues?$filter=paygroup eq %27foo%27',
  isEmailConfigured: false
};

describe('PayDistributionStore', () => {
  let payDistributionStore: PayDistributionStore;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [PayDistributionStore]
    });

    payDistributionStore = TestBed.inject(PayDistributionStore);
  });

  it('should create the store with an initial state and call getWorker', () => {
    expect(payDistributionStore.stateValue).toEqual({
      [PayDistributionsStoreSlice.PAY_DISTRIBUTIONS]: {
        data: {
          hasChangePermission: false,
          distributions: null,
          itemID: null
        },
        loading: false,
        error: {}
      },
      [PayDistributionsStoreSlice.PAY_DISTRIBUTIONS_META]: {
        data: {
          meta: null
        },
        loading: false,
        error: {}
      }
    });
  });

  it('should tell if there is a wisely account present in pay distributions', () => {
    payDistributionStore.update(PayDistributionsStoreSlice.PAY_DISTRIBUTIONS, {
      data: {
        distributions: distributionsWithWisely
      }
    });

    let hasWisely = payDistributionStore.hasWiselyAccount;
    expect(hasWisely).toBeTrue();

    payDistributionStore.update(PayDistributionsStoreSlice.PAY_DISTRIBUTIONS, {
      data: {
        distributions
      }
    });

    hasWisely = payDistributionStore.hasWiselyAccount;
    expect(hasWisely).toBeFalse();
  });

  describe('state slices', () => {
    it('should select itemID', async () => {
      payDistributionStore.update(PayDistributionsStoreSlice.PAY_DISTRIBUTIONS, {
        data: {
          itemID: 'foo'
        }
      });

      const itemID = payDistributionStore.itemId;
      expect(itemID).toBe('foo');
    });

    it('should select pay distributions', async (done: DoneFn) => {
      payDistributionStore.update(PayDistributionsStoreSlice.PAY_DISTRIBUTIONS, {
        data: {
          distributions
        }
      });

      const hasPayDistributions = payDistributionStore.hasPayDistributions;
      expect(hasPayDistributions).toBeTrue();

      payDistributionStore.payDistributions$.subscribe((payDistributions) => {
        expect(payDistributions).toEqual(distributions);
        done();
      });
    });

    it('should return the country assigned to the pay distributions', () => {
      payDistributionStore.update(PayDistributionsStoreSlice.PAY_DISTRIBUTIONS, {
        data: {
          country: COUNTRY_CONFIG[COUNTRY.US]
        }
      });

      expect(payDistributionStore.payDistributionCountry).toEqual(COUNTRY_CONFIG[COUNTRY.US]);
    });

    it('should return pay distributions snapshot', async () => {
      payDistributionStore.update(PayDistributionsStoreSlice.PAY_DISTRIBUTIONS, {
        data: {
          distributions
        }
      });

      expect(payDistributionStore.payDistributionsSnapshot).toEqual(distributions);
    });

    it('should select pay distributions meta', async (done: DoneFn) => {
      payDistributionStore.update(PayDistributionsStoreSlice.PAY_DISTRIBUTIONS_META, {
        data: {
          meta
        }
      });

      const hasPayDistributions = payDistributionStore.hasPayDistributions;
      expect(hasPayDistributions).toBeFalse();

      payDistributionStore.payDistributionMeta$.subscribe((payDistributionsMeta) => {
        expect(payDistributionsMeta).toEqual(meta);
        done();
      });
    });

    it('should return pay distributions meta snapshot', async () => {
      payDistributionStore.update(PayDistributionsStoreSlice.PAY_DISTRIBUTIONS_META, {
        data: {
          meta
        }
      });

      expect(payDistributionStore.payDistributionMetaSnapshot).toEqual(meta);
    });

    describe('loading', () => {
      it('should return true when the store is loading', async (done: DoneFn) => {
        payDistributionStore.update(PayDistributionsStoreSlice.PAY_DISTRIBUTIONS, {
          loading: false
        });
        payDistributionStore.update(PayDistributionsStoreSlice.PAY_DISTRIBUTIONS_META, {
          loading: true
        });

        payDistributionStore.isLoading$.subscribe((isLoading) => {
          expect(isLoading).toBe(true);
          done();
        });
      });

      it('should return false when the store is not loading', async (done: DoneFn) => {
        payDistributionStore.update(PayDistributionsStoreSlice.PAY_DISTRIBUTIONS, {
          loading: false
        });
        payDistributionStore.update(PayDistributionsStoreSlice.PAY_DISTRIBUTIONS_META, {
          loading: false
        });

        payDistributionStore.isLoading$.subscribe((isLoading) => {
          expect(isLoading).toBe(false);
          done();
        });
      });
    });

    describe('error', () => {
      it('should return false when there is no error', async (done: DoneFn) => {
        payDistributionStore.update(PayDistributionsStoreSlice.PAY_DISTRIBUTIONS, {
          error: {}
        });

        payDistributionStore.hasDistributionError$.subscribe((hasError) => {
          expect(hasError).toBe(false);
          done();
        });
      });

      it('should return true when there is an error  in pay distributions', async (done: DoneFn) => {
        payDistributionStore.update(PayDistributionsStoreSlice.PAY_DISTRIBUTIONS, {
          error: {
            distributionsError: true
          }
        });

        payDistributionStore.hasDistributionError$.subscribe((hasError) => {
          expect(hasError).toBe(true);
          done();
        });
      });

      it('should return true when there is an error in pay distributions meta', async (done: DoneFn) => {
        payDistributionStore.update(PayDistributionsStoreSlice.PAY_DISTRIBUTIONS_META, {
          error: {
            distributionsMetaError: true
          }
        });

        payDistributionStore.hasDistributionError$.subscribe((hasError) => {
          expect(hasError).toBe(true);
          done();
        });
      });
    });
  });
});
