import { Directive, ElementRef, Inject } from '@angular/core';
import { UpgradeComponent } from '@angular/upgrade/static';
import { LazyHelperService } from '@myadp/common';

@Directive({ selector: 'pay-direct-deposit-sandbox' })
export class DirectDepositSandboxUpgradeDirective extends UpgradeComponent {
  constructor(@Inject(ElementRef) elementRef: ElementRef, lazyHelperService: LazyHelperService) {
    super('payDirectDepositSandbox', elementRef, lazyHelperService.upgradeModuleAngularInjectorSync);
  }
}
