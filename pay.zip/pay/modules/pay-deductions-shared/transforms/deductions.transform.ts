import { DeductionsDTO } from '@myadp/dto';

import { WorkflowUI } from '../../shared/models/workflow-ui.model';
import { PayDeductionsUI } from '../models/pay-deductions-ui';

export function transformDeductions(res: DeductionsDTO.WfResponse): PayDeductionsUI.Deduction[] {
  return mapToDeduction(
    res?.currentData?.workerGeneralDeductionInstructions[0]?.generalDeductionInstructions,
    res?.pendingData?.workerGeneralDeductionInstructions[0]?.generalDeductionInstructions,
    res?.pendingEvents?.[0]
  );
}

function mapToDeduction(
  currentData: DeductionsDTO.GeneralDeductionInstruction[] = [],
  pendingData: DeductionsDTO.GeneralDeductionInstruction[] = null,
  pendingEvent: DeductionsDTO.PendingDeductionEvent
): PayDeductionsUI.Deduction[] {
  const currentDedDetails: PayDeductionsUI.DeductionDetails[] = currentData.map(
    (rawDeductions: DeductionsDTO.GeneralDeductionInstruction) =>
      rawDeductions
  );
  const pendingDedDetails: PayDeductionsUI.DeductionDetails[] = pendingData?.map(
    (rawDeductions: DeductionsDTO.GeneralDeductionInstruction) =>
      rawDeductions
  );

  const approver = pendingEvent?.history?.find(
    (person) => person?.actionTaken.toLowerCase() !== 'submitted'
  );
  const event: Partial<WorkflowUI.PendingEvent> = {
    approver: approver?.assignedTo ?? null
  };

  return matchDeductions(currentDedDetails, pendingDedDetails, pendingEvent, event);
}

function matchDeductions(
  currentDeds: PayDeductionsUI.DeductionDetails[],
  pendingDeds: PayDeductionsUI.DeductionDetails[],
  pendingEvent: DeductionsDTO.PendingDeductionEvent,
  event: Partial<WorkflowUI.PendingEvent>
): PayDeductionsUI.Deduction[] {
  const eventNameCode = pendingEvent?.body?.events?.[0]?.eventNameCode?.codeValue;
  const eventType = eventNameCode?.slice(eventNameCode?.indexOf('.') + 1, eventNameCode?.length); // 'start', 'change', or 'stop'
  const changeType: WorkflowUI.ChangeType = {
    start: 'add',
    change: 'edit',
    stop: 'delete'
  }?.[eventType];

  const pendingWfDetails: Partial<PayDeductionsUI.DeductionDetails> = getWorkflowDetails(pendingEvent);
  const pendingEventInfo: WorkflowUI.PendingEvent = { ...event, changeType };

  if (!changeType || changeType !== 'add') {
    return currentDeds?.map((deduction: PayDeductionsUI.DeductionDetails) =>
      deduction?.itemID === pendingWfDetails.itemID
        ? {
          currentData: deduction,
          pendingData:
              changeType === 'edit'
                ? {
                  ...deduction,
                  ...pendingWfDetails,
                  deductionRate: {
                    ...deduction?.deductionRate,
                    ...pendingWfDetails.deductionRate
                  },
                  deductionGoal: {
                    ...deduction?.deductionGoal,
                    ...pendingWfDetails?.deductionGoal
                  }
                }
                : null,
          pendingEvent: pendingEventInfo
        }
        : mapNonPendingDeduction(deduction)
    );
  } else {
    // new deductions show up in pendingData but not currentData
    return pendingDeds?.map((deduction: PayDeductionsUI.DeductionDetails) =>
      deduction?.itemID === pendingWfDetails.itemID
        ? {
          currentData: null,
          pendingData: {
            ...deduction,
            deductionRate: {
              ...deduction?.deductionRate,
              ...pendingWfDetails?.deductionRate
            }
          },
          pendingEvent: pendingEventInfo
        }
        : mapNonPendingDeduction(deduction)
    );
  }
}

function getWorkflowDetails(
  pendingEvent: DeductionsDTO.PendingDeductionEvent
): Partial<PayDeductionsUI.DeductionDetails> {
  const pendingBodyData = pendingEvent?.body?.events?.[0]?.data;
  const eventContextInstruction =
    pendingBodyData?.eventContext?.workerGeneralDeductionInstruction?.generalDeductionInstruction;
  const dataTransformInstruction =
    pendingBodyData?.transform?.workerGeneralDeductionInstruction?.generalDeductionInstruction;

  const itemID: string =
    eventContextInstruction?.itemID ?? dataTransformInstruction?.deductionCode?.codeValue;
  const pendingDeductionRate = dataTransformInstruction?.deductionRate;

  // if missing rateValue or rateValue is empty string: default to null
  const useNullRate = !pendingDeductionRate?.rateValue && pendingDeductionRate?.rateValue !== 0;
  const deductionRate = {
    ...pendingDeductionRate,
    rateValue: !useNullRate ? Number(pendingDeductionRate?.rateValue) : null
  };

  return {
    itemID,
    deductionRate,
    deductionGoal: dataTransformInstruction?.deductionGoal
  };
}

function mapNonPendingDeduction(
  deduction: PayDeductionsUI.DeductionDetails
): PayDeductionsUI.Deduction {
  return {
    currentData: deduction,
    pendingData: null,
    pendingEvent: null
  };
}

interface TransformDTOConfig {
  aoid: string;
  deduction: PayDeductionsUI.DeductionDetails;
}

export function transformToDTO(
  { aoid, deduction }: TransformDTOConfig,
  isEdit: boolean
): DeductionsDTO.GeneralDeductionInstructionPostDTO {
  const generalDeductionInstruction: PayDeductionsUI.DeductionDetails = {
    deductionRate: deduction?.deductionRate,
    deductionGoal: { // only include goalLimitAmount and not goalBalanceAmount
      goalLimitAmount: deduction?.deductionGoal?.goalLimitAmount
    }
  };
  const eventContext = {
    worker: {
      associateOID: aoid
    }
  };

  if (!isEdit) {
    generalDeductionInstruction.deductionCode = deduction?.deductionCode;
  } else {
    eventContext['workerGeneralDeductionInstruction'] = {
      generalDeductionInstruction: {
        itemID: deduction?.deductionCode?.codeValue
      }
    };
  }

  return {
    events: [
      {
        data: {
          transform: {
            workerGeneralDeductionInstruction: {
              generalDeductionInstruction
            }
          },
          eventContext
        },
        actor: {
          associateOID: aoid
        },
        serviceCategoryCode: {
          codeValue: 'payrollManagement'
        },
        eventNameCode: {
          codeValue: !isEdit
            ? 'workerGeneralDeductionInstruction.start'
            : 'workerGeneralDeductionInstruction.change'
        }
      }
    ]
  };
}

export function transformToStopDTO(
  { aoid, deduction }: TransformDTOConfig,
  hasNestedItemID: boolean
): DeductionsDTO.GeneralDeductionInstructionStopDTO {
  const deductionInstructionObj = hasNestedItemID
    ? {
      generalDeductionInstruction: {
        itemID: deduction?.deductionCode?.codeValue
      }
    }
    : {
      itemID: deduction?.deductionCode?.codeValue
    };

  return {
    events: [
      {
        data: {
          eventContext: {
            worker: {
              associateOID: aoid
            },
            workerGeneralDeductionInstruction: {
              ...deductionInstructionObj
            }
          }
        },
        actor: {
          associateOID: aoid
        },
        serviceCategoryCode: {
          codeValue: 'payrollManagement'
        },
        eventNameCode: {
          codeValue: 'workerGeneralDeductionInstruction.stop'
        }
      }
    ]
  };
}
