import { Injectable } from '@angular/core';

import { FindSffoService, PAY_SFFO } from '@myadp/pay-shared';

import { PayDeductionsUI } from '../../pay-deductions-shared/models/pay-deductions-ui';
import { PayDeductionsStoreActions } from '../../pay-deductions-shared/store/pay-deductions-store.actions';
import { WorkflowUI } from '../../shared/models/workflow-ui.model';
import { DeductionForm } from '../models/deduction-form.model';
import { DeductionsStore } from './deductions.store';

@Injectable({
  providedIn: 'root'
})
export class DeductionsStoreActions {
  constructor(
    private deductionsStore: DeductionsStore,
    private findSffoService: FindSffoService,
    private payDeductionsStoreActions: PayDeductionsStoreActions
  ) {}

  public loadDeductions() {
    this.payDeductionsStoreActions.loadDeductions();
    this.setPermissions();
  }

  public loadStartMeta() {
    this.payDeductionsStoreActions.loadStartMeta();
  }

  public loadCodeList(bustCache: boolean = true) {
    this.payDeductionsStoreActions.loadCodeList(undefined, bustCache);
  }

  public loadDeductionMeta(codeValue: string, isEdit: boolean) {
    this.payDeductionsStoreActions.loadDeductionMeta(codeValue, isEdit);
  }

  public async postDeduction(
    modifiedDeduction: PayDeductionsUI.DeductionDetails,
    changeType: WorkflowUI.ChangeType
  ): Promise<void> {
    return this.payDeductionsStoreActions.postDeduction(modifiedDeduction, changeType);
  }

  public recallDeduction(recalledDeduction: PayDeductionsUI.Deduction) {
    this.payDeductionsStoreActions.recallDeduction(recalledDeduction);
  }

  public resetFormData() {
    this.deductionsStore.update('formData', {
      data: null
    });
  }

  public updateFormData(formData: DeductionForm) {
    const formDataRate = formData?.deductionRate;
    const {
      rateValue,
      currencyCode,
      unitCode
    }: {
      rateValue?: number;
      currencyCode?: string;
      unitCode?: { codeValue?: string };
    } = formDataRate ?? {};

    this.deductionsStore.update('formData', {
      data: {
        ...formData,
        ...(!!formDataRate && {
          deductionRate: {
            rateValue,
            currencyCode,
            unitCode
          }
        })
      }
    });
  }

  public deleteDeduction(deductionDetails: PayDeductionsUI.DeductionDetails): Promise<void> {
    if (this.deductionsStore.hasUnsavedAdd) {
      const newSnapshot = this.deductionsStore.deductionsSnapshot
        .map((deduction) =>
          (deduction?.pendingData ?? deduction?.currentData)?.itemID === deductionDetails.itemID
            ? null
            : deduction
        )
        .filter((d) => d);

      this.payDeductionsStoreActions.updateDeductions(newSnapshot);
      return Promise.resolve();
    } else {
      this.updateChanges('delete', this.deductionsStore.getDeductionByID(deductionDetails?.itemID));
      return this.payDeductionsStoreActions.stopDeduction(deductionDetails);
    }
  }

  public updateDeductionChanges(): PayDeductionsUI.Deduction {
    const deductions = this.deductionsStore.deductionsSnapshot;
    const deductionChanges = this.deductionsStore.changedDeductionDetails;
    const modifiedDeduction = this.deductionsStore.getDeductionByID(deductionChanges?.itemID);
    const isNewDeduction = !modifiedDeduction;

    const updatedDeduction: PayDeductionsUI.Deduction = {
      ...modifiedDeduction,
      currentData: modifiedDeduction?.currentData ?? null,
      pendingData: {
        ...deductionChanges
      },
      pendingEvent: modifiedDeduction?.pendingEvent ? {} : null
    };

    if (deductionChanges) {
      isNewDeduction
        ? this.updateChanges('add', updatedDeduction)
        : this.updateChanges('edit', updatedDeduction);

      const updatedDeductions = isNewDeduction
        ? deductions.concat(updatedDeduction)
        : deductions.map((deduction) =>
          (deduction?.pendingData ?? deduction?.currentData)?.itemID ===
            updatedDeduction.pendingData?.itemID
            ? updatedDeduction
            : deduction
        );

      this.payDeductionsStoreActions.updateDeductions(updatedDeductions);
    }

    return updatedDeduction;
  }

  public updateChangedDeduction(deductionData: PayDeductionsUI.Deduction | DeductionForm): void {
    const dataDetails: PayDeductionsUI.DeductionDetails =
      (deductionData as PayDeductionsUI.Deduction)?.pendingData ??
      (deductionData as PayDeductionsUI.Deduction)?.currentData;
    const formData = deductionData as DeductionForm;

    this.deductionsStore.update('changedDeductionDetails', {
      data:
        dataDetails ??
        ({
          itemID: formData?.itemID,
          deductionCode: formData?.deductionCode,
          deductionRate: formData?.deductionRate,
          deductionGoal: formData?.deductionGoal
        } as PayDeductionsUI.DeductionDetails)
    });
  }

  public updateChanges(changeType: WorkflowUI.ChangeType, deduction: PayDeductionsUI.Deduction) {
    const changedDetails = this.deductionsStore.changes?.deductionDetails;
    const deductionDetails = deduction?.pendingData ?? deduction?.currentData;

    // 'delete' will overwrite 'add' or 'edit'
    if (changedDetails?.itemID !== deductionDetails?.itemID || changeType === 'delete') {
      this.deductionsStore.update('changes', {
        data: {
          changeType,
          deductionDetails
        }
      });
    }
  }

  public revertAllChanges(): void {
    this.payDeductionsStoreActions.revertToInitialDeductions();
    this.resetDeductionChanges();
  }

  public resetDeductionChanges(): void {
    this.deductionsStore.update('changes', {
      data: null
    });
  }

  private setPermissions() {
    const { sffo: addSffo, href: addHref } = this.findSffoService.findSffo([
      PAY_SFFO.DEDUCTIONS_START_PERMISSION
    ]);
    const { sffo: editSffo, href: editHref } = this.findSffoService.findSffo([
      PAY_SFFO.DEDUCTIONS_CHANGE_PERMISSION
    ]);
    const { sffo: deleteSffo, href: deleteHref } = this.findSffoService.findSffo([
      PAY_SFFO.DEDUCTIONS_STOP_PERMISSION
    ]);

    const hasAddPermission = !!addSffo && !!addHref;
    const hasEditPermission = !!editSffo && !!editHref;
    const hasDeletePermission = !!deleteSffo && !!deleteHref;

    this.deductionsStore.update('permissions', {
      data: {
        add: hasAddPermission,
        edit: hasEditPermission,
        delete: hasDeletePermission
      }
    });
  }
}
