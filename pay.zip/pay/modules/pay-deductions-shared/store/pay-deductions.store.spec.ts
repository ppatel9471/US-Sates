import { TestBed } from '@angular/core/testing';

import { RawMetaObject } from '@myadp/forms';
import {
  MOCK_DEDUCTIONS,
  MOCK_PAY_DEDUCTIONS_DEDUCTION_META,
  MOCK_PAY_DEDUCTIONS_DEDUCTION_META_CURRENCY,
  MOCK_PAY_DEDUCTIONS_START_META
} from '@specHelpers/pay/pay-deductions/pay-deductions';

import { PayDeductionsStoreSlice, PayDeductionsUI } from '../models/pay-deductions-ui';
import { PayDeductionsStore } from './pay-deductions.store';

describe('PayDeductionsStore', () => {
  const deductions: PayDeductionsUI.Deduction[] = MOCK_DEDUCTIONS;
  const mockStartMeta: RawMetaObject = MOCK_PAY_DEDUCTIONS_START_META;
  const mockDeductionMeta: RawMetaObject = MOCK_PAY_DEDUCTIONS_DEDUCTION_META;
  const mockEditDeductionMeta: RawMetaObject = MOCK_PAY_DEDUCTIONS_DEDUCTION_META_CURRENCY;

  let payDeductionsStore: PayDeductionsStore;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [PayDeductionsStore]
    });

    payDeductionsStore = TestBed.inject(PayDeductionsStore);
  });

  it('should create the store with an initial state', () => {
    expect(payDeductionsStore.stateValue).toEqual({
      [PayDeductionsStoreSlice.PAY_DEDUCTIONS]: {
        data: null,
        loading: false,
        error: {}
      },
      [PayDeductionsStoreSlice.PAY_DEDUCTIONS_INITIAL]: {
        data: null
      },
      [PayDeductionsStoreSlice.PAY_DEDUCTIONS_META]: {
        data: {
          rawStartMeta: null
        },
        loading: false,
        error: {}
      }
    });
  });

  describe('state slices', () => {
    it('should select pay deductions', async (done: DoneFn) => {
      payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS, {
        data: deductions
      });

      payDeductionsStore.payDeductions$.subscribe((payDeductions) => {
        expect(payDeductions).toEqual(deductions);
        done();
      });
    });

    it('should select initial pay deductions', async () => {
      payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS_INITIAL, {
        data: deductions
      });

      expect(payDeductionsStore.payDeductionsInitialSnapshot).toEqual(deductions);
    });

    it('should select pay deductions start meta', async (done: DoneFn) => {
      payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS_META, {
        data: {
          rawStartMeta: mockStartMeta
        }
      });

      payDeductionsStore.payDeductionsStartMeta$.subscribe((payDeductionsStartMeta) => {
        expect(payDeductionsStartMeta).toEqual(mockStartMeta);
        done();
      });
    });

    it('should emit pay deduction add meta by itemID', async (done: DoneFn) => {
      const itemID = '40A';
      payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS_META, {
        data: {
          addFormMeta: { [itemID]: mockDeductionMeta }
        }
      });

      payDeductionsStore.payDeductionAddFormMeta$(itemID).subscribe((payDeductionMeta) => {
        expect(payDeductionMeta).toEqual(mockDeductionMeta);
        done();
      });
    });

    it('should emit pay deduction edit meta by itemID', async (done: DoneFn) => {
      const itemID = '40A';
      payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS_META, {
        data: {
          editFormMeta: { [itemID]: mockEditDeductionMeta }
        }
      });

      payDeductionsStore.payDeductionEditFormMeta$(itemID).subscribe((payDeductionEditMeta) => {
        expect(payDeductionEditMeta).toEqual(mockEditDeductionMeta);
        done();
      });
    });

    it('should return pay deductions meta error snapshot', () => {
      payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS_META, {
        error: {
          deductionMetaError: true
        }
      });

      expect(payDeductionsStore.hasDeductionMetaError).toEqual(true);
    });

    it('should return pay deduction meta item snapshot for addFormMeta', async () => {
      const itemID = '40A';
      payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS_META, {
        data: {
          addFormMeta: { [itemID]: mockDeductionMeta }
        }
      });

      expect(payDeductionsStore.payDeductionMetaItemSnapshot(itemID, false)).toEqual(
        mockDeductionMeta
      );
    });

    it('should return pay deduction meta item snapshot for editFormMeta', async () => {
      const itemID = '40A';
      payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS_META, {
        data: {
          editFormMeta: { [itemID]: mockEditDeductionMeta }
        }
      });

      expect(payDeductionsStore.payDeductionMetaItemSnapshot(itemID, true)).toEqual(
        mockEditDeductionMeta
      );
    });

    describe('loading', () => {
      it('should return true when the pay deductions is loading', async (done: DoneFn) => {
        payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS, {
          loading: true
        });

        payDeductionsStore.isPayDeductionsLoading$.subscribe((isLoading) => {
          expect(isLoading).toBe(true);
          done();
        });
      });

      it('should return true when the Pay deductions metaLoading is loading', async (done: DoneFn) => {
        payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS_META, {
          loading: true
        });

        payDeductionsStore.isPayDeductionsMetaLoading$.subscribe((isLoading) => {
          expect(isLoading).toBe(true);
          done();
        });
      });

      it('should return false when the store is not loading pay deductions', async (done: DoneFn) => {
        payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS, {
          loading: false
        });

        payDeductionsStore.isPayDeductionsLoading$.subscribe((isLoading) => {
          expect(isLoading).toBe(false);
          done();
        });
      });

      it('should return false when the store is not loading pay deduction meta', async (done: DoneFn) => {
        payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS_META, {
          loading: false
        });

        payDeductionsStore.isPayDeductionsMetaLoading$.subscribe((isLoading) => {
          expect(isLoading).toBe(false);
          done();
        });
      });
    });

    describe('error', () => {
      it('should return false when there is no error in pay deductions', async (done: DoneFn) => {
        payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS, {
          error: {}
        });

        payDeductionsStore.hasDeductionError$.subscribe((hasError) => {
          expect(hasError).toBe(false);
          done();
        });
      });

      it('should return false when there is no error in pay deduction meta', async (done: DoneFn) => {
        payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS_META, {
          error: {}
        });

        payDeductionsStore.hasDeductionMetaError$.subscribe((hasError) => {
          expect(hasError).toBe(false);
          done();
        });
      });

      it('should return false when there is no error in pay deductions for stopping a deduction', async (done: DoneFn) => {
        payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS, {
          error: null
        });

        payDeductionsStore.hasDeductionStopError$.subscribe((hasError) => {
          expect(hasError).toBe(false);
          done();
        });
      });

      it('should return true when there is an error in pay deductions', async (done: DoneFn) => {
        payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS, {
          error: {
            deductionsError: true
          }
        });

        payDeductionsStore.hasDeductionError$.subscribe((hasError) => {
          expect(hasError).toBe(true);
          done();
        });
      });

      it('should return true when there is an error in pay deduction meta', async (done: DoneFn) => {
        payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS_META, {
          error: {
            deductionMetaError: true
          }
        });

        payDeductionsStore.hasDeductionMetaError$.subscribe((hasError) => {
          expect(hasError).toBe(true);
          done();
        });
      });

      it('should return true when there is an error in pay deductions for stopping a deduction', (done: DoneFn) => {
        payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS, {
          error: {
            stopError: true
          }
        });

        payDeductionsStore.hasDeductionStopError$.subscribe((hasError) => {
          expect(hasError).toBe(true);
          done();
        });
      });
    });
  });
});
