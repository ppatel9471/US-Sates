import { Component, Input, OnInit } from '@angular/core';

import { first } from 'rxjs/operators';

import * as log4javascript from 'log4javascript';

import { LoggerFactory } from '@espresso/core';
import { CustomContentService } from '../../services/custom-content.service';

@Component({
  selector: 'pay-custom-content',
  templateUrl: './custom-content.component.html',
  styleUrls: ['./custom-content.component.scss']
})
export class CustomContentComponent implements OnInit {
  @Input() featureKey: string;
  @Input() contentKey: string;
  public customContent: string;
  private logger: log4javascript.Logger;
  constructor(private customContentService: CustomContentService, loggerFactory: LoggerFactory) {
    this.logger = loggerFactory.getLogger('myadp.pay.shared.customContent');
  }
  ngOnInit() {
    if (this.featureKey) {
      this.customContentService
        .getCustomContent(this.featureKey, this.contentKey)
        .pipe(first())
        .subscribe(
          (res: string) => {
            this.customContent = res;
          },
          (error) => {
            this.logger.error(`Error loading custom content: ${error}`);
          }
        );
    }
  }
}
