import { waitForAsync } from '@angular/core/testing';
import { BehaviorSubject, of } from 'rxjs';
import { Shallow } from 'shallow-render';
import { Mock } from 'ts-mockery';

import { QueryParamsService } from '@myadp/common';
import { WorkerTaxStatementsDTO } from '@myadp/dto';
import { PaperlessStore } from '@myadp/pay-paperless-shared';
import { PAY_DEEP_LINKS, PayPermissionService } from '@myadp/pay-shared';

import { PdfStatement } from '../../../shared/models/pdf-viewer.model';
import { TaxStatementsStoreActions } from '../../store/tax-statements-store.actions';
import { TaxStatementsStore } from '../../store/tax-statements.store';
import { TaxStatementsTileModule } from '../../tax-statements-tile.module';
import { TaxStatementsModalComponent } from '../tax-statements-modal/tax-statements-modal.component';
import { TaxStatementsTileComponent } from './tax-statements-tile.component';

describe('TaxStatementsTileComponent', () => {
  let shallow: Shallow<TaxStatementsTileComponent>;
  const mockStatement = {
    statementName: '2013 1095-C',
    employerName: 'AUTOMATIC DATA PROCESSING',
    form: {
      code: '1095-C'
    },

    statementYear: {
      year: '2013'
    },
    summaryAmount: {
      amountValue: 20130,
      currencyCode: 'USD'
    },
    statementImageUri: {
      href: 'mockPDF.pdf'
    }
  };
  const mockStatements: WorkerTaxStatementsDTO.WorkerTaxStatement[] = [
    mockStatement,
    mockStatement,
    mockStatement
  ];
  let mockTaxStatementsModalComponent: TaxStatementsModalComponent;

  const mockstatementsForPdfViewer: PdfStatement = {
    title: '2019',
    uri: 'uri1',
    statementDetails: [
      { label: 'Tax Year: ', value: '2013' },
      { label: 'Form Type: ', value: '1095-C' }
    ]
  };
  beforeEach(
    waitForAsync(() => {
      mockTaxStatementsModalComponent = Mock.of<TaxStatementsModalComponent>({
        setShowTaxStatementsModal: () => Mock.noop
      });

      shallow = new Shallow(TaxStatementsTileComponent, TaxStatementsTileModule)
        .mock(TaxStatementsModalComponent, mockTaxStatementsModalComponent)
        .mock(QueryParamsService, {
          getParameterValue: () => null
        })
        .mock(TaxStatementsStore, {
          selectionYears$: () => of([{ value: '2019', label: '2019 (3)' }]),
          taxStatementsError$: () => of(false),
          emptyTaxStatement$: () => of(false),
          mostRecentTaxYear$: () => of('2019'),
          taxStatementsIsLoading$: () => of(false),
          filterStatementsByYear$: () => of(mockStatements),
          statementsForPdfViewer$: () =>
            of([mockstatementsForPdfViewer, mockstatementsForPdfViewer, mockstatementsForPdfViewer])
        })
        .mock(TaxStatementsStoreActions, { getTaxStatements: () => Mock.noop })
        .mock(PayPermissionService, { canViewTaxStatementsImportBanner: () => false })
        .mock(PaperlessStore, {
          showForcedDialog$: () => of(false)
        });
    })
  );

  describe('isLoading', () => {
    it('should  show shimmer when isLoading', async () => {
      const { find } = await shallow
        .mock(TaxStatementsStore, {
          taxStatementsIsLoading$: () => of(true)
        })
        .render();
      expect(find('sdf-shimmer')).toHaveFound(1);
    });

    it('should not show loading indicator when isLoading', async () => {
      const { find } = await shallow
        .mock(TaxStatementsStore, {
          taxStatementsIsLoading$: () => of(false)
        })
        .render();
      expect(find('sdf-shimmer')).toHaveFound(0);
    });
  });

  describe('open modal button', () => {
    it('should not show open modal button when there is only one tax year', async () => {
      const { find } = await shallow.render();
      expect(find('adp-button')).toHaveFound(0);
    });

    it('should show open modal button when there is more than one tax year', async () => {
      const { find } = await shallow
        .mock(TaxStatementsStore, {
          selectionYears$: () =>
            of([
              { value: '2019', label: '2019 (3)' },
              { value: '2018', label: '2018 (1)' }
            ])
        })
        .render();
      expect(find('adp-button')).toHaveFound(1);
    });
  });

  describe('auto open modal', () => {
    it('should handle when auto open is tax-statements', async () => {
      const mockMostRecentTaxYear$ = new BehaviorSubject(undefined);
      await shallow
        .mock(TaxStatementsStore, {
          mostRecentTaxYear$: () => mockMostRecentTaxYear$
        })
        .mock(QueryParamsService, {
          getParameterValue: () => PAY_DEEP_LINKS.TaxStatements
        })
        .render();

      // Need to fire after ViewChild has a chance to init
      mockMostRecentTaxYear$.next('2019');

      expect(mockTaxStatementsModalComponent.setShowTaxStatementsModal).toHaveBeenCalledWith(true);
    });

    it('should not open when auto open is for non tax-statements', async () => {
      const mockMostRecentTaxYear$ = new BehaviorSubject(undefined);
      await shallow
        .mock(TaxStatementsStore, {
          mostRecentTaxYear$: () => mockMostRecentTaxYear$
        })
        .mock(QueryParamsService, {
          getParameterValue: () => PAY_DEEP_LINKS.MyPayDetails
        })
        .render();

      // Need to fire after ViewChild has a chance to init
      mockMostRecentTaxYear$.next('2019');

      expect(mockTaxStatementsModalComponent.setShowTaxStatementsModal).toHaveBeenCalledTimes(0);
    });
  });

  describe('year dropdown', () => {
    it('PIMYPI-T711 should always show year dropdown when there is only one tax year', async () => {
      const { find } = await shallow.render();
      expect(find('adp-select')).toHaveFound(1);
    });

    it('PIMYPI-T712 should show year dropdown when there is more than one tax year', async () => {
      const { find } = await shallow
        .mock(TaxStatementsStore, {
          selectionYears$: () =>
            of([
              { value: '2019', label: '2019 (3)' },
              { value: '2018', label: '2018 (1)' }
            ])
        })
        .render();
      expect(find('adp-select')).toHaveFound(1);
    });
  });

  describe('empty tax statement tip', () => {
    it('should not show empty tax statement tip when there is statement', async () => {
      const { find } = await shallow.render();
      expect(find('div[data-e2e="empty-tax-statement"]')).toHaveFound(0);
    });

    it('should show empty tax statement tip when there is no statement', async () => {
      const { find } = await shallow
        .mock(TaxStatementsStore, {
          emptyTaxStatement$: () => of(true)
        })
        .render();
      expect(find('div[data-e2e="empty-tax-statement"]')).toHaveFound(1);
    });
  });

  describe('import banner', () => {
    it('should not show import banner', async () => {
      const { find } = await shallow.render();
      expect(find('tax-statements-banner[data-e2e="import-banner"]')).toHaveFound(0);
    });

    it('should show import banner', async () => {
      const { find } = await shallow
        .mock(PayPermissionService, {
          canViewTaxStatementsImportBanner: () => true
        })
        .render();
      expect(find('tax-statements-banner[data-e2e="import-banner"]')).toHaveFound(1);
    });
  });

  describe('alert', () => {
    it('should show alert', async () => {
      const { find, fixture } = await shallow
        .mock(PaperlessStore, {
          showForcedDialog$: () => of(true)
        })
        .render();

      fixture.detectChanges();
      expect(find('adp-alert[type="info"]')).toHaveFound(1);
    });

    it('should show alert', async () => {
      const { find } = await shallow
        .mock(PaperlessStore, {
          showForcedDialog$: () => of(false)
        })
        .render();

      expect(find('adp-alert[type="info"]')).toHaveFound(0);
    });
  });
});
