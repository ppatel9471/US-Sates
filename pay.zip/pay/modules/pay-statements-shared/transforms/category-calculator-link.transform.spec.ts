import { Amount } from '@myadp/dto';

import { PayStatementsUI } from '../models/pay-statement-ui';
import { MOCK_TRANSFORMED_PAY_STATEMENT_DETAILS_RESPONSE } from '../../../../../../src/spec-helpers/pay/pay-statement/pay-statement-details';
import { buildCalculatorLink } from './category-calculator-link.transform';

describe('buildCalculatorLink', () => {
  let calculatorLink: PayStatementsUI.CalculatorLink;
  const zeroAmount: Amount = { amountValue: 0, currencyCode: 'USD' };
  const nonZeroAmount: Amount = { amountValue: -123.0, currencyCode: 'USD' };

  beforeEach(() => {
    calculatorLink = undefined;
  });

  it('should not build a calculator link for a category that does not have a calculator link', () => {
    calculatorLink = buildCalculatorLink(
      'benefits',
      nonZeroAmount,
      MOCK_TRANSFORMED_PAY_STATEMENT_DETAILS_RESPONSE.deductionsCategories[1].deductions
    );

    expect(calculatorLink).toBeUndefined();
  });

  it('should not build a calculator link if deduction amount is not using USD', () => {
    calculatorLink = buildCalculatorLink(
      'taxes',
      { amountValue: 45, currencyCode: 'EUR' },
      MOCK_TRANSFORMED_PAY_STATEMENT_DETAILS_RESPONSE.deductionsCategories[1].deductions
    );

    expect(calculatorLink).toBeUndefined();
  });

  it('should not build a calculator link if category amount is zero', () => {
    calculatorLink = buildCalculatorLink(
      'taxes',
      zeroAmount,
      MOCK_TRANSFORMED_PAY_STATEMENT_DETAILS_RESPONSE.deductionsCategories[0].deductions
    );

    expect(calculatorLink).toBeUndefined();
  });

  it('should build a calculator link if deduction amount is using USD', () => {
    calculatorLink = buildCalculatorLink(
      'tax',
      nonZeroAmount,
      MOCK_TRANSFORMED_PAY_STATEMENT_DETAILS_RESPONSE.deductionsCategories[0].deductions
    );

    expect(calculatorLink).toBeTruthy();
  });

  it('should build a calculator link for the Taxes category', () => {
    calculatorLink = buildCalculatorLink(
      'tax',
      nonZeroAmount,
      MOCK_TRANSFORMED_PAY_STATEMENT_DETAILS_RESPONSE.deductionsCategories[0].deductions
    );

    expect(calculatorLink).toEqual(
      MOCK_TRANSFORMED_PAY_STATEMENT_DETAILS_RESPONSE.deductionsCategories[0].displayConfig
        .calculatorLink
    );
  });

  it('should build a calculator link for the Retirement category', () => {
    calculatorLink = buildCalculatorLink(
      'retirement',
      nonZeroAmount,
      MOCK_TRANSFORMED_PAY_STATEMENT_DETAILS_RESPONSE.deductionsCategories[2].deductions
    );

    expect(calculatorLink).toEqual(
      MOCK_TRANSFORMED_PAY_STATEMENT_DETAILS_RESPONSE.deductionsCategories[2].displayConfig
        .calculatorLink
    );
  });

  it('should build a calculator link for the Take Home category', () => {
    calculatorLink = buildCalculatorLink(
      'takeHome',
      nonZeroAmount,
      MOCK_TRANSFORMED_PAY_STATEMENT_DETAILS_RESPONSE.deductionsCategories[6].deductions
    );

    expect(calculatorLink).toEqual(
      MOCK_TRANSFORMED_PAY_STATEMENT_DETAILS_RESPONSE.deductionsCategories[6].displayConfig
        .calculatorLink
    );
  });
});
