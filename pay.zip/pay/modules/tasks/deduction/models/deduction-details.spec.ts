import { DeductionsDTO, PayPendingEvent } from '@myadp/dto';

import { DEDUCTION_EVENT_TYPE } from './deduction-tasks-details.model';
import { DeductionDetails } from './deduction-details';
import { NOTIFICATION_CODE_TYPES } from '@myadp/thingstodo-shared';

describe('Deduction Details', () => {
  const rateValue = 100;
  const goalLimit = 0;
  const pendingRateValue = 200;
  const pendingGoalLimit = 10;
  const currentDataInstruction = {
    itemID: 'A',
    deductionCode: {
      codeValue: 'A',
      longName: 'Medicare Surtax'
    },
    deductionRate: {
      rateValue: rateValue,
      currencyCode: 'USD'
    },
    deductionGoal: {
      goalBalanceAmount: { amountValue: 0, currencyCode: 'USD' },
      goalLimitAmount: {
        amountValue: goalLimit,
        currencyCode: 'USD'
      }
    }
  };

  const pendingEventInstruction = {
    deductionRate: {
      rateValue: 200,
      currencyCode: 'USD'
    },
    deductionGoal: {
      goalLimitAmount: {
        amountValue: 10,
        currencyCode: 'USD'
      }
    }
  };

  const currentData: DeductionsDTO.DeductionData = {
    workerGeneralDeductionInstructions: [
      {
        payrollGroupCode: {
          codeValue: '21E'
        },
        generalDeductionInstructions: [currentDataInstruction]
      }
    ]
  };

  const pendingData: DeductionsDTO.DeductionData = {
    workerGeneralDeductionInstructions: [
      {
        generalDeductionInstructions: [
          {
            itemID: 'A',
            deductionCode: {
              codeValue: 'A',
              longName: 'Medicare Surtax'
            },
            deductionRate: {
              rateValue: pendingRateValue,
              currencyCode: 'USD'
            },
            deductionGoal: {
              goalLimitAmount: {
                amountValue: pendingGoalLimit,
                currencyCode: 'USD'
              }
            }
          }
        ]
      }
    ]
  };

  const pendingEvent: PayPendingEvent<DeductionsDTO.DeductionTaskPendingActionData> = {
    method: 'POST',
    resourcePath: '/events/payroll/v1/worker-general-deduction-instruction.change',
    history: [
      {
        actionDate: 1111,
        actionTaken: 'submitted',
        assignedTo: 'assigned',
        comments: 'comment',
        processStepID: 54321
      }
    ],
    body: {
      events: [
        {
          data: {
            transform: {
              workerGeneralDeductionInstruction: {
                generalDeductionInstruction: pendingEventInstruction
              }
            },
            eventContext: {
              worker: {
                associateOID: 'G3NVBKA5GXDASSZX'
              },
              workerGeneralDeductionInstruction: {
                generalDeductionInstruction: {
                  itemID: 'A'
                }
              }
            }
          }
        }
      ]
    }
  };

  const mockResponse: DeductionsDTO.DeductionTasksDetails = {
    currentData,
    pendingData,
    pendingEvents: [pendingEvent]
  };

  beforeEach(() => {
    currentDataInstruction.deductionRate.rateValue = rateValue;
    currentDataInstruction.deductionGoal.goalLimitAmount.amountValue = goalLimit;
    pendingEventInstruction.deductionRate.rateValue = pendingRateValue;
    pendingEventInstruction.deductionGoal.goalLimitAmount.amountValue = pendingGoalLimit;
  });

  describe('change deduction', () => {
    it('should transform item A', () => {
      const deductionDetails = new DeductionDetails(mockResponse, NOTIFICATION_CODE_TYPES.TASK);
      const comparisonData = deductionDetails.comparisonData;
      expect(comparisonData.itemID).toEqual('A');
      expect(comparisonData.type).toEqual(DEDUCTION_EVENT_TYPE.CHANGE);
      expect(comparisonData.currentData).toEqual(
        currentData.workerGeneralDeductionInstructions[0].generalDeductionInstructions[0]
      );
      expect(comparisonData.pendingData).toEqual({
        deductionRate: {
          rateValue: 200,
          currencyCode: 'USD'
        },
        deductionGoal: {
          goalLimitAmount: {
            amountValue: 10,
            currencyCode: 'USD'
          }
        }
      });
      expect(deductionDetails.payrollGroupCode.codeValue).toEqual('21E');
    });

    it('should transform item A when deduction amount is changed from 0 to null and goal limit is unchanged', () => {
      currentDataInstruction.deductionRate.rateValue = 0;
      currentDataInstruction.deductionGoal.goalLimitAmount.amountValue = pendingGoalLimit;
      pendingEventInstruction.deductionRate.rateValue = null;

      const deductionDetails = new DeductionDetails(mockResponse, NOTIFICATION_CODE_TYPES.TASK);
      const comparisonData = deductionDetails.comparisonData;

      expect(comparisonData.itemID).toEqual('A');
      expect(comparisonData.type).toEqual(DEDUCTION_EVENT_TYPE.CHANGE);
      expect(comparisonData.currentData).toEqual(
        currentData.workerGeneralDeductionInstructions[0].generalDeductionInstructions[0]
      );
      expect(comparisonData.pendingData).toEqual({
        deductionRate: {
          rateValue: 0,
          currencyCode: 'USD'
        }
      });
    });

    it('should transform item A when goal limit is changed from 0 to null and deduction amount is unchanged', () => {
      pendingEventInstruction.deductionRate.rateValue = rateValue;
      currentDataInstruction.deductionGoal.goalLimitAmount.amountValue = 0;
      pendingEventInstruction.deductionGoal.goalLimitAmount.amountValue = null;

      const deductionDetails = new DeductionDetails(mockResponse, NOTIFICATION_CODE_TYPES.TASK);
      const comparisonData = deductionDetails.comparisonData;

      expect(comparisonData.itemID).toEqual('A');
      expect(comparisonData.type).toEqual(DEDUCTION_EVENT_TYPE.CHANGE);
      expect(comparisonData.currentData).toEqual(
        currentData.workerGeneralDeductionInstructions[0].generalDeductionInstructions[0]
      );
      expect(comparisonData.pendingData).toEqual({
        deductionGoal: {
          goalLimitAmount: {
            amountValue: 0,
            currencyCode: 'USD'
          }
        }
      });
    });
  });

  describe('add deduction', () => {
    it('should transform item A', () => {
      mockResponse.currentData = null;
      mockResponse.pendingEvents[0].resourcePath =
        '/events/payroll/v1/worker-general-deduction-instruction.start';

      const deductionDetails = new DeductionDetails(mockResponse, NOTIFICATION_CODE_TYPES.TASK);
      const comparisonData = deductionDetails.comparisonData;

      expect(comparisonData.itemID).toEqual('A');
      expect(comparisonData.type).toEqual(DEDUCTION_EVENT_TYPE.START);
      expect(comparisonData.currentData).toBeUndefined();
      expect(comparisonData.pendingData.deductionRate).toEqual({
        rateValue: 200,
        currencyCode: 'USD'
      });
      expect(comparisonData.pendingData.deductionGoal).toEqual({
        goalLimitAmount: {
          amountValue: 10,
          currencyCode: 'USD'
        }
      });
    });

    it('should transform item A when deduction amount and goal limit amount are null', () => {
      mockResponse.currentData = null;
      mockResponse.pendingEvents[0].resourcePath =
        '/events/payroll/v1/worker-general-deduction-instruction.start';

      pendingEventInstruction.deductionRate.rateValue = null;
      pendingEventInstruction.deductionGoal.goalLimitAmount.amountValue = null;

      const deductionDetails = new DeductionDetails(mockResponse, NOTIFICATION_CODE_TYPES.TASK);
      const comparisonData = deductionDetails.comparisonData;

      expect(comparisonData.itemID).toEqual('A');
      expect(comparisonData.type).toEqual(DEDUCTION_EVENT_TYPE.START);
      expect(comparisonData.currentData).toBeUndefined();
      expect(comparisonData.pendingData.deductionRate).toEqual({
        rateValue: 0,
        currencyCode: 'USD'
      });
      expect(comparisonData.pendingData.deductionGoal).toEqual({
        goalLimitAmount: {
          amountValue: 0,
          currencyCode: 'USD'
        }
      });
    });

    it('should transform item A when deduction amount and goal limit amount are 0', () => {
      mockResponse.currentData = null;
      mockResponse.pendingEvents[0].resourcePath =
        '/events/payroll/v1/worker-general-deduction-instruction.start';

      pendingEventInstruction.deductionRate.rateValue = 0;
      pendingEventInstruction.deductionGoal.goalLimitAmount.amountValue = 0;

      const deductionDetails = new DeductionDetails(mockResponse, NOTIFICATION_CODE_TYPES.TASK);
      const comparisonData = deductionDetails.comparisonData;

      expect(comparisonData.itemID).toEqual('A');
      expect(comparisonData.type).toEqual(DEDUCTION_EVENT_TYPE.START);
      expect(comparisonData.currentData).toBeUndefined();
      expect(comparisonData.pendingData.deductionRate).toEqual({
        rateValue: 0,
        currencyCode: 'USD'
      });
      expect(comparisonData.pendingData.deductionGoal).toEqual({
        goalLimitAmount: {
          amountValue: 0,
          currencyCode: 'USD'
        }
      });
    });
  });

  describe('delete deduction', () => {
    it('should transform item A', () => {
      currentDataInstruction.deductionGoal.goalLimitAmount.amountValue = 10;
      mockResponse.currentData = currentData;
      mockResponse.pendingEvents[0].resourcePath =
        '/events/payroll/v1/worker-general-deduction-instruction.stop';

      const deductionDetails = new DeductionDetails(mockResponse, NOTIFICATION_CODE_TYPES.TASK);
      const comparisonData = deductionDetails.comparisonData;

      expect(comparisonData.itemID).toEqual('A');
      expect(comparisonData.type).toEqual(DEDUCTION_EVENT_TYPE.STOP);
      expect(comparisonData.currentData.deductionRate).toEqual({
        rateValue: 100,
        currencyCode: 'USD'
      });
      expect(comparisonData.currentData.deductionGoal.goalLimitAmount).toEqual({
        amountValue: 10,
        currencyCode: 'USD'
      });
    });

    it('should transform item A when deduction amount and goal limit amount are null', () => {
      currentDataInstruction.deductionRate.rateValue = null;
      currentDataInstruction.deductionGoal.goalLimitAmount.amountValue = null;
      mockResponse.currentData = currentData;
      mockResponse.pendingEvents[0].resourcePath =
        '/events/payroll/v1/worker-general-deduction-instruction.stop';

      const deductionDetails = new DeductionDetails(mockResponse, NOTIFICATION_CODE_TYPES.TASK);
      const comparisonData = deductionDetails.comparisonData;

      expect(comparisonData.itemID).toEqual('A');
      expect(comparisonData.type).toEqual(DEDUCTION_EVENT_TYPE.STOP);
      expect(comparisonData.currentData.deductionRate).toEqual({
        rateValue: 0,
        currencyCode: 'USD'
      });
      expect(comparisonData.currentData.deductionGoal.goalLimitAmount).toEqual({
        amountValue: 0,
        currencyCode: 'USD'
      });
    });

    it('should transform item A when deduction amount and goal limit amount are 0', () => {
      currentDataInstruction.deductionRate.rateValue = 0;
      currentDataInstruction.deductionGoal.goalLimitAmount.amountValue = 0;
      mockResponse.currentData = currentData;
      mockResponse.pendingEvents[0].resourcePath =
        '/events/payroll/v1/worker-general-deduction-instruction.stop';

      const deductionDetails = new DeductionDetails(mockResponse, NOTIFICATION_CODE_TYPES.TASK);
      const comparisonData = deductionDetails.comparisonData;

      expect(comparisonData.itemID).toEqual('A');
      expect(comparisonData.type).toEqual(DEDUCTION_EVENT_TYPE.STOP);
      expect(comparisonData.currentData.deductionRate).toEqual({
        rateValue: 0,
        currencyCode: 'USD'
      });
      expect(comparisonData.currentData.deductionGoal.goalLimitAmount).toEqual({
        amountValue: 0,
        currencyCode: 'USD'
      });
    });
  });

  it('should transform notification data structure', () => {
    const mockNotificationResponse: DeductionsDTO.DeductionTasksDetails = {
      oldData: currentData,
      ...pendingEvent
    };
    const deductionDetailsNotification = new DeductionDetails(
      mockNotificationResponse,
      NOTIFICATION_CODE_TYPES.NOTIFICATION
    );

    expect(deductionDetailsNotification.currentData).toEqual(
      currentData.workerGeneralDeductionInstructions[0].generalDeductionInstructions
    );
  });

  it('should get the history from pendingEvents if the history in taskDetails does not exist', () => {
    const deductionDetails = new DeductionDetails(mockResponse, NOTIFICATION_CODE_TYPES.TASK);
    expect(deductionDetails.pendingEventsHistory).toEqual(mockResponse.pendingEvents[0].history);
  });

  it('should return history object from taskDetails if it exists', () => {
    mockResponse.history = [
      {
        actionDate: 123456789,
        actionTaken: 'submitted',
        assignedTo: 'assignedTo',
        comments: 'comments',
        processStepID: 987654321
      }
    ];

    const deductionDetails = new DeductionDetails(mockResponse, NOTIFICATION_CODE_TYPES.TASK);
    expect(deductionDetails.pendingEventsHistory).toEqual(mockResponse.history);
  });
});
