import { cloneDeep } from 'lodash';

import { PayStatementsUI } from '../models/pay-statement-ui';
import {
  MOCK_PAY_STATEMENT_DETAILS_RESPONSE,
  MOCK_TRANSFORMED_PAY_STATEMENT_DETAILS_RESPONSE
} from '../../../../../../src/spec-helpers/pay/pay-statement/pay-statement-details';
import { transformStatementDetails } from './pay-statement-details.transform';

describe('transformStatementDetails', () => {
  let statementDetails: PayStatementsUI.PayStatementDetails;

  it('should transform details', () => {
    statementDetails = transformStatementDetails(MOCK_PAY_STATEMENT_DETAILS_RESPONSE);
    expect(statementDetails).toEqual(MOCK_TRANSFORMED_PAY_STATEMENT_DETAILS_RESPONSE);
  });

  it('should transform earnings', () => {
    statementDetails = transformStatementDetails(MOCK_PAY_STATEMENT_DETAILS_RESPONSE);
    expect(statementDetails.earnings).toEqual(
      MOCK_TRANSFORMED_PAY_STATEMENT_DETAILS_RESPONSE.earnings
    );
  });

  it('should transform memos', () => {
    statementDetails = transformStatementDetails(MOCK_PAY_STATEMENT_DETAILS_RESPONSE);
    expect(statementDetails.memos).toEqual(MOCK_TRANSFORMED_PAY_STATEMENT_DETAILS_RESPONSE.memos);
  });

  it('should transform details with nulls', () => {
    const mockResponse = cloneDeep(MOCK_PAY_STATEMENT_DETAILS_RESPONSE);
    mockResponse.payStatement.earnings = null;
    mockResponse.payStatement.deductionCategoryDetails = null;
    mockResponse.payStatement.deductions = null;
    mockResponse.payStatement.otherPay = null;
    mockResponse.payStatement.payDistributions = null;
    mockResponse.payStatement.directDeposits = null;
    mockResponse.payStatement.memos = null;

    statementDetails = transformStatementDetails(mockResponse);

    expect(statementDetails.earnings).toEqual([]);
    expect(statementDetails.deductionsCategories.length).toEqual(2);
    expect(statementDetails.deductionsCategories[0].id).toEqual('deductions');
    expect(statementDetails.deductionsCategories[1].id).toEqual('takeHome');
    expect(statementDetails.directDeposits).toBeNull();
    expect(statementDetails.memos.otherMemos).toBeNull();
    expect(statementDetails.memos.taxableBenefits).toBeNull();
  });

  describe('Should determine if there is YTD data', () => {
    it('should be false if gross is missing and category details and deductions are empty ', () => {
      const mockResponse = cloneDeep(
        MOCK_PAY_STATEMENT_DETAILS_RESPONSE
      );

      mockResponse.payStatement.grossPayYTDAmount = null;
      mockResponse.payStatement.deductionCategoryDetails = [];
      mockResponse.payStatement.deductions = [];
      statementDetails = transformStatementDetails(mockResponse);

      expect(statementDetails.hasYearToDateData).toBe(false);
    });

    it('should be true when grossPayYTDAmount is present and all categories have YTD amount', () => {
      const mockResponse = cloneDeep(MOCK_PAY_STATEMENT_DETAILS_RESPONSE);
      mockResponse.payStatement.deductionCategoryDetails = [
        {
          deductionCategoryCodeName: 'Taxes',
          deductionCategoryTotalYTDAmount: {
            amountValue: 10449.62,
            currencyCode: 'USD'
          }
        },
        {
          deductionCategoryCodeName: 'Benefits',
          deductionCategoryTotalYTDAmount: {
            amountValue: 3562,
            currencyCode: 'USD'
          }
        }
      ];
      mockResponse.payStatement.deductions = [
        {
          CodeName: 'Federal Income Tax        ',
          deductionCategoryCodeName: 'Taxes',
          deductionAmount: {
            amountValue: -392.97,
            currencyCode: 'USD'
          },
          preTaxIndicator: false
        },
        {
          CodeName: 'Tfb2 Other Ded            ',
          deductionCategoryCodeName: 'Benefits',
          deductionAmount: {
            amountValue: -12,
            currencyCode: 'USD'
          },
          preTaxIndicator: false
        }
      ];
      statementDetails = transformStatementDetails(mockResponse);

      expect(statementDetails.hasYearToDateData).toBe(true);
    });

    it('should be true when grossPayYTDAmount is present and all deduction items have YTD data', () => {
      const mockResponse = cloneDeep(MOCK_PAY_STATEMENT_DETAILS_RESPONSE);
      mockResponse.payStatement.deductionCategoryDetails = [
        {
          deductionCategoryCodeName: 'Taxes',
          deductionCategoryTotalYTDAmount: {
            amountValue: 10449.62,
            currencyCode: 'USD'
          }
        },
        {
          deductionCategoryCodeName: 'Benefits',
          deductionCategoryTotalPeriodAmount: {
            amountValue: -149,
            currencyCode: 'USD'
          }
        }
      ];
      mockResponse.payStatement.deductions = [
        {
          CodeName: 'Federal Income Tax        ',
          deductionCategoryCodeName: 'Taxes',
          deductionAmount: {
            amountValue: -392.97,
            currencyCode: 'USD'
          },
          deductionYTDAmount: {
            amountValue: 5190.64,
            currencyCode: 'USD'
          },
          preTaxIndicator: false
        },
        {
          CodeName: 'Tfb2 Other Ded            ',
          deductionCategoryCodeName: 'Benefits',
          deductionAmount: {
            amountValue: -12,
            currencyCode: 'USD'
          },
          deductionYTDAmount: {
            amountValue: 3562,
            currencyCode: 'USD'
          },
          preTaxIndicator: false
        }
      ];
      statementDetails = transformStatementDetails(mockResponse);

      expect(statementDetails.hasYearToDateData).toBe(true);
    });

    it('should be false when gross is 0 and categories and deductions are empty', () => {
      const mockResponse = cloneDeep(MOCK_PAY_STATEMENT_DETAILS_RESPONSE);
      mockResponse.payStatement.grossPayYTDAmount = { amountValue: 0, currencyCode: 'USD' };
      mockResponse.payStatement.deductionCategoryDetails = [];
      mockResponse.payStatement.deductions = [];

      statementDetails = transformStatementDetails(mockResponse);
      expect(statementDetails.hasYearToDateData).toBe(false);
    });

    it('should be true when gross is 0 and deductions net to 0', () => {
      const mockResponse = cloneDeep(MOCK_PAY_STATEMENT_DETAILS_RESPONSE);
      mockResponse.payStatement.grossPayYTDAmount = { amountValue: 0, currencyCode: 'USD' };
      mockResponse.payStatement.deductionCategoryDetails = [
        {
          deductionCategoryCodeName: 'Taxes',
          deductionCategoryTotalYTDAmount: {
            amountValue: 1000.0,
            currencyCode: 'USD'
          }
        },
        {
          deductionCategoryCodeName: 'Other',
          deductionCategoryTotalYTDAmount: {
            amountValue: -1000.0,
            currencyCode: 'USD'
          }
        }
      ];
      mockResponse.payStatement.deductions = [];

      statementDetails = transformStatementDetails(mockResponse);
      expect(statementDetails.hasYearToDateData).toBe(true);
    });

    it('should be true when gross is missing and a category detail has a YTD amount', () => {
      const mockResponse = cloneDeep(MOCK_PAY_STATEMENT_DETAILS_RESPONSE);
      mockResponse.payStatement.grossPayYTDAmount = null;
      mockResponse.payStatement.deductionCategoryDetails = [
        {
          deductionCategoryCodeName: 'Taxes',
          deductionCategoryTotalYTDAmount: {
            amountValue: 5000.0,
            currencyCode: 'USD'
          }
        },
        {
          deductionCategoryCodeName: 'Other',
          deductionCategoryTotalPeriodAmount: {
            amountValue: -392.97,
            currencyCode: 'USD'
          }
        }
      ];
      mockResponse.payStatement.deductions = [];

      statementDetails = transformStatementDetails(mockResponse);
      expect(statementDetails.hasYearToDateData).toBe(true);
    });

    it('should be false when gross is null and YTD value is 0 for a category detail', () => {
      const mockResponse = cloneDeep(MOCK_PAY_STATEMENT_DETAILS_RESPONSE);
      mockResponse.payStatement.grossPayYTDAmount = null;
      mockResponse.payStatement.deductionCategoryDetails = [
        {
          deductionCategoryCodeName: 'Other',
          deductionCategoryTotalYTDAmount: {
            amountValue: 0,
            currencyCode: 'USD'
          }
        }
      ];
      mockResponse.payStatement.deductions = [];

      statementDetails = transformStatementDetails(mockResponse);
      expect(statementDetails.hasYearToDateData).toBe(false);
    });

    it('should be false when gross is null and YTD value is null for a category detail', () => {
      const mockResponse = cloneDeep(MOCK_PAY_STATEMENT_DETAILS_RESPONSE);
      mockResponse.payStatement.grossPayYTDAmount = { amountValue: null, currencyCode: 'USD' };
      mockResponse.payStatement.deductionCategoryDetails = [
        {
          deductionCategoryCodeName: 'Taxes',
          deductionCategoryTotalYTDAmount: {
            amountValue: null,
            currencyCode: 'USD'
          }
        }
      ];
      mockResponse.payStatement.deductions = [];

      statementDetails = transformStatementDetails(mockResponse);
      expect(statementDetails.hasYearToDateData).toBe(false);
    });

    it('should be true when gross is missing and no incomplete YTD deductions ', () => {
      const mockResponse = cloneDeep(MOCK_PAY_STATEMENT_DETAILS_RESPONSE);
      mockResponse.payStatement.grossPayYTDAmount = null;
      mockResponse.payStatement.deductionCategoryDetails = [
        {
          deductionCategoryCodeName: 'Taxes',
          deductionCategoryTotalYTDAmount: {
            amountValue: 10449.62,
            currencyCode: 'USD'
          }
        },
        {
          deductionCategoryCodeName: 'Benefits',
          deductionCategoryTotalYTDAmount: {
            amountValue: 3562,
            currencyCode: 'USD'
          }
        }
      ];
      mockResponse.payStatement.deductions = [
        {
          CodeName: 'Federal Income Tax        ',
          deductionCategoryCodeName: 'Taxes',
          deductionYTDAmount: {
            amountValue: -392.97,
            currencyCode: 'USD'
          },
          preTaxIndicator: false
        },
        {
          CodeName: 'Tfb2 Other Ded            ',
          deductionCategoryCodeName: 'Benefits',
          deductionYTDAmount: {
            amountValue: 312,
            currencyCode: 'USD'
          },
          preTaxIndicator: false
        }
      ];

      statementDetails = transformStatementDetails(mockResponse);
      expect(statementDetails.hasYearToDateData).toBe(true);
    });

    it('should be true when gross is present and a deduction has incomplete YTD data', () => {
      const mockResponse = cloneDeep(MOCK_PAY_STATEMENT_DETAILS_RESPONSE);
      mockResponse.payStatement.grossPayYTDAmount = { amountValue: 34000, currencyCode: 'USD' };
      mockResponse.payStatement.deductionCategoryDetails = [
        {
          deductionCategoryCodeName: 'Taxes',
          deductionCategoryTotalYTDAmount: {
            amountValue: 10449.62,
            currencyCode: 'USD'
          }
        },
        {
          deductionCategoryCodeName: 'Benefits'
        }
      ];
      mockResponse.payStatement.deductions = [
        {
          CodeName: 'Federal Income Tax        ',
          deductionCategoryCodeName: 'Taxes',
          deductionYTDAmount: {
            amountValue: -392.97,
            currencyCode: 'USD'
          },
          preTaxIndicator: false
        },
        {
          CodeName: 'Tfb2 Other Ded            ',
          deductionCategoryCodeName: 'Benefits',
          deductionAmount: {
            amountValue: -125,
            currencyCode: 'USD'
          },
          preTaxIndicator: false
        }
      ];

      statementDetails = transformStatementDetails(mockResponse);
      expect(statementDetails.hasYearToDateData).toBe(true);
    });

    it('should be false when gross YTD is missing and has deductionAmounts and no YTD data', () => {
      const mockResponse = cloneDeep(MOCK_PAY_STATEMENT_DETAILS_RESPONSE);
      mockResponse.payStatement.grossPayYTDAmount = null;
      mockResponse.payStatement.deductionCategoryDetails = [
        {
          deductionCategoryCodeName: 'Taxes',
          deductionCategoryTotalPeriodAmount: {
            amountValue: -392.97,
            currencyCode: 'USD'
          }
        }
      ];
      mockResponse.payStatement.deductions = [
        {
          CodeName: 'Federal Income Tax        ',
          deductionCategoryCodeName: 'Taxes',
          deductionAmount: {
            amountValue: -392.97,
            currencyCode: 'USD'
          },
          preTaxIndicator: false
        }
      ];
      statementDetails = transformStatementDetails(mockResponse);
      expect(statementDetails.hasYearToDateData).toBe(false);
    });
  });
});
