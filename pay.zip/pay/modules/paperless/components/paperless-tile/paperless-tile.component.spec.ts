import { Shallow } from 'shallow-render';
import { Mock } from 'ts-mockery';

import { LanguagePipe, QueryParamsService } from '@myadp/common';

import { PageType } from '@myadp/pay-paperless-shared';
import { PAY_DEEP_LINKS } from '@myadp/pay-shared';
import { PaperlessModule } from '../../paperless.module';
import { PaperlessViewWrapperComponent } from '../paperless-view-wrapper/paperless-view-wrapper.component';
import { PaperlessTileComponent } from './paperless-tile.component';

describe('PaperlessTileComponent', () => {
  let shallow: Shallow<PaperlessTileComponent>;
  let mockPaperlessViewWrapperComponent: PaperlessViewWrapperComponent;

  beforeEach(() => {
    mockPaperlessViewWrapperComponent = Mock.of<PaperlessViewWrapperComponent>({
      setDisplaySettingsModal: () => Mock.noop,
      pageType: null
    });

    shallow = new Shallow(PaperlessTileComponent, PaperlessModule)
      .mock(PaperlessViewWrapperComponent, mockPaperlessViewWrapperComponent)
      .mock(QueryParamsService, {
        getParameterValue: () => null
      })
      .mockPipe(LanguagePipe, (key) => key);
  });

  it('should init with the Pay page type', async () => {
    const { findComponent } = await shallow.render({
      bind: {
        pageType: PageType.PAY
      }
    });

    expect(findComponent(PaperlessViewWrapperComponent).pageType).toBe(PageType.PAY);
  });

  it('should init with the Retirement page type', async () => {
    const { findComponent } = await shallow.render({
      bind: {
        pageType: PageType.RETIREMENT
      }
    });

    expect(findComponent(PaperlessViewWrapperComponent).pageType).toBe(PageType.RETIREMENT);
  });

  it('should init with the Settings page type', async () => {
    const { findComponent } = await shallow.render({
      bind: {
        pageType: PageType.SETTINGS
      }
    });

    expect(findComponent(PaperlessViewWrapperComponent).pageType).toBe(PageType.SETTINGS);
  });

  it('should init with the Campaign page type', async () => {
    const { findComponent } = await shallow.render({
      bind: {
        pageType: PageType.CAMPAIGN
      }
    });

    expect(findComponent(PaperlessViewWrapperComponent).pageType).toBe(PageType.CAMPAIGN);
  });

  describe('auto open modal', () => {
    it('should handle when auto open is go-paperless', async () => {
      await shallow
        .mock(QueryParamsService, {
          getParameterValue: () => PAY_DEEP_LINKS.GoPaperless
        })
        .render();

      expect(mockPaperlessViewWrapperComponent.setDisplaySettingsModal).toHaveBeenCalledWith(true);
    });

    it('should not open when auto open is for non go-paperless', async () => {
      await shallow
        .mock(QueryParamsService, {
          getParameterValue: () => PAY_DEEP_LINKS.DirectDeposit
        })
        .render();

      expect(mockPaperlessViewWrapperComponent.setDisplaySettingsModal).not.toHaveBeenCalled();
    });
  });

});
