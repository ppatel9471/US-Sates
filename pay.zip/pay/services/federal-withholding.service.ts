import { Injectable } from '@angular/core';
import { get } from 'lodash';
import { from, Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { BaseHttpClient } from '@myadp/common';
import { PAY_SFFO } from '@myadp/pay-shared';

import { WorkflowStatus } from '../models/tax-withholding.model';
import { UsFederalTaxWithholdingElections } from '../models/us-federal-tax-withholding-election.model';
import { FederalWithholdingTransformService } from '../modules/shared/services/federal-withholding-transform.service';
import { WorkerUSWithholdingElectionChangeResponse } from '../modules/tax-withholding-management/us/shared/models/state-income-tw-election-event';

@Injectable({
  providedIn: 'root'
})
export class FederalWithholdingService {
  constructor(
    private baseHttpClient: BaseHttpClient,
    private federalWithholdingTransformService: FederalWithholdingTransformService
  ) {}

  public getFederalWithholding(): Promise<UsFederalTaxWithholdingElections> {
    return this.baseHttpClient.get<UsFederalTaxWithholdingElections>({
      userPermission: PAY_SFFO.TAX_WITHHOLDING_FEDERAL_READ
    });
  }

  public saveWithholding(body: Object): Observable<WorkerUSWithholdingElectionChangeResponse> {
    return from(
      this.baseHttpClient.post<WorkerUSWithholdingElectionChangeResponse>({
        userPermission: PAY_SFFO.TAX_WITHHOLDING_FEDERAL_CHANGE,
        payload: body
      })
    );
  }

  public recallWithholding(): Observable<WorkflowStatus> {
    return from(
      this.baseHttpClient.post<WorkflowStatus>({
        userPermission: PAY_SFFO.TAX_WITHHOLDING_FEDERAL_CHANGE,
        useWorkflow: true,
        urlTransform: (url: string) => `/recall${url}`
      })
    );
  }

  public isFederalWithholdingComplete(): Observable<boolean> {
    return from(this.getFederalWithholding()).pipe(
      map((withholdings) => {
        const withholdingItems =
          this.federalWithholdingTransformService.getWithholdingItems(withholdings);
        return get(withholdingItems, '0.isCompleted', false);
      })
    );
  }
}
