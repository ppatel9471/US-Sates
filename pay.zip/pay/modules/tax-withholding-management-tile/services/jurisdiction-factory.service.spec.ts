import { Injector } from '@angular/core';
import { Mock } from 'ts-mockery';

import { getState } from '../../../models/states.model';
import { DoneMetaDataService } from '../../tax-withholding-management/shared/services/done-meta-data.service';
import { ESignMetaDataService } from '../../tax-withholding-management/shared/services/esign-meta-data.service';
import { StepNavigationBaseService } from '../../tax-withholding-management/shared/services/step-navigation-base.service';
import { FedAttachmentCodes } from '../../tax-withholding-management/us/fed/models/fed-tw-change-event';
import { FEDSTEP_COMPONENT } from '../../tax-withholding-management/us/fed/models/steps-component.model';
import { FEDSTEPS } from '../../tax-withholding-management/us/fed/models/steps.enum';
import { FedDoneMetaDataService } from '../../tax-withholding-management/us/fed/services/done-meta-data.service';
import { FedStepNavigationService } from '../../tax-withholding-management/us/fed/services/fed-step-navigation.service';
import { FedSummaryMetaDataService } from '../../tax-withholding-management/us/fed/services/fed-summary-meta-data.service';
import { FedTWChangeEventService } from '../../tax-withholding-management/us/fed/services/fed-tw-change-event.service';
import { GaAttachmentCodes } from '../../tax-withholding-management/us/ga/models/ga-tw-change-event';
import { GASTEP_COMPONENT } from '../../tax-withholding-management/us/ga/models/steps-component.model';
import { GaStepNavigationService } from '../../tax-withholding-management/us/ga/services/ga-step-navigation.service';
import { GaSummaryMetaDataService } from '../../tax-withholding-management/us/ga/services/ga-summary-meta-data.service';
import { GaTWChangeEventService } from '../../tax-withholding-management/us/ga/services/ga-tw-change-event.service';
import { NyDoneMetaDataService } from '../../tax-withholding-management/us/ny/services/done-meta-data.service';
import { PaESignMetaDataService } from '../../tax-withholding-management/us/pa/services/pa-esign-meta-data.service';
import { SHARED_STEPS } from '../../tax-withholding-management/us/shared/models/steps.enum';
import { JurisdictionFactoryService } from './jurisdiction-factory.service';

describe('JurisdictionFactoryService', () => {
  let jurisdictionFactory: JurisdictionFactoryService;
  let mockInjector: Injector;

  beforeEach(() => {
    mockInjector = Mock.of({
      get: () => ''
    });

    jurisdictionFactory = new JurisdictionFactoryService(mockInjector);
  });

  describe('getDoneMetaDataService', () => {
    it('should get federal', () => {
      jurisdictionFactory.getDoneMetaDataService(getState('federal'));
      expect(mockInjector.get).toHaveBeenCalledWith(FedDoneMetaDataService);
    });

    it('should get NY', () => {
      jurisdictionFactory.getDoneMetaDataService(getState('NY'));
      expect(mockInjector.get).toHaveBeenCalledWith(NyDoneMetaDataService);
    });

    it('should get shared', () => {
      jurisdictionFactory.getDoneMetaDataService(getState('GA'));
      expect(mockInjector.get).toHaveBeenCalledWith(DoneMetaDataService);
    });
  });

  describe('getESignMetaDataService', () => {
    it('should get PA', () => {
      jurisdictionFactory.getESignMetaDataService(getState('PA'));
      expect(mockInjector.get).toHaveBeenCalledWith(PaESignMetaDataService);
    });

    it('should get shared', () => {
      jurisdictionFactory.getESignMetaDataService(getState('GA'));
      expect(mockInjector.get).toHaveBeenCalledWith(ESignMetaDataService);
    });
  });

  describe('getTwChangeEventService', () => {
    it('should get federal', () => {
      jurisdictionFactory.getTwChangeEventService(getState('federal'));
      expect(mockInjector.get).toHaveBeenCalledWith(FedTWChangeEventService);
    });

    it('should get a state', () => {
      jurisdictionFactory.getTwChangeEventService(getState('GA'));
      expect(mockInjector.get).toHaveBeenCalledWith(GaTWChangeEventService);
    });

    it('should get a state without change events', () => {
      const retVal = jurisdictionFactory.getTwChangeEventService(getState('PA2020'));
      expect(mockInjector.get).not.toHaveBeenCalled();
      expect(retVal).toBeUndefined();
    });
  });

  describe('getStepComponents', () => {
    it('should get federal', () => {
      const stepComponents = jurisdictionFactory.getStepComponents(getState('federal'));
      expect(stepComponents).toEqual(FEDSTEP_COMPONENT);
    });

    it('should get a state', () => {
      const stepComponents = jurisdictionFactory.getStepComponents(getState('GA'));
      expect(stepComponents).toEqual(GASTEP_COMPONENT);
    });

    // TODO(PIMYPI-17519): add a unit test for a state that has secondaryForms (MA)
  });

  describe('getStepsMetaData', () => {
    it('should get federal', () => {
      const stepsMetaData = jurisdictionFactory.getStepsMetaData(getState('federal'));
      expect(stepsMetaData).toEqual({
        ...FEDSTEPS,
        ...SHARED_STEPS
      });
    });

    it('should get a state that has a decorator', () => {
      const mockDecoratedSteps = SHARED_STEPS;
      mockInjector = Mock.of({
        get: () => {
          return { decorate: () => mockDecoratedSteps };
        }
      });
      jurisdictionFactory = new JurisdictionFactoryService(mockInjector);
      const stepsMetaData = jurisdictionFactory.getStepsMetaData(getState('MS'));
      expect(stepsMetaData).toEqual(mockDecoratedSteps);
    });
  });

  describe('getStepNavigationService', () => {
    it('should get federal', () => {
      jurisdictionFactory.getStepNavigationService(getState('federal'));
      expect(mockInjector.get).toHaveBeenCalledWith(FedStepNavigationService);
    });

    it('should get GA', () => {
      jurisdictionFactory.getStepNavigationService(getState('GA'));
      expect(mockInjector.get).toHaveBeenCalledWith(GaStepNavigationService);
    });

    it('should get shared', () => {
      jurisdictionFactory.getStepNavigationService(getState('NY'));
      expect(mockInjector.get).toHaveBeenCalledWith(StepNavigationBaseService);
    });
  });

  describe('getSummaryMetaDataService', () => {
    it('should get federal', () => {
      jurisdictionFactory.getSummaryMetaDataService(getState('federal'));
      expect(mockInjector.get).toHaveBeenCalledWith(FedSummaryMetaDataService);
    });

    it('should get a state', () => {
      jurisdictionFactory.getSummaryMetaDataService(getState('GA'));
      expect(mockInjector.get).toHaveBeenCalledWith(GaSummaryMetaDataService);
    });

    it('should get a state without summary service', () => {
      const retVal = jurisdictionFactory.getSummaryMetaDataService(getState('PA2020'));
      expect(mockInjector.get).not.toHaveBeenCalled();
      expect(retVal).toBeUndefined();
    });
  });

  describe('getAttachmentNameCode', () => {
    it('should get federal', () => {
      const code = jurisdictionFactory.getAttachmentNameCode(getState('federal'));
      expect(code).toEqual(FedAttachmentCodes[0].data);
    });

    it('should get a state', () => {
      const code = jurisdictionFactory.getAttachmentNameCode(getState('GA'));
      expect(code).toEqual(GaAttachmentCodes[0].data);
    });
  });
});
