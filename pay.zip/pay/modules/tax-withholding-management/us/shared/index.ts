import { FedMaritalStatusComponent } from './steps/fed-marital-status/fed-marital-status.component';
import { FedPersonalInfoComponent } from './steps/fed-personal-info/fed-personal-info.component';
import { WorkerInfoComponent } from './steps/worker-info/worker-info.component';

export const US_SHARED_COMPONENTS = [
  WorkerInfoComponent,
  FedPersonalInfoComponent,
  FedMaritalStatusComponent
];
