export { TaxWithholdingManagementTileModule } from './modules/tax-withholding-management-tile/tax-withholding-management-tile.module';

export { TaxWithholdingManagementTileComponent } from './modules/tax-withholding-management-tile/components/tax-withholding-management-tile/tax-withholding-management-tile.component';
