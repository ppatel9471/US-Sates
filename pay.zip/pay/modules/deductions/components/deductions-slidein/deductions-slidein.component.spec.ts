import { CurrencyPipe } from '@angular/common';
import { ModalComponent } from '@synerg/components/modal';
import { of } from 'rxjs';
import { Shallow } from 'shallow-render';
import { Mock } from 'ts-mockery';

import { LanguagePipe, LanguageService } from '@myadp/common';

import { CloseConfirmComponent } from '../../../shared/components/close-confirm/close-confirm.component';
import { DeductionsModule } from '../../deductions.module';
import { DeductionsStoreActions } from '../../store/deductions-store.actions';
import { DeductionsStore } from '../../store/deductions.store';
import { StepsStoreActions } from '../../store/steps/steps-store.actions';
import { StepsStore } from '../../store/steps/steps.store';
import { DeductionsSlideinComponent } from './deductions-slidein.component';

describe('DeductionsSlideinComponent', () => {
  let shallow: Shallow<DeductionsSlideinComponent>;
  const slideinElm = 'adp-slidein';

  beforeEach(() => {
    shallow = new Shallow(DeductionsSlideinComponent, DeductionsModule)
      .provide(CurrencyPipe, LanguageService)
      .dontMock(CurrencyPipe, CloseConfirmComponent, ModalComponent)
      .mock(StepsStore, {
        showStepNavigation$: of(true)
      })
      .mock(DeductionsStore, {
        hasDeductions: true
      })
      .mock(DeductionsStoreActions, {
        loadStartMeta: () => Mock.noop()
      })
      .mock(StepsStoreActions, {
        hasFormDetailChanges: () => false,
        openSlidein: () => Mock.noop(),
        closeSlidein: () => Mock.noop(),
        resetCurrentStep: () => Mock.noop()
      })
      .mockPipe(LanguagePipe, (key) => key);
  });

  describe('openSlidein()', () => {
    it('should load start meta when opening the slide-in and there are deductions', async () => {
      const { get } = await shallow.render();
      expect(get(DeductionsStoreActions).loadStartMeta).toHaveBeenCalledTimes(1);
    });

    it('should not load start meta when opening the slide-in when there are no deductions', async () => {
      const { get } = await shallow
        .mock(DeductionsStore, {
          hasDeductions: false
        })
        .render();
      expect(get(DeductionsStoreActions).loadStartMeta).not.toHaveBeenCalledTimes(1);
    });
  });

  describe('closeSlidein()', () => {
    it('should reset current step and emit closed', async () => {
      const { instance, outputs, fixture, get } = await shallow.render();

      instance.closeSlidein();
      fixture.detectChanges();

      expect(outputs.closed.emit).toHaveBeenCalled();
      expect(get(StepsStoreActions).closeSlidein).toHaveBeenCalledTimes(1);
      expect(get(StepsStoreActions).resetCurrentStep).toHaveBeenCalledTimes(1);
    });
  });

  describe('Confirm Cancel modal', () => {
    const closeConfirmModal = 'close-confirm adp-modal';

    it('PIMYPI-T926 should close modal and slide-in when clicking exit', async () => {
      const { find, instance, outputs, fixture, get } = await shallow.render();
      instance.showConfirmCancelModal = true;
      fixture.detectChanges();

      expect(find(closeConfirmModal)).toHaveFound(1);

      const yesBtn = find('close-confirm #confirm-button').nativeElement;
      yesBtn.click();
      fixture.detectChanges();

      expect(find(closeConfirmModal)).toHaveFound(0);
      expect(instance.showConfirmCancelModal).toBe(false);
      expect(get(StepsStoreActions).closeSlidein).toHaveBeenCalledTimes(1);
      expect(outputs.closed.emit).toHaveBeenCalled();
    });

    it('PIMYPI-T927 should close modal when clicking cancel or "X" button', async () => {
      const { find, instance, outputs, fixture, get } = await shallow.render();
      instance.showConfirmCancelModal = true;
      fixture.detectChanges();

      // Test for "Cancel" button
      expect(find(closeConfirmModal)).toHaveFound(1);

      const noBtn = find('close-confirm #cancel-button').nativeElement;
      noBtn.click();
      fixture.detectChanges();

      expect(find(closeConfirmModal)).toHaveFound(0);
      expect(instance.showConfirmCancelModal).toBe(false);
      expect(get(StepsStoreActions).closeSlidein).not.toHaveBeenCalled();
      expect(find(slideinElm)).toHaveFound(1);
      expect(outputs.closed.emit).not.toHaveBeenCalled();

      // Test again for "X" button
      instance.showConfirmCancelModal = true;
      fixture.detectChanges();

      expect(find(closeConfirmModal)).toHaveFound(1);

      const closeBtn = find('close-confirm .vdl-modal__close').nativeElement;
      closeBtn.click();
      fixture.detectChanges();

      expect(find(closeConfirmModal)).toHaveFound(0);
      expect(instance.showConfirmCancelModal).toBe(false);
      expect(get(StepsStoreActions).closeSlidein).not.toHaveBeenCalled();
      expect(find(slideinElm)).toHaveFound(1);
      expect(outputs.closed.emit).not.toHaveBeenCalled();
    });

    it('PIMYPI-T928 should show close confirm modal', async () => {
      const { find, findComponent, instance, fixture } = await shallow.render();
      instance.showConfirmCancelModal = true;
      fixture.detectChanges();

      expect(find(slideinElm)).toHaveFound(1);
      expect(find(closeConfirmModal)).toHaveFound(1);
      expect(findComponent(ModalComponent)).toHaveFound(1);
      expect(findComponent(ModalComponent).closeable).toBe(true);
      expect(find('close-confirm .modal-title').nativeElement.textContent).toContain(
        'common.ARE_YOU_SURE'
      );
      expect(find(closeConfirmModal)).toHaveFound(1);
      expect(find('close-confirm .modal-body').nativeElement.textContent).toContain(
        'myadp-pay.FORCED_DIALOG_CLOSE_CONFIRM_MESSAGE'
      );
      expect(find('close-confirm .modal-footer adp-button')).toHaveFound(2);
      expect(find('close-confirm #cancel-button').nativeElement.textContent).toContain(
        'common.CANCEL'
      );
      expect(find('close-confirm #confirm-button').nativeElement.textContent).toContain(
        'common.EXIT'
      );
    });
  });
});
