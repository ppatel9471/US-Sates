import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Mock } from 'ts-mockery';

import {
  MessageCenterNotificationDto,
  Notification,
  NOTIFICATION_CODE_TYPES,
  NOTIFICATION_LABEL_TYPES
} from '@myadp/thingstodo-shared';

import { PayTasksService } from '../../shared/services/pay-tasks.service';
import { DeductionTaskService } from './deduction-tasks.service';
import { DeductionDetails } from '../models/deduction-details';

describe('DeductionTaskService', () => {
  let deductionTaskService: DeductionTaskService;

  const mockNotification: Partial<Notification> = {
    uri: '/v1_0/O/A/notification/2218056821/Task'
  };

  const mockTask: { [key: string]: Partial<MessageCenterNotificationDto> } = {
    notification: {
      actions: [
        {
          labelName: 'Approve',
          uris: [
            {
              href: '/core/v1/notification/1234/approval/approve'
            }
          ]
        }
      ],
      relatedAssociateRef: {
        formattedName: 'myName',
        associateOID: 'myAoid'
      },
      eventNameCode: 'worker.workerGeneralDeductionInstruction.change'
    }
  };

  const mockTaskDetail = {
    currentData: {
      workerGeneralDeductionInstructions: [
        {
          generalDeductionInstructions: [
            {
              itemID: 'A',
              deductionCode: {
                codeValue: 'A',
                longName: 'Medicare Surtax'
              },
              deductionRate: {
                rateValue: 100,
                currencyCode: 'USD'
              },
              deductionGoal: {
                goalBalanceAmount: {
                  amountValue: 0,
                  currencyCode: 'USD'
                },
                goalLimitAmount: {
                  amountValue: 0,
                  currencyCode: 'USD'
                }
              }
            }
          ]
        }
      ]
    },
    pendingEvents: [
      {
        resourcePath: '/events/payroll/v1/worker-general-deduction-instruction.change',
        body: {
          events: [
            {
              data: {
                transform: {
                  workerGeneralDeductionInstruction: {
                    generalDeductionInstruction: {
                      deductionRate: {
                        rateValue: '200',
                        currencyCode: 'USD'
                      },
                      deductionGoal: {
                        goalLimitAmount: {
                          amountValue: 0,
                          currencyCode: 'USD'
                        }
                      }
                    }
                  }
                },
                eventContext: {
                  worker: {
                    associateOID: 'G3NVBKA5GXDASSZX'
                  },
                  workerGeneralDeductionInstruction: {
                    generalDeductionInstruction: {
                      itemID: 'A'
                    }
                  }
                }
              }
            }
          ]
        }
      }
    ]
  };

  let mockPayTasksService: PayTasksService;

  beforeEach(() => {
    mockPayTasksService = Mock.of<PayTasksService>({
      getTaskData: () => Promise.resolve(mockTask),
      getTaskDetail: () => Promise.resolve(mockTaskDetail),
      getTaskId: () => '1234'
    });

    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        DeductionTaskService,
        {
          provide: PayTasksService,
          useValue: mockPayTasksService
        }
      ]
    });

    deductionTaskService = TestBed.inject(DeductionTaskService);
  });

  it('should get getDeductionDetails for a task', (done: DoneFn) => {
    mockNotification.notificationType = {
      code: NOTIFICATION_CODE_TYPES.TASK,
      labelName: NOTIFICATION_LABEL_TYPES.TASK
    };

    deductionTaskService
      .getDeductionDetails(<Notification>mockNotification)
      .then((res: DeductionDetails) => {
        const comparisonData = res.comparisonData;
        expect(comparisonData.type).toEqual('change');
        expect(comparisonData.itemID).toEqual('A');
        expect(mockPayTasksService.getTaskData).toHaveBeenCalled();
        expect(mockPayTasksService.getTaskId).toHaveBeenCalled();
        expect(mockPayTasksService.getTaskDetail).toHaveBeenCalledWith(
          '/wf/payroll/v1/workers/myAoid/worker-general-deduction-instructions?taskId=1234'
        );
        done();
      });
  });

  it('should get getDeductionDetails for a notification', (done: DoneFn) => {
    mockNotification.notificationType = {
      code: NOTIFICATION_CODE_TYPES.NOTIFICATION,
      labelName: NOTIFICATION_LABEL_TYPES.NOTIFICATION
    };
    mockNotification.relatedAssociateRef = {
      name: 'myName',
      aoid: 'myAoid'
    };
    mockNotification.notificationId = '123456';

    deductionTaskService
      .getDeductionDetails(<Notification>mockNotification)
      .then((res: DeductionDetails) => {
        const comparisonData = res.comparisonData;
        expect(comparisonData.type).toEqual('change');
        expect(comparisonData.itemID).toEqual('A');
        expect(mockPayTasksService.getTaskData).not.toHaveBeenCalled();
        expect(mockPayTasksService.getTaskId).not.toHaveBeenCalled();
        expect(mockPayTasksService.getTaskDetail).toHaveBeenCalledWith(
          '/wf/payroll/v1/workers/myAoid/worker-general-deduction-instructions?notificationId=123456'
        );
        done();
      });
  });
});
