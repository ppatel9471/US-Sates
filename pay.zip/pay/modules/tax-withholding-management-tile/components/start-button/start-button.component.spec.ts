import { Shallow } from 'shallow-render';
import { LanguagePipe } from '@myadp/common';

import { TaxWithholdingManagementTileModule } from '../../tax-withholding-management-tile.module';
import { StartButtonComponent } from './start-button.component';

describe('StartButtonComponent', () => {
  let shallow: Shallow<StartButtonComponent>;

  beforeEach(() => {
    shallow = new Shallow(StartButtonComponent, TaxWithholdingManagementTileModule).mockPipe(
      LanguagePipe,
      (key) => key
    );
  });

  it('should show the start button if edit permissions are present', async () => {
    const { find } = await shallow.render(
      `<start-button [hasEditPermission]="editPermission"></start-button>`,
      {
        bind: {
          editPermission: true
        }
      }
    );

    expect(find('[data-e2e="start-button"]')).toHaveFound(1);
  });

  it('should hide the start button and show an alert if edit permissions are missing', async () => {
    const { find } = await shallow.render(
      `<start-button [hasEditPermission]="editPermission"></start-button>`,
      {
        bind: {
          editPermission: false
        }
      }
    );

    expect(find('[data-e2e="start-button"]')).toHaveFound(0);
    expect(find('[data-e2e="start-button-alert"]')).toHaveFound(1);
  });

  it('should handle clicking the start button', async () => {
    const { find, bindings } = await shallow.render(
      `<start-button [hasEditPermission]="editPermission" (clickStartButton)="clickStart()"></start-button>`,
      {
        bind: {
          editPermission: true,
          clickStart: () => undefined
        }
      }
    );
    find('adp-button').nativeElement.click();

    expect(bindings.clickStart).toHaveBeenCalled();
  });
});
