import { Shallow } from 'shallow-render';

import { LanguagePipe } from '@myadp/common';

import { WorkflowUI } from '../../models/workflow-ui.model';
import { SharedModule } from '../../shared.module';
import { WorkflowComparisonContainerComponent } from './workflow-comparison-container.component';

describe('WorkflowComparisonContainerComponent', () => {
  let shallow: Shallow<WorkflowComparisonContainerComponent<any>>;
  const mockData: WorkflowUI.WorkflowData<Record<string, any>> = {
    currentData: {
      name: 'Wanda',
      power: 'Magic'
    },
    pendingData: {
      name: 'Scarlett Witch',
      power: 'Magic but stronger'
    },
    pendingEvent: { changeType: 'edit', approver: 'Harkness, Agatha' }
  };

  beforeEach(() => {
    shallow = new Shallow(WorkflowComparisonContainerComponent, SharedModule).mockPipe(
      LanguagePipe,
      (key: string) => key
    );
  });

  describe('Alerts', () => {
    const alertSelector = 'adp-alert.wf-alert';

    it('PIMYPI-T878 should display an alert when there is a pending add', async () => {
      const { find } = await shallow.render({
        bind: {
          data: {
            ...mockData,
            currentData: null,
            pendingEvent: { ...mockData.pendingEvent, changeType: 'add' }
          }
        }
      });

      expect(find(alertSelector).nativeElement.innerHTML).toContain(
        'myadp-pay.WORKFLOW_PENDING_ADD_ALERT'
      );
    });

    it('PIMYPI-T879 should display an alert when there is a pending edit', async () => {
      const { find } = await shallow.render({
        bind: {
          data: mockData
        }
      });

      expect(find(alertSelector).nativeElement.innerHTML).toContain(
        'myadp-pay.WORKFLOW_PENDING_EDIT_ALERT'
      );
    });

    it('PIMYPI-T880 should display an alert when there is a pending delete', async () => {
      const { find } = await shallow.render({
        bind: {
          data: {
            ...mockData,
            pendingData: null,
            pendingEvent: { ...mockData.pendingEvent, changeType: 'delete' }
          }
        }
      });

      expect(find(alertSelector).nativeElement.innerHTML).toContain(
        'myadp-pay.WORKFLOW_PENDING_DELETE_ALERT'
      );
    });
  });

  describe('Details Comparison', () => {
    it('should display the given projected view', async () => {
      const { find } = await shallow.render(
        `<pay-workflow-comparison-container [data]="mockData">
      <adp-button id="some-btn" class="wf-details-comparison">
        Button text
      </adp-button>
      </pay-workflow-comparison-container>`,
        {
          bind: {
            data: mockData
          }
        }
      );

      expect(find('.wf-details-comparison')).toHaveFound(1);
      expect(find('adp-button[id="some-btn"]')).toHaveFound(1);
    });
  });

  describe('Cancel Request', () => {
    const btnSelector = 'adp-button.wf-cancel-request-btn';

    it('should emit the data when canceling a request', async () => {
      const { find, outputs } = await shallow.render({
        bind: {
          data: mockData
        }
      });
      find(btnSelector).nativeElement.click();

      expect(outputs.cancelRequest.emit).toHaveBeenCalledWith(mockData);
    });
  });
});
