import * as moment from 'moment';

import { PayStatementsDTO } from '@myadp/dto';

import { formatDate } from '../../shared/models/utils';
import { FISCAL_YEAR_CONFIG } from '../constants/fiscal-year-config';
import { PayStatementsUI } from '../models/pay-statement-ui';
import { PayStatementType } from '../models/pay-statement.type';

export interface TransformConfig {
  SOR: string;
  TRANSLATIONS?: Record<string, string>;
}

export function transformStatements(
  response: PayStatementsDTO.APIResponse,
  transformConfig: TransformConfig
): PayStatementsUI.PayStatement[] {
  const statementsRaw = response?.payStatements;

  return (
    statementsRaw
      ?.map((statement) => {
        const formattedPayDate =
          formatDate(statement?.payDate) ?? transformConfig.TRANSLATIONS.UNKNOWN_DATE;
        const payAdjustmentIndicator = statement?.payAdjustmentIndicator;

        return {
          payDate: formattedPayDate,
          netPay: statement?.netPayAmount,
          grossPay: statement?.grossPayAmount,
          totalHours: statement?.totalHours,
          payDetailUri: statement?.payDetailUri?.href,
          statementImageUri: statement?.statementImageUri?.href,
          payAdjustment: payAdjustmentIndicator,
          statementFiscalYear: setFiscalYear(statement?.payDate, transformConfig),
          statementType: setStatementType(
            payAdjustmentIndicator ? PayStatementType.ADJUSTMENT : null,
            transformConfig
          )
        };
      })
      // sort statements by payDate in descending order
      // if payDate is the same, that adjustments statements are sorted to be last in the list
      ?.sort((a, b) => {
        const statementADate = new Date(a.payDate).getTime();
        const statementBDate = new Date(b.payDate).getTime();
        if (statementADate === statementBDate) {
          return a.payAdjustment ? 1 : b.payAdjustment ? -1 : statementBDate - statementADate;
        }
        return statementBDate - statementADate;
      })
      ?.map((statement: PayStatementsUI.PayStatement, index) => ({
        ...statement,
        id: index + 1 // apply id after sorting for a ranked list of statements
      })) ?? []
  );
}

function setFiscalYear(date: string, transformConfig: TransformConfig): string {
  const formattedDate = formatDate(date, 'YYYY-MM-DD');
  const fyConfig = FISCAL_YEAR_CONFIG[transformConfig.SOR];
  const dates = {
    statementDate: moment(formattedDate),
    statementYear: moment(formattedDate).year(),
    previousYear: moment(formattedDate).add(-1, 'years').year(),
    nextYear: moment(formattedDate).add(1, 'years').year()
  };

  // Check for missing or bad dates (NaN)
  Object.keys(dates).forEach((key) => {
    dates[key] = isNaN(dates[key]) ? transformConfig.TRANSLATIONS.UNKNOWN_DATE : dates[key];
  });

  if (fyConfig) {
    // latest possible fiscal year for statement
    const config = {
      fyStart: moment(`${fyConfig.start.month}/${fyConfig.start.day - 1}/${dates.statementYear}`),
      fyEnd: moment(`${fyConfig.start.month}/${fyConfig.start.day}/${dates.statementYear + 1}`)
    };

    const isInLatestFiscalYear = moment(dates.statementDate).isBetween(
      config.fyStart,
      config.fyEnd
    );

    return isInLatestFiscalYear
      ? `${dates.statementYear} - ${dates.nextYear}`
      : `${dates.previousYear} - ${dates.statementYear}`;
  } else {
    return dates.statementYear.toString();
  }
}

function setStatementType(type: string, transformConfig: TransformConfig): string {
  const lookup = {
    adjustment: transformConfig.TRANSLATIONS.ADJUSTMENT
  };

  return lookup[type];
}
