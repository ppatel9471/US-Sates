import { Injectable, Injector } from '@angular/core';
import { ClientDeviceService } from '@espresso/core';

import { PayDashboardTileMobileService } from './pay-dashboard-tile-mobile.service';
import { PayDashboardTileService } from './pay-dashboard-tile.service';

@Injectable({
  providedIn: 'root'
})
export class PayDashboardTileServiceFactory {
  constructor(private injector: Injector, private clientDeviceService: ClientDeviceService) {}

  getPayDashboardTileService() {
    if (this.clientDeviceService.isNative()) {
      return this.injector.get<PayDashboardTileMobileService>(PayDashboardTileMobileService);
    }
    return this.injector.get<PayDashboardTileService>(PayDashboardTileService);
  }
}
