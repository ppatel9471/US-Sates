import { AdditionalTaxAmount, CodeType, TaxWithholdingStatus } from './tax-withholding.model';

export interface UsLocalTaxInstruction {
  stateCode?: CodeType;
  localCode?: CodeType;
  workedInJurisdictionIndicator?: boolean;
  livedInJurisdictionIndicator?: boolean;
  taxWithholdingStatus?: TaxWithholdingStatus;
  additionalTaxPercentage?: number;
  additionalTaxAmount?: AdditionalTaxAmount;
  taxAllowanceQuantity?: number;
}
