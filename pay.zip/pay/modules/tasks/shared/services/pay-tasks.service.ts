import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { get, snakeCase } from 'lodash';
import {
  MessageCenterNotificationDto,
  SortLabelByStatusCode,
  STATUS_CODE,
  STATUS_CODE_LABEL
} from '@myadp/thingstodo-shared';
import { PayTasksDetails } from '@myadp/dto';

@Injectable({
  providedIn: 'root'
})
export class PayTasksService {
  public static getStatusCodeLabel(tasksDetails: PayTasksDetails): string {
    let history =
      // history from notifications
      tasksDetails.history ||
      // history from tasks
      get(tasksDetails, 'pendingEvents[0].history', []);

    // filter out the NOTIFIED items
    history = history.filter(value => {
      return value.actionTaken.toUpperCase() !== STATUS_CODE.notified;
    });

    // sort history array by earliest actionDate timestamp
    history.sort((a, b) => {
      return b.actionDate - a.actionDate;
    });

    // return the current actionTaken by status code, or an error should that fail
    const actionTake: string = snakeCase(get(history, '[0].actionTaken')).toUpperCase();
    return SortLabelByStatusCode[actionTake] || STATUS_CODE_LABEL.error;
  }

  constructor(private http: HttpClient) {}

  public async getTaskData(uri: string): Promise<{ [key: string]: MessageCenterNotificationDto }> {
    try {
      return await this.http.get<{ [key: string]: MessageCenterNotificationDto }>(uri).toPromise();
    } catch (err) {
      return Promise.reject(`Error occurred fetching task data: ${err.message}`);
    }
  }

  public async getTaskDetail(url: string): Promise<PayTasksDetails> {
    try {
      let headers = new HttpHeaders();
      headers = headers.set('Accept', 'application/json; masked=false');
      return await this.http
        .get<PayTasksDetails>(url, { headers })
        .toPromise();
    } catch (err) {
      return Promise.reject(`Error occurred fetching task detail data: ${err.message}`);
    }
  }

  public getTaskId(task: MessageCenterNotificationDto): string {
    return task && task.actions ? task.actions[0].uris[0].href.split('/')[4] : undefined;
  }
}
