import { ComponentFactoryResolver, ViewContainerRef } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { FormControl, FormGroup } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { of } from 'rxjs';
import { Mock } from 'ts-mockery';

import { Worker } from '@myadp/dto';

import { PayDistributionStore } from '../../../pay-distributions-shared/store/pay-distribution.store';
import { PayDistributionStoreActions } from '../../../pay-distributions-shared/store/pay-distribution.store.actions';
import { WorkerInfoStoreActions } from '../../../worker-info-shared/store/worker-info-store.actions';
import { WorkerInfoStore } from '../../../worker-info-shared/store/worker-info.store';
import { ValidationStatus } from '../../models/deposit-account.model';
import { STEPS } from '../../models/steps.enum';
import { DirectDepositStoreActions } from '../direct-deposit-store.actions';
import { DirectDepositStore } from '../direct-deposit.store';
import { StepsStoreActions } from './steps-store.actions';
import { StepsStore, StepsStoreSlice } from './steps.store';

export const mockWorker: Worker = {
  associateOID: '1',
  person: {
    communication: {
      mobiles: [{ formattedNumber: '1234567890' }],
      landlines: [{ formattedNumber: '9876543210' }]
    },
    legalName: {
      givenName: 'Rachel',
      familyName1: 'Melony',
      middleName: 'Lisa',
      generationAffixCode: { longName: 'Jr', codeValue: '1' }
    },
    legalAddress: {
      lineOne: '123 Westside Pkwy'
    },
    governmentIDs: [
      {
        idValue: 'XXXXX6789',
        itemID: 'SSN',
        nameCode: {
          codeValue: 'SSN',
          shortName: 'SSN',
          longName: 'Social Security Number'
        }
      }
    ],
    birthDate: 'XXXX-12-01'
  }
};

describe('StepsStoreActions', () => {
  let stepsStoreActions: StepsStoreActions;
  let stepsStore: StepsStore;
  let payDistributionStore: PayDistributionStore;
  let directDepositStoreActions: DirectDepositStoreActions;
  let mockViewContainerRef: ViewContainerRef;
  let directDepositStore: DirectDepositStore;
  let workerInfoStoreActions: WorkerInfoStoreActions;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [BrowserModule],
      providers: [
        StepsStoreActions,
        StepsStore,
        {
          provide: DirectDepositStoreActions,
          useValue: Mock.of<DirectDepositStoreActions>({
            updateFormData: () => Mock.noop(),
            updateAccountChanges: () => Mock.noop(),
            resetFormData: () => Mock.noop(),
            loadDirectDepositAccounts: () => Mock.noop(),
            revertAllChanges: () => Mock.noop(),
            resetModifiedAccounts: () => Mock.noop(),
            recallAccount: (arg1, arg2) => [arg1, arg2],
            deleteAccount: (arg) => arg,
            validateAccountFormDetails: () => Mock.noop(),
            accountValidationDetails: () => {
              return {
                cachedValidationStatus: null
              };
            }
          })
        },
        {
          provide: WorkerInfoStoreActions,
          useValue: Mock.of<WorkerInfoStoreActions>({
            getWorker: () => Mock.noop()
          })
        },
        {
          provide: DirectDepositStore,
          useValue: Mock.of<DirectDepositStore>({
            hasChanges: () => true,
            hasPermission: () => false,
            update: () => Mock.noop(),
            isFromCountry: () => true
          })
        },
        {
          provide: WorkerInfoStore,
          useValue: Mock.of<WorkerInfoStore>({
            worker$: () => of(mockWorker)
          })
        },
        {
          provide: ComponentFactoryResolver,
          useValue: Mock.of<ComponentFactoryResolver>({
            resolveComponentFactory: () => Mock.noop()
          })
        },
        {
          provide: PayDistributionStore,
          useValue: Mock.of<PayDistributionStore>({
            hasPayDistributions: false,
            payDistributions$: Mock.noop(),
            payDistributionMeta$: Mock.noop(),
            hasChangePermission$: Mock.noop()
          })
        },
        {
          provide: PayDistributionStoreActions,
          useValue: Mock.of<PayDistributionStoreActions>({
            loadDistributions: Mock.noop()
          })
        }
      ]
    });

    stepsStoreActions = TestBed.inject(StepsStoreActions);
    stepsStore = TestBed.inject(StepsStore);
    payDistributionStore = TestBed.inject(PayDistributionStore);
    directDepositStoreActions = TestBed.inject(DirectDepositStoreActions);
    directDepositStore = TestBed.inject(DirectDepositStore);
    workerInfoStoreActions = TestBed.inject(WorkerInfoStoreActions);

    mockViewContainerRef = Mock.of<ViewContainerRef>({
      clear: () => Mock.noop(),
      createComponent: (): any => ({ instance: { step: 0 } })
    });
    stepsStoreActions.stepContainer = mockViewContainerRef;

    spyOn(stepsStoreActions, 'disableNext');
  });

  it('should delete an account and land on review step from wisely edit when asked', () => {
    stepsStoreActions.init(mockViewContainerRef);
    stepsStoreActions.prevStep();
    stepsStoreActions.nextStep('edit-wisely');

    stepsStoreActions.deleteAccount('id');
    expect(directDepositStoreActions.deleteAccount).toHaveBeenCalledWith('id');

    expect(stepsStoreActions.currentStep.name).toBe(STEPS.REVIEW);
  });

  it('should delete an account and land on review step from edit when asked', () => {
    stepsStoreActions.init(mockViewContainerRef);
    stepsStoreActions.prevStep();
    stepsStoreActions.nextStep('edit');

    stepsStoreActions.deleteAccount('id');
    expect(directDepositStoreActions.deleteAccount).toHaveBeenCalledWith('id');

    expect(stepsStoreActions.currentStep.name).toBe(STEPS.REVIEW);
  });

  it('should init and load account type step', () => {
    stepsStoreActions.init(mockViewContainerRef);

    expect(stepsStoreActions.hasExistingAccounts).toBe(false);
    expect(stepsStore.stateValue[StepsStoreSlice.STEPS].data).toEqual({
      step: {
        current: 1,
        outOf: 6,
        name: 'ACCOUNT_TYPE'
      },
      next: {
        disabled: true,
        hidden: false
      },
      prev: {
        disabled: false,
        hidden: false
      },
      cancel: {
        hidden: true,
        disabled: false
      },
      hideNavigation: true,
      isFirstStep: false,
      showHeader: true,
      isLastStep: false,
      showProgress: true,
      isEditing: false,
      showTerms: false,
      isSubmitStep: false,
      isWisely: false
    });
  });

  it('should set existing accounts when called to update from the checkExistingAccounts function', () => {
    Mock.extend(directDepositStore).with({
      getDDAccountsSnapshot: () => [
        {
          currentData: null,
          pendingData: {
            precedence: '1',
            accountTypeName: 'Checking 1',
            accountNumber: 'X123456P7',
            routingNumber: '021000021',
            flatAmount: { amountValue: 123, currencyCode: 'USD' },
            codeValueData: {
              shortName: 'ckg1',
              longName: 'Checking 1',
              accountCode: 'C'
            }
          }
        }
      ]
    });

    stepsStoreActions.init(mockViewContainerRef);
    stepsStoreActions.checkExistingAccounts();

    expect(stepsStoreActions.hasExistingAccounts).toBe(true);
  });

  it('should call to initialize a worker', () => {
    stepsStoreActions.init(mockViewContainerRef);

    expect(workerInfoStoreActions.getWorker).toHaveBeenCalled();
  });

  it('should fetch a worker', async () => {
    expect(await stepsStoreActions.getWorker()).toEqual(mockWorker);
  });

  it('should call to update accounts', () => {
    stepsStoreActions.updateAccountChanges();
    expect(directDepositStoreActions.updateAccountChanges).toHaveBeenCalled();
  });

  it('should call cancel pending account', () => {
    stepsStoreActions.cancelPendingRequest(null, true);
    expect(directDepositStoreActions.recallAccount).toHaveBeenCalledWith(null, true);
  });

  it('should go to the add wisely flow when called on', () => {
    stepsStoreActions.init(mockViewContainerRef);
    stepsStoreActions.prevStep();
    stepsStoreActions.nextStep('add');

    stepsStoreActions.startWiselyAddFlow({});
    expect(directDepositStoreActions.resetFormData).toHaveBeenCalled();
    expect(stepsStoreActions.currentStep.name).toBe(STEPS.DEPOSIT_AMOUNT);

    expect(directDepositStoreActions.updateFormData).toHaveBeenCalledWith({});
  });

  it('should cancel a step and unset the form group', () => {
    stepsStoreActions.init(mockViewContainerRef);
    stepsStoreActions.prevStep();

    stepsStoreActions.nextStep('edit');

    stepsStoreActions.cancelStep();
    expect(directDepositStoreActions.revertAllChanges).not.toHaveBeenCalled();
    expect(stepsStoreActions.directDepositFormGroup).toBeUndefined();
    expect(stepsStoreActions.currentStep.name).toBe(STEPS.LIST);

    expect(directDepositStoreActions.resetFormData).toHaveBeenCalled();

    stepsStoreActions.nextStep('edit');
    stepsStoreActions.nextStep();

    expect(stepsStoreActions.currentStep.name).toBe(STEPS.REVIEW);

    stepsStoreActions.cancelStep();

    expect(directDepositStoreActions.revertAllChanges).toHaveBeenCalled();
  });

  it('should reset the direct deposit state when closing slide in and reset the deposit form listener', () => {
    stepsStoreActions.init(mockViewContainerRef);
    stepsStoreActions.closeSlidein();

    stepsStoreActions.nextStep();

    expect(directDepositStore.update).toHaveBeenCalledTimes(0);
    expect(directDepositStoreActions.revertAllChanges).toHaveBeenCalled();
  });

  it('should init and load account list screen', () => {
    Mock.extend(payDistributionStore).with({
      hasPayDistributions: true,
      hasWiselyAccount: true
    });
    stepsStoreActions.init(mockViewContainerRef);

    expect(stepsStoreActions.hasExistingAccounts).toBe(true);
    expect(stepsStore.stateValue[StepsStoreSlice.STEPS].data.step).toEqual(
      jasmine.objectContaining({
        current: 0,
        name: STEPS.LIST
      })
    );
  });

  it('should not skip the verification step if GIACT is enabled', () => {
    Mock.extend(directDepositStore).with({
      hasPermission: () => true
    });

    stepsStoreActions.init(mockViewContainerRef);

    stepsStoreActions.nextStep('add');
    stepsStoreActions.nextStep();

    expect(stepsStoreActions.currentStep.name).toEqual(STEPS.VERIFICATION);
  });

  it('should skip the verification step if GIACT is not enabled', () => {
    stepsStoreActions.init(mockViewContainerRef);

    stepsStoreActions.nextStep('add');
    stepsStoreActions.nextStep();

    expect(stepsStoreActions.currentStep.name).toEqual(STEPS.DEPOSIT_AMOUNT);
  });

  it('should skip the verification step if country is not US', () => {
    Mock.extend(directDepositStore).with({
      hasPermission: () => true,
      isFromCountry: () => false
    });

    stepsStoreActions.init(mockViewContainerRef);

    stepsStoreActions.nextStep('add');
    stepsStoreActions.nextStep();

    expect(stepsStoreActions.currentStep.name).toEqual(STEPS.DEPOSIT_AMOUNT);
  });

  it('should skip the verification step if GIACT is enabled and account has already been verified', () => {
    Mock.extend(directDepositStore).with({
      hasPermission: () => true
    });

    Mock.extend(directDepositStoreActions).with({
      accountValidationDetails: () => {
        return {
          cachedValidationStatus: {
            status: ValidationStatus.WARN
          }
        };
      }
    });

    stepsStoreActions.init(mockViewContainerRef);

    stepsStoreActions.nextStep('add');
    stepsStoreActions.nextStep();
    expect(directDepositStoreActions.validateAccountFormDetails).toHaveBeenCalled();
    expect(stepsStoreActions.currentStep.name).toEqual(STEPS.DEPOSIT_AMOUNT);

    stepsStoreActions.prevStep();

    expect(stepsStoreActions.currentStep.name).toEqual(STEPS.ACCOUNT_DETAILS);
  });

  it('should skip the verification step if GIACT enabled but routing/account numbers are in cache', () => {
    Mock.extend(directDepositStore).with({
      hasPermission: () => true
    });

    Mock.extend(directDepositStoreActions).with({
      accountValidationDetails: () => {
        return {
          cachedValidationStatus: {
            status: ValidationStatus.WARN
          }
        };
      }
    });

    stepsStoreActions.init(mockViewContainerRef);

    stepsStoreActions.nextStep('add');
    stepsStoreActions.nextStep();

    expect(stepsStoreActions.currentStep.name).toEqual(STEPS.DEPOSIT_AMOUNT);
  });

  it('should update form data once when going to next step while not editing', () => {
    stepsStoreActions.init(mockViewContainerRef);

    stepsStoreActions.setFormGroup(new FormGroup({}));
    stepsStoreActions.nextStep('add');

    expect(directDepositStoreActions.updateFormData).toHaveBeenCalledTimes(1);
  });

  it('should update form data when going to next step while editing', () => {
    stepsStoreActions.init(mockViewContainerRef);
    stepsStoreActions.setFormGroup(new FormGroup({}));

    stepsStoreActions.nextStep('edit');

    expect(directDepositStoreActions.updateFormData).toHaveBeenCalledTimes(1);
  });

  describe('hasAccountChanges', () => {
    it('should always consider account to have changes when on verification step', () => {
      Mock.extend(directDepositStore).with({
        hasChanges: () => false
      });

      Mock.extend(stepsStoreActions).with({
        currentStep: {
          name: STEPS.VERIFICATION
        }
      });

      expect(stepsStoreActions.hasAccountChanges()).toBeTrue();
    });

    it('should always return false for done step', () => {
      Mock.extend(directDepositStore).with({
        hasChanges: () => true
      });

      Mock.extend(stepsStoreActions).with({
        currentStep: {
          name: STEPS.DEPOSIT_DONE
        }
      });

      expect(stepsStoreActions.hasAccountChanges()).toBeFalse();
    });

    it('should know when account changes are present', () => {
      stepsStoreActions.init(mockViewContainerRef);

      expect(stepsStoreActions.hasAccountChanges()).toBeTrue();

      Mock.extend(directDepositStore).with({
        hasChanges: () => false
      });

      expect(stepsStoreActions.hasAccountChanges()).toBeFalse();

      const form = new FormGroup({});
      stepsStoreActions.setFormGroup(form);

      expect(stepsStoreActions.hasAccountChanges()).toBeFalse();

      form.markAsDirty();

      expect(stepsStoreActions.hasAccountChanges()).toBeTrue();
    });
  });

  it('should exclude properties from form value', () => {
    stepsStoreActions.init(mockViewContainerRef);

    stepsStoreActions.setFormGroup(
      new FormGroup({
        FORM: new FormGroup({
          accountNumber: new FormControl('12345'),
          removeProperty: new FormControl('anything'),
          routingNumber: new FormControl('012000018'),
          alsoRemoveProp: new FormControl(600)
        })
      }),
      'removeProperty',
      'alsoRemoveProp'
    );

    stepsStoreActions.nextStep('add');

    expect(directDepositStoreActions.updateFormData).toHaveBeenCalledTimes(1);
    expect(directDepositStoreActions.updateFormData).toHaveBeenCalledWith({
      accountNumber: '12345',
      routingNumber: '012000018'
    });
  });

  it('should update form data once when going to prev step', () => {
    stepsStoreActions.init(mockViewContainerRef);
    stepsStoreActions.setFormGroup(new FormGroup({}));

    stepsStoreActions.nextStep('add');
    stepsStoreActions.nextStep();
    stepsStoreActions.nextStep();
    stepsStoreActions.prevStep();

    expect(directDepositStoreActions.updateFormData).toHaveBeenCalledTimes(1);
  });

  it('should not update form data when going into account details then hitting prev to go back to type', () => {
    stepsStoreActions.init(mockViewContainerRef);
    stepsStoreActions.setFormGroup(new FormGroup({}));

    stepsStoreActions.nextStep('add');
    expect(stepsStoreActions.currentStep.name).toEqual(STEPS.ACCOUNT_DETAILS);
    stepsStoreActions.prevStep();

    expect(directDepositStoreActions.updateFormData).toHaveBeenCalledTimes(1);
  });

  it('should reset the store to initial state', () => {
    stepsStoreActions.resetCurrentStep();

    expect(stepsStore.stateValue[StepsStoreSlice.STEPS].data).toEqual(null);
  });

  describe('loadAccounts', () => {
    it('should GET accounts with unmasked data by default', () => {
      stepsStoreActions.loadAccounts();
      expect(directDepositStoreActions.loadDirectDepositAccounts).toHaveBeenCalledWith(
        false,
        false
      );
    });

    it('should GET accounts with meta', () => {
      stepsStoreActions.loadAccounts({ getMeta: true });
      expect(directDepositStoreActions.loadDirectDepositAccounts).toHaveBeenCalledWith(true, false);
    });

    it('should GET accounts with masked data', () => {
      stepsStoreActions.loadAccounts({ getMasked: true });
      expect(directDepositStoreActions.loadDirectDepositAccounts).toHaveBeenCalledWith(false, true);
    });

    it('should GET accounts with meta and masked data', () => {
      stepsStoreActions.loadAccounts({ getMeta: true, getMasked: true });
      expect(directDepositStoreActions.loadDirectDepositAccounts).toHaveBeenCalledWith(true, true);
    });
  });

  describe('slidein controls', () => {
    it('should close the slidein', () => {
      stepsStoreActions.closeSlidein();
      expect(stepsStore.isSlideinOpen$.getValue()).toBe(false);
    });

    it('should open the slidein', () => {
      stepsStoreActions.openSlidein();
      expect(stepsStore.isSlideinOpen$.getValue()).toBe(true);
    });
  });

  it('should disable next', () => {
    stepsStoreActions.init(mockViewContainerRef);
    stepsStoreActions.disableNext(true);

    expect(stepsStore.stateValue[StepsStoreSlice.STEPS].data.next).toEqual({
      disabled: true,
      hidden: false
    });
  });

  it('should reset the prev/next button state when told to', () => {
    stepsStoreActions.init(mockViewContainerRef);
    stepsStoreActions.resetCurrentStep();
    stepsStoreActions.hidePrev(true);

    expect(stepsStore.stateValue[StepsStoreSlice.STEPS].data.prev).toEqual({
      hidden: true
    });

    stepsStoreActions.hidePrev(false);

    expect(stepsStore.stateValue[StepsStoreSlice.STEPS].data.prev).toEqual({
      hidden: false
    });

    stepsStoreActions.resetCurrentStep();
    stepsStoreActions.hideNext(true);

    expect(stepsStore.stateValue[StepsStoreSlice.STEPS].data.next).toEqual({
      hidden: true
    });

    stepsStoreActions.hideNext(false);

    expect(stepsStore.stateValue[StepsStoreSlice.STEPS].data.next).toEqual({
      hidden: false
    });
  });
});
