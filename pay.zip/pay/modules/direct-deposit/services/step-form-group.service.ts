import { Injectable } from '@angular/core';
import { AbstractControl, FormControl, FormGroup, ValidatorFn, Validators } from '@angular/forms';

import { DistributionOptions } from '../../pay-distributions-shared/models/pay-distributions-ui';
import {
  accountNameValidator,
  bankAccountValidator,
  bankRoutingValidator,
  controlMatchValidator,
  hasMadeChanges
} from '../components/steps/account-details/form-control/account-details-form.validators';
import { conditionalFormValidator } from '../components/steps/deposit-amount/form-control/conditional-form.validator';
import { percentageAmountValidator } from '../components/steps/deposit-amount/form-control/deposit-amount-form.utils';
import { AccountDetailsControls } from '../models/account-details-form.model';
import { AccountType } from '../models/deposit-account.model';
import { DepositAmountControls } from '../models/deposit-amount-form.model';
import { StepMeta } from '../models/step-meta.model';
import { BaseStepService } from './base-step.service';
import { WiselyAccountService } from './wisely-account.service';
import { StepsStore } from '../store/steps/steps.store';
import { COUNTRY } from '../../pay-distributions-shared/models/country';

@Injectable({
  providedIn: 'root'
})
export class StepFormGroupService extends BaseStepService {
  constructor(
    private wiselyAccountService: WiselyAccountService,
    protected stepsStore: StepsStore
  ) {
    super(stepsStore);
  }

  public getStepForm(meta: StepMeta): FormGroup {
    return !this.isEditing
      ? new FormGroup({
        [this.currentStep]: this.getFormGroup(this.currentStep, meta)
      })
      : this.getEditForm(meta);
  }

  private getEditForm(stepMeta: StepMeta): FormGroup {
    const editFormGroup = new FormGroup({
      ACCOUNT_DETAILS: this.getFormGroup('ACCOUNT_DETAILS', stepMeta),
      DEPOSIT_AMOUNT: this.getFormGroup('DEPOSIT_AMOUNT', stepMeta)
    });
    editFormGroup.setValidators([hasMadeChanges(this.stepsStore.editingAccount)]);
    editFormGroup.updateValueAndValidity();

    return editFormGroup;
  }

  private getFormGroup(stepName: string, stepMeta: StepMeta): FormGroup {
    const stepFormControls = this.getStepFormControls(stepName, stepMeta);
    const isEditing = this.stepsStore.isEditing;
    return {
      ACCOUNT_DETAILS: () =>
        new FormGroup(stepFormControls, {
          updateOn: isEditing ? 'change' : 'blur',
          validators: this.getAccountDetailsValidators(isEditing)
        }),
      DEPOSIT_AMOUNT: () =>
        new FormGroup(stepFormControls, [
          conditionalFormValidator(
            DepositAmountControls.PERCENTAGE_AMOUNT,
            (form) =>
              form.value?.[DepositAmountControls.AMOUNT_TYPE] === DistributionOptions.PERCENTAGE,
            Validators.compose([Validators.required, percentageAmountValidator(stepMeta)])
          ),
          conditionalFormValidator(
            DepositAmountControls.FLAT_AMOUNT,
            (form) => form.value?.[DepositAmountControls.AMOUNT_TYPE] === DistributionOptions.FLAT,
            Validators.compose([Validators.required, Validators.min(stepMeta.minFlatAmount)])
          )
        ])
    }[stepName]();
  }

  private getAccountDetailsValidators(isEditing: boolean): ValidatorFn[] {
    const countryLookup = {
      [COUNTRY.US]: () =>
        controlMatchValidator(
          AccountDetailsControls.ROUTING_NUMBER,
          AccountDetailsControls.ROUTING_CONFIRM,
          'routingMatch',
          isEditing
        ),
      [COUNTRY.CA]: () =>
        controlMatchValidator(
          AccountDetailsControls.TRANSIT_NUMBER,
          AccountDetailsControls.TRANSIT_CONFIRM,
          'transitMatch',
          isEditing
        )
    };

    const validators = [
      controlMatchValidator(
        AccountDetailsControls.ACCOUNT_NUMBER,
        AccountDetailsControls.ACCOUNT_CONFIRM,
        'accountMatch',
        isEditing
      ),
      countryLookup?.[this.stepsStore.country.shortName]?.()
    ];

    return validators;
  }

  private getCountryFormControls(stepMeta: StepMeta): { [key: string]: AbstractControl } {
    return {
      [COUNTRY.US]: {
        [AccountDetailsControls.ROUTING_NUMBER]: new FormControl(
          this.formData?.[AccountDetailsControls.ROUTING_NUMBER],
          stepMeta.disableRoutingAndAccountValidations
            ? []
            : [Validators.required, bankRoutingValidator]
        ),
        [AccountDetailsControls.ROUTING_CONFIRM]: new FormControl(
          this.formData?.[AccountDetailsControls.ROUTING_CONFIRM] ||
            this.formData?.[AccountDetailsControls.ROUTING_NUMBER],
          Validators.required
        )
      },
      [COUNTRY.CA]: {
        [AccountDetailsControls.INSTITUTION]: new FormControl(
          (stepMeta.banks || []).find(
            (bank) => bank.value === this.formData?.[AccountDetailsControls.INSTITUTION]
          ),
          Validators.required
        ),
        [AccountDetailsControls.TRANSIT_NUMBER]: new FormControl(
          this.formData?.[AccountDetailsControls.TRANSIT_NUMBER],
          [Validators.required, Validators.pattern(/^\d{5}/)]
        ),
        [AccountDetailsControls.TRANSIT_CONFIRM]: new FormControl(
          this.formData?.[AccountDetailsControls.TRANSIT_CONFIRM] ||
            this.formData?.[AccountDetailsControls.TRANSIT_NUMBER],
          [Validators.required]
        )
      }
    }[this.stepsStore.country.shortName];
  }

  private getStepFormControls(
    stepName: string,
    stepMeta: StepMeta
  ): { [key: string]: AbstractControl } {
    return {
      ACCOUNT_DETAILS: () => {
        const accountTypeCodeData = this.formData?.[AccountDetailsControls.ACCOUNT_TYPE_CODE];
        const accountTypeSelection: AccountType =
          stepMeta.accountTypes.find(
            (accountType) => accountType.value === accountTypeCodeData?.value
          ) || accountTypeCodeData?.label
            ? accountTypeCodeData
            : stepMeta.accountTypes[0];

        return {
          [AccountDetailsControls.ACCOUNT_TYPE_CODE]: new FormControl(
            { value: accountTypeSelection, disabled: this.isEditing },
            Validators.required
          ),
          [AccountDetailsControls.ACCOUNT_NAME]: new FormControl(
            this.formData?.[AccountDetailsControls.ACCOUNT_NAME],
            stepMeta.accountNameEnabled ? accountNameValidator : undefined
          ),
          ...this.getCountryFormControls(stepMeta),
          [AccountDetailsControls.ACCOUNT_NUMBER]: new FormControl(
            this.formData?.[AccountDetailsControls.ACCOUNT_NUMBER],
            stepMeta.disableRoutingAndAccountValidations
              ? []
              : [Validators.required, bankAccountValidator]
          ),
          [AccountDetailsControls.ACCOUNT_CONFIRM]: new FormControl(
            this.formData?.[AccountDetailsControls.ACCOUNT_CONFIRM] ||
              this.formData?.[AccountDetailsControls.ACCOUNT_NUMBER],
            Validators.required
          ),
          [AccountDetailsControls.TERMS]: new FormControl(
            !!this.formData?.[AccountDetailsControls.TERMS] || !!stepMeta.isEditing,
            [Validators.required, Validators.requiredTrue]
          )
        };
      },
      DEPOSIT_AMOUNT: () => ({
        [DepositAmountControls.AMOUNT_TYPE]: new FormControl(
          stepMeta.defaultDepositType,
          Validators.required
        ),
        [DepositAmountControls.PERCENTAGE_AMOUNT]: new FormControl(
          this.formData?.[DepositAmountControls.PERCENTAGE_AMOUNT] ?? null
        ),
        [DepositAmountControls.FLAT_AMOUNT]: new FormControl(
          this.formData?.[DepositAmountControls.FLAT_AMOUNT] ?? null
        ),
        ...(!stepMeta.isEditing &&
          this.showTerms &&
          this.wiselyAccountService.shouldShowTerms() && {
          [DepositAmountControls.TERMS]: new FormControl(
            !!this.formData?.[DepositAmountControls.TERMS] || false,
            [Validators.required, Validators.requiredTrue]
          )
        })
      })
    }[stepName]();
  }
}
