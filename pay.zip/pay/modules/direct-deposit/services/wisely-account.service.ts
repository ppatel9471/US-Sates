import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { take } from 'rxjs/operators';

import { FilteredUserProfileService, ROLE, UserIdentityService } from '@myadp/common';
import { PaycardConstants } from '@myadp/paycard/shared/constants/paycard-constants';
import { ApiError, CardHolderDTO, LegacyCodeType, OrganizationProfile } from '@myadp/dto';

import {
  WiselyAccount,
  WiselyAccountStatus,
  wiselyErrorAlertMap,
  WiselyTypes
} from '../models/wisely.model';

import { PayDistributionStore } from '../../pay-distributions-shared/store/pay-distribution.store';
import { DirectDepositStore } from '../store/direct-deposit.store';
import { FormDetails } from '../models/form-details.model';
interface WiselyResponse {
  cardholders?: CardHolderDTO.APIResponse;
  organizationProfiles?: OrganizationProfile;
}

interface WrappedErrorResponse {
  error: ApiError.ErrorResponseBody;
  status: number;
}

@Injectable({
  providedIn: 'root'
})
export class WiselyAccountService {
  public cachedWiselyAccount: WiselyAccount;

  private readonly CARDHOLDER_URI = '/payroll/v1/paycard/cardholders';
  private readonly ORG_PROFILE_URI = '/money-management/v1/paycard/organization-profiles';

  constructor(
    private httpClient: HttpClient,
    private userIdentityService: UserIdentityService,
    private userProfileService: FilteredUserProfileService,
    private payDistributionStore: PayDistributionStore,
    private directDepositStore: DirectDepositStore
  ) {}

  public hasWisely(): boolean {
    return (
      (this.directDepositStore.hasPermission(WiselyTypes.WISELY_DIRECT) &&
        !this.directDepositStore.isWFN) ||
      (this.directDepositStore.hasPermission(WiselyTypes.WISELY_PAY) &&
        this.hasWiselyPayDeductionCode())
    );
  }

  public shouldShowTerms(): boolean {
    return (
      (this.directDepositStore.hasPermission(WiselyTypes.WISELY_DIRECT) &&
        !this.directDepositStore.isWFN) ||
      this.directDepositStore.hasPermission(WiselyTypes.WISELY_PAY)
    );
  }

  public flattenAccountTypeCodeList(): string[] {
    const meta = this.payDistributionStore.payDistributionMetaSnapshot;

    return (
      meta.accountTypeList
        ?.filter(Boolean)
        .map(
          (codeType: LegacyCodeType) =>
            codeType?.codeValue || codeType?.longName || codeType?.shortName
        ) || []
    );
  }

  public hasWiselyPayDeductionCode(): boolean {
    return !!this.flattenAccountTypeCodeList().includes('WIS');
  }

  public hasExistingWisely(): boolean {
    return this.directDepositStore.getDDAccountsSnapshot().some((account) => account.isWisely);
  }

  public transformDetails(wiselyAccount: WiselyAccount): FormDetails {
    const wiselyAccountCode =
      this.payDistributionStore.payDistributionMetaSnapshot.accountTypeList?.find(
        (codeType) => codeType.codeValue === 'WIS'
      );

    const wiselyName = wiselyAccount.isWiselyDirect ? 'WISELY DIRECT' : 'WISELY PAY';
    const firstNonWiselyAccountCode =
      this.flattenAccountTypeCodeList().find((code) => code !== 'WIS') || null;
    // omit ID prop to prevent treating account as an edit
    const wiselyFormDetails: FormDetails = {
      distributionType: null,
      percentageAmount: null,
      precedence: '1',
      precedenceCode: wiselyName,
      flatAmount: null,
      codeValueData: {
        itemID: null,
        accountCode: !wiselyAccount.isWiselyDirect
          ? wiselyAccountCode?.codeValue
          : firstNonWiselyAccountCode,
        shortName: !wiselyAccount.isWiselyDirect ? wiselyAccountCode?.shortName : null,
        longName: wiselyAccount.isWiselyDirect ? 'WISELY DIRECT' : null
      },
      accountTypeCode: wiselyAccountCode
        ? wiselyAccountCode
        : {
          longName: 'WISELY DIRECT',
          value: firstNonWiselyAccountCode
        },
      accountName: wiselyName,
      accountTypeName:
        wiselyAccountCode?.longName ||
        wiselyAccountCode?.shortName ||
        wiselyAccountCode?.codeValue ||
        wiselyName,
      prenoteIndicator: false,
      accountNumber: wiselyAccount.accountNumber,
      routingNumber: wiselyAccount.routingNumber
    };

    return wiselyFormDetails;
  }

  public async getWiselyAccount(refresh: boolean = false): Promise<WiselyAccount> {
    if (!refresh && this.cachedWiselyAccount) {
      return this.cachedWiselyAccount;
    }

    const AOID = await this.userIdentityService.getAoid();
    const [wiselyAccountStatus, isNotEnrolled] = await this.getWiselyData(
      `${this.CARDHOLDER_URI}/${AOID}`
    );

    const isD2E = await this.userProfileService.hasD2E.pipe(take(1)).toPromise();

    const wiselyAccount: WiselyAccount = {
      isActivated: false,
      routingNumber: '',
      accountNumber: '',
      isWiselyDirect: isD2E,
      status: wiselyAccountStatus
        ? WiselyAccountStatus.UNENROLLED
        : this.setWiselyStatus(isNotEnrolled)
    };

    if (wiselyAccount.status === WiselyAccountStatus.DONOTSHOW) {
      this.cachedWiselyAccount = wiselyAccount;
      return this.cachedWiselyAccount;
    }

    if (isD2E) {
      wiselyAccount.status = WiselyAccountStatus.SELFENROLL;
    }

    if (isNotEnrolled && !isD2E) {
      await this.getSelfEnrollmentStatus(wiselyAccount);
    } else {
      const cardholder: CardHolderDTO.CardHolder = wiselyAccountStatus?.cardholders?.[0];
      const primaryCard: CardHolderDTO.Card = cardholder?.cards?.find(
        (card: CardHolderDTO.Card) => !!card?.primaryIndicator
      );

      wiselyAccount.isActivated = primaryCard && primaryCard?.pinSet;
      wiselyAccount.accountNumber = cardholder?.cardholderAccount?.accountNumber ?? '';
      wiselyAccount.routingNumber = cardholder?.cardholderAccount?.routingTransitID?.idValue ?? '';

      if (primaryCard) {
        const cardStatus =
          primaryCard?.cardStatusCode?.codeValue?.toUpperCase() as WiselyAccountStatus;

        this.setStatusWithPrimaryCard(wiselyAccount, cardStatus);
      }
    }

    this.cachedWiselyAccount = wiselyAccount;
    return this.cachedWiselyAccount;
  }

  public async getSelfEnrollmentStatus(wiselyAccount: WiselyAccount): Promise<void> {
    const [selfEnrollment, cannotSelfEnroll] = await this.getWiselyData(this.ORG_PROFILE_URI);

    if (cannotSelfEnroll) {
      wiselyAccount.status = WiselyAccountStatus.DONOTSHOW;
    } else {
      const selfEnroll =
        selfEnrollment?.organizationProfiles[0]?.profileSettings?.allowSelfEnrollment || '';
      const orgProfileSelfEnrollStatus =
        selfEnroll.match && selfEnroll.match(/^(y|yes|true)$/i) ? true : false;

      const isWiselyDirect = await this.userProfileService.hasD2E.pipe(take(1)).toPromise();
      const canSelfEnroll = isWiselyDirect || orgProfileSelfEnrollStatus;

      wiselyAccount.status = canSelfEnroll
        ? WiselyAccountStatus.SELFENROLL
        : WiselyAccountStatus.UNENROLLED;
    }
  }

  public setWiselyStatus(apiResponse: WrappedErrorResponse): WiselyAccountStatus {
    const wiselyStatusLookup: Record<string, () => WiselyAccountStatus> = {
      404: () => WiselyAccountStatus.UNENROLLED,
      400: () => {
        const code: string =
          apiResponse?.error?.confirmMessage?.resourceMessages[0]?.processMessages[0]?.userMessage
            ?.codeValue;
        const codeLookup: Record<string, WiselyAccountStatus> = {
          [PaycardConstants.ERROR_CODES.ENROLLMENT_FAILED]: WiselyAccountStatus.DONOTSHOW,
          [PaycardConstants.ERROR_CODES.ENROLLMENT_DECLINED]: WiselyAccountStatus.DONOTSHOW
        };

        return codeLookup?.[code] ?? WiselyAccountStatus.DONOTSHOW;
      }
    };

    return wiselyStatusLookup?.[String(apiResponse?.status)]?.() ?? WiselyAccountStatus.DONOTSHOW;
  }

  private setUIStatusFromApiStatus(
    apiStatus: WiselyAccountStatus,
    isD2E: boolean
  ): WiselyAccountStatus {
    const cardStatusToUI = {
      [WiselyAccountStatus.CLOSED]: WiselyAccountStatus.CANCELED,
      [WiselyAccountStatus.CANCELED]: WiselyAccountStatus.CANCELED,
      [WiselyAccountStatus.LOST]: WiselyAccountStatus.LOST,
      [WiselyAccountStatus.STOLEN]: WiselyAccountStatus.STOLEN,
      [WiselyAccountStatus.OFAC]: WiselyAccountStatus.DONOTSHOW,
      [WiselyAccountStatus.DISABLED]: WiselyAccountStatus.DONOTSHOW,
      [WiselyAccountStatus.DECEASED]: WiselyAccountStatus.DONOTSHOW,
      [WiselyAccountStatus.LIMITED]: isD2E ? WiselyAccountStatus.DONOTSHOW : false,
      [WiselyAccountStatus.LOCKED]: WiselyAccountStatus.DONOTSHOW,
      [WiselyAccountStatus.IDLE]: WiselyAccountStatus.DONOTSHOW
    };

    return cardStatusToUI[apiStatus];
  }

  private setStatusWithPrimaryCard(
    wiselyAccount: WiselyAccount,
    cardStatus: WiselyAccountStatus
  ): void {
    if (!wiselyAccount.isActivated) {
      wiselyAccount.status = WiselyAccountStatus.INACTIVE;
      return;
    }
    const hasExistingWisely = this.hasExistingWisely();

    wiselyAccount.status = this.setUIStatusFromApiStatus(cardStatus, wiselyAccount.isWiselyDirect);

    if (!wiselyAccount.status && wiselyAccount.isActivated) {
      wiselyAccount.status = hasExistingWisely
        ? WiselyAccountStatus.MAX
        : WiselyAccountStatus.UNCREATED;
    }

    wiselyAccount.wiselyErrorMessage =
      cardStatus === WiselyAccountStatus.LIMITED && !wiselyAccount.isWiselyDirect
        ? null
        : wiselyErrorAlertMap(
          wiselyAccount.isWiselyDirect ? WiselyTypes.WISELY_DIRECT : WiselyTypes.WISELY_PAY
        )[cardStatus];
  }

  private async getWiselyData(url: string): Promise<[WiselyResponse, WrappedErrorResponse]> {
    const headers = new HttpHeaders().set('roleCode', ROLE.EMPLOYEE);
    let result: WiselyResponse = undefined;
    let error: WrappedErrorResponse = null;

    await this.httpClient
      .get(url, { headers })
      .toPromise()
      .then((res) => (result = res))
      .catch((err) => (error = err));

    return [result, error];
  }
}
