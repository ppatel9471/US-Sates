import { TestBed } from '@angular/core/testing';
import { Mock } from 'ts-mockery';

import { DistributionOptions } from '../../pay-distributions-shared/models/pay-distributions-ui';
import { PayDistributionStore } from '../../pay-distributions-shared/store/pay-distribution.store';
import { DirectDepositStore } from '../store/direct-deposit.store';
import { StepsStore } from '../store/steps/steps.store';
import { BaseStepService } from './base-step.service';
import { StepMetaService } from './step-meta.service';

describe('StepMetaService', () => {
  let stepMetaService: StepMetaService;
  let directDepositStore: DirectDepositStore;
  let stepsStore: StepsStore;
  let payDistributionStore: PayDistributionStore;

  const accountTypeListItem = {
    Savings2: {
      codeValue: '102',
      shortName: 'SAV2',
      longName: 'Savings2'
    },
    Checking3: {
      codeValue: '103',
      shortName: 'CKG3',
      longName: 'Checking3'
    },
    Checking4: {
      codeValue: '104',
      shortName: 'CKG4',
      longName: 'Checking4'
    }
  };

  const accountTypes = {
    Savings2: {
      label: 'Savings2',
      value: '102',
      longName: 'Savings2',
      shortName: 'SAV2'
    },
    Checking3: {
      label: 'Checking3',
      value: '103',
      longName: 'Checking3',
      shortName: 'CKG3'
    },
    Checking4: {
      label: 'Checking4',
      value: '104',
      longName: 'Checking4',
      shortName: 'CKG4'
    }
  };

  const codeData = {
    Savings2: {
      codeValueData: {
        accountCode: '102'
      }
    },
    Checking3: {
      codeValueData: {
        accountCode: '103'
      }
    },
    Checking4: {
      codeValueData: {
        accountCode: '104'
      }
    }
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        BaseStepService,
        {
          provide: DirectDepositStore,
          useValue: Mock.of<DirectDepositStore>({
            isCanadian: false,
            getAvailableAccountTypes: () => [
              accountTypes.Savings2,
              accountTypes.Checking3,
              accountTypes.Checking4
            ],
            getDDAccountsSnapshot: () => [
              {
                currentData: {
                  id: 'id1',
                  distributionType: DistributionOptions.PERCENTAGE,
                  percentageAmount: 42,
                  flatAmount: null
                }
              }
            ],
            isAvsddm: false
          })
        },
        {
          provide: StepsStore,
          useValue: Mock.of<StepsStore>({
            isEditing: false,
            currentStepName: 'ACCOUNT_DETAILS'
          })
        },
        {
          provide: PayDistributionStore,
          useValue: Mock.of<PayDistributionStore>({
            payDistributionMetaSnapshot: {
              showDistributionPercentage: true,
              accountName: {
                enabled: false
              },
              accountTypeList: [
                accountTypeListItem.Savings2,
                accountTypeListItem.Checking3,
                accountTypeListItem.Checking4
              ]
            }
          })
        }
      ]
    });

    stepMetaService = TestBed.inject(StepMetaService);
    stepsStore = TestBed.inject(StepsStore);
    directDepositStore = TestBed.inject(DirectDepositStore);
    payDistributionStore = TestBed.inject(PayDistributionStore);
  });

  it('should build step meta for ACCOUNT_DETAILS step', () => {
    expect(stepMetaService.getStepMeta()).toEqual({
      accountTypes: [accountTypes.Savings2, accountTypes.Checking3, accountTypes.Checking4],
      isEditing: false,
      displayConfirm: true,
      accountNameEnabled: false,
      accountNameMaxLength: undefined,
      disableRoutingAndAccountValidations: false
    });
  });

  it('should prevent SORs that do not use static accounts from allowing duplicate account types', () => {
    Mock.extend(directDepositStore).with({
      getAvailableAccountTypes: () => [accountTypes.Checking3, accountTypes.Checking4],
      hasStaticAccountTypes: false
    });

    // Savings2 should be removed from account types
    expect(stepMetaService.getStepMeta().accountTypes).toEqual([
      accountTypes.Checking3,
      accountTypes.Checking4
    ]);

    Mock.extend(directDepositStore).with({
      getDDAccountsSnapshot: () => [
        {
          currentData: codeData.Savings2
        }
      ],
      hasStaticAccountTypes: true
    });

    expect(stepMetaService.getStepMeta().accountTypes).toEqual([
      accountTypes.Savings2,
      accountTypes.Checking3,
      accountTypes.Checking4
    ]);
  });

  it('should have a list of banking institutions available for Canadian DD', () => {
    Mock.extend(directDepositStore).with({ isCanadian: true });
    Mock.extend(payDistributionStore).with({
      payDistributionMetaSnapshot: {
        showDistributionPercentage: true,
        accountName: {
          enabled: false
        },
        accountTypeList: [
          accountTypeListItem.Savings2,
          accountTypeListItem.Checking3,
          accountTypeListItem.Checking4
        ],
        banks: [
          {
            codeValue: 'foo',
            shortName: 'bar'
          }
        ]
      }
    });

    expect(stepMetaService.getStepMeta().banks).toEqual([
      {
        label: 'bar - foo',
        value: 'foo'
      }
    ]);
  });

  it('should select account code from pendingData account', () => {
    Mock.extend(directDepositStore).with({
      getAvailableAccountTypes: () => [accountTypes.Savings2, accountTypes.Checking3],
      hasStaticAccountTypes: false
    });

    expect(stepMetaService.getStepMeta().accountTypes).toEqual([
      accountTypes.Savings2,
      accountTypes.Checking3
    ]);
    expect(stepMetaService.getStepMeta().accountTypes).not.toContain(
      jasmine.objectContaining(accountTypes.Checking4)
    );
  });

  it('should build step meta for DEPOSIT_AMOUNT step', () => {
    Mock.extend(stepsStore).with({
      currentStepName: 'DEPOSIT_AMOUNT'
    });

    expect(stepMetaService.getStepMeta()).toEqual({
      showRemainingLabel: true,
      hasExistingDeposits: true,
      showPercentageType: true,
      hasOneAccount: true,
      isDepositingRemainder: false,
      remainingPercentage: 58,
      maxPercentage: 100,
      minFlatAmount: 0.01,
      depositTypeOptions: [
        {
          label: `myadp-pay.DD_DEPOSIT_AMOUNT_REMAINING_LABEL`,
          value: DistributionOptions.REMAINING,
          disabled: false
        },
        {
          label: 'myadp-pay.DD_DEPOSIT_AMOUNT_PERCENTAGE_LABEL',
          value: DistributionOptions.PERCENTAGE,
          disabled: false
        },
        {
          label: 'myadp-pay.DD_DEPOSIT_AMOUNT_FLAT_LABEL',
          value: DistributionOptions.FLAT
        }
      ],
      defaultDepositType: DistributionOptions.REMAINING
    });
  });

  it('should get combined step meta when editing', () => {
    Mock.extend(stepsStore).with({
      isEditing: true
    });

    expect(stepMetaService.getStepMeta()).toEqual({
      accountTypes: [accountTypes.Savings2, accountTypes.Checking3, accountTypes.Checking4],
      isEditing: true,
      disableRoutingAndAccountValidations: false,
      displayConfirm: false,
      accountNameEnabled: false,
      hasOneAccount: true,
      accountNameMaxLength: undefined,
      showRemainingLabel: true,
      hasExistingDeposits: true,
      showPercentageType: true,
      isDepositingRemainder: false,
      remainingPercentage: 58,
      maxPercentage: 100,
      minFlatAmount: 0.01,
      depositTypeOptions: [
        {
          label: `myadp-pay.DD_DEPOSIT_AMOUNT_REMAINING_LABEL`,
          value: DistributionOptions.REMAINING,
          disabled: false
        },
        {
          label: 'myadp-pay.DD_DEPOSIT_AMOUNT_PERCENTAGE_LABEL',
          value: DistributionOptions.PERCENTAGE,
          disabled: false
        },
        {
          label: 'myadp-pay.DD_DEPOSIT_AMOUNT_FLAT_LABEL',
          value: DistributionOptions.FLAT
        }
      ],
      defaultDepositType: DistributionOptions.REMAINING
    });
  });

  it('should build step meta for ACCOUNT_DETAILS step with avsDDM while editing', () => {
    Mock.extend(stepsStore).with({
      isEditing: true
    });

    Mock.extend(directDepositStore).with({
      isAvsddm: true
    });

    expect(stepMetaService.getStepMeta()).toEqual({
      accountTypes: [accountTypes.Savings2, accountTypes.Checking3, accountTypes.Checking4],
      isEditing: true,
      hasOneAccount: true,
      disableRoutingAndAccountValidations: true,
      displayConfirm: false,
      accountNameEnabled: false,
      accountNameMaxLength: undefined,
      showRemainingLabel: true,
      hasExistingDeposits: true,
      showPercentageType: true,
      isDepositingRemainder: false,
      remainingPercentage: 58,
      maxPercentage: 100,
      minFlatAmount: 0.01,
      depositTypeOptions: [
        {
          label: `myadp-pay.DD_DEPOSIT_AMOUNT_REMAINING_LABEL`,
          value: DistributionOptions.REMAINING,
          disabled: false
        },
        {
          label: 'myadp-pay.DD_DEPOSIT_AMOUNT_PERCENTAGE_LABEL',
          value: DistributionOptions.PERCENTAGE,
          disabled: false
        },
        {
          label: 'myadp-pay.DD_DEPOSIT_AMOUNT_FLAT_LABEL',
          value: DistributionOptions.FLAT
        }
      ],
      defaultDepositType: DistributionOptions.REMAINING
    });
  });
});
