import { CurrencyPipe } from '@angular/common';
import { TestBed } from '@angular/core/testing';
import { Mock } from 'ts-mockery';

import { LanguageService } from '@myadp/common';

import { ValueFormatterService } from './value-formatter.service';
import { WorkflowComparisonService } from './workflow-comparison.service';

describe('WorkflowComparisonService', () => {
  let service: WorkflowComparisonService<any, any>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        WorkflowComparisonService,
        ValueFormatterService,
        CurrencyPipe,
        {
          provide: LanguageService,
          useValue: Mock.of<LanguageService>({ get: (key) => key })
        }
      ]
    });
    service = TestBed.inject(WorkflowComparisonService);
  });

  it('should format currency', () => {
    expect(service.formatCurrency({ amountValue: 13, currencyCode: 'USD' })).toEqual('$13.00');
    expect(service.formatCurrency({ amountValue: 0, currencyCode: 'USD' })).toEqual('$0.00');
    expect(service.formatCurrency(null)).toEqual(null);
  });

  it('should format percentages', () => {
    expect(service.formatPercentage(14)).toEqual('14%');
    expect(service.formatCurrency(null)).toEqual(null);
  });
});
