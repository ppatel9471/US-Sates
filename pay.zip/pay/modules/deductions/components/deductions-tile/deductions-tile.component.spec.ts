import { ValueFormatterService } from '@ag-grid-enterprise/all-modules';
import { CurrencyPipe } from '@angular/common';
import { ClientDeviceService } from '@synerg/components/shared';
import { BehaviorSubject, of } from 'rxjs';
import { Shallow } from 'shallow-render';
import { Mock } from 'ts-mockery';

import { LanguagePipe, LanguageService } from '@myadp/common';

import { CurrencyFormatComponent } from '../../../../';
import { PayDeductionsUI } from '../../../pay-deductions-shared/models/pay-deductions-ui';
import { PayDeductionsStoreActions } from '../../../pay-deductions-shared/store/pay-deductions-store.actions';
import { PayDeductionsStore } from '../../../pay-deductions-shared/store/pay-deductions.store';
import { PrivacyModeStore } from '../../../privacy-mode-shared/store/privacy-mode.store';
import { HasWorkflowChangesPipe } from '../../../shared/pipes/has-workflow-changes/has-workflow-changes.pipe';
import { DeductionsModule } from '../../deductions.module';
import { DeductionDetailsSelectorPipe } from '../../pipes/deduction-details-selector.pipe';
import { DeductionsStoreActions } from '../../store/deductions-store.actions';
import { StepsStoreActions } from '../../store/steps/steps-store.actions';
import { StepsStore } from '../../store/steps/steps.store';
import { DeductionAmountFormatComponent } from '../shared/deduction-amount-format/deduction-amount-format.component';
import { DeductionsTileComponent } from './deductions-tile.component';

describe('DeductionsTileComponent', () => {
  let shallow: Shallow<DeductionsTileComponent>;
  let mockShowSlidein$: BehaviorSubject<boolean>;

  const deductions: PayDeductionsUI.Deduction[] = [
    {
      currentData: {
        itemID: 'AL3',
        deductionCode: {
          codeValue: 'AL3',
          longName: 'ALLOWANCE 3'
        },
        deductionRate: {
          rateValue: 120,
          currencyCode: 'USD'
        }
      },
      pendingData: null,
      pendingEvent: null
    },
    {
      currentData: {
        itemID: 'UD',
        deductionCode: {
          codeValue: 'UD',
          longName: 'UNION DUES'
        },
        deductionRate: {
          rateValue: 18,
          unitCode: {
            codeValue: 'percent'
          }
        }
      },
      pendingData: null,
      pendingEvent: null
    }
  ];

  beforeEach(() => {
    mockShowSlidein$ = new BehaviorSubject<boolean>(false);

    shallow = new Shallow(DeductionsTileComponent, DeductionsModule)
      .provide(CurrencyPipe, LanguageService, ValueFormatterService)
      .dontMock(
        DeductionAmountFormatComponent,
        DeductionDetailsSelectorPipe,
        HasWorkflowChangesPipe,
        CurrencyFormatComponent,
        CurrencyPipe,
        ValueFormatterService
      )
      .mock(PayDeductionsStore, {
        state$: of({
          payDeductions: {
            data: deductions,
            loading: false,
            error: {}
          }
        })
      })
      .mock(DeductionsStoreActions, {
        loadDeductions: () => Mock.noop()
      })
      .mock(PayDeductionsStoreActions, {
        loadDeductions: () => Mock.noop()
      })
      .mock(StepsStore, {
        isSlideinOpen$: mockShowSlidein$,
        isSlideinOpenObs$: mockShowSlidein$.asObservable()
      })
      .mock(StepsStoreActions, {
        openSlidein: () => mockShowSlidein$.next(true),
        closeSlidein: () => mockShowSlidein$.next(false)
      })
      .mock(PrivacyModeStore, {
        showMaskedValue$: of(false)
      })
      .mock(ClientDeviceService, {
        isMobile: () => false,
        isNative: () => false
      })
      .mockPipe(LanguagePipe, (key) => key);
  });

  it('PIMYPI-T662/T666/T875 should show deduction items and manage button', async () => {
    const { find } = await shallow.render();
    const deductionItems = find('.deduction-item-value');

    expect(deductionItems.length).toBe(2);
    expect(deductionItems[0].nativeElement.textContent).toContain('ALLOWANCE 3');
    expect(deductionItems[0].nativeElement.textContent).toContain('$120.00');
    expect(deductionItems[1].nativeElement.textContent).toContain('UNION DUES');
    expect(deductionItems[1].nativeElement.textContent).toContain('18%');
    expect(find('.no-deduction')).toHaveFound(0);
    expect(find('.open-deductions-btn').nativeElement.textContent).toContain(
      'myadp-pay.DEDUCTIONS_MANAGE_DEDUCTIONS'
    );
  });

  it('PIMYPI-T665 should show single deduction and manage button', async () => {
    const { find } = await shallow
      .mock(PayDeductionsStore, {
        state$: of({
          payDeductions: {
            data: [
              {
                currentData: {
                  itemID: 'APT',
                  deductionCode: { codeValue: 'APT', longName: 'AD&D PST-TX' },
                  deductionRate: { rateValue: 3, unitCode: { codeValue: 'percent' } }
                },
                pendingData: null,
                pendingEvent: null
              }
            ],
            loading: false,
            error: {}
          }
        })
      })
      .render();
    const deductionItems = find('.deduction-item-value');

    expect(deductionItems.length).toBe(1);
    expect(deductionItems[0].nativeElement.textContent).toContain('AD&D PST-TX');
    expect(deductionItems[0].nativeElement.textContent).toContain('3%');
    expect(find('.no-deduction')).toHaveFound(0);
    expect(find('.open-deductions-btn').nativeElement.textContent).toContain(
      'myadp-pay.DEDUCTIONS_MANAGE_DEDUCTIONS'
    );
  });

  it('PIMYPI-T663 should show no deductions message and setup buttton', async () => {
    const { find } = await shallow
      .mock(PayDeductionsStore, {
        state$: of({
          payDeductions: {
            data: [],
            loading: false,
            error: {}
          }
        })
      })
      .render();

    expect(find('.deduction-item-value')).toHaveFound(0);
    expect(find('.no-deduction')).toHaveFound(1);
    expect(find('.open-deductions-btn').nativeElement.textContent).toContain(
      'myadp-pay.DEDUCTIONS_SET_UP_DEDUCTIONS'
    );
  });

  it('PIMYPI-T667 should show $0.00 when missing rateValue', async () => {
    const { find } = await shallow
      .mock(PayDeductionsStore, {
        state$: of({
          payDeductions: {
            data: [
              {
                currentData: {
                  itemID: 'APT',
                  deductionCode: { codeValue: 'APT', longName: 'AD&D PST-TX' },
                  deductionRate: { currencyCode: 'USD' }
                },
                pendingData: null,
                pendingEvent: null
              }
            ],
            loading: false,
            error: {}
          }
        })
      })
      .render();
    const [item] = find('.deduction-item-value');

    expect(item.nativeElement.textContent).toContain('AD&D PST-TX');
    expect(item.nativeElement.textContent).toContain('$0.00');
  });

  it('PIMYPI-T981 should show $0.00 when missing deductionRate', async () => {
    const { find } = await shallow
      .mock(PayDeductionsStore, {
        state$: of({
          payDeductions: {
            data: [
              {
                currentData: {
                  itemID: 'APT',
                  deductionCode: { codeValue: 'APT', longName: 'AD&D PST-TX' }
                },
                pendingData: null,
                pendingEvent: null
              }
            ],
            loading: false,
            error: {}
          }
        })
      })
      .render();
    const [item] = find('.deduction-item-value');

    expect(item.nativeElement.textContent).toContain('AD&D PST-TX');
    expect(item.nativeElement.textContent).toContain('$0.00');
  });

  it('PIMYPI-T982 should show $0.00 when rateValue is empty string', async () => {
    const { find } = await shallow
      .mock(PayDeductionsStore, {
        state$: of({
          payDeductions: {
            data: [
              {
                currentData: {
                  itemID: 'APT',
                  deductionCode: { codeValue: 'APT', longName: 'AD&D PST-TX' },
                  deductionRate: { rateValue: '', currencyCode: 'USD' }
                },
                pendingData: null,
                pendingEvent: null
              } as any // rateValue shouldn't be a string
            ],
            loading: false,
            error: {}
          }
        })
      })
      .render();
    const [item] = find('.deduction-item-value');

    expect(item.nativeElement.textContent).toContain('AD&D PST-TX');
    expect(item.nativeElement.textContent).toContain('$0.00');
  });

  describe('Alerts', () => {
    it('PIMYPI-T664 should show error alert when GET API throws 4xx/5xx', async () => {
      const { find } = await shallow
        .mock(PayDeductionsStore, {
          state$: of({
            payDeductions: {
              data: null,
              loading: false,
              error: { deductionsError: true }
            }
          })
        })
        .render();

      expect(find('.error-alert').nativeElement.textContent).toContain('common.GENERAL_ERROR');
      expect(find('.deduction-item-value')).toHaveFound(0);
    });

    it('PIMYPI-T876 should show pending changes alert if there is a pending Workflow add/edit', async () => {
      const pendingAddDed: PayDeductionsUI.Deduction = {
        currentData: null,
        pendingData: deductions[0].currentData,
        pendingEvent: { changeType: 'add' }
      };
      const { find } = await shallow
        .mock(PayDeductionsStore, {
          state$: of({
            payDeductions: {
              data: [pendingAddDed, deductions[1]],
              loading: false,
              error: {}
            }
          })
        })
        .render();

      expect(find('.pending-alert').nativeElement.textContent).toContain(
        'myadp-pay.WORKFLOW_PENDING_APPROVAL'
      );
      expect(find('.deduction-item-value')).toHaveFound(2);
    });

    it('PIMYPI-T877 should hide pending deletes and show pending changes alert if there is a pending deletion', async () => {
      const pendingDelete: PayDeductionsUI.Deduction = {
        currentData: deductions[0].currentData,
        pendingData: null,
        pendingEvent: { approver: 'Guy, Some', changeType: 'delete' }
      };
      const { find } = await shallow
        .mock(PayDeductionsStore, {
          state$: of({
            payDeductions: {
              data: [pendingDelete, deductions[1]],
              loading: false,
              error: {}
            }
          })
        })
        .render();

      expect(find('.pending-alert').nativeElement.textContent).toContain(
        'myadp-pay.WORKFLOW_PENDING_APPROVAL'
      );
      expect(find('.deduction-item-value')).toHaveFound(1);
    });
  });

  it('should open slidein', async () => {
    const { get, find, fixture } = await shallow.render();

    expect(find('deductions-slidein')).toHaveFound(0);

    find('.open-deductions-btn').nativeElement.click();
    fixture.detectChanges();

    expect(get(StepsStoreActions).openSlidein).toHaveBeenCalled();
    expect(find('deductions-slidein')).toHaveFoundOne();
  });
});
