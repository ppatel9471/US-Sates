import { Injectable } from '@angular/core';

import { Amount } from '@myadp/dto';

import { ValueFormatterService, ValueFormatterType } from './value-formatter.service';

@Injectable({
  providedIn: 'root'
})
export abstract class WorkflowComparisonService<DataType, ComparisonDetailsType> {
  constructor(private valueFormatterService: ValueFormatterService) {}

  // returns [currentData, pendingData]-tuple
  public abstract getComparisonData(
    data: DataType,
    ...args: any[]
  ): [ComparisonDetailsType, ComparisonDetailsType];

  public formatCurrency(amount: Partial<Amount>): string {
    return this.valueFormatterService.format(amount ?? null, ValueFormatterType.Currency);
  }

  public formatPercentage(percentage: number): string {
    return percentage
      ? this.valueFormatterService.format(percentage, ValueFormatterType.Percentage)
      : null;
  }
}
