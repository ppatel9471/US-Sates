import { Injectable } from '@angular/core';
import { BaseHttpClient } from '@myadp/common';

import { PayPermissionService, PAY_SFFO } from '@myadp/pay-shared';
import { WorkerTaxStatementsDTO } from '@myadp/dto';

@Injectable({
  providedIn: 'root'
})
export class TaxStatementsService {
  constructor(
    private payPermissionService: PayPermissionService,
    private baseHttpClient: BaseHttpClient
  ) {}

  public getTaxStatements(): Promise<WorkerTaxStatementsDTO.APIResponse> {
    const sffo = this.payPermissionService.hasTaxStatementsReadPermission()
      ? PAY_SFFO.TAX_STATEMENTS_READ
      : PAY_SFFO.TAX_STATEMENTS_READ_LEGACY;

    return this.baseHttpClient.get<WorkerTaxStatementsDTO.APIResponse>({
      userPermission: sffo
    });
  }
}
