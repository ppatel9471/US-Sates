import { PendingEventDataHistory } from '@myadp/dto';

export interface CodeType {
  codeValue: string;
  longName?: string;
  shortName?: string;
}
export interface AdditionalStatutoryInput {
  tagCode: string;
  tagValues: string[];
  dataTypeCode?: string;
  formatCode?: string;
}

export interface TaxWithholdingStatus {
  effectiveDate?: string;
  statusCode?: CodeType;
}

export interface AdditionalTaxAmount {
  amountValue: number;
  currencyCode?: string;
}

export interface Link {
  href?: string;
  rel?: string;
  method?: string;
}

export interface Action {
  attestation?: Attestation;
  operationID?: string;
  actionTypeCode?: string;
  confirmationRequiredIndicator?: boolean;
  commentAllowedIndicator?: boolean;
  defaultIndicator?: boolean;
  links?: Link[];
}

export interface Attestation {
  messageTxt?: string;
  actionBlockIndicator?: boolean;
}

export interface AttachmentType {
  nameCode?: CodeType;
  textValue?: string;
  attachmentLink?: {
    mediaType?: string;
    payLoadArguments: {
      argumentPath?: string;
      argumentValue?: string;
    }[];
  };
}

export interface PendingEvent {
  eventTypeId?: number;
  eventName?: string;
  history?: PendingEventDataHistory[];
  affectedUser?: PendingEventUser;
  submitter?: PendingEventUser;
}

export const enum PendingEventType {
  EMPLOYEE_INITIATED = 3,
  PRACTITIONER_INITIATE = 4
}

export interface PendingEventUser {
  firstName?: string;
  lastName?: string;
  userOID?: string;
}

export interface WorkflowStatus {
  wfStatusCode: number;
}

export interface ESignatureIndicator {
  signatureIndicator: boolean;
}
