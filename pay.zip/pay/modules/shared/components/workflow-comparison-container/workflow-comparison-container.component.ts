import { Component, EventEmitter, Input, Output } from '@angular/core';

import { WorkflowUI } from '../../models/workflow-ui.model';

@Component({
  selector: 'pay-workflow-comparison-container',
  templateUrl: './workflow-comparison-container.component.html'
})
export class WorkflowComparisonContainerComponent<Data extends { pendingEvent?: WorkflowUI.PendingEvent }> {
  @Input() data: Data;
  @Output() cancelRequest: EventEmitter<Data> = new EventEmitter<Data>();

  public canceledRequest() {
    this.cancelRequest.emit(this.data);
  }
}
