import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { EMPTY } from 'rxjs';
import { Shallow } from 'shallow-render';
import { Mock } from 'ts-mockery';

import {
  ExternalWindowService,
  LanguagePipe,
  LanguageService,
  PrintModalService
} from '@myadp/common';

import { SharedModule } from '../../shared.module';
import { PayTermsAndConditionsComponent } from './pay-terms-conditions.component';

describe('PayTermsAndConditions', () => {
  let shallow: Shallow<PayTermsAndConditionsComponent>;
  let defaultBinding: any;

  beforeEach(() => {
    defaultBinding = {
      bind: {
        formGroupControlName: 'ACCOUNT_DETAILS',
        formGroupControl: new FormGroup({
          ACCOUNT_DETAILS: new FormGroup({ terms: new FormControl() })
        }),
        consentText: 'consentText',
        printedConsentText: 'printedConsentText',
        consentTitle: 'consentTitle'
      }
    };

    return (shallow = new Shallow(PayTermsAndConditionsComponent, SharedModule)
      .dontMock(FormBuilder)
      .mock(ExternalWindowService, {
        open: () => Mock.noop()
      })
      .mock(PrintModalService, {
        printText: () => EMPTY
      })
      .mock(LanguageService, {
        get: (key) => key
      })
      .mockPipe(LanguagePipe, (key) => key));
  });

  describe('consent', () => {
    it('should show the modal whenever the checkbox is not true, clicking the checkbox should bring up the consent modal', async () => {
      const { find, fixture } = await shallow.render(defaultBinding);

      find('#pay-terms-conditions-checkbox').nativeElement.click();

      fixture.detectChanges();

      expect(find('.modal-body').nativeElement.textContent).toContain('consentText');
    });

    it('should show the modal with print option when terms and conditons link is clicked provided that the checkbox is true', async () => {
      const { find, fixture, instance } = await shallow.render(defaultBinding);
      instance.handleAgree();

      expect(instance.showTerms).toBeFalse();
      expect(instance.formGroupControl.get('ACCOUNT_DETAILS').get('terms').value).toBeTrue();

      fixture.detectChanges();
      find('#pay-terms-and-conditions-link').nativeElement.click();
      fixture.detectChanges();

      expect(find('.modal-footer adp-button')[1].nativeElement.textContent).toContain(
        'common.PRINT'
      );
    });

    it('should allow you to click the privacy link', async () => {
      const { find, get } = await shallow.render(defaultBinding);
      find('#pay-privacy-link').nativeElement.click();

      expect(get(ExternalWindowService).open).toHaveBeenCalledWith({
        uri: 'https://privacy.adp.com/privacy.html'
      });
    });

    it('should allow the user to toggle off the check box when it is true without bringing up the modal', async () => {
      const { find, fixture, instance } = await shallow.render(defaultBinding);

      instance.handleAgree();
      expect(instance.showTerms).toBeFalse();
      expect(instance.formGroupControl.get('ACCOUNT_DETAILS').get('terms').value).toBeTrue();

      fixture.detectChanges();
      find('#pay-terms-conditions-checkbox').nativeElement.click();
      fixture.detectChanges();

      expect(find('.modal-body')).toHaveFound(0);
      expect(instance.formGroupControl.get('ACCOUNT_DETAILS').get('terms').value).toBeFalse();
    });

    it('should allow the user to consent from either the terms link or from the default pop up modal', async () => {
      const { find, fixture, instance } = await shallow.render(defaultBinding);
      find('#pay-terms-conditions-checkbox').nativeElement.click();
      fixture.detectChanges();

      find('.modal-footer adp-button')[1].nativeElement.click();
      fixture.detectChanges();

      expect(instance.formGroupControl.get('ACCOUNT_DETAILS').get('terms').value).toBeTrue();

      find('#pay-terms-conditions-checkbox').nativeElement.click();
      fixture.detectChanges();

      expect(instance.formGroupControl.get('ACCOUNT_DETAILS').get('terms').value).toBeFalse();

      find('#pay-terms-and-conditions-link').nativeElement.click();
      fixture.detectChanges();

      find('.modal-footer adp-button')[1].nativeElement.click();
      fixture.detectChanges();

      expect(instance.formGroupControl.get('ACCOUNT_DETAILS').get('terms').value).toBeTrue();
    });

    it('should print modal', async () => {
      const { instance, get, fixture } = await shallow.render(defaultBinding);
      instance.showTermsWithPrint = true;
      fixture.detectChanges();
      instance.handlePrint();

      expect(get(PrintModalService).printText).toHaveBeenCalled();
    });
  });
});
