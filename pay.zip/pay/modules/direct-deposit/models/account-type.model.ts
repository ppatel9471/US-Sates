import { MiscPermissions } from '../models/deposit-account.model';

export enum StepOptions {
  DIRECT = 'DIRECT_DEPOSIT_STEPS',
  WISELY = 'WISELY_PAY_STEPS'
}

export interface AccountOption {
  icon: string;
  type: string;
  id: string;
  label: string;
  permission?: MiscPermissions;
}

export const ACCOUNT_OPTION: AccountOption = {
  icon: 'icon-bank-o',
  type: StepOptions.DIRECT,
  id: 'direct-deposit-account-type',
  label: 'myadp-pay.DIRECT_DEPOSIT'
};
