import { Shallow } from 'shallow-render';

import { SharedModule } from '../../shared.module';
import { TextFormatComponent } from './text-format.component';

describe('TextFormatComponent', () => {
  let shallow: Shallow<TextFormatComponent>;

  beforeEach(() => {
    shallow = new Shallow(TextFormatComponent, SharedModule);
  });

  it('should display the given text when the text is valid', async () => {
    const text: string = 'wash your hands';
    const { find } = await shallow.render({
      bind: {
        value: text
      }
    });

    expect(find('[data-e2e="value-section"]').nativeElement.innerHTML).toContain(text);
    expect(find('[data-e2e="double-dash-section"]')).toHaveFound(0);
  });

  it('should display two dashes when the given content is null', async () => {
    const { find } = await shallow.render({
      bind: {
        value: null
      }
    });

    expect(find('[data-e2e="value-section"]')).toHaveFound(0);
    expect(find('[data-e2e="double-dash-section"]').nativeElement.innerHTML).toContain('--');
  });

  it('should display two dashes when the given content is undefined', async () => {
    const { find } = await shallow.render({
      bind: {
        value: undefined
      }
    });

    expect(find('[data-e2e="value-section"]')).toHaveFound(0);
    expect(find('[data-e2e="double-dash-section"]').nativeElement.innerHTML).toContain('--');
  });
});
