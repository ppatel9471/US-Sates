import { TestBed } from '@angular/core/testing';
import { Mock } from 'ts-mockery';

import { WindowImplService as WindowService } from '@myadp/common/services/window-impl.service';
import { MockWindow } from '@specHelpers';

import { WebComponentsService } from './web-components.service';

describe('WebComponentsService', () => {
  let service: WebComponentsService;
  let mockWindow: MockWindow;

  beforeEach(() => {
    mockWindow = new MockWindow();
    mockWindow['customElements'] = {
      get: () => {
        return true;
      }
    };

    TestBed.configureTestingModule({
      providers: [
        {
          provide: WindowService,
          useValue: Mock.of<WindowService>({
            getWindow: () => mockWindow
          })
        }
      ]
    });

    service = TestBed.inject(WebComponentsService);
  });

  describe('hasRegistryDefinition', () => {
    it('should return true', () => {
      const hasDefinition = service.hasRegistryDefinition('pwc-pcc-tile-mfe');

      expect(hasDefinition).toBeTrue();
    });
    it('should return false', () => {
      mockWindow['customElements'] = {
        get: () => false
      };
      const hasDefinition = service.hasRegistryDefinition('pwc-pcc-tile-mfe');

      expect(hasDefinition).toBeFalse();
    });
  });
});
