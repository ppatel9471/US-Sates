import { Injectable } from '@angular/core';
import { findIndex, forEach, get, isArray } from 'lodash';

import { LanguageService } from '@myadp/common';

import { SummaryItem, WithholdingItem, WithholdingType } from '../../../models/formatted-tax-withholding.model';
import { AdditionalTaxAmount, CodeType, PendingEvent } from '../../../models/tax-withholding.model';
import { StateIncomeTaxWithholdingElection, UsStateTaxWithholdingElections } from '../../../models/us-state-tax-withholding-election.model';
import { FederalStateVersionService } from './federal-state-version.service';
import { ValueFormatterService, ValueFormatterType } from './value-formatter.service';
import { WithholdingFormatterService } from './withholding-formatter.service';

@Injectable({
  providedIn: 'root'
})
export class StateWithholdingTransformService {
  constructor(
    private withholdingFormatterService: WithholdingFormatterService,
    private valueFormatterService: ValueFormatterService,
    private languageService: LanguageService,
    private federalStateVersionService: FederalStateVersionService
  ) {}

  public getWithholdingItems(withholdingData: UsStateTaxWithholdingElections): WithholdingItem[] {
    const withholdings = this.getCurrentWithholdings(withholdingData);
    const pendingWithholding = this.getPendingWithholding(withholdingData);
    const pendingEvents = this.getPendingEvents(withholdingData);
    const payrollGroupCode = this.getPayrollGroupCode(withholdingData);
    const payrollRegionCode = this.getPayrollRegionCode(withholdingData);

    let withholdingItems = withholdings.map((withholding) =>
      this.getWithholdingItem(
        withholding,
        pendingWithholding,
        pendingEvents,
        payrollGroupCode,
        payrollRegionCode
      )
    );

    withholdingItems = this.withholdingFormatterService.sortWithholdingInfo(withholdingItems);
    return withholdingItems;
  }

  private getWithholdingItem(
    withholding: StateIncomeTaxWithholdingElection,
    pendingWithholding: StateIncomeTaxWithholdingElection,
    pendingEvents: PendingEvent,
    payrollGroupCode: CodeType,
    payrollRegionCode: CodeType
  ): WithholdingItem {
    const longName = this.withholdingFormatterService.getTitleName(withholding?.stateCode);
    const attachments = this.withholdingFormatterService.getAttachments(withholding);
    const currentSummaryItem = this.getSummaryItems(withholding);
    const effectiveDate = this.valueFormatterService.format(
      withholding?.taxWithholdingStatus?.effectiveDate,
      ValueFormatterType.Date
    );
    let pendingSummaryItem: SummaryItem[];
    let withholdingItemPendingEvents: PendingEvent;

    if (withholding?.stateCode?.codeValue === pendingWithholding?.stateCode?.codeValue) {
      pendingSummaryItem = this.getSummaryItems(pendingWithholding);
      this.withholdingFormatterService.formatPendingItems(currentSummaryItem, pendingSummaryItem);
      withholdingItemPendingEvents = pendingEvents;
    }
    const isLocked = this.isStateEditLocked(withholding);

    return {
      livedIn: withholding.livedInJurisdictionIndicator,
      workedIn: withholding.workedInJurisdictionIndicator,
      type: WithholdingType.STATE,
      state: this.federalStateVersionService.getYearState(longName),
      title: longName,
      payrollGroupCode: payrollGroupCode,
      payrollRegionCode: payrollRegionCode,
      effectiveDate: effectiveDate,
      rawData: withholding,
      summaryItems: currentSummaryItem,
      pendingSummaryItems: pendingSummaryItem,
      pendingEvents: withholdingItemPendingEvents,
      isLocked,
      lockedOutMessage: isLocked ? this.isStateLockedOut(withholding) : undefined,
      attachments: attachments
    };
  }

  private getPayrollGroupCode(withholdingData: UsStateTaxWithholdingElections): CodeType {
    return get(withholdingData, 'usStateTaxWithholdingElections[0].payrollGroupCode');
  }

  private getPayrollRegionCode(withholdingData: UsStateTaxWithholdingElections): CodeType {
    return get(withholdingData, 'usStateTaxWithholdingElections[0].payrollRegionCode');
  }

  private getCurrentWithholdings(
    withholdingData: UsStateTaxWithholdingElections
  ): StateIncomeTaxWithholdingElection[] {
    return get(
      withholdingData,
      'usStateTaxWithholdingElections[0].stateIncomeTaxWithholdingElections',
      []
    );
  }

  private getPendingWithholding(
    withholdingData: UsStateTaxWithholdingElections
  ): StateIncomeTaxWithholdingElection {
    return get(
      withholdingData,
      'usStateTaxWithholdingElections[0].workflowData.pendingData.usStateTaxWithholdingElections[0].stateIncomeTaxWithholdingElections[0]'
    );
  }

  private getPendingEvents(withholdingData: UsStateTaxWithholdingElections): PendingEvent {
    return get(withholdingData, 'usStateTaxWithholdingElections[0].workflowData.pendingEvents');
  }

  private getSummaryItems(withholding: StateIncomeTaxWithholdingElection): SummaryItem[] {
    const summaryItems: SummaryItem[] = [];
    this.withholdingFormatterService.summaryItemHelper(
      summaryItems,
      withholding,
      'taxFilingStatusCode.longName',
      'FILING_STATUS'
    );

    if (get(withholding, 'taxWithholdingAllowanceQuantity') >= 0) {
      this.withholdingFormatterService.summaryItemHelper(
        summaryItems,
        withholding,
        'taxWithholdingAllowanceQuantity',
        'TOTAL_ALLOWANCES'
      );
    }

    // CO2022 annual allowance amount
    const annualAllowanceAmount = this.withholdingFormatterService.getAdditionalStatutoryInputs(
      'ANNUAL_WITHHOLDING_ALLOWANCE',
      withholding
    );
    if (annualAllowanceAmount) {
      summaryItems.push({
        displayName: 'TWM_CO2022_SUMMARY_ALLOWANCES_LABEL',
        displayValue: this.valueFormatterService.format(
          { amountValue: annualAllowanceAmount },
          ValueFormatterType.Currency
        )
      });
    }

    // MS total exemption amount
    const totalExemptionAmount = this.withholdingFormatterService.getAdditionalStatutoryInputs(
      'TOTAL_EXEMPTION_AMOUNT',
      withholding
    );
    if (totalExemptionAmount) {
      summaryItems.push({
        displayName: 'TWM_SHARED_SUMMARY_EXEMPTION_AMOUNT_HEADING',
        displayValue: this.valueFormatterService.format(
          { amountValue: totalExemptionAmount },
          ValueFormatterType.Currency
        )
      });
    }

    // for New York local allowances
    this.getLocalAllowances(
      'NEW_YORK_CITY',
      'TWM_NY_SUMMARY_NEW_YORK_CITY_ALLOWANCES_LABEL',
      withholding,
      summaryItems
    );

    // for Additional Dependent Exemptions (IN)
    this.getLocalAllowances(
      'ADDITIONAL_DEPENDENTS',
      'TWM_SHARED_SUMMARY_ADDITIONAL_DEPENDENT_EXEMPTIONS_HEADING',
      withholding,
      summaryItems
    );

    this.withholdingFormatterService.summaryItemHelper(
      summaryItems,
      withholding,
      'taxWithholdingRate',
      'WITHHOLDING_TAX_PERCENTAGE',
      ValueFormatterType.Percentage
    );

    // for Louisiana exemptions
    this.getLocalAllowances('PERSONAL', 'TOTAL_ALLOWANCES', withholding, summaryItems);

    // for Louisiana Dependents
    this.getLocalAllowances(
      'DEPENDENTS',
      'TWM_LA_SUMMARY_NUMBER_OF_DEPENDENTS_HEADING',
      withholding,
      summaryItems
    );

    const additionalAmount: AdditionalTaxAmount = get(withholding, 'additionalTaxAmount');
    const additionalPercent: number = get(withholding, 'additionalTaxPercentage');
    if (
      this.withholdingFormatterService.showAdditionalTaxAmount(additionalAmount, additionalPercent)
    ) {
      this.withholdingFormatterService.summaryItemHelper(
        summaryItems,
        withholding,
        'additionalTaxAmount',
        'ADDITIONAL_WITHHOLDING_AMOUNT',
        ValueFormatterType.Currency
      );
    }

    if (
      this.withholdingFormatterService.showAdditionalTaxPercentage(
        additionalAmount,
        additionalPercent
      )
    ) {
      this.withholdingFormatterService.summaryItemHelper(
        summaryItems,
        withholding,
        'additionalTaxPercentage',
        'ADDITIONAL_PERCENT_WITHHELD',
        ValueFormatterType.Percentage
      );
    }

    // for New York local additional withholding
    const newYorkAdditionalWithholding = [
      'YONKERS_ADDITIONAL_WITHHOLDING',
      'NEW_YORK_CITY_ADDITIONAL_WITHHOLDING'
    ];
    forEach(newYorkAdditionalWithholding, (local) => {
      this.getLocalAdditionalWithholding(
        local,
        `TWM_NY_SUMMARY_${local}_LABEL`,
        withholding,
        summaryItems
      );
    });

    // additional county withholding amount (IN)
    this.getLocalAdditionalWithholding(
      'COUNTY_ADDITIONAL_WITHHOLDING',
      'TWM_IN_ADDITIONAL_WITHHOLDING_COUNTY_LABEL',
      withholding,
      summaryItems
    );

    const withholdLowerRate = this.withholdingFormatterService.getAdditionalStatutoryInputs(
      'LOWER_RATE',
      withholding
    );
    const withholdLowerRateKey = withholdLowerRate === 'true' ? 'common.YES' : 'common.NO';
    if (withholdLowerRate) {
      summaryItems.push({
        displayName: `TWM_SHARED_SUMMARY_WITHHOLD_LOWER_RATE_HEADING`,
        displayValue: this.languageService.get(withholdLowerRateKey)
      });
    }

    const withholdingCode = this.withholdingFormatterService.getAdditionalStatutoryInputs(
      'WITHHOLDING_CODE',
      withholding
    );
    if (withholdingCode) {
      summaryItems.push({
        displayName: `TWM_CT_SUMMARY_WITHHOLDING_CODE_HEADING`,
        displayValue: withholdingCode
      });
    }

    const overrideAmount: AdditionalTaxAmount = get(withholding, 'overrideTaxAmount');
    const overridePercent: number = get(withholding, 'overrideTaxPercentage');
    if (this.withholdingFormatterService.showAdditionalTaxAmount(overrideAmount, overridePercent)) {
      this.withholdingFormatterService.summaryItemHelper(
        summaryItems,
        withholding,
        'overrideTaxAmount',
        'OVERRIDE_AMOUNT_WITHHELD',
        ValueFormatterType.Currency
      );
    }

    if (
      this.withholdingFormatterService.showAdditionalTaxPercentage(overrideAmount, overridePercent)
    ) {
      this.withholdingFormatterService.summaryItemHelper(
        summaryItems,
        withholding,
        'overrideTaxPercentage',
        'OVERRIDE_PERCENT_WITHHELD',
        ValueFormatterType.Percentage
      );
    }

    const exemptSummaryItem = this.withholdingFormatterService.isExempt(withholding);
    if (exemptSummaryItem) {
      summaryItems.push(exemptSummaryItem);
    }

    if (get(withholding, 'reducedTaxAmount.amountValue') >= 0) {
      this.withholdingFormatterService.summaryItemHelper(
        summaryItems,
        withholding,
        'reducedTaxAmount',
        'REDUCED_WITHHOLDING_AMOUNT',
        ValueFormatterType.Currency
      );
    }

    return summaryItems;
  }

  private isStateEditLocked(withholding: StateIncomeTaxWithholdingElection = {}): boolean {
    if (!isArray(withholding.actions)) {
      return false;
    }
    return (
      findIndex(
        withholding.actions,
        (action) => action.operationID === 'worker.usState.taxWithholding.election.read'
      ) !== -1
    );
  }
  private isStateLockedOut(withholding: StateIncomeTaxWithholdingElection = {}): string {
    const action = withholding.actions.find(
      (withholdingAction) => !!withholdingAction.attestation?.messageTxt
    );
    return action?.attestation?.messageTxt;
  }

  private getLocalAllowances(
    codeValue: string,
    heading: string,
    withholding: StateIncomeTaxWithholdingElection,
    summaryItems: SummaryItem[]
  ): void {
    const allowances = findIndex(get(withholding, 'taxAllowances'), {
      allowanceTypeCode: { codeValue: codeValue }
    });
    if (allowances > -1) {
      this.withholdingFormatterService.summaryItemHelper(
        summaryItems,
        withholding,
        `taxAllowances[${allowances}].taxAllowanceQuantity`,
        heading
      );
    }
  }

  private getLocalAdditionalWithholding(
    tagCode: string,
    heading: string,
    withholding: StateIncomeTaxWithholdingElection,
    summaryItems: SummaryItem[]
  ): void {
    const additionalWithholding = this.withholdingFormatterService.getAdditionalStatutoryInputs(
      tagCode,
      withholding
    );
    if (additionalWithholding) {
      summaryItems.push({
        displayName: heading,
        displayValue: this.valueFormatterService.format(
          { amountValue: additionalWithholding },
          ValueFormatterType.Currency
        )
      });
    }
  }
}
