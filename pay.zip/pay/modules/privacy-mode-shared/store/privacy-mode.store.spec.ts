import { fakeAsync, flush, TestBed } from '@angular/core/testing';
import { ClientDeviceService } from '@synerg/components/shared';
import { skip, take } from 'rxjs/operators';
import { Mock } from 'ts-mockery';

import { UserPreferenceKeys, UserPreferencesService } from '@myadp/common';

import { PrivacyModeStore } from './privacy-mode.store';

describe('PrivacyModeStore', () => {
  let privacyModeStore: PrivacyModeStore;
  let userPrefsService: UserPreferencesService;
  let clientDeviceService: ClientDeviceService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        PrivacyModeStore,
        {
          provide: UserPreferencesService,
          useValue: Mock.of<UserPreferencesService>({
            getPreferenceValue: () => Promise.resolve<boolean>(false),
            setPreference: () => Promise.resolve(true)
          })
        },
        {
          provide: ClientDeviceService,
          useValue: Mock.of<ClientDeviceService>({
            isNative: () => false,
            isMobile: () => false
          })
        }
      ]
    });

    privacyModeStore = TestBed.inject(PrivacyModeStore);
    userPrefsService = TestBed.inject(UserPreferencesService);
    clientDeviceService = TestBed.inject(ClientDeviceService);
  });

  it('should create the store with an initial state', async (done: DoneFn) => {
    expect(privacyModeStore).toBeTruthy();
    expect(privacyModeStore.privacyMode).toBeNull();
    expect(userPrefsService.getPreferenceValue).toHaveBeenCalledWith(
      UserPreferenceKeys.ENABLE_PAY_PRIVACY_MODE
    );

    // skip the first value since BehaviorSubjects have a default value
    privacyModeStore.privacyMode$.pipe(skip(1)).subscribe((value: boolean) => {
      expect(value).toBe(false);
      done();
    });
    privacyModeStore.showMaskedValue$.pipe(skip(1)).subscribe((value: boolean) => {
      expect(value).toBe(false);
      done();
    });
  });

  it('should show masked value when privacy mode is on and not mobile', fakeAsync(() => {
    privacyModeStore.setPrivacyMode(true);
    flush();
    privacyModeStore.showMaskedValue$.pipe(take(1)).subscribe((value: boolean) => {
      expect(value).toBe(true);
    });
    flush();
  }));

  it('should not show masked value when privacy mode is on but is on mobile', fakeAsync(() => {
    Mock.extend(clientDeviceService).with({
      isNative: () => true,
      isMobile: () => true
    });
    privacyModeStore.setPrivacyMode(true);
    flush();
    privacyModeStore.showMaskedValue$.pipe(take(1)).subscribe((value: boolean) => {
      expect(value).toBe(false);
    });
    flush();
  }));

  it('should save the privacy mode to user preferences', fakeAsync(() => {
    privacyModeStore.setPrivacyMode(true);
    flush();

    expect(userPrefsService.setPreference).toHaveBeenCalledWith(
      UserPreferenceKeys.ENABLE_PAY_PRIVACY_MODE,
      true
    );
    expect(privacyModeStore.privacyMode).toBe(true);
  }));
});
