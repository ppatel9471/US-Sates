import { Component } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { CountryDetails } from '../../../pay-distributions-shared/models/country';
import { Observable } from 'rxjs';
import { take } from 'rxjs/operators';

import { DirectDepositAccount } from '../../models/direct-deposit-account.model';
import { StepsStore, StepsStoreActions } from '../../store/steps/steps.store';

@Component({
  selector: 'dd-base-step',
  template: ''
})
export class BaseStepComponent {
  public directDepositAccounts: DirectDepositAccount[];
  public directDepositAccounts$: Observable<DirectDepositAccount[]>;
  public hasChangePermission$: Observable<boolean>;
  public isEditing: boolean;
  public country: CountryDetails;

  constructor(public stepsStore: StepsStore, public stepsStoreActions: StepsStoreActions) {
    this.directDepositAccounts$ = this.stepsStore.directDepositAccounts$;
    this.hasChangePermission$ = this.stepsStore.hasChangePermission$;
    this.isEditing = this.stepsStore.isEditing;
    this.country = this.stepsStore.country;

    // turn the Observable into raw value for child steps
    this.directDepositAccounts$.pipe(take(1)).subscribe((accounts) => {
      this.directDepositAccounts = accounts;
    });
  }

  public disableNext(value: boolean = true): void {
    this.stepsStoreActions.disableNext(value);
  }

  public setFormGroup(form: FormGroup, ...excludedFormProps: string[]): void {
    this.stepsStoreActions.setFormGroup(form, ...excludedFormProps);
  }
}
