import { StateModel } from './states.model';
import { CodeType, PendingEvent } from './tax-withholding.model';

export const enum WithholdingType {
  FEDERAL = 'FEDERAL',
  STATE = 'STATE',
  LOCAL = 'LOCAL'
}

export interface SummaryItem {
  displayName: string;
  displayValue?: any;
}

export interface Info {
  type: string;
  title?: string;
  message: string;
}

export interface Attachment {
  shortName?: string;
  gssUrl: string;
  submittedDateTime?: string;
}

export interface WithholdingItem {
  livedIn?: boolean;
  workedIn?: boolean;
  type?: WithholdingType;
  state: StateModel;
  title?: string;
  summaryItems?: SummaryItem[];
  pendingSummaryItems?: SummaryItem[];
  pendingEvents?: PendingEvent;
  payrollGroupCode?: CodeType;
  payrollRegionCode?: CodeType;
  rawData?: any;
  allowEdit?: boolean;
  showEffectiveDate?: boolean;
  isNoIncomeTax?: boolean;
  isLocked?: boolean;
  isUneditable?: boolean;
  lockedOutMessage?: string;
  isUnsupported?: boolean;
  isFlatRate?: boolean;
  info?: Info;
  effectiveDate?: string;
  attachments?: Attachment[];
  isCompleted?: boolean;
  invalidFederalDependency?: boolean;
}

export interface WithholdingInfo {
  type?: WithholdingType;
  withholdingItems?: WithholdingItem[];
  jurisdiction?: string;
  pendingEvents?: PendingEvent;
  hasError?: boolean;
  hasElections?: boolean;
}
