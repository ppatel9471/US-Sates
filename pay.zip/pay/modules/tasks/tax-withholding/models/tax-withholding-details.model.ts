import { get } from 'lodash';

import { PendingEvent } from '../../../..//models/tax-withholding.model';
import { WithholdingItem } from '../../../..//models/formatted-tax-withholding.model';
import { UsFederalTaxWithholdingElections } from '../../../..//models/us-federal-tax-withholding-election.model';
import { UsStateTaxWithholdingElections } from '../../../..//models/us-state-tax-withholding-election.model';
import {
  loadRequesterAndLatestComments,
  NotificationComments
} from '@myadp/thingstodo-shared';

type Elections = UsFederalTaxWithholdingElections | UsStateTaxWithholdingElections;

export class TaxWithholdingDetails {
  public withholdingItem: WithholdingItem;
  public pendingEvents: PendingEvent;
  public comments: NotificationComments;
  private elections: Elections;

  constructor(elections: Elections) {
    this.elections = elections;
    this.setPendingEvents(elections);
  }

  public isFederal(): boolean {
    return get(this.elections, 'usFederalTaxWithholdingElections') !== undefined;
  }

  private setPendingEvents(elections: Elections) {
    if (this.isFederal()) {
      this.pendingEvents = get(
        elections,
        'usFederalTaxWithholdingElections[0].workflowData.pendingEvents'
      );
    } else {
      this.pendingEvents = get(
        elections,
        'usStateTaxWithholdingElections[0].workflowData.pendingEvents'
      );
    }
    this.comments = loadRequesterAndLatestComments(this.pendingEvents, null);
  }
}
