import { Amount } from '@myadp/dto';

export enum StatementType {
  PAY_STATEMENT = 'payStatement',
  TAX_STATEMENT = 'taxStatement',
  TAX_WITHHOLDING = 'taxWithholding',
  TAX_WITHHOLDING_GSS = 'taxWithholdingGss',
  TAX_WITHHOLDING_BLANK_FORM = 'taxWithholdingBlankForm'
}

export enum StatementDetailItemType {
  CURRENCY = 'currency'
}

export interface StatementDetailItem {
  label: string;
  value: string | Amount;
  type?: StatementDetailItemType;
}

export interface StatementBehaviorSubject {
  finalUrl?: string;
  uri?: string;
  type?: StatementType;
  stepUpEnabled?: boolean;
  useAudioEye?: boolean;
  singleStatement?: PdfStatement;
}

export interface PdfStatement {
  title?: string;
  uri?: string;
  statementDetails?: StatementDetailItem[];
}
