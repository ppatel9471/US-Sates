import { NgModule } from '@angular/core';
import { ButtonModule } from '@espresso/button';
import { CoreModule } from '@espresso/core';
import { AlertModule } from '@synerg/components/alert';
import { BusyIndicatorModule } from '@synerg/components/busy-indicator';

import { LazyHelperService, MyAdpCommonModule } from '@myadp/common';

import { OCRConfirmationStepComponent } from './components/ocr-confirmation-step/ocr-confirmation-step.component';
import { OCRTriggerButtonComponent } from './components/ocr-trigger-button/ocr-trigger-button.component';
import { DirectDepositSandboxWrapperComponent } from './components/sandbox/direct-deposit-sandbox-wrapper.component';
import { DirectDepositSandboxUpgradeDirective } from './components/sandbox/direct-deposit-sandbox.upgrade.directive';

@NgModule({
  imports: [CoreModule, MyAdpCommonModule, AlertModule, ButtonModule, BusyIndicatorModule],
  declarations: [
    OCRTriggerButtonComponent,
    OCRConfirmationStepComponent,
    DirectDepositSandboxUpgradeDirective,
    DirectDepositSandboxWrapperComponent
  ],
  exports: [OCRTriggerButtonComponent, OCRConfirmationStepComponent],
  providers: [
    {
      provide: 'redbox.pay.directDeposit.DirectDepositService',
      useFactory: (lazyHelperService: LazyHelperService) => {
        return lazyHelperService.ng1InjectorSync.get(
          'redbox.pay.directDeposit.DirectDepositService'
        );
      },
      deps: [LazyHelperService]
    },
    {
      provide: 'redbox.pay.common.CommonConstant',
      useFactory: (lazyHelperService: LazyHelperService) => {
        return lazyHelperService.ng1InjectorSync.get('redbox.pay.common.CommonConstant');
      },
      deps: [LazyHelperService]
    }
  ]
})
export class DirectDepositModule {}
