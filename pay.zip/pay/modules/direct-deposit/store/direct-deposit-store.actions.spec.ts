import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { fakeAsync, flush, TestBed, tick } from '@angular/core/testing';
import { LoggerFactory, WindowService } from '@espresso/core';
import { of, throwError } from 'rxjs';
import { delay } from 'rxjs/operators';
import { Mock } from 'ts-mockery';

import { FilteredUserProfileService } from '@myadp/common';
import { FindSffoService, PayPermissionService } from '@myadp/pay-shared';
import { MockLoggerFactory } from '@specHelpers';
import {
  MOCK_ALT_WF_ACCOUNTS,
  MOCK_FORM_DETAILS,
  MOCK_TRANSFORMED_DIRECT_DEPOSIT_ACCOUNTS,
  MOCK_TRANSFORMED_DIRECT_DEPOSIT_ACCOUNTS_CACHE,
  MOCK_TRANSFORMED_MASKED_DIRECT_DEPOSIT_ACCOUNTS,
  MOCK_WF_RECALL_ACCOUNTS
} from '@specHelpers/pay/direct-deposit/direct-deposit';
import {
  MOCK_TRANSFORMED_MASKED_PAY_DISTRIBUTIONS,
  MOCK_TRANSFORMED_PAY_DISTRIBUTIONS
} from '@specHelpers/pay/pay-distributions/pay-distributions';
import { MOCK_PAY_DISTRIBUTIONS_META_RESPONSE } from '@specHelpers/pay/pay-distributions/pay-distributions-meta';

import {
  DistributionOptions,
  PayDistributionsStoreSlice
} from '../../pay-distributions-shared/models/pay-distributions-ui';
import { PayDistributionStore } from '../../pay-distributions-shared/store/pay-distribution.store';
import { PayDistributionStoreActions } from '../../pay-distributions-shared/store/pay-distribution.store.actions';
import { AccountDetailsControls } from '../models/account-details-form.model';
import { ValidationStatus } from '../models/deposit-account.model';
import { DepositAmountControls } from '../models/deposit-amount-form.model';
import { DirectDepositAccount } from '../models/direct-deposit-account.model';
import { WiselyTypes } from '../models/wisely.model';
import { ValidationStatusCodes } from './direct-deposit-store.actions';
import {
  DirectDepositStore,
  DirectDepositStoreActions,
  DirectDepositStoreSlice
} from './direct-deposit.store';

import { COUNTRY, COUNTRY_CONFIG } from './../../pay-distributions-shared/models/country';

const sffo = {
  sffo: {
    sffo: [
      'payrollManagement',
      'payrollInstructionManagement',
      'payDistributionManagement',
      'payDistribution.read'
    ]
  },
  href: 'foo'
};

describe('DirectDepositStoreActions', () => {
  let directDepositStoreActions: DirectDepositStoreActions;
  let directDepositStore: DirectDepositStore;
  let userProfileService: FilteredUserProfileService;
  let payDistributionStore: PayDistributionStore;
  let payDistributionStoreActions: PayDistributionStoreActions;
  let httpClient: HttpTestingController;
  let payPermissionService: PayPermissionService;
  let findSffoService: FindSffoService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        DirectDepositStore,
        {
          provide: FindSffoService,
          useValue: Mock.of<FindSffoService>({
            findSffo: () => sffo
          })
        },
        {
          provide: FilteredUserProfileService,
          useValue: Mock.of<FilteredUserProfileService>({
            getApplicationId: () => of('SOR_PROVIDER')
          })
        },
        {
          provide: PayPermissionService,
          useValue: Mock.of<PayPermissionService>({
            hasWiselyDirectPermissionPromise: () => Promise.resolve(false),
            hasWiselyPayPermissionPromise: () => Promise.resolve(false),
            hasDirectDepositAccountManagementPermissionPromise: () => Promise.resolve(false)
          })
        },
        {
          provide: PayDistributionStore,
          useValue: Mock.of<PayDistributionStore>({
            hasChangePermission$: of(true),
            payDistributions$: of(MOCK_TRANSFORMED_PAY_DISTRIBUTIONS),
            payDistributionMeta$: of(MOCK_PAY_DISTRIBUTIONS_META_RESPONSE),
            payDistributionCountry: COUNTRY_CONFIG[COUNTRY.US],
            hasDistributionError$: of(false),
            isLoading$: of(false),
            stateValue: {
              [PayDistributionsStoreSlice.PAY_DISTRIBUTIONS_META]: {
                data: {
                  meta: {
                    canValidateBankInfo: true
                  }
                }
              }
            }
          })
        },
        {
          provide: PayDistributionStoreActions,
          useValue: Mock.of<PayDistributionStoreActions>({
            recallDistributions: () => Promise.resolve(),
            postDistributions: () => Promise.resolve(),
            loadDistributions: () => Mock.noop()
          })
        },
        { provide: LoggerFactory, useClass: MockLoggerFactory },
        {
          provide: WindowService,
          useValue: Mock.of<WindowService>({
            getConfig: () => ({ BANK_ACCOUNT_VALIDATION_ENABLED: true })
          })
        }
      ]
    });

    directDepositStore = TestBed.inject(DirectDepositStore);
    directDepositStoreActions = TestBed.inject(DirectDepositStoreActions);
    payDistributionStore = TestBed.inject(PayDistributionStore);
    payPermissionService = TestBed.inject(PayPermissionService);
    findSffoService = TestBed.inject(FindSffoService);
    payDistributionStoreActions = TestBed.inject(PayDistributionStoreActions);
    userProfileService = TestBed.inject(FilteredUserProfileService);
    httpClient = TestBed.inject(HttpTestingController);
  });

  it('should init and store SOR provider and permission info', fakeAsync(() => {
    directDepositStoreActions.init();
    flush();

    expect(userProfileService.getApplicationId).toHaveBeenCalledWith('MobileESSPayDistribution');
    expect(
      directDepositStore.stateValue[DirectDepositStoreSlice.DIRECT_DEPOSIT_CONFIG].data
    ).toEqual({
      sorProvider: 'SOR_PROVIDER'
    });
  }));

  it('should reset form data', () => {
    const [mockFormDetails] = MOCK_FORM_DETAILS.flatNew;
    directDepositStore.update(DirectDepositStoreSlice.FORM_DETAILS, {
      data: mockFormDetails
    });
    directDepositStoreActions.resetFormData();

    expect(directDepositStore.stateValue[DirectDepositStoreSlice.FORM_DETAILS].data).toBeNull();
  });

  it('should reset modified accounts', () => {
    directDepositStore.update(DirectDepositStoreSlice.MODIFIED_ACCOUNTS, {
      data: { add: [] }
    });
    directDepositStoreActions.resetModifiedAccounts();

    expect(
      directDepositStore.stateValue[DirectDepositStoreSlice.MODIFIED_ACCOUNTS].data
    ).toBeNull();
  });

  it('should delete direct deposits', fakeAsync(() => {
    directDepositStoreActions.loadDirectDepositAccounts(false, false);
    flush();

    const deletedAccount =
      directDepositStore.stateValue[DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS].data[0];
    directDepositStoreActions.deleteAccount(deletedAccount.currentData.id);

    expect(
      directDepositStore.stateValue[DirectDepositStoreSlice.MODIFIED_ACCOUNTS].data?.delete
    ).toEqual([deletedAccount]);
    expect(
      directDepositStore.stateValue[DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS].data.length
    ).toEqual(2);
    expect(directDepositStore.stateValue[DirectDepositStoreSlice.FORM_DETAILS].data).toBeNull();
  }));

  it('should remove an add event if the source of the add was later deleted in the session', () => {
    Mock.extend(directDepositStore).with({
      getDDAccountsSnapshot: () => [
        {
          currentData: {
            id: 'foo'
          }
        }
      ]
    });

    directDepositStore.update(DirectDepositStoreSlice.MODIFIED_ACCOUNTS, {
      data: { add: [{ currentData: { id: 'foo' } }] }
    });

    directDepositStoreActions.deleteAccount('foo');

    expect(
      directDepositStore.stateValue[DirectDepositStoreSlice.MODIFIED_ACCOUNTS].data.add.length
    ).toBe(0);
  });

  it('should delete a Workflow direct deposit account', () => {
    const mockData: DirectDepositAccount[] = [
      MOCK_TRANSFORMED_DIRECT_DEPOSIT_ACCOUNTS[0], // no change
      {
        currentData: MOCK_TRANSFORMED_DIRECT_DEPOSIT_ACCOUNTS[1].currentData,
        pendingData: null,
        pendingEvent: { changeType: null }
      },
      {
        currentData: null,
        pendingData: null,
        pendingEvent: { changeType: null }
      },
      {
        currentData: null,
        pendingData: MOCK_TRANSFORMED_DIRECT_DEPOSIT_ACCOUNTS[2].currentData,
        pendingEvent: { changeType: 'add' }
      }
    ];
    directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS, {
      data: mockData
    });

    const deletedAccount = mockData[3];
    directDepositStoreActions.deleteAccount(deletedAccount.pendingData.id);

    expect(
      directDepositStore.stateValue[DirectDepositStoreSlice.MODIFIED_ACCOUNTS].data?.delete
    ).toEqual([deletedAccount]);
    expect(
      directDepositStore.stateValue[DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS].data.length
    ).toEqual(4);
    expect(directDepositStore.getDDAccountsSnapshot().length).toEqual(3);
    expect(
      directDepositStore.stateValue[DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS].data[3]
    ).toEqual({ currentData: null, pendingData: null, pendingEvent: { changeType: 'pruned' } });
    expect(directDepositStore.stateValue[DirectDepositStoreSlice.FORM_DETAILS].data).toBeNull();
  });

  it('should not add duplicate accounts to MODIFIED_ACCOUNTS', () => {
    const [mockFormDetails] = MOCK_FORM_DETAILS.percentageEdit;
    const existingAccount = MOCK_TRANSFORMED_DIRECT_DEPOSIT_ACCOUNTS[1];

    directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS, {
      data: [existingAccount]
    });
    directDepositStore.update(DirectDepositStoreSlice.FORM_DETAILS, {
      data: mockFormDetails
    });

    let accounts = directDepositStoreActions.updateAccountChanges();
    const editedAccount = accounts[0];

    expect(
      directDepositStore.stateValue[DirectDepositStoreSlice.MODIFIED_ACCOUNTS].data.edit.length
    ).toBe(1);
    expect(
      directDepositStore.stateValue[DirectDepositStoreSlice.MODIFIED_ACCOUNTS].data.edit
    ).toEqual([editedAccount]);

    directDepositStore.update(DirectDepositStoreSlice.FORM_DETAILS, {
      data: {
        id: 'C22',
        [AccountDetailsControls.ACCOUNT_TYPE_CODE]: {
          label: 'Checking 2',
          value: 'C2',
          shortName: '',
          longName: 'Checking 2'
        },
        codeValueData: {
          accountCode: 'C2',
          shortName: '',
          longName: 'Checking 2'
        },
        [AccountDetailsControls.ACCOUNT_NAME]: '',
        [AccountDetailsControls.ACCOUNT_NUMBER]: 'X123456P7',
        [AccountDetailsControls.ROUTING_NUMBER]: '021000021',
        [DepositAmountControls.AMOUNT_TYPE]: DistributionOptions.PERCENTAGE,
        [DepositAmountControls.PERCENTAGE_AMOUNT]: '18',
        [DepositAmountControls.FLAT_AMOUNT]: null
      }
    });

    accounts = directDepositStoreActions.updateAccountChanges();

    expect(
      directDepositStore.stateValue[DirectDepositStoreSlice.MODIFIED_ACCOUNTS].data.edit.length
    ).toBe(1);
    expect(
      directDepositStore.stateValue[DirectDepositStoreSlice.MODIFIED_ACCOUNTS].data.edit
    ).toEqual([editedAccount]);
  });

  describe('loadDirectDepositAccounts', () => {
    it('should reset direct deposit accounts to initial data and reset modified accounts', () => {
      directDepositStoreActions.loadDirectDepositAccounts(false, false);
      directDepositStore.update(DirectDepositStoreSlice.MODIFIED_ACCOUNTS, {
        data: { delete: [], edit: [] }
      });

      expect(
        directDepositStore.stateValue[DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS_INITIAL]
      ).toEqual({
        data: MOCK_TRANSFORMED_DIRECT_DEPOSIT_ACCOUNTS,
        loading: false,
        error: null
      });

      directDepositStoreActions.revertAllChanges();

      expect(
        directDepositStore.stateValue[DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS].data
      ).toEqual(
        directDepositStore.stateValue[DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS_INITIAL].data
      );
      expect(
        directDepositStore.stateValue[DirectDepositStoreSlice.MODIFIED_ACCOUNTS].data
      ).toBeNull();
    });

    it('should cache all the current accounts and their validation status', () => {
      Mock.extend(payDistributionStore).with({
        payDistributions$: of(MOCK_TRANSFORMED_DIRECT_DEPOSIT_ACCOUNTS_CACHE)
      });

      const sampleAccount = MOCK_TRANSFORMED_DIRECT_DEPOSIT_ACCOUNTS_CACHE[0].currentData;
      const sampleKey = `${sampleAccount.routingNumber}${sampleAccount.accountNumber}`;

      directDepositStoreActions.loadDirectDepositAccounts(false, false);
      expect(
        directDepositStore.stateValue[DirectDepositStoreSlice.ACCOUNT_VERIFICATION].data
      ).toHaveProperty(sampleKey);

      expect(
        directDepositStore.stateValue[DirectDepositStoreSlice.ACCOUNT_VERIFICATION].data[sampleKey]
      ).toEqual({ status: ValidationStatus.SUCCESS });

      const secondSample = MOCK_TRANSFORMED_DIRECT_DEPOSIT_ACCOUNTS_CACHE[1].currentData;
      const secondKey = `${secondSample.routingNumber}${secondSample.accountNumber}`;

      expect(
        directDepositStore.stateValue[DirectDepositStoreSlice.ACCOUNT_VERIFICATION].data[secondKey]
      ).toEqual({ status: ValidationStatus.WARN });
    });

    it('should not cache when there is an error in the payload', fakeAsync(() => {
      Mock.extend(payDistributionStore).with({
        payDistributions$: throwError('payDistributions error')
      });

      expect(
        directDepositStore.stateValue[DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS]
      ).toEqual({
        data: null,
        loading: false,
        error: {}
      });
      directDepositStoreActions.loadDirectDepositAccounts(false, false);
      flush();

      expect(directDepositStore.stateValue[DirectDepositStoreSlice.ACCOUNT_VERIFICATION]).toEqual({
        data: undefined,
        loading: false,
        error: {}
      });
    }));

    it('should load direct deposit accounts into an initial store for resetting purposes', () => {
      directDepositStoreActions.loadDirectDepositAccounts(false, false);
      expect(
        directDepositStore.stateValue[DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS_INITIAL]
      ).toEqual({
        data: MOCK_TRANSFORMED_DIRECT_DEPOSIT_ACCOUNTS,
        loading: false,
        error: null
      });
    });

    it('should load direct deposit accounts', fakeAsync(() => {
      expect(
        directDepositStore.stateValue[DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS]
      ).toEqual({
        data: null,
        loading: false,
        error: {}
      });
      directDepositStoreActions.loadDirectDepositAccounts(false, false);
      flush();

      expect(payDistributionStoreActions.loadDistributions).toHaveBeenCalledWith(false, false);

      expect(directDepositStore.stateValue[DirectDepositStoreSlice.PERMISSIONS].data).toEqual({
        [WiselyTypes.WISELY_DIRECT]: false,
        [WiselyTypes.WISELY_PAY]: false,
        GIACT: false,
        canValidateBankInfo: true
      });

      expect(directDepositStore.directDepositCountry).toEqual(COUNTRY_CONFIG[COUNTRY.US]);

      expect(
        directDepositStore.stateValue[DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS]
      ).toEqual({
        data: MOCK_TRANSFORMED_DIRECT_DEPOSIT_ACCOUNTS,
        loading: false,
        error: null
      });
    }));

    it('should handle loading errors', fakeAsync(() => {
      Mock.extend(payDistributionStore).with({
        payDistributions$: throwError('payDistributions error')
      });

      expect(
        directDepositStore.stateValue[DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS]
      ).toEqual({
        data: null,
        loading: false,
        error: {}
      });
      directDepositStoreActions.loadDirectDepositAccounts(false, false);
      flush();

      expect(
        directDepositStore.stateValue[DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS]
      ).toEqual({
        data: null,
        loading: false,
        error: { ddAccountsLoadError: true }
      });
    }));

    it('should handle pay distributions load errors', fakeAsync(() => {
      Mock.extend(payDistributionStore).with({
        hasDistributionError$: of(true)
      });

      expect(
        directDepositStore.stateValue[DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS]
      ).toEqual({
        data: null,
        loading: false,
        error: {}
      });
      directDepositStoreActions.loadDirectDepositAccounts(false, false);
      flush();

      expect(
        directDepositStore.stateValue[DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS]
      ).toEqual({
        data: null,
        loading: false,
        error: { ddAccountsLoadError: true }
      });
    }));

    it('should set existing (masked) pay distributions if pay distributions exist and has error', fakeAsync(() => {
      directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS, {
        data: MOCK_TRANSFORMED_PAY_DISTRIBUTIONS
      });

      Mock.extend(payDistributionStore).with({
        hasDistributionError$: of(true)
      });

      directDepositStoreActions.loadDirectDepositAccounts(false, false);

      expect(
        directDepositStore.stateValue[DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS]
      ).toEqual({
        data: MOCK_TRANSFORMED_PAY_DISTRIBUTIONS,
        loading: false,
        error: { ddAccountsLoadError: true }
      });
    }));

    it('should update direct deposit accounts after loading pay distributions', fakeAsync(() => {
      Mock.extend(payDistributionStore).with({
        payDistributions$: of(MOCK_TRANSFORMED_MASKED_PAY_DISTRIBUTIONS),
        isLoading$: of(true, false).pipe(delay(1))
      });
      directDepositStoreActions.loadDirectDepositAccounts();

      expect(
        directDepositStore.stateValue[DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS]
      ).toEqual({
        data: null,
        loading: true,
        error: null
      });
      tick(1);
      flush();

      expect(
        directDepositStore.stateValue[DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS]
      ).toEqual({
        data: MOCK_TRANSFORMED_MASKED_DIRECT_DEPOSIT_ACCOUNTS,
        loading: false,
        error: null
      });
    }));

    it('should update direct deposits after getting masked data and then getting unmasked data', fakeAsync(() => {
      Mock.extend(payDistributionStore).with({
        payDistributionMeta$: of(null, MOCK_PAY_DISTRIBUTIONS_META_RESPONSE).pipe(delay(1)),
        payDistributions$: of(null, MOCK_TRANSFORMED_MASKED_PAY_DISTRIBUTIONS).pipe(delay(1)),
        isLoading$: of(true, false).pipe(delay(1))
      });
      directDepositStoreActions.loadDirectDepositAccounts();
      expect(payDistributionStoreActions.loadDistributions).toHaveBeenCalledWith(false, true);
      tick(1);
      flush();

      expect(
        directDepositStore.stateValue[DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS]
      ).toEqual({
        data: MOCK_TRANSFORMED_MASKED_DIRECT_DEPOSIT_ACCOUNTS,
        loading: false,
        error: null
      });

      Mock.extend(payDistributionStore).with({
        payDistributionMeta$: of(MOCK_PAY_DISTRIBUTIONS_META_RESPONSE),
        payDistributions$: of(
          MOCK_TRANSFORMED_MASKED_PAY_DISTRIBUTIONS,
          MOCK_TRANSFORMED_PAY_DISTRIBUTIONS
        ).pipe(delay(1)),
        isLoading$: of(true, false).pipe(delay(1))
      });
      directDepositStoreActions.loadDirectDepositAccounts(false, false);
      expect(payDistributionStoreActions.loadDistributions).toHaveBeenCalledWith(false, false);

      expect(
        directDepositStore.stateValue[DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS]
      ).toEqual({
        data: MOCK_TRANSFORMED_MASKED_DIRECT_DEPOSIT_ACCOUNTS,
        loading: true,
        error: null
      });

      tick(1);
      flush();

      expect(
        directDepositStore.stateValue[DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS]
      ).toEqual({
        data: MOCK_TRANSFORMED_DIRECT_DEPOSIT_ACCOUNTS,
        loading: false,
        error: null
      });
    }));

    it('should reset existing direct deposit accounts error when call is made to load accounts', () => {
      directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS, {
        error: { ddAccountsLoadError: true }
      });

      directDepositStoreActions.loadDirectDepositAccounts(false, false);

      expect(
        directDepositStore.stateValue[DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS].error
      ).toBeNull();
      expect(
        directDepositStore.stateValue[DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS_INITIAL].error
      ).toBeNull();
    });
  });

  describe('updateFormData', () => {
    it('should update the FORM_DETAILS slice with form data when not editing', () => {
      const [mockFormDetails] = MOCK_FORM_DETAILS.flatNew;
      directDepositStoreActions.updateFormData(mockFormDetails, false);

      expect(directDepositStore.stateValue[DirectDepositStoreSlice.FORM_DETAILS].data).toEqual(
        mockFormDetails
      );
    });

    it('should update the FORM_DETAILS slice with transformed form data when editing', () => {
      const [mockFormDetails] = MOCK_FORM_DETAILS.percentageEdit;
      directDepositStoreActions.updateFormData(mockFormDetails, true);

      expect(directDepositStore.stateValue[DirectDepositStoreSlice.FORM_DETAILS].data).toEqual({
        id: 'C22',
        [AccountDetailsControls.ACCOUNT_TYPE_CODE]: {
          label: 'Checking 2',
          value: 'C2',
          shortName: '',
          longName: 'Checking 2'
        },
        codeValueData: {
          accountCode: 'C2',
          shortName: '',
          longName: 'Checking 2'
        },
        [AccountDetailsControls.ACCOUNT_NAME]: '',
        [AccountDetailsControls.ACCOUNT_NUMBER]: 'X123456P7',
        [AccountDetailsControls.ROUTING_NUMBER]: '021000021',
        [DepositAmountControls.AMOUNT_TYPE]: DistributionOptions.PERCENTAGE,
        [DepositAmountControls.PERCENTAGE_AMOUNT]: '5.75',
        [DepositAmountControls.FLAT_AMOUNT]: null
      });
    });
  });

  describe('updateAccountChanges', () => {
    it('should add a new account', async () => {
      const [mockFormDetails] = MOCK_FORM_DETAILS.flatNew;

      directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS, {
        data: []
      });
      directDepositStore.update(DirectDepositStoreSlice.FORM_DETAILS, {
        data: mockFormDetails
      });

      const accounts = directDepositStoreActions.updateAccountChanges();

      expect(
        directDepositStore.stateValue[DirectDepositStoreSlice.MODIFIED_ACCOUNTS].data.add
      ).toEqual([accounts[0]]);
      expect(accounts).toEqual(
        directDepositStore.stateValue[DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS].data
      );
    });

    it('should add a new account when another account exists', async () => {
      const [mockFormDetails, transformedForm] = MOCK_FORM_DETAILS.remainingNew;
      const existingAccount = MOCK_TRANSFORMED_DIRECT_DEPOSIT_ACCOUNTS[0];

      directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS, {
        data: [existingAccount]
      });
      directDepositStore.update(DirectDepositStoreSlice.FORM_DETAILS, {
        data: mockFormDetails
      });

      const accounts = directDepositStoreActions.updateAccountChanges();
      const directDepositState =
        directDepositStore.stateValue[DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS].data;

      const transformedFormWithId = Object.assign(transformedForm, {
        id: directDepositState[1].pendingData.id
      });

      expect(directDepositState).toEqual([
        existingAccount,
        {
          currentData: null,
          pendingData: transformedFormWithId,
          pendingEvent: null,
          isWisely: false
        }
      ]);

      expect(accounts).toEqual(directDepositState);
    });

    it('should update an existing account', async () => {
      const [mockFormDetails, transformedForm] = MOCK_FORM_DETAILS.percentageEdit;
      const existingAccount = MOCK_TRANSFORMED_DIRECT_DEPOSIT_ACCOUNTS[1];

      directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS, {
        data: [existingAccount]
      });
      directDepositStore.update(DirectDepositStoreSlice.FORM_DETAILS, {
        data: mockFormDetails
      });

      const accounts = directDepositStoreActions.updateAccountChanges();

      expect(
        directDepositStore.stateValue[DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS].data
      ).toEqual([
        {
          isReadOnly: false,
          isWisely: false,
          isDailyPay: false,
          hasAltWorkflow: false,
          currentData: existingAccount.currentData,
          pendingData: transformedForm,
          pendingEvent: null
        }
      ]);
      expect(
        directDepositStore.stateValue[DirectDepositStoreSlice.MODIFIED_ACCOUNTS].data.edit
      ).toEqual([accounts[0]]);
      expect(accounts).toEqual(
        directDepositStore.stateValue[DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS].data
      );
    });

    it('should not update accounts if the account was deleted', async () => {
      const existingAccount = MOCK_TRANSFORMED_DIRECT_DEPOSIT_ACCOUNTS[1];

      directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS, {
        data: [existingAccount]
      });
      directDepositStore.update(DirectDepositStoreSlice.FORM_DETAILS, {
        data: null
      });

      const accounts = directDepositStoreActions.updateAccountChanges();

      expect(
        directDepositStore.stateValue[DirectDepositStoreSlice.MODIFIED_ACCOUNTS].data
      ).toBeFalsy();
      expect(accounts).toEqual(
        directDepositStore.stateValue[DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS].data
      );
    });
  });

  describe('Account Validation', () => {
    const [mockFormDetails] = MOCK_FORM_DETAILS.flatNew;
    const routingAccountKey = `${mockFormDetails.routingNumber}${mockFormDetails.accountNumber}`;
    beforeEach(() => {
      Mock.extend(payPermissionService).with({
        hasDirectDepositAccountManagementPermissionPromise: () => Promise.resolve(true)
      });

      Mock.extend(findSffoService).with({
        findSffo: () => sffo
      });

      directDepositStoreActions.updateFormData(mockFormDetails, false);
    });

    it('should be able to set Permission to validate through GIACT to false if meta does not allow it ', async () => {
      Mock.extend(payDistributionStore).with({
        stateValue: {
          [PayDistributionsStoreSlice.PAY_DISTRIBUTIONS_META]: {
            data: {
              meta: {
                canValidateBankInfo: false
              }
            }
          }
        }
      });

      await directDepositStoreActions.validateAccountFormDetails();

      expect(directDepositStore.hasPermission('GIACT')).toBeFalse();
      expect(
        directDepositStore.stateValue[DirectDepositStoreSlice.PERMISSIONS]?.data
          ?.canValidateBankInfo
      ).toBeFalse();

      expect(directDepositStore.getValidationStatus(routingAccountKey).status).toBe(
        ValidationStatus.ERROR
      );
    });

    it('should be able to set Permission to validate through GIACT to false if sffo does not allow it ', async () => {
      Mock.extend(findSffoService).with({
        findSffo: () => {
          const mockSffo = JSON.parse(JSON.stringify(sffo));
          mockSffo.href = null;
          return mockSffo;
        }
      });

      await directDepositStoreActions.validateAccountFormDetails();

      httpClient.expectNone('/money-movement/v2/deposit-account-validations');

      expect(directDepositStore.getValidationStatus(routingAccountKey).status).toBe(
        ValidationStatus.WARN
      );
    });

    it('should  not call GIACT if the routing number and account number is in the store', async () => {
      directDepositStore.update(DirectDepositStoreSlice.ACCOUNT_VERIFICATION, {
        data: {
          [routingAccountKey]: { status: ValidationStatus.SUCCESS }
        }
      });

      await directDepositStoreActions.validateAccountFormDetails();

      httpClient.expectNone('/money-movement/v2/deposit-account-validations');

      expect(directDepositStore.getValidationStatus(routingAccountKey).status).toBe(
        ValidationStatus.SUCCESS
      );
    });

    it('should be able to call GIACT  if the href and if both meta and sffo allow it and it is not cached', fakeAsync(() => {
      spyOn(directDepositStoreActions, 'updateFormData');
      directDepositStoreActions.validateAccountFormDetails();

      tick();

      const apiCall = httpClient.expectOne('/money-movement/v2/deposit-account-validations');

      apiCall.flush({
        accountValidationResponse: {
          responseMessage: { messageCode: ValidationStatusCodes.VALID }
        }
      });

      tick();

      expect(directDepositStore.getValidationStatus(routingAccountKey).status).toBe(
        ValidationStatus.SUCCESS
      );

      expect(directDepositStoreActions.updateFormData).toHaveBeenCalledWith({
        validationStatus: ValidationStatus.SUCCESS,
        prenoteIndicator: false
      });
    }));

    it('should give a response even when the API returns an unknown status or corrupted status', fakeAsync(() => {
      directDepositStoreActions.validateAccountFormDetails();

      tick();

      const apiCall = httpClient.expectOne('/money-movement/v2/deposit-account-validations');

      apiCall.flush({
        accountValidationResponse: {
          responseMessage: 'nt'
        }
      });

      tick();

      expect(directDepositStore.getValidationStatus(routingAccountKey).status).toBe(
        ValidationStatus.INVALID
      );
    }));

    it('should give a response when given a well formed error message', fakeAsync(() => {
      directDepositStoreActions.validateAccountFormDetails();

      tick();

      const apiCall = httpClient.expectOne('/money-movement/v2/deposit-account-validations');

      apiCall.flush(
        {
          _confirmMessage: {
            messages: [{ messageCode: ValidationStatusCodes.INVALID_REQUEST }]
          }
        },
        { status: 400, statusText: 'nt' }
      );

      tick();

      expect(directDepositStore.getValidationStatus(routingAccountKey).status).toBe(
        ValidationStatus.INVALID
      );
    }));

    it('should give a response when given a poorly formed error message', fakeAsync(() => {
      directDepositStoreActions.validateAccountFormDetails();

      tick();

      const apiCall = httpClient.expectOne('/money-movement/v2/deposit-account-validations');

      apiCall.flush(
        {
          _confirmMessage: 'nt'
        },
        { status: 400, statusText: 'nt' }
      );

      tick();

      expect(directDepositStore.getValidationStatus(routingAccountKey).status).toBe(
        ValidationStatus.WARN
      );
    }));
  });

  describe('postDirectDepositAccounts', () => {
    let recallSpy: jasmine.Spy;
    let postSpy: jasmine.Spy;

    beforeEach(() => {
      recallSpy = payDistributionStoreActions.recallDistributions as jasmine.Spy;
      postSpy = payDistributionStoreActions.postDistributions as jasmine.Spy;

      directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS_INITIAL, {
        data: MOCK_WF_RECALL_ACCOUNTS
      });
      directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS, {
        data: MOCK_WF_RECALL_ACCOUNTS
      });
    });

    it('should Recall and POST accounts when there are pending Workflow events', fakeAsync(() => {
      directDepositStoreActions.postDirectDepositAccounts();
      flush();

      expect(recallSpy).toHaveBeenCalled();
      expect(postSpy).toHaveBeenCalledWith(
        [MOCK_WF_RECALL_ACCOUNTS[0], MOCK_WF_RECALL_ACCOUNTS[1], MOCK_WF_RECALL_ACCOUNTS[2]],
        false,
        false
      );
    }));

    it('should only Recall when deleting a pending add workflow event', fakeAsync(() => {
      directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS_INITIAL, {
        data: [
          MOCK_WF_RECALL_ACCOUNTS[2],
          {
            currentData: null,
            pendingData: MOCK_TRANSFORMED_DIRECT_DEPOSIT_ACCOUNTS[0].currentData,
            pendingEvent: { changeType: 'add' }
          }
        ]
      });
      directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS, {
        data: [
          MOCK_WF_RECALL_ACCOUNTS[2],
          { currentData: null, pendingData: null, pendingEvent: { changeType: 'pruned' } }
        ]
      });
      directDepositStoreActions.postDirectDepositAccounts();
      flush();

      expect(recallSpy).toHaveBeenCalled();
      expect(postSpy).not.toHaveBeenCalled();
    }));

    it('should Recall and POST when deleting a pending edit workflow event', fakeAsync(() => {
      const editedAccount: DirectDepositAccount = {
        currentData: MOCK_TRANSFORMED_DIRECT_DEPOSIT_ACCOUNTS[0].currentData,
        pendingData: {
          ...MOCK_TRANSFORMED_DIRECT_DEPOSIT_ACCOUNTS[0].currentData,
          flatAmount: { amountValue: 15, currencyCode: 'USD' }
        },
        pendingEvent: { changeType: 'edit' }
      };

      directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS_INITIAL, {
        data: [MOCK_WF_RECALL_ACCOUNTS[2], editedAccount]
      });
      directDepositStore.update(DirectDepositStoreSlice.MODIFIED_ACCOUNTS, {
        data: {
          delete: [editedAccount]
        }
      });
      directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS, {
        data: [
          MOCK_WF_RECALL_ACCOUNTS[2],
          { currentData: null, pendingData: null, pendingEvent: { changeType: 'pruned' } }
        ]
      });
      directDepositStoreActions.postDirectDepositAccounts();
      flush();

      expect(recallSpy).toHaveBeenCalled();
      expect(postSpy).toHaveBeenCalledWith([MOCK_WF_RECALL_ACCOUNTS[2]], false, false);
    }));

    it('should Recall and POST when there is pending add, edit, and delete', fakeAsync(() => {
      const editedAccount: DirectDepositAccount = {
        currentData: MOCK_TRANSFORMED_DIRECT_DEPOSIT_ACCOUNTS[0].currentData,
        pendingData: {
          ...MOCK_TRANSFORMED_DIRECT_DEPOSIT_ACCOUNTS[0].currentData,
          flatAmount: { amountValue: 15, currencyCode: 'USD' }
        },
        pendingEvent: { changeType: 'edit' }
      };
      directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS_INITIAL, {
        data: [
          MOCK_WF_RECALL_ACCOUNTS[0],
          MOCK_WF_RECALL_ACCOUNTS[1],
          MOCK_WF_RECALL_ACCOUNTS[3],
          editedAccount
        ]
      });
      directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS, {
        data: [
          MOCK_WF_RECALL_ACCOUNTS[0],
          MOCK_WF_RECALL_ACCOUNTS[1],
          MOCK_WF_RECALL_ACCOUNTS[3],
          { currentData: null, pendingData: null, pendingEvent: { changeType: 'pruned' } }
        ]
      });
      directDepositStoreActions.postDirectDepositAccounts();
      flush();

      expect(recallSpy).toHaveBeenCalled();
      expect(postSpy).toHaveBeenCalledWith(
        [MOCK_WF_RECALL_ACCOUNTS[0], MOCK_WF_RECALL_ACCOUNTS[1]],
        false,
        false
      );
    }));

    it('should Recall and POST when there is a pending delete and non-pending account is deleted', fakeAsync(() => {
      directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS_INITIAL, {
        data: [MOCK_WF_RECALL_ACCOUNTS[1], MOCK_WF_RECALL_ACCOUNTS[2]]
      });
      directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS, {
        data: [MOCK_WF_RECALL_ACCOUNTS[1]]
      });
      directDepositStoreActions.postDirectDepositAccounts();
      flush();

      expect(recallSpy).toHaveBeenCalled();
      expect(postSpy).toHaveBeenCalledWith([MOCK_WF_RECALL_ACCOUNTS[1]], false, false);
    }));

    it('should Recall and POST when deleting a pending workflow event and there is a pending delete', fakeAsync(() => {
      directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS_INITIAL, {
        data: [
          MOCK_WF_RECALL_ACCOUNTS[2],
          {
            // pending delete
            hasAltWorkflow: false,
            currentData: MOCK_WF_RECALL_ACCOUNTS[1].pendingData,
            pendingData: null,
            pendingEvent: {
              changeType: 'delete'
            }
          },
          MOCK_WF_RECALL_ACCOUNTS[0]
        ]
      });
      directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS, {
        data: [
          MOCK_WF_RECALL_ACCOUNTS[2],
          {
            // pending delete
            hasAltWorkflow: false,
            currentData: MOCK_WF_RECALL_ACCOUNTS[1].pendingData,
            pendingData: null,
            pendingEvent: {
              changeType: 'delete'
            }
          },
          { currentData: null, pendingData: null, pendingEvent: { changeType: 'pruned' } }
        ]
      });
      directDepositStoreActions.postDirectDepositAccounts();
      flush();

      expect(recallSpy).toHaveBeenCalled();
      expect(postSpy).toHaveBeenCalledWith([MOCK_WF_RECALL_ACCOUNTS[2]], false, false);
    }));

    it('should only Recall when all accounts are canceled pending accounts', fakeAsync(() => {
      directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS_INITIAL, {
        data: [MOCK_WF_RECALL_ACCOUNTS[0], MOCK_WF_RECALL_ACCOUNTS[1], MOCK_WF_RECALL_ACCOUNTS[3]]
      });
      directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS, {
        data: [
          { currentData: null, pendingData: null, pendingEvent: { changeType: null } },
          { currentData: null, pendingData: null, pendingEvent: { changeType: null } },
          { currentData: null, pendingData: null, pendingEvent: { changeType: null } }
        ]
      });
      directDepositStoreActions.postDirectDepositAccounts();
      flush();

      expect(recallSpy).toHaveBeenCalled();
      expect(postSpy).not.toHaveBeenCalled();
    }));

    it('should not Recall when there are no pending Workflow events', fakeAsync(() => {
      directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS_INITIAL, {
        data: [MOCK_WF_RECALL_ACCOUNTS[2]]
      });
      directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS, {
        data: [MOCK_WF_RECALL_ACCOUNTS[2]]
      });
      directDepositStoreActions.postDirectDepositAccounts();
      flush();

      expect(recallSpy).not.toHaveBeenCalled();
      expect(postSpy).toHaveBeenCalledWith([MOCK_WF_RECALL_ACCOUNTS[2]], false, false);
    }));

    it('should not Recall when accounts are alt Workflow', fakeAsync(() => {
      directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS_INITIAL, {
        data: MOCK_ALT_WF_ACCOUNTS
      });
      directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS, {
        data: MOCK_ALT_WF_ACCOUNTS
      });
      directDepositStoreActions.postDirectDepositAccounts();
      flush();

      expect(recallSpy).not.toHaveBeenCalled();
      expect(postSpy).toHaveBeenCalledWith(MOCK_ALT_WF_ACCOUNTS, false, false);
    }));

    it('should Recall and POST when there is an edit of a pending Workflow event', fakeAsync(() => {
      const editPendingWFAccount = {
        currentData: {
          id: 'CheckingDED3',
          distributionType: DistributionOptions.PERCENTAGE,
          percentageAmount: 14
        },
        pendingData: {
          id: 'CheckingDED3',
          distributionType: DistributionOptions.PERCENTAGE,
          percentageAmount: 5
        },
        pendingEvent: {}
      };
      directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS_INITIAL, {
        data: [
          {
            ...editPendingWFAccount,
            pendingData: {
              ...editPendingWFAccount.pendingData,
              distributionType: DistributionOptions.PERCENTAGE,
              percentageAmount: 10
            },
            pendingEvent: { changeType: 'edit' }
          }
        ]
      });
      directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS, {
        data: [editPendingWFAccount]
      });
      directDepositStoreActions.postDirectDepositAccounts();
      flush();

      expect(recallSpy).toHaveBeenCalled();
      expect(postSpy).toHaveBeenCalledWith([editPendingWFAccount], false, false);
    }));

    it('should POST correct accounts with edit, no change, and cancelled deletion', fakeAsync(() => {
      directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS_INITIAL, {
        data: [
          MOCK_WF_RECALL_ACCOUNTS[0],
          MOCK_WF_RECALL_ACCOUNTS[2],
          {
            currentData: {
              id: 'slC2',
              distributionType: DistributionOptions.REMAINING
            },
            pendingData: {
              id: 'slC2',
              distributionType: DistributionOptions.PERCENTAGE,
              percentageAmount: 3
            },
            pendingEvent: { changeType: 'edit' }
          }
        ]
      });
      directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS, {
        data: [
          MOCK_WF_RECALL_ACCOUNTS[0],
          MOCK_WF_RECALL_ACCOUNTS[2],
          {
            currentData: {
              id: 'slC2',
              distributionType: DistributionOptions.REMAINING
            },
            pendingData: null,
            pendingEvent: { changeType: null }
          }
        ]
      });
      directDepositStoreActions.postDirectDepositAccounts();
      flush();

      expect(recallSpy).toHaveBeenCalled();
      expect(postSpy).toHaveBeenCalledWith(
        [
          MOCK_WF_RECALL_ACCOUNTS[0],
          MOCK_WF_RECALL_ACCOUNTS[2],
          {
            currentData: {
              id: 'slC2',
              distributionType: DistributionOptions.REMAINING
            },
            pendingData: null,
            pendingEvent: { changeType: null }
          }
        ],
        false,
        false
      );
    }));

    it('should handle errors when Recall fails', fakeAsync(() => {
      Mock.extend(payDistributionStoreActions).with({
        recallDistributions: () => Promise.reject('recall error')
      });
      recallSpy = payDistributionStoreActions.recallDistributions as jasmine.Spy;
      directDepositStoreActions.postDirectDepositAccounts().catch(() => undefined);
      flush();

      expect(recallSpy).toHaveBeenCalled();
      expect(postSpy).not.toHaveBeenCalled();
      expect(
        directDepositStore.stateValue[DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS]
      ).toHaveProperty('loading', false);
      expect(
        directDepositStore.stateValue[DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS]
      ).toHaveProperty('error', { ddAccountsPostError: true });
    }));

    it('should handle errors when POST fails', fakeAsync(() => {
      Mock.extend(payDistributionStoreActions).with({
        postDistributions: () => Promise.reject('post error')
      });
      postSpy = payDistributionStoreActions.postDistributions as jasmine.Spy;
      directDepositStoreActions.postDirectDepositAccounts().catch(() => undefined);
      flush();

      expect(recallSpy).toHaveBeenCalled();
      expect(postSpy).toHaveBeenCalled();
      expect(
        directDepositStore.stateValue[DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS]
      ).toHaveProperty('loading', false);
      expect(
        directDepositStore.stateValue[DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS]
      ).toHaveProperty('error', { ddAccountsPostError: true });
    }));

    it('should POST with nonCompliantSchema', fakeAsync(() => {
      Mock.extend(userProfileService).with({
        getApplicationId: () => of('ENTERPRISE')
      });
      directDepositStoreActions.init();
      flush();
      directDepositStoreActions.postDirectDepositAccounts();
      flush();

      expect(postSpy).toHaveBeenCalledWith(
        [MOCK_WF_RECALL_ACCOUNTS[0], MOCK_WF_RECALL_ACCOUNTS[1], MOCK_WF_RECALL_ACCOUNTS[2]],
        true,
        false
      );
    }));

    it('should reset existing direct deposit accounts error when call is made to post direct deposit accounts', fakeAsync(() => {
      directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS, {
        error: { ddAccountsPostError: true }
      });

      directDepositStoreActions.postDirectDepositAccounts();
      flush();

      expect(
        directDepositStore.stateValue[DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS].error
      ).toBeNull();
    }));
  });

  describe('recallAccount', () => {
    it('should cancel a request for an added account', () => {
      directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS, {
        data: MOCK_WF_RECALL_ACCOUNTS
      });
      directDepositStoreActions.recallAccount(MOCK_WF_RECALL_ACCOUNTS[1]);

      expect(directDepositStore.getDDAccountsSnapshot()).toEqual([
        MOCK_WF_RECALL_ACCOUNTS[0],
        {
          currentData: null,
          pendingData: null,
          pendingEvent: { changeType: null }
        },
        MOCK_WF_RECALL_ACCOUNTS[2],
        MOCK_WF_RECALL_ACCOUNTS[3],
        MOCK_WF_RECALL_ACCOUNTS[4]
      ]);
    });

    it('should cancel a request for an edited account', () => {
      directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS, {
        data: MOCK_WF_RECALL_ACCOUNTS
      });
      const account = MOCK_WF_RECALL_ACCOUNTS[0];
      directDepositStoreActions.recallAccount(account);

      expect(
        directDepositStore.stateValue[DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS].data
      ).toEqual([
        {
          currentData: account.currentData,
          pendingData: null,
          pendingEvent: { changeType: null }
        },
        MOCK_WF_RECALL_ACCOUNTS[1],
        MOCK_WF_RECALL_ACCOUNTS[2],
        MOCK_WF_RECALL_ACCOUNTS[3],
        MOCK_WF_RECALL_ACCOUNTS[4]
      ]);
    });

    it('should cancel a request for a deleted account', () => {
      directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS, {
        data: MOCK_WF_RECALL_ACCOUNTS
      });
      const account = MOCK_WF_RECALL_ACCOUNTS[3];
      directDepositStoreActions.recallAccount(account);

      expect(
        directDepositStore.stateValue[DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS].data
      ).toEqual([
        MOCK_WF_RECALL_ACCOUNTS[0],
        MOCK_WF_RECALL_ACCOUNTS[1],
        MOCK_WF_RECALL_ACCOUNTS[2],
        {
          currentData: account.currentData,
          pendingData: null,
          pendingEvent: { changeType: null }
        },
        MOCK_WF_RECALL_ACCOUNTS[4]
      ]);
    });

    it('should call Recall API when POSTing changes', fakeAsync(() => {
      directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS_INITIAL, {
        data: MOCK_WF_RECALL_ACCOUNTS
      });
      directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS, {
        data: MOCK_WF_RECALL_ACCOUNTS
      });
      const account = MOCK_WF_RECALL_ACCOUNTS[3];
      const recallSpy = payDistributionStoreActions.recallDistributions as jasmine.Spy;
      const postSpy = payDistributionStoreActions.postDistributions as jasmine.Spy;
      const getSpy = payDistributionStoreActions.loadDistributions as jasmine.Spy;

      directDepositStoreActions.recallAccount(account, true);
      flush();

      expect(recallSpy).toHaveBeenCalled();
      expect(postSpy).toHaveBeenCalledWith(
        [
          MOCK_WF_RECALL_ACCOUNTS[0],
          MOCK_WF_RECALL_ACCOUNTS[1],
          MOCK_WF_RECALL_ACCOUNTS[2],
          {
            currentData: account.currentData,
            pendingData: null,
            pendingEvent: { changeType: null }
          }
        ],
        false,
        false
      );
      expect(getSpy).toHaveBeenCalledWith(false, false);
    }));

    it('should not call POST when recalling only one pending Workflow event', fakeAsync(() => {
      directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS_INITIAL, {
        data: [MOCK_WF_RECALL_ACCOUNTS[0], MOCK_WF_RECALL_ACCOUNTS[2]]
      });
      directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS, {
        data: [MOCK_WF_RECALL_ACCOUNTS[0], MOCK_WF_RECALL_ACCOUNTS[2]]
      });
      const recallSpy = payDistributionStoreActions.recallDistributions as jasmine.Spy;
      const postSpy = payDistributionStoreActions.postDistributions as jasmine.Spy;

      directDepositStoreActions.recallAccount(MOCK_WF_RECALL_ACCOUNTS[0], true);
      flush();

      expect(recallSpy).toHaveBeenCalled();
      expect(postSpy).not.toHaveBeenCalled();
    }));
  });

  describe('revertAllChanges', () => {
    it('should reset existing direct deposit accounts error when call is made revert all changes', fakeAsync(() => {
      directDepositStore.update(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS, {
        error: { ddAccountsLoadError: true }
      });

      directDepositStoreActions.revertAllChanges();
      flush();

      expect(
        directDepositStore.stateValue[DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS].error
      ).toBeNull();
    }));
  });
});
