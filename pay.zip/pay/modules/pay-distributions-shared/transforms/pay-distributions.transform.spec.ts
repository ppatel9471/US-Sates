import { PayDistributionsDTO } from '@myadp/dto';
import {
  MOCK_TRANSFORMED_POST_NON_COMPLIANT_PAYLOAD,
  MOCK_TRANSFORMED_POST_PAYLOAD,
  MOCK_UI_PAY_DISTRIBUTIONS
} from '@specHelpers/pay/direct-deposit/direct-deposit';

import {
  MOCK_TRANSFORMED_WF_PAY_DISTRIBUTIONS_RESPONSE,
  MOCK_WF_EV5_DISTRIBUTIONS_RESPONSE,
  MOCK_WF_PAY_DISTRIBUTIONS_RESPONSE
} from '../../../../../../src/spec-helpers/pay/pay-distributions/pay-distributions';
import { COUNTRY, CountryDetails } from '../models/country';
import { DistributionOptions, PayDistributionsUI } from '../models/pay-distributions-ui';
import { countryDTOtransforms } from './country-mappings/country-transforms';
import {
  generateDistributionID,
  transformDistributionDetails,
  transformDistributions
} from './pay-distributions.transform';

describe('transformDistributions', () => {
  const country: CountryDetails = {
    shortName: COUNTRY.US,
    currencyCode: 'USD'
  };
  let distributions: PayDistributionsUI.PayDistribution[];
  let itemID: string;

  beforeEach(() => {
    distributions = transformDistributions(country, MOCK_WF_PAY_DISTRIBUTIONS_RESPONSE);
  });

  it('should transform US distributions', () => {
    expect(distributions).toEqual(MOCK_TRANSFORMED_WF_PAY_DISTRIBUTIONS_RESPONSE);
  });

  it('should transform CA distributions', () => {
    const canadaDistributions = transformDistributions(
      {
        shortName: COUNTRY.CA,
        currencyCode: 'CAD'
      },
      MOCK_WF_PAY_DISTRIBUTIONS_RESPONSE
    );
    expect(canadaDistributions.length).toBe(3);
  });

  it('should transform details without id when asked', () => {
    expect(
      transformDistributionDetails(
        country,
        {
          precedenceCode: {
            codeValue: '1',
            shortName: 'WISELY PAY'
          },
          prenoteBypassIndicator: false,
          paymentMethodCode: {
            codeValue: 'D',
            shortName: 'Direct Deposit'
          },
          depositAccount: {
            financialParty: {
              nameCode: {},
              routingTransitID: {
                idValue: '123'
              }
            },
            financialAccount: {
              accountName: 'WISELY PAY',
              accountNumber: '123',
              typeCode: {
                codeValue: 'WIS',
                longName: 'wisely pay'
              }
            }
          }
        },
        false
      )
    ).toEqual({
      distributionType: DistributionOptions.FLAT,
      percentageAmount: null,
      flatAmount: null,
      codeValueData: {
        itemID: null,
        accountCode: 'WIS',
        shortName: null,
        longName: 'wisely pay'
      },
      precedence: '1',
      precedenceCode: 'WISELY PAY',
      accountName: 'WISELY PAY',
      accountTypeName: 'wisely pay',
      accountNumber: '123',
      routingNumber: '123',
      prenoteIndicator: true
    });
  });

  // Currently RUN doesn't send back the longName, we only get the shortName for account type
  it('should transform distributions using shortName for account type', () => {
    const mockShortNameDistribution: PayDistributionsDTO.WfResponse = {
      currentData: {
        payDistributions: [
          {
            distributionInstructions: [
              {
                depositAccount: {
                  financialAccount: {
                    accountNumber: 'X123456P7',
                    typeCode: { codeValue: 'C1', shortName: 'Checking 1' }
                  },
                  financialParty: {
                    routingTransitID: { idValue: '021000021' }
                  }
                },
                distributionAmount: { amountValue: 0, currencyCode: 'USD' },
                distributionPercentage: null,
                precedenceCode: { codeValue: '1' },
                remainingBalanceIndicator: true
              }
            ]
          }
        ]
      }
    };

    expect(transformDistributions(country, mockShortNameDistribution)).toEqual([
      {
        currentData: {
          id: 'C11',
          codeValueData: {
            itemID: null,
            longName: null,
            shortName: 'Checking 1',
            accountCode: 'C1'
          },
          precedence: '1',
          precedenceCode: null,
          accountTypeName: 'Checking 1',
          accountNumber: 'X123456P7',
          routingNumber: '021000021',
          accountName: null,
          distributionType: DistributionOptions.REMAINING,
          flatAmount: null,
          percentageAmount: null,
          prenoteIndicator: undefined
        },
        pendingData: null,
        pendingEvent: null
      }
    ]);
  });

  it('should transform distributions using typeCode codeValue if longName or shortName is not provided', () => {
    const mockShortNameDistribution: PayDistributionsDTO.WfResponse = {
      currentData: {
        payDistributions: [
          {
            distributionInstructions: [
              {
                depositAccount: {
                  financialAccount: {
                    accountNumber: 'X123456P7',
                    typeCode: { codeValue: 'C1' }
                  },
                  financialParty: {
                    routingTransitID: { idValue: '021000021' }
                  }
                },
                distributionAmount: { amountValue: 0, currencyCode: 'USD' },
                distributionPercentage: null,
                precedenceCode: { codeValue: '1' },
                remainingBalanceIndicator: true
              }
            ]
          }
        ]
      }
    };

    expect(transformDistributions(country, mockShortNameDistribution)).toEqual([
      {
        currentData: {
          id: 'C11',
          codeValueData: {
            itemID: null,
            longName: null,
            shortName: null,
            accountCode: 'C1'
          },
          precedence: '1',
          precedenceCode: null,
          accountTypeName: 'C1',
          accountNumber: 'X123456P7',
          routingNumber: '021000021',
          accountName: null,
          distributionType: DistributionOptions.REMAINING,
          flatAmount: null,
          percentageAmount: null,
          prenoteIndicator: undefined
        },
        pendingData: null,
        pendingEvent: null
      }
    ]);
  });

  describe('generateDistributionID', () => {
    const codeValueData1: PayDistributionsUI.CodeValueData = {
      shortName: 'shortName',
      longName: 'longName',
      accountCode: null
    };
    const codeValueData2: PayDistributionsUI.CodeValueData = {
      shortName: 'shortname', // differs from codeValueData1.shortName
      longName: 'longName',
      accountCode: 'null'
    };
    const codeValueData3: PayDistributionsUI.CodeValueData = {
      shortName: 'shortName',
      longName: 'longName',
      accountCode: 'accountCode'
    };
    const codeValueData4: PayDistributionsUI.CodeValueData = {
      itemID: 'X1',
      shortName: 'shortName',
      longName: 'longName',
      accountCode: 'accountCode'
    };

    it('should generate a unique hash for a given codeValueData', () => {
      expect(generateDistributionID(codeValueData1, '1')).toBeTruthy();
    });

    it('should generate a unique hash when precedence is missing', () => {
      expect(generateDistributionID(codeValueData4, null)).toEqual('accountCodeX1');
    });

    it('should not generate the same id for two similar distributions', () => {
      expect(generateDistributionID(codeValueData1, '1')).not.toEqual(
        generateDistributionID(codeValueData2, '2')
      );
    });

    it('should generate a unique id given the same distribution values', () => {
      expect(generateDistributionID(codeValueData3, '3')).not.toEqual(
        generateDistributionID(codeValueData4, '4')
      );
    });
  });

  describe('set ALT workflow messages', () => {
    it('should set alternate workflow messages', () => {
      const mockAltWfResponse: PayDistributionsDTO.WfResponse = {
        currentData: {
          payDistributions: [
            {
              distributionInstructions: [
                {
                  itemID: '139504180916_1',
                  prenoteIndicator: true,
                  depositAccount: {
                    financialParty: {
                      routingTransitID: { idValue: '021200025' },
                      nameCode: { shortName: 'WellsFargo', longName: 'Wells Fargo' }
                    },
                    financialAccount: {
                      accountNumber: '0000000015',
                      typeCode: { codeValue: '103', longName: 'DED3' },
                      currencyCode: 'USD'
                    }
                  },
                  distributionAmount: { amountValue: 50, currencyCode: 'USD' },
                  remainingBalanceIndicator: false
                },
                {
                  itemID: '139504180471_1',
                  prenoteIndicator: true,
                  depositAccount: {
                    financialParty: {
                      routingTransitID: { idValue: '021000018' },
                      nameCode: { shortName: 'WellsFargo', longName: 'Wells Fargo' }
                    },
                    financialAccount: {
                      accountNumber: '0000000016',
                      typeCode: { codeValue: '104', longName: 'DED4' },
                      currencyCode: 'USD'
                    }
                  },
                  distributionPercentage: 14,
                  distributionAmount: { amountValue: null, currencyCode: 'USD' },
                  remainingBalanceIndicator: false
                },
                {
                  itemID: '139504180582_1',
                  prenoteIndicator: true,
                  depositAccount: {
                    financialParty: {
                      routingTransitID: { idValue: '021000018' },
                      nameCode: { shortName: 'WellsFargo', longName: 'Wells Fargo' }
                    },
                    financialAccount: {
                      accountNumber: '0000000016',
                      typeCode: { codeValue: '105', longName: 'DED5' },
                      currencyCode: 'USD'
                    }
                  },
                  distributionPercentage: null,
                  distributionAmount: { amountValue: null, currencyCode: 'USD' },
                  remainingBalanceIndicator: true
                }
              ]
            }
          ],
          confirmMessage: {
            resourceMessages: [
              {
                processMessages: [
                  {
                    messageTypeCode: {
                      codeValue: 'info'
                    },
                    links: [
                      {
                        href: '/events/payroll/v1/worker.pay-distribution.change/139504180916_1',
                        rel: '/adp/workflow'
                      }
                    ],
                    userMessage: {
                      codeValue: 'WFN-WORKFLOW',
                      title: 'Pending Approval',
                      messageTxt: 'Changes are currently pending approval.'
                    }
                  }
                ]
              },
              {
                processMessages: [
                  {
                    messageTypeCode: {
                      codeValue: 'info'
                    },
                    links: [
                      {
                        href: '/events/payroll/v1/worker.pay-distribution.change/139504180916_1',
                        rel: '/adp/workflow'
                      }
                    ],
                    userMessage: {
                      codeValue: 'NOT-WFN-WORKFLOW',
                      title: 'Title',
                      messageTxt: 'Should not be this messsage'
                    }
                  }
                ]
              },
              {
                processMessages: [
                  {
                    messageTypeCode: {
                      codeValue: 'info'
                    },
                    links: [
                      {
                        href: '/events/payroll/v1/worker.pay-distribution.change/139504180582_1',
                        rel: '/adp/workflow'
                      }
                    ],
                    userMessage: {
                      codeValue: 'ALT-WORKFLOW',
                      title: 'Pending Approval',
                      messageTxt: 'Alt changes are currently pending approval.'
                    }
                  }
                ]
              }
            ]
          }
        }
      };

      expect(transformDistributions(country, mockAltWfResponse)).toEqual([
        {
          currentData: {
            id: '103139504180916_1',
            codeValueData: {
              itemID: '139504180916_1',
              accountCode: '103',
              shortName: null,
              longName: 'DED3'
            },
            accountNumber: '0000000015',
            routingNumber: '021200025',
            accountName: null,
            accountTypeName: 'DED3',
            precedence: undefined,
            precedenceCode: null,
            distributionType: DistributionOptions.FLAT,
            flatAmount: { amountValue: 50, currencyCode: 'USD' },
            percentageAmount: null,
            prenoteIndicator: true
          },
          pendingData: null,
          pendingEvent: {
            altWorkflowMessage: 'Changes are currently pending approval.'
          }
        },
        {
          currentData: {
            id: '104139504180471_1',
            codeValueData: {
              itemID: '139504180471_1',
              accountCode: '104',
              shortName: null,
              longName: 'DED4'
            },
            accountNumber: '0000000016',
            routingNumber: '021000018',
            accountName: null,
            accountTypeName: 'DED4',
            precedence: undefined,
            precedenceCode: null,
            distributionType: DistributionOptions.PERCENTAGE,
            flatAmount: null,
            percentageAmount: 14,
            prenoteIndicator: true
          },
          pendingData: null,
          pendingEvent: null
        },
        {
          currentData: {
            id: '105139504180582_1',
            codeValueData: {
              itemID: '139504180582_1',
              accountCode: '105',
              shortName: null,
              longName: 'DED5'
            },
            accountNumber: '0000000016',
            routingNumber: '021000018',
            accountName: null,
            accountTypeName: 'DED5',
            precedence: undefined,
            precedenceCode: null,
            distributionType: DistributionOptions.REMAINING,
            flatAmount: null,
            percentageAmount: null,
            prenoteIndicator: true
          },
          pendingData: null,
          pendingEvent: {
            altWorkflowMessage: 'Alt changes are currently pending approval.'
          }
        }
      ]);
    });
  });

  describe('EV5 / Old schema transform', () => {
    it('should transform distributions', () => {
      expect(transformDistributions(country, MOCK_WF_EV5_DISTRIBUTIONS_RESPONSE)).toEqual([
        {
          currentData: {
            id: 'XX',
            distributionType: DistributionOptions.FLAT,
            percentageAmount: null,
            flatAmount: {
              amountValue: 10,
              currencyCode: 'USD'
            },
            codeValueData: {
              itemID: null,
              accountCode: 'X',
              shortName: null,
              longName: 'Checking Deduction # 1'
            },
            precedence: undefined,
            precedenceCode: null,
            accountName: null,
            accountTypeName: 'Checking Deduction # 1',
            accountNumber: '0000000001',
            routingNumber: '122105278',
            prenoteIndicator: false
          },
          pendingData: null,
          pendingEvent: null
        },
        {
          currentData: null,
          pendingData: {
            id: 'ZZ',
            distributionType: DistributionOptions.REMAINING,
            percentageAmount: null,
            flatAmount: null,
            codeValueData: {
              itemID: null,
              accountCode: 'Z',
              shortName: null,
              longName: 'Checking Deduction # 3'
            },
            precedence: 'Z',
            precedenceCode: 'Checking Deduction # 3',
            accountName: 'Checking Deduction # 3',
            accountTypeName: 'Checking Deduction # 3',
            accountNumber: '000789',
            routingNumber: '021000018',
            prenoteIndicator: false
          },
          pendingEvent: {
            approver: 'Goodrich, Celeste',
            changeType: 'add'
          }
        }
      ]);
    });
  });

  describe('transformToDTO - US', () => {
    it('should transform to POST payload with compliant schema', () => {
      const payload = countryDTOtransforms[COUNTRY.US](
        {
          effectiveDate: '01/01/2021',
          aoid: 'XG234234',
          distributions: MOCK_UI_PAY_DISTRIBUTIONS,
          itemID
        },
        false,
        false
      );

      expect(payload).toEqual(MOCK_TRANSFORMED_POST_PAYLOAD);
    });

    // ENTERPRISE (EV5) expect the POST to be the non-compliant version of the schema
    it('should transform to POST payload with non-compliant schema and include prenoteBypassIndicator', () => {
      distributions = [MOCK_UI_PAY_DISTRIBUTIONS[0], MOCK_UI_PAY_DISTRIBUTIONS[1]];
      distributions[0].currentData.prenoteIndicator = false;
      distributions[1].pendingData.prenoteIndicator = true;

      // percentages isn't supported in non-compliant schema
      distributions = distributions.map((dist) => {
        delete dist.currentData?.percentageAmount;
        delete dist.pendingData?.percentageAmount;
        return dist;
      });

      const payload = countryDTOtransforms[COUNTRY.US](
        {
          effectiveDate: '01/01/2021',
          aoid: 'XG234234',
          distributions,
          itemID
        },
        true,
        true
      );

      expect(payload).toEqual(MOCK_TRANSFORMED_POST_NON_COMPLIANT_PAYLOAD);
    });

    describe('includePrenoteBypassIndicator flag', () => {
      it('should include and set prenoteBypassIndicator to false', () => {
        distributions = [MOCK_UI_PAY_DISTRIBUTIONS[0]];
        distributions[0].currentData.prenoteIndicator = true;

        const payload = countryDTOtransforms[COUNTRY.US](
          {
            effectiveDate: '01/01/2021',
            aoid: 'XG234234',
            distributions,
            itemID
          },
          false,
          true
        );

        expect(
          payload.events[0].data.transform.payDistribution.distributionInstructions[0]
        ).toEqual(jasmine.objectContaining({ prenoteBypassIndicator: false }));
      });

      it('should include and set prenoteBypassIndicator to false', () => {
        distributions = [MOCK_UI_PAY_DISTRIBUTIONS[0]];
        distributions[0].currentData.prenoteIndicator = true;

        const payload = countryDTOtransforms[COUNTRY.US](
          {
            effectiveDate: '01/01/2021',
            aoid: 'XG234234',
            distributions,
            itemID
          },
          false,
          true
        );

        expect(
          payload.events[0].data.transform.payDistribution.distributionInstructions[0]
        ).toEqual(jasmine.objectContaining({ prenoteBypassIndicator: false }));
      });

      it('should exclude prenoteBypassIndicator', () => {
        distributions = [MOCK_UI_PAY_DISTRIBUTIONS[0]];
        distributions[0].currentData.prenoteIndicator = false;

        const payload = countryDTOtransforms[COUNTRY.US](
          {
            effectiveDate: '01/01/2021',
            aoid: 'XG234234',
            distributions,
            itemID
          },
          false,
          false
        );

        expect(
          payload.events[0].data.transform.payDistribution.distributionInstructions[0]
        ).not.toEqual(jasmine.objectContaining({ prenoteBypassIndicator: true }));
      });
    });

    describe('itemID', () => {
      // The itemID is passed back in the POST from the GET response
      // It is required that this itemID be sent back for WFN
      it('should include itemID', () => {
        distributions = [MOCK_UI_PAY_DISTRIBUTIONS[0]];
        distributions[0].currentData.prenoteIndicator = true;

        const payload = countryDTOtransforms[COUNTRY.US](
          {
            effectiveDate: '01/01/2021',
            aoid: 'XG234234',
            distributions,
            itemID: 'foo'
          },
          false,
          true
        );

        expect(payload.events[0].data.eventContext.payDistribution.itemID).toBe('foo');
      });

      it('should not include itemID', () => {
        distributions = [MOCK_UI_PAY_DISTRIBUTIONS[0]];
        distributions[0].currentData.prenoteIndicator = true;

        const payload = countryDTOtransforms[COUNTRY.US](
          {
            effectiveDate: '01/01/2021',
            aoid: 'XG234234',
            distributions,
            itemID
          },
          false,
          true
        );

        expect(payload.events[0].data.eventContext.payDistribution).toBeUndefined();
      });
    });
  });
});
