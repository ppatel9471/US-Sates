import { Amount } from '@myadp/dto';

import { PayStatementsUI } from '../models/pay-statement-ui';

export function transformDonut(
  deductionsCategories: PayStatementsUI.DeductionsCategory[],
  grossPay: Amount
): PayStatementsUI.PayDonutData {
  let categoriesTotalSum: number = 0;

  const donutItems: PayStatementsUI.PayDonutItem[] = deductionsCategories?.map(
    (category: PayStatementsUI.DeductionsCategory) => {
      const categoryAmount = category?.amount;
      const categoryAmountValue = Math.abs(category?.amount?.amountValue);
      const categoryAmountYTD = category?.amountYTD;
      categoriesTotalSum += categoryAmountValue || 0;

      return {
        id: category?.id,
        key: category?.name,
        amount: categoryAmount,
        amountYTD: categoryAmountYTD,
        value: categoryAmountValue,
        valueYTD: Math.abs(categoryAmountYTD?.amountValue),
        color: category.displayConfig.color
      };
    }
  );

  return {
    hasPositiveDeductions: !(Math.abs(categoriesTotalSum - grossPay?.amountValue) <= 0.1),
    data: donutItems
  };
}
