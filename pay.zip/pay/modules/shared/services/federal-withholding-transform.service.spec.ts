import { CurrencyPipe } from '@angular/common';
import { TestBed } from '@angular/core/testing';
import { merge } from 'lodash';
import { Mock } from 'ts-mockery';

import { LanguageService } from '@myadp/common';

import { WithholdingType } from '../../../models/formatted-tax-withholding.model';
import { FEDERAL } from '../../../models/states.model';
import { PendingEventType } from '../../../models/tax-withholding.model';
import {
  UsFederalIncomeTaxWithholdingElection,
  UsFederalTaxWithholdingElections
} from '../../../models/us-federal-tax-withholding-election.model';
import { FederalWithholdingTransformService } from './federal-withholding-transform.service';
import { ValueFormatterService } from './value-formatter.service';
import { WithholdingFormatterService } from './withholding-formatter.service';

describe('FederalWithholdingTransformService', () => {
  let service: FederalWithholdingTransformService;
  let mockWithholdingData: UsFederalTaxWithholdingElections;
  let mockFederal: UsFederalIncomeTaxWithholdingElection;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        FederalWithholdingTransformService,
        WithholdingFormatterService,
        ValueFormatterService,
        CurrencyPipe,
        {
          provide: LanguageService,
          useValue: Mock.of<LanguageService>({ get: (key) => key })
        }
      ]
    });
  });

  beforeEach(() => {
    service = TestBed.inject(FederalWithholdingTransformService);
  });

  describe('summary items', () => {
    beforeEach(() => {
      mockFederal = {};
      mockWithholdingData = {
        usFederalTaxWithholdingElections: [
          {
            usFederalIncomeTaxWithholdingElection: mockFederal
          }
        ]
      };
    });

    it('should show allowances when it is >=0', () => {
      merge(mockFederal, { taxWithholdingAllowanceQuantity: 0 });
      expectSummaryItemsToEqual(
        jasmine.arrayContaining([
          {
            displayName: 'TOTAL_ALLOWANCES',
            displayValue: 0
          }
        ])
      );
    });

    it('should hide allowances when it is not in the response or <0', () => {
      expectSummaryItemsToEqual([]);

      merge(mockFederal, { taxWithholdingAllowanceQuantity: -1 });
      expectSummaryItemsToEqual([]);
    });

    it('should show non resident alien when user is NRA', () => {
      merge(mockFederal, { nonResidentAlienIndicator: true });
      expectSummaryItemsToEqual(
        jasmine.arrayContaining([
          {
            displayName: 'NONRESIDENT_ALIEN',
            displayValue: 'common.YES'
          }
        ])
      );
    });

    it('should hide non resident alien when user is not NRA', () => {
      merge(mockFederal, { nonResidentAlienIndicator: false });
      expectSummaryItemsToEqual([]);
    });

    it('should show withholding status when user is exempt', () => {
      merge(mockFederal, {
        taxWithholdingStatus: { statusCode: { codeValue: 'X' } }
      });
      expectSummaryItemsToEqual(
        jasmine.arrayContaining([
          {
            displayName: 'WITHHOLDING_STATUS',
            displayValue: 'myadp-pay.EXEMPT'
          }
        ])
      );
    });

    it('should hide withholding status when user is not exempt', () => {
      merge(mockFederal, { nonResidentAlienIndicator: false });
      expectSummaryItemsToEqual([]);
    });
  });

  describe('fed tile additionalStatutoryInputs', () => {
    beforeEach(() => {
      mockFederal = {};
      mockWithholdingData = {
        usFederalTaxWithholdingElections: [
          {
            usFederalIncomeTaxWithholdingElection: mockFederal
          }
        ]
      };
    });

    it('should show higher tax rate if it is true', () => {
      merge(mockFederal, {
        additionalStatutoryInputs: [
          {
            tagCode: 'USE_HIGHER_TAX_RATE',
            tagValues: ['true']
          }
        ]
      });

      expectSummaryItemsToEqual(
        jasmine.arrayContaining([
          {
            displayName: 'TWM_SHARED_SUMMARY_HIGHER_TAX_RATE_HEADING',
            displayValue: 'common.YES'
          }
        ])
      );
    });

    it('should show total tax credit amount if it is in the response', () => {
      merge(mockFederal, {
        additionalStatutoryInputs: [
          {
            tagCode: 'TAX_CREDITS_TOTAL_AMOUNT',
            tagValues: ['1']
          }
        ]
      });

      expectSummaryItemsToEqual(
        jasmine.arrayContaining([
          {
            displayName: 'TWM_FED_TAX_CREDITS_TOTAL_AMOUNT_HEADING',
            displayValue: '$1.00'
          }
        ])
      );
    });

    it('should show other income amount if it is in the response', () => {
      merge(mockFederal, {
        additionalStatutoryInputs: [
          {
            tagCode: 'OTHER_INCOME',
            tagValues: ['2']
          }
        ]
      });

      expectSummaryItemsToEqual(
        jasmine.arrayContaining([
          {
            displayName: 'TWM_FED_OTHER_INCOME_HEADING',
            displayValue: '$2.00'
          }
        ])
      );
    });

    it('should show deduction amount if it is in the response', () => {
      merge(mockFederal, {
        additionalStatutoryInputs: [
          {
            tagCode: 'ITEMIZED_DEDUCTIONS',
            tagValues: ['3']
          }
        ]
      });

      expectSummaryItemsToEqual(
        jasmine.arrayContaining([
          {
            displayName: 'TWM_FED_ITEMIZED_DEDUCTIONS_HEADING',
            displayValue: '$3.00'
          }
        ])
      );
    });
  });

  describe('withholding model', () => {
    beforeEach(() => {
      mockFederal = {
        taxWithholdingAllowanceQuantity: 1,
        taxFilingStatusCode: {
          codeValue: 'X',
          longName: 'Married Filing Jointly or Sep'
        },
        eSignature: {
          signatureIndicator: false
        },
        legalNameDiffersFromSSCardIndicator: false,
        attachments: [
          {
            nameCode: {
              codeValue: 'TAX_WITHHOLDING',
              shortName: 'W-4'
            },
            attachmentLink: {
              payLoadArguments: [
                {
                  argumentPath: 'gssID',
                  argumentValue: '31cb9db9-4ffd-4f7d-9743-dd23b64c9e3c'
                }
              ]
            }
          }
        ]
      };
      mockWithholdingData = {
        usFederalTaxWithholdingElections: [
          {
            usFederalIncomeTaxWithholdingElection: mockFederal,
            payrollGroupCode: {
              codeValue: 'myPayrollGroupCode'
            },
            payrollRegionCode: {
              codeValue: 'myPayrollRegionCode'
            },
            workflowData: {
              pendingData: {
                usFederalTaxWithholdingElections: [
                  {
                    usFederalIncomeTaxWithholdingElection: {
                      taxWithholdingAllowanceQuantity: 2,
                      taxFilingStatusCode: {
                        codeValue: 'X',
                        longName: 'Married Filing Jointly or Sep'
                      },
                      legalNameDiffersFromSSCardIndicator: false
                    }
                  }
                ]
              },
              pendingEvents: {
                eventTypeId: PendingEventType.EMPLOYEE_INITIATED,
                history: [
                  {
                    assignedTo: 'Smith, Bob',
                    actionTaken: 'None',
                    actionDate: 12345,
                    comments: 'comment',
                    processStepID: 6789
                  }
                ]
              }
            }
          }
        ]
      };
    });

    it('should populate basic federal information', () => {
      const mockPendingEvents =
        mockWithholdingData.usFederalTaxWithholdingElections[0].workflowData.pendingEvents;
      const withholdingItems = service.getWithholdingItems(mockWithholdingData);
      const expectedValue = FEDERAL;
      expect(withholdingItems[0].type).toEqual(WithholdingType.FEDERAL);
      expect(withholdingItems[0].state).toEqual(expectedValue);
      expect(withholdingItems[0].title).toEqual('myadp-pay.FEDERAL');
      expect(withholdingItems[0].payrollGroupCode).toEqual({ codeValue: 'myPayrollGroupCode' });
      expect(withholdingItems[0].payrollRegionCode).toEqual({ codeValue: 'myPayrollRegionCode' });
      expect(withholdingItems[0].title).toEqual('myadp-pay.FEDERAL');

      expect(withholdingItems[0].rawData).toEqual(mockFederal);
      expect(withholdingItems[0].pendingEvents).toEqual(mockPendingEvents);
      expect(withholdingItems[0].attachments.length).toEqual(1);
    });

    it('should return isCompleted false when signatureIndicator is false and has no pending data', () => {
      delete mockWithholdingData.usFederalTaxWithholdingElections[0].workflowData;
      const withholdingItems = service.getWithholdingItems(mockWithholdingData);

      expect(withholdingItems[0].isCompleted).toBe(false);
    });

    it('should return isCompleted true when signatureIndicator is true', () => {
      mockFederal.eSignature = {
        signatureIndicator: true
      };
      delete mockWithholdingData.usFederalTaxWithholdingElections[0].workflowData;
      const withholdingItems = service.getWithholdingItems(mockWithholdingData);

      expect(withholdingItems[0].isCompleted).toBe(true);
    });

    it('should return isCompleted true has pending data', () => {
      delete mockWithholdingData.usFederalTaxWithholdingElections[0]
        .usFederalIncomeTaxWithholdingElection;
      const withholdingItems = service.getWithholdingItems(mockWithholdingData);

      expect(withholdingItems[0].isCompleted).toBe(true);
    });

    it('should return isCompleted true without eSignature indicator and has pending data', () => {
      delete mockFederal.eSignature;
      delete mockWithholdingData.usFederalTaxWithholdingElections[0]
        .usFederalIncomeTaxWithholdingElection;
      const withholdingItems = service.getWithholdingItems(mockWithholdingData);

      expect(withholdingItems[0].isCompleted).toBe(true);
    });

    it('should return isCompleted true without eSignature indicator and has current data', () => {
      delete mockFederal.eSignature;
      delete mockWithholdingData.usFederalTaxWithholdingElections[0].workflowData;
      const withholdingItems = service.getWithholdingItems(mockWithholdingData);

      expect(withholdingItems[0].isCompleted).toBe(true);
    });

    it('should handle effectiveDate scenarios', () => {
      // valid effectiveDate
      mockFederal['taxWithholdingStatus'] = {
        effectiveDate: '2020-01-01'
      };
      const withholdingItemsOne = service.getWithholdingItems(mockWithholdingData);
      expect(withholdingItemsOne[0].effectiveDate).toEqual(
        mockFederal.taxWithholdingStatus.effectiveDate
      );

      // invalid effectiveDate
      mockFederal['taxWithholdingStatus'] = {
        effectiveDate: 'invalid'
      };
      const withholdingItemsTwo = service.getWithholdingItems(mockWithholdingData);
      expect(withholdingItemsTwo[0].effectiveDate).toEqual('invalid');
    });

    it('should populate basic federal information when there is no withholding data', () => {
      const withholdingItems = service.getWithholdingItems({});
      expect(withholdingItems[0].state).toEqual(FEDERAL);
      expect(withholdingItems[0].title).toEqual('myadp-pay.FEDERAL');
      expect(withholdingItems[0].rawData).toBeUndefined();
      expect(withholdingItems[0].pendingEvents).toBeUndefined();
    });

    it('should populate pending summary items', () => {
      const withholdingItems = service.getWithholdingItems(mockWithholdingData);

      expect(withholdingItems[0].pendingSummaryItems).toEqual([
        {
          displayName: 'TOTAL_ALLOWANCES',
          displayValue: 2
        }
      ]);
    });

    it('should populate pending summary with legal name when it changes', () => {
      mockWithholdingData.usFederalTaxWithholdingElections[0].workflowData.pendingData
        .usFederalTaxWithholdingElections[0].usFederalIncomeTaxWithholdingElection.legalNameDiffersFromSSCardIndicator =
        true;
      const withholdingItems = service.getWithholdingItems(mockWithholdingData);

      expect(withholdingItems[0].summaryItems).toContain({
        displayName: 'TWM_FED_SUMMARY_LAST_NAME_HEADING',
        displayValue: 'common.NO'
      });
      expect(withholdingItems[0].pendingSummaryItems).toContain({
        displayName: 'TWM_FED_SUMMARY_LAST_NAME_HEADING',
        displayValue: 'common.YES'
      });
    });

    it('should not populate pending summary with legal name when it does not changes', () => {
      mockWithholdingData.usFederalTaxWithholdingElections[0].usFederalIncomeTaxWithholdingElection.legalNameDiffersFromSSCardIndicator =
        true;
      mockWithholdingData.usFederalTaxWithholdingElections[0].workflowData.pendingData
        .usFederalTaxWithholdingElections[0].usFederalIncomeTaxWithholdingElection.legalNameDiffersFromSSCardIndicator =
        true;
      const withholdingItems = service.getWithholdingItems(mockWithholdingData);

      expect(withholdingItems[0].summaryItems).not.toContain({
        displayName: 'TWM_FED_SUMMARY_LAST_NAME_HEADING',
        displayValue: 'common.YES'
      });
      expect(withholdingItems[0].pendingSummaryItems).not.toContain({
        displayName: 'TWM_FED_SUMMARY_LAST_NAME_HEADING',
        displayValue: 'common.YES'
      });
    });
  });

  describe('is federal locked', () => {
    beforeEach(() => {
      mockFederal = {
        taxWithholdingAllowanceQuantity: 1,
        actions: [
          {
            operationID: '',
            attestation: {
              messageTxt: ''
            }
          }
        ]
      };
      mockWithholdingData = {
        usFederalTaxWithholdingElections: [
          {
            usFederalIncomeTaxWithholdingElection: mockFederal
          }
        ]
      };
    });

    it('should return true if state is locked', () => {
      mockFederal.actions[0].operationID = 'worker.usFederal.taxWithholding.election.read';
      const withholdingItems = service.getWithholdingItems(mockWithholdingData);
      expect(withholdingItems[0].isLocked).toEqual(true);
    });

    it('should return false if state is not locked', () => {
      mockFederal.actions[0].operationID = 'worker.usFederal.taxWithholding.election.change';
      const withholdingItems = service.getWithholdingItems(mockWithholdingData);
      expect(withholdingItems[0].isLocked).toEqual(false);
    });

    it('should return messageTxt', () => {
      const mockMessageTxt = 'TWT_1001';
      mockFederal.actions[0].operationID = 'worker.usFederal.taxWithholding.election.read';
      mockFederal.actions[0].attestation.messageTxt = mockMessageTxt;
      const withholdingItems = service.getWithholdingItems(mockWithholdingData);
      expect(withholdingItems[0].lockedOutMessage).toEqual(mockMessageTxt);
    });

    it('should return false if there is no actions field', () => {
      delete mockFederal.actions;
      const withholdingItems = service.getWithholdingItems(mockWithholdingData);
      expect(withholdingItems[0].isLocked).toEqual(false);
    });
  });

  function expectSummaryItemsToEqual(expectedValue: any) {
    const withholdingItem = service.getWithholdingItems(mockWithholdingData);
    expect(withholdingItem[0].summaryItems).toEqual(expectedValue);
  }
});
