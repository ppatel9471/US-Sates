import { Component, Input, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { ClientDeviceService } from '@espresso/core';
import { ModalComponent } from '@synerg/components/modal';
import { take } from 'rxjs/operators';

import { LanguageService, PrintModalService } from '@myadp/common';
import { PageType, PaperlessStore, PaperlessStoreActions, PaperlessType, TAX_FORM_CODES } from '@myadp/pay-paperless-shared';

@Component({
  selector: 'paperless-view-wrapper',
  templateUrl: './paperless-view-wrapper.component.html',
  styleUrls: ['./paperless-view-wrapper.component.scss']
})
export class PaperlessViewWrapperComponent implements OnInit, OnDestroy {
  @Input('pageType') public pageType: PageType;
  @Input() public displaySettingsType: 'inline' | 'modal' = 'modal';
  @ViewChild('paperlessSettingsModal') public paperlessSettingsModal: ModalComponent;
  @ViewChild('paperlessConsentModal') public paperlessConsentModal: ModalComponent;
  @ViewChild('paperlessPrintConsentModal') public paperlessPrintConsentModal: ModalComponent;
  public isNative: boolean = false;
  public isAdaptive: boolean = false;
  public showSettingsModal: boolean = false;
  public showConsentModal: boolean = false;
  public showPrintConsentModal: boolean = false;
  public settingsModalTitle: string;
  public paperlessType = PaperlessType;
  public type: PaperlessType;

  constructor(
    private paperlessStore: PaperlessStore,
    private paperlessStoreActions: PaperlessStoreActions,
    private languageService: LanguageService,
    private clientDeviceService: ClientDeviceService,
    private printModalService: PrintModalService
  ) {}

  public setDisplaySettingsModal(display: boolean): void {
    this.showSettingsModal = display;
    this.paperlessStoreActions.setSettingsModalOpen(display);
  }

  public setDisplayConsentModal(display: boolean): void {
    this.showConsentModal = display;
  }

  public setDisplayPrintConsentModal(display: boolean): void {
    this.showPrintConsentModal = display;
  }

  public consentToPaperless(): void {
    const saveLookup = {
      [PaperlessType.PAY]: () => this.paperlessStoreActions.savePayStatementPaperless(true),
      [PaperlessType.TAX]: () =>
        this.paperlessStoreActions.saveTaxStatementPaperless(true, TAX_FORM_CODES.W2_CODE),
      [PaperlessType.TAX_COVERAGE_INSURANCE]: () =>
        this.paperlessStoreActions.saveTaxStatementPaperless(
          true,
          TAX_FORM_CODES.COVERAGE_INSURANCE_CODE
        ),
      [PaperlessType.RETIREMENT]: () => this.paperlessStoreActions.saveRetirementNotification(true)
    };

    this.setDisplayConsentModal(false);
    saveLookup[this.type]();
  }

  public printConsent(): void {
    let consentPrintText: string = '';
    if (this.type === PaperlessType.PAY) {
      consentPrintText =
        this.languageService.get('myadp-pay.GO_PAPERLESS_CONTENT_INFO_PAY_LABEL') +
        this.languageService.get('myadp-pay.GO_PAPERLESS_PAY_TAX_SHARED_CONSENT_PAY');
    } else if (
      this.type === PaperlessType.TAX ||
      this.type === PaperlessType.TAX_COVERAGE_INSURANCE
    ) {
      consentPrintText = this.languageService.get('myadp-pay.GO_PAPERLESS_PAY_TAX_SHARED_CONSENT');
    }

    consentPrintText =
      consentPrintText + this.languageService.get(`myadp-pay.GO_PAPERLESS_${this.type}_CONSENT`);

    if (this.type === PaperlessType.PAY) {
      consentPrintText =
        consentPrintText +
        this.languageService.get(`myadp-pay.GO_PAPERLESS_SHARED_CONSENT_AGREEMENT_PAY`);
    }

    const consentPrintTitle: string = this.languageService.get(this.consentModalTitle);

    this.printModalService.printText(`
      <html>
        <head>
          <title>${consentPrintTitle}</title>
        </head>
        <body>
          ${consentPrintText}
        </body>
      </html>`);
  }

  public setType(type: PaperlessType): void {
    this.type = type;
  }

  public ngOnInit() {
    this.isNative = this.clientDeviceService.isNative();
    this.isAdaptive = this.isNative && this.clientDeviceService.isMobile();
    this.getModalTitle();
  }

  public ngOnDestroy() {
    if (this.showSettingsModal && this.paperlessSettingsModal && !this.isAdaptive) {
      this.paperlessSettingsModal.close();
    }

    this.setDisplaySettingsModal(false);
    this.setDisplayConsentModal(false);
    this.setDisplayPrintConsentModal(false);
  }

  public get consentModalTitle() {
    return `myadp-pay.GO_PAPERLESS_${this.type}_CONSENT_MODAL_TITLE`;
  }

  private getModalTitle(): void {
    this.settingsModalTitle = this.languageService.get(
      'myadp-pay.GO_PAPERLESS_SETTINGS_MODAL_TITLE'
    );

    if (!this.isNative) {
      this.paperlessStore
        .onlyEmailSettingsVisible$()
        .pipe(take(1))
        .subscribe((onlyEmail: boolean) => {
          if (onlyEmail) {
            this.settingsModalTitle = this.languageService.get(
              'myadp-pay.GO_PAPERLESS_SETTINGS_EMAIL_MODAL_TITLE'
            );
          }
        });
    }
  }
}
