import { Shallow } from 'shallow-render';

import { DirectDepositComparisonService } from '../../services/direct-deposit-comparison.service';
import { SharedModule } from '../../shared.module';
import { WorkflowDetailsComparisonComponent } from '../workflow-details-comparison/workflow-details-comparison.component';
import { DirectDepositDetailsComparisonComponent } from './direct-deposit-details-comparison.component';
import { DirectDepositDetailsComponent } from './direct-deposit-details/direct-deposit-details.component';

describe('DirectDepositDetailsComparisonComponent', () => {
  let shallow: Shallow<DirectDepositDetailsComparisonComponent>;

  beforeEach(() => {
    shallow = new Shallow<DirectDepositDetailsComparisonComponent>(
      DirectDepositDetailsComparisonComponent,
      SharedModule
    )
      .dontMock(WorkflowDetailsComparisonComponent, DirectDepositDetailsComponent)
      .mock(DirectDepositComparisonService, {
        getComparisonData: () => [{}, {}]
      });
  });

  it('should handle getting comparison data', async () => {
    const { find, get, instance } = await shallow.render({
      bind: {
        data: null,
        hasMultipleAccounts: false
      }
    });

    expect(get(DirectDepositComparisonService).getComparisonData).toHaveBeenCalledWith(
      instance.data,
      false
    );
    expect(find('dd-details.wf-current-data')).toHaveFound(1);
    expect(find('dd-details.wf-pending-data')).toHaveFound(1);
  });
});
