import {
  MOCK_PAY_STATEMENTS_RESPONSE,
  MOCK_TRANSFORMED_PAY_STATEMENTS
} from '../../../../../../src/spec-helpers/pay/pay-statement/pay-statements';
import { PayStatementsUI } from '../models/pay-statement-ui';
import { TransformConfig, transformStatements } from './pay-statements.transform';

const transformedStatements: PayStatementsUI.PayStatement[] = MOCK_TRANSFORMED_PAY_STATEMENTS;
describe('transformStatements', () => {
  let statements: PayStatementsUI.PayStatement[];
  const transformConfig: TransformConfig = {
    SOR: '',
    TRANSLATIONS: {
      ADJUSTMENT: 'myadp-pay.PAY_ADJUSTMENT',
      UNKNOWN_DATE: 'myadp-pay.PAY_UNKNOWN_DATE'
    }
  };

  beforeEach(() => {
    statements = transformStatements(MOCK_PAY_STATEMENTS_RESPONSE, transformConfig);
  });

  it('should sort statements by date and payAdjustments', () => {
    expect(statements).toEqual(transformedStatements);
  });

  it('should include statement type of Adjustment', () => {
    expect(statements[0].statementType).toBeUndefined();
    expect(statements[1].statementType).toEqual('myadp-pay.PAY_ADJUSTMENT');
  });

  it('should format date', () => {
    expect(statements[5].payDate).toBe('Sep 13, 2017');
  });

  it('should set date to Unknown Date', () => {
    expect(statements[6].payDate).toBe('myadp-pay.PAY_UNKNOWN_DATE');
  });

  describe('setFiscalYear', () => {
    it('should set fiscal year', () => {
      statements = transformStatements(MOCK_PAY_STATEMENTS_RESPONSE, transformConfig);
      expect(statements[0].statementFiscalYear).toBe('2019');
      expect(statements[1].statementFiscalYear).toBe('2019');
      expect(statements[2].statementFiscalYear).toBe('2019');
      expect(statements[3].statementFiscalYear).toBe('2018');
      expect(statements[4].statementFiscalYear).toBe('2017');
      expect(statements[5].statementFiscalYear).toBe('2017');
      expect(statements[6].statementFiscalYear).toBe('myadp-pay.PAY_UNKNOWN_DATE');
    });

    it('should set fiscal year ranges for FREEDOM', () => {
      transformConfig.SOR = 'FREEDOM';
      statements = transformStatements(MOCK_PAY_STATEMENTS_RESPONSE, transformConfig);
      expect(statements[0].statementFiscalYear).toBe('2019 - 2020');
      expect(statements[1].statementFiscalYear).toBe('2019 - 2020');
      expect(statements[2].statementFiscalYear).toBe('2018 - 2019');
      expect(statements[3].statementFiscalYear).toBe('2017 - 2018');
      expect(statements[4].statementFiscalYear).toBe('2017 - 2018');
      expect(statements[5].statementFiscalYear).toBe('2017 - 2018');
      expect(statements[6].statementFiscalYear).toBe(
        'myadp-pay.PAY_UNKNOWN_DATE - myadp-pay.PAY_UNKNOWN_DATE'
      );
    });
  });
});
