import { Injectable } from '@angular/core';
import { LanguageService } from '@myadp/common';
import { cloneDeep, findIndex, get, has, sortBy, sortByOrder } from 'lodash';

import { AdditionalTaxAmount, CodeType } from '../../../models/tax-withholding.model';
import {
  Attachment,
  SummaryItem,
  WithholdingInfo,
  WithholdingItem,
  WithholdingType
} from '../../../models/formatted-tax-withholding.model';
import { StateIncomeTaxWithholdingElection } from '../../../models/us-state-tax-withholding-election.model';
import { UsFederalIncomeTaxWithholdingElection } from '../../../models/us-federal-tax-withholding-election.model';
import { ValueFormatterService } from '../../shared/services/value-formatter.service';

@Injectable({
  providedIn: 'root'
})
export class WithholdingFormatterService {

  private displayKeyLookup = {
    'WITHHOLDING_STATUS' : 'myadp-pay.NOT_EXEMPT',
    'TWM_SHARED_SUMMARY_HIGHER_TAX_RATE_HEADING' : 'common.NO'
  };
  private GSS_URL = '/api/tax/v1/statutory-forms/file/';

  constructor(
    private valueFormatterService: ValueFormatterService,
    private languageService: LanguageService
  ) {}

  public showAdditionalTaxPercentage(
    additionalTaxAmount: AdditionalTaxAmount,
    additionalTaxPercentage: number
  ): boolean {
    return (
      !this.showAdditionalTaxAmount(additionalTaxAmount, additionalTaxPercentage) &&
      additionalTaxPercentage !== undefined
    );
  }

  public showAdditionalTaxAmount(
    additionalTaxAmount: AdditionalTaxAmount,
    additionalTaxPercentage: number
  ): boolean {
    const amount = get(additionalTaxAmount, 'amountValue');
    const percent = additionalTaxPercentage || 0;
    return amount !== undefined && (amount > 0 || (amount === 0 && percent === 0));
  }

  public summaryItemHelper(
    formattedWithholding: SummaryItem[],
    withholding: StateIncomeTaxWithholdingElection | UsFederalIncomeTaxWithholdingElection,
    attribute: string,
    displayName: string,
    formatter?: string
  ): void {
    if (has(withholding, attribute)) {
      const value = get(withholding, attribute);
      const displayValue = this.valueFormatterService.format(value, formatter);
      formattedWithholding.push({
        displayName: displayName,
        displayValue: displayValue
      });
    }
  }

  public getTitleName(code: CodeType): string {
    const { longName, shortName, codeValue } = code;
    return longName || shortName || `State code: ${codeValue}`;
  }

  public sortWithholdingInfo(withholdingInfos: WithholdingItem[]) {
    return sortBy(withholdingInfos, 'title');
  }

  public getErrorModel(type: WithholdingType): WithholdingInfo {
    return { type: type, hasError: true };
  }

  public isExempt(
    withholding: StateIncomeTaxWithholdingElection | UsFederalIncomeTaxWithholdingElection
  ): SummaryItem {
    // if exempt
    if (get(withholding, 'taxWithholdingStatus.statusCode.codeValue') === 'X') {
      return {
        displayName: 'WITHHOLDING_STATUS',
        displayValue: this.languageService.get('myadp-pay.EXEMPT')
      };
    }
    return null;
  }

  public getAttachments(
    withholding: StateIncomeTaxWithholdingElection | UsFederalIncomeTaxWithholdingElection
  ): Attachment[] {
    const formattedAttachments = withholding?.attachments
      ?.map(a => {
        const gssID = a?.attachmentLink?.payLoadArguments
          .find(argument => argument.argumentPath === 'gssID')?.argumentValue;

        return {
          shortName: a?.nameCode?.shortName,
          gssUrl: gssID ? this.GSS_URL + gssID : undefined,
          submittedDateTime: a?.attachmentLink?.payLoadArguments
            .find(argument => argument.argumentPath === 'submittedDateTime')?.argumentValue
        };
      })
      .filter(a => a.gssUrl);

    return sortByOrder(formattedAttachments, 'submittedDateTime', 'desc');
  }

  public formatPendingItems(currentItems: SummaryItem[], pendingItems: SummaryItem[]): void {
    const origPendingItems: SummaryItem[] = cloneDeep(pendingItems);
    pendingItems.length = 0;

    origPendingItems.forEach((pendingItem: SummaryItem) => {
      const currentItem = currentItems.find(item => item.displayName === pendingItem.displayName);
      const fieldAdded = !currentItem;
      const fieldChanged = pendingItem.displayValue !== get(currentItem, 'displayValue');

      if (fieldAdded) {
        const displayKey = this.displayKeyLookup[pendingItem.displayName] || 'common.NONE';
        currentItems.push({
          displayName: pendingItem.displayName,
          displayValue: this.languageService.get(displayKey)
        });
      }

      if (fieldChanged) {
        pendingItems.push(pendingItem);
      }
    });

    currentItems.forEach((currentItem: SummaryItem) => {
      const pendingItem = origPendingItems.find(
        item => item.displayName === currentItem.displayName
      );
      const fieldRemoved = !pendingItem;

      if (fieldRemoved) {
        const displayKey = this.displayKeyLookup[currentItem.displayName] || 'myadp-pay.REMOVED';
        pendingItems.push({
          displayName: currentItem.displayName,
          displayValue: this.languageService.get(displayKey)
        });
      }
    });

    this.sortSummaryItems(currentItems);
    this.sortSummaryItems(pendingItems);
  }

  public getAdditionalStatutoryInputs(
    tagCode: string,
    withholding: StateIncomeTaxWithholdingElection | UsFederalIncomeTaxWithholdingElection
  ) {
    const index = findIndex(get(withholding, 'additionalStatutoryInputs'), { tagCode: tagCode });
    return get(withholding, `additionalStatutoryInputs[${index}].tagValues[0]`);
  }

  private sortSummaryItems(items: SummaryItem[]) {
    items.sort((a, b) => a.displayName.localeCompare(b.displayName));
  }
}
