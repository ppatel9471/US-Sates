import { LegacyCodeType } from '@myadp/dto';

import { WiselyTypes } from './wisely.model';

export interface MessageWithType {
  messageCode: string;
  messageText: string;
  messageTypeCode?: string;
}

export interface AccountType extends LegacyCodeType {
  label?: string;
  value?: string;
}
export interface AccountNameDetails {
  enabled: boolean;
  maxLength: number;
}

export type MiscPermissions = WiselyTypes | 'GIACT' | 'canValidateBankInfo';

export enum ValidationStatus {
  WARN = 'WARN',
  SUCCESS = 'SUCCESS',
  INVALID = 'INVALID',
  ERROR = 'ERROR'
}

export interface ValidationStatusObj {
  status?: ValidationStatus;
  setByVendor?: boolean;
}

export type ValidationStatusType =
  | ValidationStatus.WARN
  | ValidationStatus.SUCCESS
  | ValidationStatus.INVALID
  | ValidationStatus.ERROR;

export interface GIACTValidationResponse {
  accountValidationResponse: {
    responseMessage: MessageWithType;
  };
}

export interface GIACTValidationError {
  error: {
    _confirmMessage: {
      messages: Array<{
        messageCode: string;
        messageText: string;
      }>;
    };
  };
}
export interface OCRData {
  routingNumber?: string;
  accountNumber?: string;
  financialInstituteNumber?: string;
  transitNumber?: string;
}
export interface PersonName {
  givenName: string;
  middleName?: string;
  familyName1: string;
}
