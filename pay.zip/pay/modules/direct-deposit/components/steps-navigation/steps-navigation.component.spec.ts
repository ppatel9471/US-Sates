import { fakeAsync, flush } from '@angular/core/testing';
import { of } from 'rxjs';
import { Shallow } from 'shallow-render';
import { Mock } from 'ts-mockery';

import { LanguagePipe } from '@myadp/common';

import { CloseConfirmComponent } from '../../../shared/components/close-confirm/close-confirm.component';
import { MyADPDirectDepositModule } from '../../direct-deposit.module';
import { PrevNext } from '../../store/steps/steps-store.actions';
import { StepsStore, StepsStoreActions } from '../../store/steps/steps.store';
import { StepsNavigationComponent } from './steps-navigation.component';

describe('StepsNavigationComponent', () => {
  let shallow: Shallow<StepsNavigationComponent>;
  let changes: boolean = true;

  beforeEach(() => {
    changes = true;

    return (shallow = new Shallow(StepsNavigationComponent, MyADPDirectDepositModule)
      .dontMock(CloseConfirmComponent)
      .mock(StepsStore, {
        getPrevOrNextProperties$: (dir: PrevNext) =>
          dir === 'next'
            ? of({ disabled: false, hidden: false })
            : of({ disabled: false, hidden: false }),
        isSubmitStep$: of(false),
        stepsStoreData: { isSubmitStep: false }
      })
      .mock(StepsStoreActions, {
        submit: () => Promise.resolve(),
        hasAccountChanges: () => changes,
        nextStep: () => Mock.noop(),
        prevStep: () => Mock.noop(),
        cancelStep: () => Mock.noop()
      })
      .mockPipe(LanguagePipe, (key) => key));
  });

  it('should show both buttons', async () => {
    const { find } = await shallow.render();
    expect(find('adp-button')).toHaveFound(3);
  });

  describe('Next button', () => {
    it('should have Next button when not on submit step', async () => {
      const { find } = await shallow.render();
      const [nextBtn] = find('#next-btn');

      expect(nextBtn.nativeElement.innerHTML).toContain('common.NEXT');
    });

    it('should go to next step when clicking next', async () => {
      const { find, get } = await shallow.render();
      const [nextBtn] = find('#next-btn');
      nextBtn.nativeElement.click();

      expect(get(StepsStoreActions).nextStep).toHaveBeenCalledTimes(1);
    });

    describe('disabled prop', () => {
      it('should not be disabled', async () => {
        const { find } = await shallow.render();
        const [nextBtn] = find('#next-btn');

        expect(nextBtn.componentInstance.disabled).toBeFalsy();
      });

      it('should be disabled', async () => {
        const { find } = await shallow
          .mock(StepsStore, {
            getPrevOrNextProperties$: () => of({ hidden: false, disabled: true })
          })
          .render();
        const [nextBtn] = find('#next-btn');

        expect(nextBtn.componentInstance.disabled).toBeTruthy();
      });
    });

    describe('hidden prop', () => {
      it('should be hidden', async () => {
        const { find } = await shallow
          .mock(StepsStore, {
            getPrevOrNextProperties$: (dir: PrevNext) =>
              dir === 'next'
                ? of({ hidden: true, disabled: false })
                : of({ hidden: false, disabled: false })
          })
          .render();
        const [prevBtn] = find('#prev-btn');

        expect(find('#prev-btn')).toHaveFoundOne();
        expect(prevBtn.nativeElement.innerHTML).toContain('common.PREV');
      });
    });

    describe('Submit Step', () => {
      it('should change Next button to Submit button if on submit step', async () => {
        const { find } = await shallow
          .mock(StepsStore, {
            isSubmitStep$: of(true),
            stepsStoreData: { isSubmitStep: true }
          })
          .render();
        const [nextBtn] = find('#next-btn');

        expect(nextBtn.nativeElement.innerHTML).toContain('common.SUBMIT');
      });

      it('should call POST and go to next step when POST succeeds', fakeAsync(async () => {
        const { find, get } = await shallow
          .mock(StepsStore, {
            isSubmitStep$: of(true),
            stepsStoreData: { isSubmitStep: true }
          })
          .render();
        const [nextBtn] = find('#next-btn');
        nextBtn.nativeElement.click();
        flush();

        expect(get(StepsStoreActions).submit).toHaveBeenCalledTimes(1);
        expect(get(StepsStoreActions).nextStep).toHaveBeenCalledTimes(1);
      }));

      it('should call POST and not go to next step when POST fails', async () => {
        const { find, get } = await shallow
          .mock(StepsStore, {
            isSubmitStep$: of(true),
            stepsStoreData: { isSubmitStep: true }
          })
          .mock(StepsStoreActions, {
            submit: () => Promise.reject()
          })
          .render();
        const [nextBtn] = find('#next-btn');
        nextBtn.nativeElement.click();

        expect(get(StepsStoreActions).submit).toHaveBeenCalledTimes(1);
        expect(get(StepsStoreActions).nextStep).not.toHaveBeenCalledTimes(1);
      });
    });
  });

  describe('Prev button', () => {
    it('should go to prev step when clicking prev', async () => {
      const { find, get } = await shallow.render();
      const [prevBtn] = find('#prev-btn');
      prevBtn.nativeElement.click();

      expect(get(StepsStoreActions).prevStep).toHaveBeenCalledTimes(1);
    });

    describe('disabled prop', () => {
      it('should not be disabled', async () => {
        const { find } = await shallow.render();
        const [prevBtn] = find('#prev-btn');

        expect(prevBtn.componentInstance.disabled).toBeFalsy();
      });

      it('should be disabled', async () => {
        const { find } = await shallow
          .mock(StepsStore, {
            getPrevOrNextProperties$: () => of({ hidden: false, disabled: true })
          })
          .render();
        const [prevBtn] = find('#prev-btn');

        expect(prevBtn.componentInstance.disabled).toBeTruthy();
      });
    });

    describe('hidden prop', () => {
      it('should be hidden', async () => {
        const { find } = await shallow
          .mock(StepsStore, {
            getPrevOrNextProperties$: (dir: PrevNext) =>
              dir === 'prev'
                ? of({ hidden: true, disabled: false })
                : of({ hidden: false, disabled: false })
          })
          .render();
        const [nextBtn] = find('#next-btn');

        expect(find('#next-btn')).toHaveFoundOne();
        expect(nextBtn.nativeElement.innerHTML).toContain('common.NEXT');
      });
    });
  });

  describe('Cancel button', () => {
    it('should go to cancel step when clicked', async () => {
      changes = false;

      const { find, get } = await shallow.render();
      const [cancelBtn] = find('#cancel-btn');
      cancelBtn.nativeElement.click();

      expect(get(StepsStoreActions).cancelStep).toHaveBeenCalledTimes(1);
    });

    describe('disabled prop', () => {
      it('should not be disabled', async () => {
        const { find } = await shallow.render();
        const [cancelBtn] = find('#cancel-btn');

        expect(cancelBtn.componentInstance.disabled).toBeFalsy();
      });

      it('should be disabled', async () => {
        const { find } = await shallow
          .mock(StepsStore, {
            getPrevOrNextProperties$: () => of({ hidden: false, disabled: true })
          })
          .render();
        const [cancelBtn] = find('#cancel-btn');

        expect(cancelBtn.componentInstance.disabled).toBeTruthy();
      });
    });

    describe('hidden prop', () => {
      it('should be hidden', async () => {
        const { find } = await shallow
          .mock(StepsStore, {
            getPrevOrNextProperties$: (dir: PrevNext) =>
              dir === 'cancel'
                ? of({ hidden: true, disabled: false })
                : of({ hidden: false, disabled: false })
          })
          .render();
        const [nextBtn] = find('#next-btn');

        expect(find('#next-btn')).toHaveFoundOne();
        expect(nextBtn.nativeElement.innerHTML).toContain('common.NEXT');
      });
    });

    describe('confirm cancel', () => {
      it('should display confirm cancel modal when cancel is hit and changes are made', async () => {
        changes = true;
        const { find, fixture, get } = await shallow.render();
        const [cancelBtn] = find('#cancel-btn');
        cancelBtn.nativeElement.click();
        fixture.detectChanges();

        expect(find('close-confirm')).toHaveFound(1);
        expect(get(StepsStoreActions).cancelStep).toHaveBeenCalledTimes(0);
      });

      it('should close modal and cancel step when confirming cancel', async () => {
        changes = true;
        const { find, fixture, get } = await shallow.render();
        const [cancelBtn] = find('#cancel-btn');
        cancelBtn.nativeElement.click();
        fixture.detectChanges();

        const [confirmCancelBtn] = find('close-confirm #confirm-button');
        confirmCancelBtn.nativeElement.click();
        fixture.detectChanges();

        expect(find('close-confirm')).toHaveFound(0);
        expect(get(StepsStoreActions).cancelStep).toHaveBeenCalledTimes(1);
      });

      it('should not display confirm cancel modal when cancel is hit and changes are made', async () => {
        changes = false;
        const { find, get } = await shallow.render();
        const [cancelBtn] = find('#cancel-btn');
        cancelBtn.nativeElement.click();

        expect(find('close-confirm')).toHaveFound(0);
        expect(get(StepsStoreActions).cancelStep).toHaveBeenCalledTimes(1);
      });
    });
  });
});
