import { Component } from '@angular/core';

@Component({
  selector: 'twm-meta-demo',
  templateUrl: './meta-demo.component.html'
})
export class MetaDemoComponent {}
