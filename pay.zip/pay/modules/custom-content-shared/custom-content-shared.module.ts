import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MyAdpCommonModule } from '@myadp/common';

import { CustomContentComponent } from './components/custom-content/custom-content.component';

@NgModule({
  imports: [CommonModule, MyAdpCommonModule],
  declarations: [CustomContentComponent],
  exports: [CustomContentComponent]
})
export class CustomContentSharedModule {}
