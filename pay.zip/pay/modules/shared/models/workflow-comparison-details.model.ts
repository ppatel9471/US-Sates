import { PayDeductionsUI } from '../../pay-deductions-shared/models/pay-deductions-ui';
import { PayDistributionsUI } from '../../pay-distributions-shared/models/pay-distributions-ui';

type WorkflowComparisonDetails<DetailsType> = Partial<DetailsType> & {
  addOrDeleteMsg?: string;
  displayAmount?: string;
};

export type DeductionComparisonDetails =
  WorkflowComparisonDetails<PayDeductionsUI.DeductionDetails> & {
    goalDisplayAmount?: string;
  };

export type DirectDepositComparisonDetails =
  WorkflowComparisonDetails<PayDistributionsUI.PayDistributionDetails> & {
    isWisely?: boolean;
  };
