export namespace WorkflowUI {
  export interface WorkflowData<DataType, PE = PendingEvent> {
    currentData: DataType;
    pendingData?: DataType;
    pendingEvent?: PE;
  }

  // common
  export interface PendingEvent<CT = ChangeType> {
    approver?: string;
    changeType?: CT;
  }

  export type ChangeType = 'add' | 'edit' | 'delete';
}
