import { GaIntroComponent } from './steps/intro/ga-intro.component';
import { GaExemptionComponent } from './steps/exemption/ga-exemption.component';
import { GaMaritalStatusComponent } from './steps/marital-status/ga-marital-status.component';
import { GaDependentAllowancesComponent } from './steps/dependent-allowances/ga-dependent-allowances.component';
import { GaAdditionalAllowancesComponent } from './steps/additional-allowances/ga-additional-allowances.component';

export { GaStepNavigationService } from './services/ga-step-navigation.service';
export { GaTWChangeEventService } from './services/ga-tw-change-event.service';
export { GaSummaryMetaDataService } from './services/ga-summary-meta-data.service';

export const GA_COMPONENTS = [
  GaAdditionalAllowancesComponent,
  GaIntroComponent,
  GaExemptionComponent,
  GaMaritalStatusComponent,
  GaDependentAllowancesComponent,
  GaAdditionalAllowancesComponent
];

export { GASTEP_COMPONENT } from './models/steps-component.model';

export { GaAttachmentCodes } from './models/ga-tw-change-event';
