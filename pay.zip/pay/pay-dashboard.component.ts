import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'pay',
  templateUrl: 'pay-dashboard.html'
})
export class PayDashboardComponent {
  testOcrData: any;

  constructor(private router: Router) {
    this.testOcrData = {
      accountNumber: '0000000016',
      routingNumber: '2125678'
    };
  }

  public clickMetaDemo() {
    this.router.navigate(['/pay-meta-demo']);
  }
}
