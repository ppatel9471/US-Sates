import { NavigationRoute } from './navigation-route';

describe('Navigation Route', () => {
  it('should be able to create a representation of a navigation route', () => {
    const navDetails = {
      name: 'foo'
    };

    const fooRoute = new NavigationRoute(navDetails);

    expect(fooRoute.name).toEqual(navDetails.name);
  });

  describe('more complicated scenarios', () => {
    let root: NavigationRoute, fooRoute: NavigationRoute, barRoute: NavigationRoute;

    const rootDetails = {
      name: 'root'
    };

    const navDetails = {
      name: 'foo'
    };

    const childDetails = {
      name: 'bar'
    };

    beforeEach(() => {
      root = new NavigationRoute(rootDetails);
      fooRoute = new NavigationRoute(navDetails);
      barRoute = new NavigationRoute(childDetails);
      root.buildRoutes([fooRoute, barRoute], true);
    });

    it('should be able to append a route', () => {
      expect(fooRoute.routes.length).toEqual(1);
    });

    it('should be able to take an array of routes, construct a chain of routes from it and then append it to the parent', () => {
      expect(root.routes.length).toEqual(1);
    });

    it('should set the parent properly for each route chain.', () => {
      expect(root.routes[0].name).toEqual(navDetails.name);
      expect(root.routes[0].routes[0].name).toEqual(childDetails.name);
    });

    it('should set a returnTo if available', () => {
      expect(root.routes[0].returnTo.name).toEqual(rootDetails.name);
    });

    it('should find a child route by its tag.', () => {
      const detailsWithTag = {
        name: 'moaf',
        tag: 'stuff'
      };
      root.appendRoute(new NavigationRoute(detailsWithTag));

      expect(root.findByTag('stuff').name).toEqual(detailsWithTag.name);
    });

    it('should find the nearest child without tag ', () => {
      expect(root.findNearestRouteWithoutTag().name).toEqual(navDetails.name);
    });

    it('should be able to find the next child', () => {
      expect(root.next().name).toEqual(navDetails.name);
    });

    it('should be able to return to the parent', () => {
      expect(root.next().prev().name).toEqual(rootDetails.name);
    });

    it('should be able to cancel and return to the ReturnTo', () => {
      expect(root.next().cancel().name).toEqual(rootDetails.name);
    });

    it('should set returnTo', () => {
      expect(root.next().returnTo.name).toEqual(rootDetails.name);
    });

    it('should set a parent properly and preserve the chain', () => {
      expect(root.next().parent.name).toEqual(rootDetails.name);
      expect(root.next().next().parent.name).toEqual(fooRoute.name);
    });
  });
});
