import { HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { LoggerFactory } from '@espresso/core';
import * as log4javascript from 'log4javascript';

import { BaseHttpClient, ROLE, UserIdentityService, WorkflowRecallService } from '@myadp/common';
import { CodeListItem, DeductionsDTO } from '@myadp/dto';
import { CodeList, CodeListService, Meta, MetaService, RawMetaObject } from '@myadp/forms';
import { PAY_SFFO } from '@myadp/pay-shared';

import { PayrollWorkerProfileService } from '../../../services/payroll-worker-profile.service';
import { WorkflowUI } from '../../shared/models/workflow-ui.model';
import { PayDeductionsStoreSlice, PayDeductionsUI } from '../models/pay-deductions-ui';
import {
  transformDeductions,
  transformToDTO,
  transformToStopDTO
} from '../transforms/deductions.transform';
import { PayDeductionsStore } from './pay-deductions.store';

@Injectable({
  providedIn: 'root'
})
export class PayDeductionsStoreActions {
  private logger: log4javascript.Logger;

  constructor(
    private metaService: MetaService,
    private loggerFactory: LoggerFactory,
    private baseHttpClient: BaseHttpClient,
    private codeListService: CodeListService,
    private payDeductionsStore: PayDeductionsStore,
    private userIdentityService: UserIdentityService,
    private workflowRecallService: WorkflowRecallService,
    private payrollWorkerProfileService: PayrollWorkerProfileService
  ) {
    this.logger = this.loggerFactory.getLogger(
      'myadp.pay.pay-deductions-shared.PayDeductionsStoreActions'
    );
  }

  public updateDeductions(deductions: PayDeductionsUI.Deduction[]): void {
    this.payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS, {
      data: deductions
    });
  }

  public loadDeductions(): void {
    this.payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS, {
      loading: true,
      error: null
    });

    this.userIdentityService.getAoid().then(() => {
      this.baseHttpClient
        .get<DeductionsDTO.WfResponse>({
        userPermission: PAY_SFFO.DEDUCTIONS_READ_PERMISSION,
        useWorkflow: true
      })
        .then((res: DeductionsDTO.WfResponse) => {
          if (res) {
            const deductions = transformDeductions(res);
            this.payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS_INITIAL, {
              data: deductions
            });
            this.payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS, {
              data: deductions
            });
          }
        })
        .catch((error: HttpErrorResponse) => {
          this.payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS, {
            error: {
              deductionsError: true
            }
          });
          this.logger.error(`loadDeductions() error: ${error.message}`);
        })
        .finally(() =>
          this.payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS, {
            loading: false
          })
        );
    });
  }

  public loadStartMeta(): void {
    const hasStartMetaCached = this.payDeductionsStore.hasPayDeductionsStartMeta;

    if (!hasStartMetaCached) {
      this.payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS_META, {
        loading: true,
        error: null
      });

      this.getStartMeta()
        .then(async (r: RawMetaObject) => {
          if (r) {
            return this.processStartMeta(r).then(async (rawMeta) => {
              this.payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS_META, {
                data: {
                  rawStartMeta: rawMeta as RawMetaObject
                }
              });

              await this.getCodeListItems(rawMeta as RawMetaObject);
            });
          }
        })
        .catch((error: HttpErrorResponse) => {
          this.payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS_META, {
            error: {
              startMetaError: true
            }
          });
          this.logger.error(`loadStartMeta() error: ${error.message}`);
        })
        .finally(() =>
          this.payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS_META, {
            loading: false
          })
        );
    }
  }

  public loadCodeList(rawStartMeta?: RawMetaObject, bustCache: boolean = false): void {
    const startMeta =
      rawStartMeta ??
      this.payDeductionsStore.getData(PayDeductionsStoreSlice.PAY_DEDUCTIONS_META, 'rawStartMeta');

    if (startMeta) {
      // codeList is cached in CodeListService
      this.getCodeListItems(startMeta, bustCache)
        .catch((error: HttpErrorResponse) => {
          this.payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS_META, {
            error: {
              startMetaError: true
            }
          });
          this.logger.error(`loadCodeList() error: ${error.message}`);
        })
        .finally(() =>
          this.payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS_META, {
            loading: false
          })
        );
    }
  }

  /* Load meta specific for a deduction by codeValue */
  public loadDeductionMeta(codeValue: string, isEdit: boolean = false): void {
    this.payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS_META, {
      loading: true,
      error: null
    });

    this.getDeductionFormMeta(codeValue, isEdit)
      .then((res: RawMetaObject) => {
        const metaKey = !isEdit ? 'addFormMeta' : 'editFormMeta';

        if (!res) {
          // handles HTTP 204 responses
          throw new Error('No deduction meta in response');
        } else {
          this.payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS_META, {
            data: {
              [metaKey]: {
                [codeValue]: res
              }
            }
          });
        }
      })
      .catch((error: HttpErrorResponse) => {
        this.payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS_META, {
          error: {
            deductionMetaError: true
          }
        });
        this.logger.error(`loadDeductionMeta() error: ${error.message}`);
      })
      .finally(() =>
        this.payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS_META, {
          loading: false
        })
      );
  }

  public processStartMeta(startMeta: RawMetaObject): Promise<RawMetaObject | [string, string]> {
    // looks like we would need to intercept this step and call getRaw() and decode /reset the codeList href property here
    // since we need to pass aoid / paygroup query params that aren't handled in
    // meta form groups / forms module when the codelist href is encoded
    const codeListItem: CodeList = this.extractCodeList(startMeta) ?? {};
    let href = codeListItem?.links[0]?.href;

    if (href) {
      href = href.slice(0, href.indexOf('?'));

      return Promise.all([this.userIdentityService.getAoid(), this.getPayrollGroupCode()]).then(
        ([aoid, payGroup]) => {
          // updated via object reference ✨
          codeListItem.links[0].href = href.concat(`?aoid=${aoid}&paygroup=${payGroup}`);
          return startMeta;
        }
      );
    }
  }

  public async postDeduction(
    deduction: PayDeductionsUI.DeductionDetails,
    changeType: WorkflowUI.ChangeType
  ): Promise<void> {
    this.payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS, {
      loading: true,
      error: null
    });

    return this.userIdentityService
      .getAoid()
      .then(async (aoid) => {
        const isEdit = changeType === 'edit';
        const payload: DeductionsDTO.GeneralDeductionInstructionPostDTO = transformToDTO(
          { deduction, aoid },
          isEdit
        );

        const permission = !isEdit
          ? PAY_SFFO.DEDUCTIONS_START_PERMISSION
          : PAY_SFFO.DEDUCTIONS_CHANGE_PERMISSION;

        return this.baseHttpClient.post<void>({
          userPermission: permission,
          payload: payload,
          useWorkflow: true
        });
      })
      .catch((error) => {
        this.payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS, {
          error: {
            postError: true
          }
        });
        this.logger.error('postDeduction() error: ', error);
        return Promise.reject();
      })
      .finally(() =>
        this.payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS, {
          loading: false
        })
      );
  }

  public stopDeduction(deduction: PayDeductionsUI.DeductionDetails): Promise<void> {
    this.payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS, {
      loading: true,
      error: null
    });

    return this.getStopMeta()
      .then(async (stopMeta) => {
        return this.userIdentityService.getAoid().then(async (aoid) => {
          const hasNestedItemID = stopMeta.has(
            '/workerGeneralDeductionInstruction/generalDeductionInstruction/itemID'
          );
          const payload: DeductionsDTO.GeneralDeductionInstructionStopDTO = transformToStopDTO(
            {
              deduction,
              aoid
            },
            hasNestedItemID
          );

          return this.baseHttpClient.post<void>({
            userPermission: PAY_SFFO.DEDUCTIONS_STOP_PERMISSION,
            payload,
            useWorkflow: true
          });
        });
      })
      .catch((error) => {
        this.payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS, {
          error: {
            stopError: true
          }
        });
        this.logger.error('stopDeduction() error: ', error);
        return Promise.reject();
      })
      .finally(() =>
        this.payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS, {
          loading: false
        })
      );
  }

  public recallDeduction(recalledDeduction: PayDeductionsUI.Deduction): void {
    const event: string = {
      add: 'GENERAL_DEDUCTIONS_START',
      edit: 'GENERAL_DEDUCTIONS_CHANGE',
      delete: 'GENERAL_DEDUCTIONS_STOP'
    }[recalledDeduction.pendingEvent.changeType];

    this.userIdentityService
      .getAoid()
      .then(async (aoid) => {
        this.payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS, {
          error: null
        });

        return this.workflowRecallService.recallEvent(aoid, event).then(() => {
          const deductions = this.payDeductionsStore.payDeductionsSnapshot;
          const canceledPendingDeduction: PayDeductionsUI.Deduction = {
            ...recalledDeduction,
            pendingData: null,
            pendingEvent: null
          };
          const updatedDeductions: PayDeductionsUI.Deduction[] = deductions.map((deduction) =>
            (deduction?.pendingData ?? deduction?.currentData)?.itemID ===
            (recalledDeduction?.pendingData ?? recalledDeduction?.currentData)?.itemID
              ? canceledPendingDeduction
              : deduction
          );

          this.payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS, {
            data: updatedDeductions
          });

          this.loadDeductions();
          this.loadCodeList(undefined, true);
        });
      })
      .catch(() => {
        this.payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS, {
          loading: false,
          error: { recallError: true }
        });
        return Promise.resolve();
      });
  }

  public revertToInitialDeductions(): void {
    this.payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS, {
      loading: false,
      data: this.payDeductionsStore.payDeductionsInitialSnapshot,
      error: null
    });
    this.payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS_META, {
      loading: false,
      error: null
    });
  }

  private async getStartMeta(): Promise<RawMetaObject> {
    return this.metaService.getRaw(PAY_SFFO.DEDUCTIONS_START_PERMISSION, undefined);
  }

  private async getCodeListItems(
    startMeta: RawMetaObject,
    bustCache: boolean = false
  ): Promise<void> {
    const href: string = this.extractCodeList(startMeta)?.links[0]?.href;

    return this.codeListService
      .getCodeListItems(href, ROLE.EMPLOYEE, bustCache)
      .then((codeListItems: CodeListItem[]) => {
        this.payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS_META, {
          data: {
            maxDeductionsReached: (codeListItems?.length ?? 0) === 0
          }
        });
      });
  }

  private extractCodeList(startMeta: RawMetaObject): CodeList {
    return startMeta?.meta?.['/data/transforms']?.[0]?.[
      '/workerGeneralDeductionInstruction/generalDeductionInstruction/deductionCode'
    ]?.codeList;
  }

  private async getDeductionFormMeta(
    deductionCodeValue: string,
    isEdit: boolean
  ): Promise<RawMetaObject> {
    const aoid = await this.userIdentityService.getAoid();
    const payrollGroupCode = await this.getPayrollGroupCode();
    const urlTransform = (url: string) => {
      const finalUrl = url.indexOf('meta') !== -1 ? `${url}` : `${url}/meta`;
      return `${finalUrl}?associateOID=${aoid}&payrollGroupCode=${payrollGroupCode}&deductionCode=${deductionCodeValue}`;
    };

    return this.metaService.getRaw(
      !isEdit ? PAY_SFFO.DEDUCTIONS_START_PERMISSION : PAY_SFFO.DEDUCTIONS_CHANGE_PERMISSION,
      urlTransform
    );
  }

  private async getStopMeta(): Promise<Meta> {
    return this.metaService.get(PAY_SFFO.DEDUCTIONS_STOP_PERMISSION);
  }

  private async getPayrollGroupCode(): Promise<string> {
    return (
      await this.payrollWorkerProfileService.getWorker().catch(() => {
        this.payDeductionsStore.update(PayDeductionsStoreSlice.PAY_DEDUCTIONS_META, {
          error: { payrollGroupCodeError: true }
        });
        return Promise.reject();
      })
    )?.workAssignments?.[0]?.payrollGroupCode;
  }
}
