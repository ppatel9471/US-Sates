import { cloneDeep } from 'lodash';

import { PayStatementsDTO } from '@myadp/dto';

import { PayStatementsUI } from '../models/pay-statement-ui';
import {
  MOCK_PAY_STATEMENT_DETAILS_RESPONSE,
  MOCK_TRANSFORMED_PAY_STATEMENT_DETAILS_RESPONSE
} from '../../../../../../src/spec-helpers/pay/pay-statement/pay-statement-details';
import { buildCategory } from './take-home.transform';
import { TAKE_HOME_ID } from '../constants/deduction-category-metadata.const';

describe('buildCategory', () => {
  let takeHomeCategory: PayStatementsUI.DeductionsCategory;

  beforeEach(() => {
    takeHomeCategory = undefined;
  });

  it('should transform Take Home', () => {
    takeHomeCategory = buildCategory(
      TAKE_HOME_ID,
      MOCK_PAY_STATEMENT_DETAILS_RESPONSE.payStatement
    );

    expect(takeHomeCategory).toEqual(
      MOCK_TRANSFORMED_PAY_STATEMENT_DETAILS_RESPONSE.deductionsCategories[6]
    );
  });

  it('should transform Take Home when payDistributions is not an array', () => {
    const mockPayDistributions: PayStatementsDTO.PayDistribution = {
      itemID: 1,
      distributions: [
        {
          itemID: 1,
          paymentMethodCode: {
            codeValue: 'directDeposit',
            shortName: 'Direct Deposit'
          },
          distributionAmount: {
            amountValue: 75,
            currencyCode: 'USD'
          },
          depositAccount: {
            financialParty: {
              routingTransitID: '1117005058'
            },
            financialAccount: {
              accountNumber: '2293',
              typeCode: {
                codeValue: 'Checking',
                shortName: 'Checking'
              }
            }
          }
        }
      ]
    };
    const mockPayStatement = cloneDeep(MOCK_PAY_STATEMENT_DETAILS_RESPONSE);
    mockPayStatement.payStatement.payDistributions = mockPayDistributions;
    takeHomeCategory = buildCategory(
      TAKE_HOME_ID,
      mockPayStatement.payStatement
    );

    expect(takeHomeCategory).toEqual({
      id: 'takeHome',
      name: 'myadp-pay.PAY_TAKE_HOME',
      amount: { amountValue: 771.95, currencyCode: 'USD' },
      deductions: [
        {
          name: 'Checking (2293)',
          amount: { amountValue: 75, currencyCode: 'USD' }
        }
      ],
      displayConfig:
        MOCK_TRANSFORMED_PAY_STATEMENT_DETAILS_RESPONSE.deductionsCategories[6].displayConfig
    });
  });
});
