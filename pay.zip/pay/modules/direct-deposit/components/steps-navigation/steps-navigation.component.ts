import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { ProgressProperties } from '../../models/steps-navigation-helper.model';

import { StepsStore, StepsStoreActions } from '../../store/steps/steps.store';

@Component({
  selector: 'dd-steps-navigation',
  templateUrl: './steps-navigation.component.html',
  styleUrls: ['./steps-navigation.component.scss', '../shared/direct-deposit.scss']
})
export class StepsNavigationComponent implements OnInit {
  public prevStepProps: Observable<ProgressProperties>;
  public cancelStepProps: Observable<ProgressProperties>;
  public nextStepProps: Observable<ProgressProperties>;
  public isSubmitStep$: Observable<boolean>;
  public cancelConfirm: boolean = false;

  constructor(private stepsStore: StepsStore, private stepsStoreActions: StepsStoreActions) {}

  public prev(): void {
    this.stepsStoreActions.prevStep();
  }

  public cancel(): void {
    if (this.stepsStoreActions.hasAccountChanges()) {
      this.cancelConfirm = true;
    } else {
      this.stepsStoreActions.cancelStep();
    }
  }

  public confirmCancel(): void {
    this.cancelConfirm = false;
    this.stepsStoreActions.cancelStep();
  }

  public next(): void {
    if (!this.stepsStore.stepsStoreData.isSubmitStep) {
      this.stepsStoreActions.nextStep();
    } else {
      this.stepsStoreActions
        .submit()
        .then(() => this.stepsStoreActions.nextStep())
        .catch(() => undefined);
    }
  }

  public async ngOnInit(): Promise<void> {
    this.prevStepProps = this.stepsStore.getPrevOrNextProperties$('prev');
    this.nextStepProps = this.stepsStore.getPrevOrNextProperties$('next');
    this.cancelStepProps = this.stepsStore.getPrevOrNextProperties$('cancel');
    this.isSubmitStep$ = this.stepsStore.isSubmitStep$;
  }
}
