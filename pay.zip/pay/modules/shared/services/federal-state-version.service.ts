import { Injectable } from '@angular/core';

import { MyAdpToggles, SORS, UserProfileService } from '@myadp/common';

import { getState, StateModel } from '../../../models/states.model';
import { StepsService } from '../../tax-withholding-management/shared/services/steps.service';

type DeprecatedMap = Record<
string,
{
  sors: string[]; // if SOR is on this list, they get old form
  stateModel: StateModel;
  featureToggle: keyof MyAdpToggles | null;
}
>;

@Injectable({
  providedIn: 'root'
})
export class FederalStateVersionService {
  private deprecatedMap: DeprecatedMap = {
    Ohio: {
      sors: [SORS.US.GLOBAL_VIEW],
      stateModel: getState('OH2020'),
      featureToggle: null
    },
    Pennsylvania: {
      sors: [SORS.US.GLOBAL_VIEW, SORS.US.PRWC],
      stateModel: getState('PA2020'),
      featureToggle: 'payPA2021'
    },
    Nebraska: {
      sors: [], // all SORs get old form
      stateModel: getState('NE2019'),
      featureToggle: 'payNE2022'
    }
  };

  private readonly fedStatesSorAllowlist = [
    SORS.US.GLOBAL_VIEW,
    SORS.US.LIFION,
    SORS.US.RUN,
    SORS.US.VANTAGE
  ];
  private federalStatesMap: DeprecatedMap = {
    'New Mexico': {
      sors: this.fedStatesSorAllowlist,
      stateModel: getState('NM2019'),
      featureToggle: null
    },
    'North Dakota': {
      sors: this.fedStatesSorAllowlist,
      stateModel: getState('ND2019'),
      featureToggle: null
    },
    Utah: {
      sors: this.fedStatesSorAllowlist,
      stateModel: getState('UT2019'),
      featureToggle: null
    }
  };

  constructor(
    private userProfileService: UserProfileService,
    private stepsService: StepsService,
    private myAdpToggles: MyAdpToggles
  ) {}

  public getYearState(state: string): StateModel {
    if (state === 'Colorado') {
      return this.getColoradoWizard();
    }

    const deprecatedMap = this.deprecatedMap?.[state];
    const fedMap = this.federalStatesMap?.[state];
    const latestStateModel = getState(state);

    if (
      deprecatedMap &&
      (this.hasFeaturedForSOR(deprecatedMap.sors) || !deprecatedMap.sors?.length)
    ) {
      if (this.myAdpToggles?.[deprecatedMap?.featureToggle]) {
        return latestStateModel;
      } else {
        return deprecatedMap.stateModel;
      }
    } else if (
      fedMap &&
      this.hasFeaturedForSOR(fedMap.sors) &&
      this.stepsService.isFederalData2019()
    ) {
      return fedMap.stateModel;
    }
    return latestStateModel;
  }

  public getColoradoWizard() {
    const CO2022Whitelist: string[] = [];
    const CO2019Whitelist = this.fedStatesSorAllowlist;
    if (this.hasFeaturedForSOR(CO2022Whitelist) || this.myAdpToggles.payCO2022) {
      return getState('CO2022');
    } else if (this.hasFeaturedForSOR(CO2019Whitelist) && this.stepsService.isFederalData2019()) {
      return getState('CO2019');
    }
    return getState('CO');
  }

  private hasFeaturedForSOR(sors: Array<string>): boolean {
    return this.userProfileService.hasFeaturedForSOR('MobileESSTaxWithholding', sors);
  }
}
