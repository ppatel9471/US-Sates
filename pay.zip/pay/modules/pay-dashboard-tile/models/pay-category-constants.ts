import { Amount } from '@myadp/dto';

export interface DeductionCategoryItem {
  key?: string;
  color?: string;
  value?: number;
  formatted?: string;
  amount?: Amount;
}

// Colors approved by SynerG UX as accessible for charts
export const PAY_CATEGORY_CONSTANTS: Record<string, DeductionCategoryItem> = {
  disabled: {
    key: '',
    color: '#949494',
    amount: {
      amountValue: 1
    }
  },
  deductions: {
    key: 'myadp-pay.PAY_DEDUCTIONS',
    color: '#949494'
  },
  takeHome: {
    key: 'myadp-pay.PAY_TAKE_HOME',
    color: '#22aa22'
  }
};
