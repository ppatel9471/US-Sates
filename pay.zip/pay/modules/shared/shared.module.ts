import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CoreModule as SynergCoreModule } from '@synerg/angular-components';
import { AlertModule } from '@synerg/components/alert';
import { BusyIndicatorModule } from '@synerg/components/busy-indicator';
import { ButtonModule } from '@synerg/components/button';
import { CheckboxModule } from '@synerg/components/checkbox';
import { FormGroupModule } from '@synerg/components/form-group';
import { ModalModule } from '@synerg/components/modal';
import { PaginatorModule } from '@synerg/components/paginator';
import { PopoverModule } from '@synerg/components/popover';
import { SlideinModule } from '@synerg/components/slidein';
import { SnackbarModule } from '@synerg/components/snackbar';

import { MyAdpCommonModule } from '@myadp/common';
import { TaskModule } from '@myadp/thingstodo-shared';

import { AddButtonComponent } from './components/add-button/add-button.component';
import { CloseConfirmComponent } from './components/close-confirm/close-confirm.component';
import { CurrencyFormatComponent } from './components/currency-format/currency-format.component';
import { DeductionDetailsComparisonComponent } from './components/deduction-details-comparison/deduction-details-comparison.component';
import { DeductionDetailsComponent } from './components/deduction-details-comparison/deduction-details/deduction-details.component';
import { DirectDepositDetailsComparisonComponent } from './components/direct-deposit-details-comparison/direct-deposit-details-comparison.component';
import { DirectDepositDetailsComponent } from './components/direct-deposit-details-comparison/direct-deposit-details/direct-deposit-details.component';
import { NumberFormatComponent } from './components/number-format/number-format.component';
import { PayTermsAndConditionsComponent } from './components/pay-terms-conditions/pay-terms-conditions.component';
import { PdfViewerSlideinComponent } from './components/pdf-viewer-slidein/pdf-viewer-slidein.component';
import { PdfViewerStatementDetailComponent } from './components/pdf-viewer-slidein/pdf-viewer-statement-detail/pdf-viewer-statement-detail.component';
import { TaxWithholdingSummaryDetailsComponent } from './components/tax-withholding-summary/details/tax-withholding-summary-details.component';
import { TaxWithholdingSummaryItemComponent } from './components/tax-withholding-summary/item/tax-withholding-summary-item.component';
import { TextFormatComponent } from './components/text-format/text-format.component';
import { WizardDoneStepComponent } from './components/wizard-done-step/wizard-done-step.component';
import { WorkflowComparisonContainerComponent } from './components/workflow-comparison-container/workflow-comparison-container.component';
import { WorkflowDetailsComparisonComponent } from './components/workflow-details-comparison/workflow-details-comparison.component';
import { DownloadPdfDirective } from './directives/download-pdf.directive';
import { ExternalLinkComponent } from './external-link/external-link.component';
import { HelpTooltipComponent } from './help-tooltip/help-tooltip.component';
import { HasWorkflowChangesPipe } from './pipes/has-workflow-changes/has-workflow-changes.pipe';

@NgModule({
  imports: [
    CommonModule,
    MyAdpCommonModule,
    AlertModule,
    FormsModule,
    ButtonModule,
    CheckboxModule,
    PopoverModule,
    BusyIndicatorModule,
    SlideinModule,
    SnackbarModule,
    ModalModule,
    TaskModule,
    PaginatorModule,
    FormGroupModule,
    ReactiveFormsModule,
    SynergCoreModule
  ],
  declarations: [
    ExternalLinkComponent,
    HelpTooltipComponent,
    TaxWithholdingSummaryDetailsComponent,
    TaxWithholdingSummaryItemComponent,
    DownloadPdfDirective,
    CurrencyFormatComponent,
    NumberFormatComponent,
    TextFormatComponent,
    PdfViewerSlideinComponent,
    PdfViewerStatementDetailComponent,
    CloseConfirmComponent,
    PayTermsAndConditionsComponent,
    DirectDepositDetailsComparisonComponent,
    DirectDepositDetailsComponent,
    HasWorkflowChangesPipe,
    AddButtonComponent,
    WorkflowDetailsComparisonComponent,
    DeductionDetailsComparisonComponent,
    DeductionDetailsComponent,
    WorkflowComparisonContainerComponent,
    WizardDoneStepComponent
  ],
  exports: [
    ExternalLinkComponent,
    HelpTooltipComponent,
    TaxWithholdingSummaryDetailsComponent,
    DownloadPdfDirective,
    CurrencyFormatComponent,
    NumberFormatComponent,
    TextFormatComponent,
    PdfViewerSlideinComponent,
    PdfViewerStatementDetailComponent,
    CloseConfirmComponent,
    PayTermsAndConditionsComponent,
    DirectDepositDetailsComparisonComponent,
    HasWorkflowChangesPipe,
    AddButtonComponent,
    DeductionDetailsComparisonComponent,
    WorkflowComparisonContainerComponent,
    WizardDoneStepComponent
  ]
})
export class SharedModule {}
