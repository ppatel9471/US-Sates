import { cloneDeep } from 'lodash';

import { TAKE_HOME_ID } from '../constants/deduction-category-metadata.const';
import { PayStatementsUI } from '../models/pay-statement-ui';
import {
  MOCK_PAY_STATEMENT_DETAILS_RESPONSE,
  MOCK_TRANSFORMED_PAY_STATEMENT_DETAILS_RESPONSE
} from '../../../../../../src/spec-helpers/pay/pay-statement/pay-statement-details';
import {
  transformDeductionsCategories
} from './deduction-category.transform';

describe('transformDeductionsCategories', () => {
  let deductionCategoryDetails: PayStatementsUI.DeductionsCategory[];

  beforeEach(() => {
    deductionCategoryDetails = undefined;
  });

  it('should transform deduction categories', () => {
    deductionCategoryDetails = transformDeductionsCategories(
      MOCK_PAY_STATEMENT_DETAILS_RESPONSE.payStatement
    );

    expect(deductionCategoryDetails).toEqual(
      MOCK_TRANSFORMED_PAY_STATEMENT_DETAILS_RESPONSE.deductionsCategories
    );
  });

  it('should default to Deductions as the category if deductionCategoryDetails is missing', () => {
    const mockResponse = cloneDeep(MOCK_PAY_STATEMENT_DETAILS_RESPONSE);
    mockResponse.payStatement.deductionCategoryDetails = [];
    mockResponse.payStatement.deductions = [
      {
        codeName: 'ST Income Tax',
        deductionCategoryCodeName: '',
        deductionYTDAmount: { amountValue: 421.93, currencyCode: 'USD' },
        deductionAmount: { amountValue: 30.0, currencyCode: 'USD' }
      },
      {
        codeName: null,
        deductionCategoryCodeName: '',
        deductionYTDAmount: { amountValue: 421.93, currencyCode: 'USD' },
        deductionAmount: { amountValue: 30.0, currencyCode: 'USD' }
      }
    ];

    deductionCategoryDetails = transformDeductionsCategories(mockResponse.payStatement);
    const expectedDeductionCategoryDetails = [
      {
        id: 'deductions',
        name: 'myadp-pay.PAY_DEDUCTIONS',
        amount: { amountValue: 60.0, currencyCode: 'USD' },
        amountYTD: { amountValue: 843.86, currencyCode: 'USD' },
        deductions: [
          {
            name: 'ST Income Tax',
            amount: { amountValue: 30.0, currencyCode: 'USD' },
            amountYTD: { amountValue: 421.93, currencyCode: 'USD' },
            preTax: undefined
          },
          {
            name: null,
            amount: { amountValue: 30.0, currencyCode: 'USD' },
            amountYTD: { amountValue: 421.93, currencyCode: 'USD' },
            preTax: undefined
          }
        ],
        displayConfig: {
          rank: 2,
          color: '#e70b5b',
          calculatorLink: undefined
        }
      },
      MOCK_TRANSFORMED_PAY_STATEMENT_DETAILS_RESPONSE.deductionsCategories[5],
      MOCK_TRANSFORMED_PAY_STATEMENT_DETAILS_RESPONSE.deductionsCategories[6]
    ];
    expect(deductionCategoryDetails).toEqual(expectedDeductionCategoryDetails);
  });

  it('should have Take Home as the last category', () => {
    deductionCategoryDetails = transformDeductionsCategories(
      MOCK_PAY_STATEMENT_DETAILS_RESPONSE.payStatement
    );
    expect(deductionCategoryDetails[deductionCategoryDetails.length - 1].id).toBe(TAKE_HOME_ID);
  });
});
