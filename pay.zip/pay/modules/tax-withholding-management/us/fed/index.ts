import { FedIntroComponent } from './steps/intro/fed-intro.component';
import { FedNonresidentAlienComponent } from './steps/nonresident-alien/fed-nonresident-alien.component';
import { FedOtherAdjustmentsComponent } from './steps/other-adjustments/fed-other-adjustments.component';
import { FedMultipleJobsComponent } from './steps/multiple-jobs/fed-multiple-jobs.component';
import { FedTaxCreditsComponent } from './steps/tax-credits/fed-tax-credits.component';
import { FedExemptionComponent } from './steps/exemption/fed-exemption.component';

export { FedTWChangeEventService } from './services/fed-tw-change-event.service';
export { FedSummaryMetaDataService } from './services/fed-summary-meta-data.service';
export { FedStepNavigationService } from './services/fed-step-navigation.service';
export { FedDoneMetaDataService } from './services/done-meta-data.service';

export const FED_COMPONENTS = [
  FedIntroComponent,
  FedNonresidentAlienComponent,
  FedExemptionComponent,
  FedMultipleJobsComponent,
  FedTaxCreditsComponent,
  FedOtherAdjustmentsComponent
];

export { FEDSTEP_COMPONENT } from './models/steps-component.model';

export { FedAttachmentCodes } from './models/fed-tw-change-event';
