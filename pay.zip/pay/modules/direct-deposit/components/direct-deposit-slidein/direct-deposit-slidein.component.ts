import { Component, EventEmitter, HostBinding, Input, OnInit, Output } from '@angular/core';
import { slideinAnimation } from '@synerg/components/slidein';
import { combineLatest, Observable } from 'rxjs';
import { skipWhile, take, tap } from 'rxjs/operators';

import { StoreState } from '@myadp/pay-shared';

import { PayDistributionStore } from '../../../pay-distributions-shared/store/pay-distribution.store';
import { DirectDepositStore, DirectDepositStoreState } from '../../store/direct-deposit.store';
import { StepsState, StepsStore, StepsStoreActions } from '../../store/steps/steps.store';

@Component({
  selector: 'direct-deposit-slidein',
  templateUrl: './direct-deposit-slidein.component.html',
  animations: [slideinAnimation],
  styleUrls: ['./direct-deposit-slidein.component.scss']
})
export class DirectDepositSlideinComponent implements OnInit {
  @Input() nonPayDashboardView: boolean = true;
  @HostBinding('@slideinTransition') slideinTransition = 'slidein';
  @Output() closed: EventEmitter<void> = new EventEmitter<void>();
  @Output() error: EventEmitter<boolean> = new EventEmitter<boolean>();
  public show: boolean = false;
  public unmaskError: boolean = false;
  public state$: Observable<StoreState<DirectDepositStoreState>>;
  public stepsStore$: Observable<StepsState>;
  public showConfirmCancelModal: boolean = false;
  public showFooter$: Observable<boolean>;
  public stepName$: Observable<string>;

  constructor(
    private stepsStore: StepsStore,
    private stepsStoreActions: StepsStoreActions,
    private directDepositStore: DirectDepositStore,
    private payDistributionStore: PayDistributionStore
  ) {}

  public ngOnInit(): void {
    this.showFooter$ = this.stepsStore.showStepNavigation$;
    this.state$ = this.directDepositStore?.state$;
    this.stepsStore$ = this.stepsStore.stepsStore$;
    this.stepName$ = this.stepsStore.stepName$;
    this.openSlidein();

    this.stepsStore.isSlideinOpenObs$
      .pipe(
        skipWhile((open) => open),
        take(1)
      )
      .subscribe(() => this.closed.emit());
  }

  public openSlidein(): void {
    this.unmaskError = false;

    if (this.nonPayDashboardView) {
      this.stepsStore.isSlideinOpen$.next(true);
      // First GET happens here for non pay dashboard features
      this.stepsStoreActions.loadAccounts({ getMeta: true });
    } else if (this.payDistributionStore.hasPayDistributions && !this.directDepositStore.isAvsddm) {
      // request for unmasked account/routing number
      this.stepsStoreActions.loadAccounts();
    }

    combineLatest([
      this.payDistributionStore.hasDistributionError$,
      this.payDistributionStore.isPayDistributionsLoading$
    ])
      .pipe(
        skipWhile(([, isLoading]: [boolean, boolean]) => isLoading),
        take(1),
        tap(([hasError]) => {
          if (hasError) {
            // when we want to show an error on the slidein
            if (this.nonPayDashboardView) {
              this.unmaskError = hasError;
              this.show = true;
            } else {
              // when we want to show the error on the dashboard tile
              this.error.emit(hasError);
            }
          } else {
            this.show = true;
          }
        })
      )
      .subscribe();
  }

  public closeSlidein(): void {
    if (this.stepsStoreActions.hasAccountChanges()) {
      this.showConfirmCancelModal = true;
    } else {
      this.handleSlideinClose();
    }
  }

  public confirmClose(): void {
    this.showConfirmCancelModal = false;
    this.handleSlideinClose();
  }

  private handleSlideinClose(): void {
    this.stepsStoreActions.closeSlidein();
    this.stepsStoreActions.resetCurrentStep();
  }
}
