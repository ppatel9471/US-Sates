import { SnackbarTotalComponent } from './components/snackbar/snackbar-total.component';
import { SnackbarComponent } from './components/snackbar/snackbar.component';
import { AdditionalReducedWithholdingComponent } from './steps/additional-reduced-withholding/additional-reduced-withholding.component';
import { AdditionalWithholdingComponent } from './steps/additional-withholding/additional-withholding.component';
import { AllowancesSnackbarComponent } from './steps/allowances-snackbar/allowances-snackbar.component';
import { DoneComponent } from './steps/done/done.component';
import { ElectronicSignatureComponent } from './steps/electronic-signature/electronic-signature.component';
import { IntroComponent } from './steps/intro/intro.component';
import { MetaSummaryItemComponent } from './steps/meta-summary/meta-summary-item/meta-summary-item.component';
import { MetaSummaryComponent } from './steps/meta-summary/meta-summary.component';
import { PersonalInfoPhoneNumberComponent } from './steps/personal-info-phone-number/personal-info-phone-number.component';
import { PersonalInfoComponent } from './steps/personal-info/personal-info.component';
import { PreviewComponent } from './steps/preview/preview.component';
import { WizardButtonsComponent } from './steps/wizard-buttons/wizard-buttons.component';
import { WizardContainerComponent } from './steps/wizard-container/wizard-container.component';
import { WizardLayoutComponent } from './steps/wizard-layout/wizard-layout.component';
import { WizardProgressBarComponent } from './steps/wizard-progress-bar/wizard-progress-bar.component';

export const SHARED_COMPONENTS = [
  DoneComponent,
  PreviewComponent,
  PersonalInfoComponent,
  PersonalInfoPhoneNumberComponent,
  ElectronicSignatureComponent,
  WizardButtonsComponent,
  IntroComponent,
  WizardLayoutComponent,
  WizardContainerComponent,
  WizardProgressBarComponent,
  SnackbarComponent,
  SnackbarTotalComponent,
  AllowancesSnackbarComponent,
  AdditionalWithholdingComponent,
  MetaSummaryItemComponent,
  MetaSummaryComponent,
  AdditionalReducedWithholdingComponent
];
