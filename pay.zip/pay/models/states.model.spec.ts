import { FEDERAL, getState, StateModel, StateOptionModel, STATES, StateUtil } from './states.model';

const alabama: StateModel = { shortName: 'AL', longName: 'Alabama', countryCode: 'US' };
const alabamaOption: StateOptionModel = { value: 'AL', label: 'Alabama' };
const dc: StateModel = { shortName: 'DC', longName: 'District of Columbia', countryCode: 'US' };
const delaware: StateModel = { shortName: 'DE', longName: 'Delaware', countryCode: 'US' };
const delawareOption: StateOptionModel = { value: 'DE', label: 'Delaware' };
const ohio2020: StateModel = { shortName: 'OH2020', longName: 'Ohio', countryCode: 'US', deprecated: true, iconCode: 'OH' };
const ohio2020Option: StateOptionModel = { value: 'OH2020', label: 'Ohio' };
const puertoRico: StateModel = { shortName: 'PR', longName: 'Puerto Rico', countryCode: 'US' };
const puertoRicoOption: StateOptionModel = { value: 'PR', label: 'Puerto Rico' };
const guam: StateModel = { shortName: 'GU', longName: 'Guam', countryCode: 'US' };
const guamOption: StateOptionModel = { value: 'GU', label: 'Guam' };
const stateUtil = new StateUtil();

describe('States Model: getState', () => {
  it('should return a state', () => {
    expect(getState('AL')).toEqual(alabama);
    expect(getState('Alabama')).toEqual(alabama);

    expect(getState('DC')).toEqual(dc);
    expect(getState('District of Columbia')).toEqual(dc);
    expect(getState('District Of Columbia')).toEqual(dc);

    expect(getState('FEDERAL')).toEqual(FEDERAL);
    expect(getState('Federal')).toEqual(FEDERAL);

    expect(getState(undefined)).toEqual(undefined);
  });

  it('should return a territory', () => {
    const territory: StateModel = getState('PR');
    expect(territory).toEqual(puertoRico);
  });

  it('should return a deprecated state model for Ohio', () => {
    const deprecatedState: StateModel = getState('OH2020');
    expect(deprecatedState).toEqual(ohio2020);
  });
});

describe('StateUtil:', () => {
  it('should return true when state is federal', async () => {
    expect(StateUtil.isFederal(FEDERAL.shortName)).toBe(true);
  });

  it('should return false when state is not federal', async () => {
    STATES.forEach((state) => expect(StateUtil.isFederal(state.shortName)).toBe(false));
  });

  it('should return a list of all states', () => {
    const states: StateOptionModel[] = stateUtil.getStates();
    expect(states.length).toEqual(51);
  });

  it('should return an options list that excludes the state of AL', () => {
    let states: StateOptionModel[] = stateUtil.getStates();
    states = stateUtil.removeStatesOrTerritories(['AL'], states);
    expect(states).not.toContain(alabamaOption);
    expect(states.length).toEqual(50);
  });

  it('should return an options list that excludes the state of AL and DE', () => {
    let states: StateOptionModel[] = stateUtil.getStates();
    states = stateUtil.removeStatesOrTerritories(['AL', 'DE'], states);
    expect(states).not.toContain(alabamaOption);
    expect(states).not.toContain(delawareOption);
    expect(states.length).toEqual(49);
  });

  it('should return an options list that excludes deprecated state model of OH2020 and GA', () => {
    let states: StateOptionModel[] = stateUtil.getStates();
    states = stateUtil.removeStatesOrTerritories(['AL'], states);
    expect(states).not.toContain(alabamaOption);
    expect(states).not.toContain(ohio2020Option);
    expect(states.length).toEqual(50);
  });

  it('should return an options list that excludes the Territories of PR and GU', () => {
    let states: StateOptionModel[] = [...stateUtil.getStates(), ...stateUtil.getTerritories()];
    states = stateUtil.removeStatesOrTerritories(['PR', 'GU'], states);
    expect(states).not.toContain(puertoRicoOption);
    expect(states).not.toContain(guamOption);
    expect(states.length).toEqual(54);
  });

  it('should return a state', () => {
    const state = stateUtil.getState('DE');
    expect(state).toEqual(delaware);
  });

  it('should return a territory', () => {
    const territory = stateUtil.getState('GU');
    expect(territory).toEqual(guam);
  });

  it('should return a deprecated state model', () => {
    const state = stateUtil.getState('OH2020');
    expect(state).toEqual(ohio2020);
  });
});
