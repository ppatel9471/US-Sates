import { IaIntroComponent } from './steps/intro/ia-intro.component';
import { IaMaritalStatusComponent } from './steps/marital-status/ia-marital-status.component';
import { IaAllowancesComponent } from './steps/allowances/ia-allowances.component';
import { IaExemptionComponent } from './steps/exemption/ia-exemption.component';

export { IaTWChangeEventService } from './services/ia-tw-change-event.service';
export { IaStepNavigationService } from './services/ia-step-navigation.service';
export { IaSummaryMetaDataService } from './services/ia-summary-meta-data.service';

export const IA_COMPONENTS = [
  IaIntroComponent,
  IaMaritalStatusComponent,
  IaExemptionComponent,
  IaAllowancesComponent
];

export { IASTEP_COMPONENT } from './models/steps-component.model';

export { IaAttachmentCodes } from './models/ia-tw-change-event';
