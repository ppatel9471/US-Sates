import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

import { DownloadPdfService } from './download-pdf.service';

describe('DownloadPdfService', () => {
  let service: DownloadPdfService;
  let httpMock: HttpTestingController;
  const payStatementUri = '/l2/v1_0/O/A/payStatement/1/images/1.pdf';

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [DownloadPdfService]
    });
    service = TestBed.inject(DownloadPdfService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  it('should get PDF', (done: DoneFn) => {
    const mockArrayBuffer = new ArrayBuffer(8);

    service.getPdf(payStatementUri).subscribe((res: ArrayBuffer) => {
      expect(res).toEqual(mockArrayBuffer);
      done();
    });
    const req = httpMock.expectOne(payStatementUri);
    expect(req.request.method).toBe('GET');
    req.flush(mockArrayBuffer);
  });
});
