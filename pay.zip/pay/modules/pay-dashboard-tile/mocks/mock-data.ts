export const MOCK_PAY_STATEMENTS_RESPONSE = {
  payStatements: [
    {
      payDate: '2020-02-06',
      netPayAmount: {
        amountValue: 1009.35,
        currencyCode: 'USD'
      },
      grossPayAmount: {
        amountValue: 1732.1,
        currencyCode: 'USD'
      },
      totalHours: 80,
      payDetailUri: {
        href: '/v1_0/O/A/payStatement/1074162520066377000198001637962'
      },
      statementImageUri: {
        href: '/l2/v1_0/O/A/payStatement/1074162520066377000198001637962/images/CERooo008000600000r701F570CF93F521.pdf'
      },
      payAdjustmentIndicator: false
    }
  ]
};

export const MOCK_DONUT_CONFIG = [
  {
    key: 'myadp-pay.PAY_DEDUCTIONS',
    color: '#949494',
    amount: {
      amountValue: 400,
      currencyCode: 'USD'
    }
  },
  {
    key: 'myadp-pay.PAY_TAKE_HOME',
    color: '#22aa22',
    amount: {
      amountValue: 600,
      currencyCode: 'USD'
    }
  }
];

export const MOCK_DONUT_CONFIG_FORMATTED = [
  {
    key: 'myadp-pay.PAY_DEDUCTIONS',
    color: '#949494',
    value: 400,
    formatted: '$400.00',
    amount: {
      amountValue: 400,
      currencyCode: 'USD'
    }
  },
  {
    key: 'myadp-pay.PAY_TAKE_HOME',
    color: '#22aa22',
    value: 600,
    formatted: '$600.00',
    amount: {
      amountValue: 600,
      currencyCode: 'USD'
    }
  }
];
