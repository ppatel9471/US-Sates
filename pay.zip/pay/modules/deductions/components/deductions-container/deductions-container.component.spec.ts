import { Shallow } from 'shallow-render';
import { Mock } from 'ts-mockery';

import { DeductionsModule } from '../../deductions.module';
import { StepsStoreActions } from '../../store/steps/steps.store';
import { DeductionsContainerComponent } from './deductions-container.component';

describe('DeductionsContainerComponent', () => {
  let shallow: Shallow<DeductionsContainerComponent>;

  beforeEach(() => {
    shallow = new Shallow(DeductionsContainerComponent, DeductionsModule).mock(StepsStoreActions, {
      init: () => Mock.noop()
    });
  });

  it('should call to init steps store', async () => {
    const { find, get } = await shallow.render();
    const stepsStoreActions = get(StepsStoreActions);

    expect(find('vded-steps-navigation')).toHaveFound(0);
    expect(stepsStoreActions.init).toHaveBeenCalled();
  });

  it('should show navigation if not in tile mode', async () => {
    const { find } = await shallow.render({
      bind: {
        tileMode: false
      }
    });

    expect(find('vded-steps-navigation')).toHaveFoundOne();
  });
});
