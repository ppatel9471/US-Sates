import { fakeAsync, TestBed } from '@angular/core/testing';
import { NativeResourceService } from '@espresso/core';
import { Mock } from 'ts-mockery';

import { FindSffoService, PAY_SFFO } from '@myadp/pay-shared';

import {
  MOCK_DONUT_CONFIG,
  MOCK_PAY_STATEMENTS_RESPONSE
} from '../mocks/mock-data';
import { PayDashboardTileMobileService } from './pay-dashboard-tile-mobile.service';

describe('PayDashboardMobilesService', () => {
  const sffo = {
    sffo: { sffo: PAY_SFFO.PAY_STATEMENTS_READ.sffo },
    href: 'foo'
  };

  let nativeResourceService: NativeResourceService;
  let payService: PayDashboardTileMobileService;
  let findSffoService: FindSffoService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        PayDashboardTileMobileService,
        FindSffoService,
        {
          provide: FindSffoService,
          useValue: Mock.of<FindSffoService>({
            findSffo: () => sffo
          })
        },
        { provide: NativeResourceService, useValue: Mock.of<NativeResourceService>() }
      ]
    });

    nativeResourceService = TestBed.inject(NativeResourceService);
    payService = TestBed.inject(PayDashboardTileMobileService);
    findSffoService = TestBed.inject(FindSffoService);
  });

  describe('getPayStatements', () => {
    it('should get pay statements', fakeAsync(() => {
      Mock.extend(nativeResourceService).with({
        makeRestCall: () => Promise.resolve(mockMakeRestCall(MOCK_PAY_STATEMENTS_RESPONSE))
      });

      payService.getPayStatements().then((response) => {
        expect(response).toEqual(MOCK_PAY_STATEMENTS_RESPONSE);
      });
    }));

    it('should return false if response does not contain body', fakeAsync(() => {
      Mock.extend(nativeResourceService).with({
        makeRestCall: () => Promise.resolve({})
      });

      payService.getPayStatements().then((response) => {
        expect(response).toBeFalsy();
      });
    }));

    it('should return error if href not found', fakeAsync(() => {
      Mock.extend(findSffoService).with({
        findSffo: () => {
          return {
            sffo: undefined,
            href: undefined
          };
        }
      });

      payService.getPayStatements().catch((error) => {
        expect(error).toEqual('Pay Permission or URL not found!');
      });
    }));
  });

  describe('getPayDonutData', () => {
    it('should build pay donutConfig', () => {
      const gross = {
        amountValue: 1000,
        currencyCode: 'USD'
      };
      const net = {
        amountValue: 600,
        currencyCode: 'USD'
      };
      const donutConfig = payService.getPayDonutData(gross, net);
      expect(donutConfig).toEqual(MOCK_DONUT_CONFIG);
    });
  });
});

function mockMakeRestCall(mockData: object) {
  return {
    RESTResponse: {
      status: 200,
      method: 'GET',
      body: JSON.stringify(mockData)
    }
  };
}
