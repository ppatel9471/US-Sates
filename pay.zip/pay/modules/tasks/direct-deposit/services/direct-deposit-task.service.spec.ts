import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Mock } from 'ts-mockery';

import {
  MessageCenterNotificationDto,
  Notification,
  NOTIFICATION_CODE_TYPES,
  NOTIFICATION_LABEL_TYPES
} from '@myadp/thingstodo-shared';
import { PayTasksDetails } from '@myadp/dto';

import { PayTasksService } from '../../shared/services/pay-tasks.service';
import { DirectDepositTaskService } from './direct-deposit-tasks.service';
import { DirectDepositDetails } from '../models/direct-deposit-details';
import {
  DIRECT_DEPOSIT_EVENT_TYPE,
  DirectDepositComparisonData
} from '../models/direct-deposit-tasks-details.model';

describe('DirectDepositTaskService', () => {
  let directDepositTaskService: DirectDepositTaskService;

  const mockNotification: Partial<Notification> = {
    uri: '/v1_0/O/A/notification/2218056821/Task'
  };
  const mockTask: { [key: string]: Partial<MessageCenterNotificationDto> } = {
    notification: {
      actions: [
        {
          labelName: 'Approve',
          uris: [
            {
              href: '/core/v1/notification/1234/approval/approve'
            }
          ]
        }
      ],
      relatedAssociateRef: {
        formattedName: 'myName',
        associateOID: 'myAoid'
      },
      eventNameCode: 'worker.payDistribution.change'
    }
  };

  const mockTaskDetail: PayTasksDetails = {
    currentData: {
      payDistributions: [
        {
          distributionInstructions: [
            {
              accountType: '101',
              paymentMethodCode: { codeValue: 'DD', longName: 'Direct Deposit' },
              depositAccount: {
                financialParty: { routingTransitID: { idValue: '122105278' } },
                financialAccount: {
                  accountNumber: '0000000001',
                  typeCode: { codeValue: '101', longName: 'DED1' },
                  currencyCode: 'USD'
                }
              },
              distributionAmount: { amountValue: 200, currencyCode: 'USD' },
              remainingBalanceIndicator: false
            }
          ]
        }
      ]
    },
    pendingData: {
      payDistributions: [
        {
          distributionInstructions: [
            {
              precedenceCode: { codeValue: '101', longName: 'DED1' },
              depositAccount: {
                BBAN: '0000000001',
                financialParty: { routingTransitID: { schemeCode: { codeValue: '122105278' } } }
              },
              distributionAmount: { amountValue: 20, currencyCode: 'USD' },
              distributionPercentage: undefined,
              remainingBalanceIndicator: false,
              accountType: '101'
            }
          ]
        }
      ]
    },
    pendingEvents: []
  };

  let mockPayTasksService: PayTasksService;

  beforeEach(() => {
    mockPayTasksService = Mock.of<PayTasksService>({
      getTaskData: () => Promise.resolve(mockTask),
      getTaskDetail: () => Promise.resolve(mockTaskDetail),
      getTaskId: () => '1234'
    });

    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        DirectDepositTaskService,
        {
          provide: PayTasksService,
          useValue: mockPayTasksService
        }
      ]
    });

    directDepositTaskService = TestBed.inject(DirectDepositTaskService);
  });

  it('should get getDirectDepositDetails for a task', (done: DoneFn) => {
    mockNotification.notificationType = {
      code: NOTIFICATION_CODE_TYPES.TASK,
      labelName: NOTIFICATION_LABEL_TYPES.TASK
    };

    directDepositTaskService
      .getDirectDepositDetails(<Notification>mockNotification)
      .then((res: DirectDepositDetails) => {
        const directDepositDetails: DirectDepositComparisonData[] = [
          {
            accountType: { codeValue: '101', longName: 'DED1' },
            currentData: {
              routingNumber: '122105278',
              accountNumber: '0000000001',
              accountType: { codeValue: '101', longName: 'DED1' },
              distributionAmount: { amountValue: 200, currencyCode: 'USD' },
              remainingBalanceIndicator: false,
              distributionPercentage: undefined,
              totalAccount: 1,
              isPayCard: false
            },
            pendingData: {
              routingNumber: '122105278',
              accountNumber: '0000000001',
              accountType: { codeValue: '101', longName: 'DED1' },
              distributionAmount: { amountValue: 20, currencyCode: 'USD' },
              remainingBalanceIndicator: false,
              totalAccount: 1,
              isPayCard: false
            },
            type: DIRECT_DEPOSIT_EVENT_TYPE.CHANGE,
            comparisonData: {
              distributionAmount: { amountValue: 20, currencyCode: 'USD' },
              totalAccount: 1
            }
          }
        ];
        expect(res.comparisonData).toEqual(directDepositDetails); //
        expect(mockPayTasksService.getTaskData).toHaveBeenCalled();
        expect(mockPayTasksService.getTaskId).toHaveBeenCalled();
        expect(mockPayTasksService.getTaskDetail).toHaveBeenCalledWith(
          '/wf/payroll/v2/workers/myAoid/pay-distributions?taskId=1234'
        );
        done();
      });
  });

  it('should get getDirectDepositDetails for a notification', (done: DoneFn) => {
    mockNotification.notificationType = {
      code: NOTIFICATION_CODE_TYPES.NOTIFICATION,
      labelName: NOTIFICATION_LABEL_TYPES.NOTIFICATION
    };
    mockNotification.relatedAssociateRef = {
      name: 'myName',
      aoid: 'myAoid'
    };
    mockNotification.notificationId = '123456';

    directDepositTaskService
      .getDirectDepositDetails(<Notification>mockNotification)
      .then((res: DirectDepositDetails) => {
        const directDepositDetails: DirectDepositComparisonData[] = [
          {
            accountType: { codeValue: '101', longName: 'DED1' },
            currentData: {
              routingNumber: '122105278',
              accountNumber: '0000000001',
              accountType: { codeValue: '101', longName: 'DED1' },
              distributionAmount: { amountValue: 200, currencyCode: 'USD' },
              remainingBalanceIndicator: false,
              distributionPercentage: undefined,
              totalAccount: 1,
              isPayCard: false
            },
            pendingData: {
              routingNumber: '122105278',
              accountNumber: '0000000001',
              accountType: { codeValue: '101', longName: 'DED1' },
              distributionAmount: { amountValue: 20, currencyCode: 'USD' },
              remainingBalanceIndicator: false,
              totalAccount: 1,
              isPayCard: false
            },
            type: DIRECT_DEPOSIT_EVENT_TYPE.CHANGE,
            comparisonData: {
              distributionAmount: { amountValue: 20, currencyCode: 'USD' },
              totalAccount: 1
            }
          }
        ];
        expect(res.comparisonData).toEqual(directDepositDetails); //
        expect(mockPayTasksService.getTaskData).not.toHaveBeenCalled();
        expect(mockPayTasksService.getTaskId).not.toHaveBeenCalled();
        expect(mockPayTasksService.getTaskDetail).toHaveBeenCalledWith(
          '/wf/payroll/v2/workers/myAoid/pay-distributions?notificationId=123456'
        );
        done();
      });
  });
});
