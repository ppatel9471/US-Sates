import {
  HttpClientTestingModule,
  HttpTestingController,
  TestRequest
} from '@angular/common/http/testing';
import { TestBed, fakeAsync, flush, tick } from '@angular/core/testing';
import { LoggerFactory } from '@espresso/core';
import { Mock } from 'ts-mockery';

import { BaseHttpClient, LanguageService, UserIdentityService, MyAdpToggles } from '@myadp/common';
import { PayDistributionsDTO } from '@myadp/dto';
import { FindSffoService } from '@myadp/pay-shared';
import { MockLoggerFactory } from '@specHelpers';
import {
  MOCK_PAY_DISTRIBUTIONS_RESPONSE,
  MOCK_TRANSFORMED_PAY_DISTRIBUTIONS
} from '@specHelpers/pay/pay-distributions/pay-distributions';
import { MOCK_PAY_DISTRIBUTIONS_META_RESPONSE } from '@specHelpers/pay/pay-distributions/pay-distributions-meta';

import { WorkerInfoStoreActions } from '../../worker-info-shared/store/worker-info-store.actions';
import { PayDistributionsStoreSlice, PayDistributionsUI } from '../models/pay-distributions-ui';
import { PayDistributionStore } from './pay-distribution.store';
import { CODE_LIST_URI, PayDistributionStoreActions } from './pay-distribution.store.actions';
import { COUNTRY, COUNTRY_CONFIG } from '../models/country';

const sffo = {
  sffo: {
    sffo: [
      'payrollManagement',
      'payrollInstructionManagement',
      'payDistributionManagement',
      'payDistribution.read'
    ]
  },
  href: 'foo'
};

const transformedDistributions = MOCK_TRANSFORMED_PAY_DISTRIBUTIONS;

const transformedDistributionsMeta: PayDistributionsUI.PayDistributionMeta = {
  maxAccounts: 4,
  minAccounts: 0,
  termsAgreementMsg: 'terms message',
  showDistributionPercentage: true,
  canValidateBankInfo: true,
  forceRemaining: {
    enabled: true,
    msg: 'force remaining balance msg'
  },
  distributionAmount: {
    min: 0
  },
  accountName: {
    enabled: true,
    maxLength: 30
  },
  accountTypeList: null,
  codeListHref:
    '/codelists/payroll/v3/payroll-instruction-management/directdepositdeductioncodevalues?$filter=paygroup eq %27foo%27',
  isEmailConfigured: true,
  paymentMethodCodes: {
    codeList: [{ shortName: 'DailyPay', codeValue: 'DP2' }],
    readOnly: false
  }
};

const codeListItems = [
  {
    codeValue: 'C',
    shortName: 'Checking',
    longName: 'Checking'
  },
  {
    codeValue: 'S',
    shortName: 'Savings',
    longName: 'Savings'
  }
];

const MOCK_META_CODELIST: PayDistributionsDTO.MetaResponse = {
  meta: {
    '/data/transforms': [
      {
        '/payDistribution/distributionInstructions/depositAccount/financialAccount/typeCode': {
          codeList: {
            links: [
              {
                href: '/codelists/payroll/v3/payroll-instruction-management/directdepositdeductioncodevalues?$filter=paygroup eq %27foo%27'
              }
            ],
            listItems: codeListItems
          }
        }
      }
    ]
  }
};

describe('PayDistributionStoreActions', () => {
  let httpMock: HttpTestingController;
  let payDistributionStore: PayDistributionStore;
  let payDistributionStoreActions: PayDistributionStoreActions;
  let findSffoService: FindSffoService;
  let workerInfoStoreActions: WorkerInfoStoreActions;
  let baseHttpClient: BaseHttpClient;
  let myAdpToggles: MyAdpToggles;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        PayDistributionStoreActions,
        PayDistributionStore,
        {
          provide: BaseHttpClient,
          useValue: Mock.of<BaseHttpClient>({
            post: () => Promise.resolve()
          })
        },
        {
          provide: FindSffoService,
          useValue: Mock.of<FindSffoService>({
            findSffo: () => sffo
          })
        },
        {
          provide: UserIdentityService,
          useValue: Mock.of<UserIdentityService>({
            getAoid: () => Promise.resolve('G3VRPKH833J5E630')
          })
        },
        {
          provide: MyAdpToggles,
          useValue: Mock.of<MyAdpToggles>({
            canadianDirectDeposit: false
          })
        },
        {
          provide: LanguageService,
          useValue: Mock.of<LanguageService>({ get: (key) => key })
        },
        {
          provide: WorkerInfoStoreActions,
          useValue: Mock.of<WorkerInfoStoreActions>({
            getEffectiveDate: () => Promise.resolve('2018-01-12'),
            getPayrollGroupCode: () => Promise.resolve('baz')
          })
        },
        { provide: LoggerFactory, useClass: MockLoggerFactory }
      ]
    });

    httpMock = TestBed.inject(HttpTestingController);
    payDistributionStore = TestBed.inject(PayDistributionStore);
    payDistributionStoreActions = TestBed.inject(PayDistributionStoreActions);
    findSffoService = TestBed.inject(FindSffoService);
    workerInfoStoreActions = TestBed.inject(WorkerInfoStoreActions);
    baseHttpClient = TestBed.inject(BaseHttpClient);
    myAdpToggles = TestBed.inject(MyAdpToggles);
  });

  afterEach(() => {
    httpMock.verify();
  });

  async function makeHttpRequest({
    methodName = 'loadDistributions',
    expectNone = false,
    matchUrl = '/wffoo?effectiveDate=2018-01-12',
    getMeta = false,
    mockData = MOCK_PAY_DISTRIBUTIONS_RESPONSE,
    headers = {
      'adp-context-expressionid': 'country=US'
    },
    status = { status: 200, statusText: 'Ok' },
    error = false
  }: {
    methodName?: string;
    expectNone?: boolean;
    matchUrl?: string;
    getMeta?: boolean;
    mockData?: any | null;
    headers?: any;
    status?: any;
    error?: boolean;
  } = {}): Promise<TestRequest> {
    let req;

    // https://github.com/angular/angular/issues/25965
    // Send the request
    payDistributionStoreActions[methodName](getMeta);

    if (expectNone) {
      httpMock.expectNone(matchUrl);
    } else {
      // Wait for the request to arrive
      const INTERVAL = 100; // ms
      while ((httpMock as any).open.length === 0) {
        await new Promise((resolve) => setTimeout(resolve, INTERVAL));
      }

      // Receive and confirm the request
      req = httpMock.expectOne(matchUrl);

      // Send the response
      if (error) {
        req.error(null, { status: 500, statusText: 'ServerError' });
      } else {
        req.flush(mockData, { headers, ...status });
      }
    }

    return req;
  }

  describe('loadDistributions()', () => {
    it('should make an API call to get pay distributions and update the store', async () => {
      const req = await makeHttpRequest();

      expect(workerInfoStoreActions.getEffectiveDate).toHaveBeenCalledTimes(1);
      expect(req.request.method).toEqual('GET');
      expect(req.request.headers.get('Accept')).toEqual('application/json; masked=true');
      expect(req.request.headers.get('roleCode')).toEqual('employee');
      expect(req.request.params.get('effectiveDate')).toEqual('2018-01-12');

      expect(payDistributionStore.stateValue).toEqual({
        [PayDistributionsStoreSlice.PAY_DISTRIBUTIONS]: {
          data: {
            distributions: transformedDistributions,
            itemID: null,
            hasChangePermission: false,
            country: { shortName: COUNTRY.US, currencyCode: 'USD' }
          },
          loading: false,
          error: null
        },
        [PayDistributionsStoreSlice.PAY_DISTRIBUTIONS_META]: {
          data: {
            meta: null
          },
          loading: false,
          error: {}
        }
      });
    });

    it('should set country context to Canada and transform data', async () => {
      Mock.extend(myAdpToggles).with({
        canadianDirectDeposit: true
      });

      const req = await makeHttpRequest({ headers: { 'adp-context-expressionid': 'country=CA' } });

      expect(workerInfoStoreActions.getEffectiveDate).toHaveBeenCalledTimes(1);
      expect(req.request.method).toEqual('GET');
      expect(req.request.headers.get('Accept')).toEqual('application/json; masked=true');
      expect(req.request.params.get('effectiveDate')).toEqual('2018-01-12');

      expect(
        payDistributionStore.stateValue[PayDistributionsStoreSlice.PAY_DISTRIBUTIONS].data.country
      ).toEqual({ shortName: COUNTRY.CA, currencyCode: 'CAD' });
    });

    it('should set country context to Canada when the header is Canadian but there are no distributions', async () => {
      Mock.extend(myAdpToggles).with({
        canadianDirectDeposit: true
      });

      const req = await makeHttpRequest({ headers: { 'adp-context-expressionid': 'country=CA' } });

      expect(workerInfoStoreActions.getEffectiveDate).toHaveBeenCalledTimes(1);
      expect(req.request.method).toEqual('GET');
      expect(req.request.headers.get('Accept')).toEqual('application/json; masked=true');
      expect(req.request.params.get('effectiveDate')).toEqual('2018-01-12');

      expect(
        payDistributionStore.stateValue[PayDistributionsStoreSlice.PAY_DISTRIBUTIONS].data.country
      ).toEqual({ shortName: COUNTRY.CA, currencyCode: 'CAD' });
    });

    it('should set country context to Canada when the header is Canadian but there are no distributions', fakeAsync(async () => {
      Mock.extend(myAdpToggles).with({
        canadianDirectDeposit: true
      });

      makeHttpRequest({ mockData: null, headers: { 'adp-context-expressionid': 'country=CA' } })
        .then()
        .finally(() => {
          expect(workerInfoStoreActions.getEffectiveDate).toHaveBeenCalledTimes(1);
          expect(
            payDistributionStore.stateValue[PayDistributionsStoreSlice.PAY_DISTRIBUTIONS].data.country
          ).toEqual({ shortName: COUNTRY.CA, currencyCode: 'CAD' });
        });

      flush();
    }));

    it('should default country context to USA if header not provided', async () => {
      const req = await makeHttpRequest({ headers: {} });

      expect(workerInfoStoreActions.getEffectiveDate).toHaveBeenCalledTimes(1);
      expect(req.request.method).toEqual('GET');
      expect(req.request.headers.get('Accept')).toEqual('application/json; masked=true');
      expect(req.request.params.get('effectiveDate')).toEqual('2018-01-12');

      expect(payDistributionStore.stateValue).toEqual({
        [PayDistributionsStoreSlice.PAY_DISTRIBUTIONS]: {
          data: {
            distributions: transformedDistributions,
            itemID: null,
            hasChangePermission: false,
            country: { shortName: COUNTRY.US, currencyCode: 'USD' }
          },
          loading: false,
          error: null
        },
        [PayDistributionsStoreSlice.PAY_DISTRIBUTIONS_META]: {
          data: {
            meta: null
          },
          loading: false,
          error: {}
        }
      });
    });

    it('should set itemID in store', async () => {
      await makeHttpRequest({
        mockData: { currentData: { payDistributions: [{ itemID: 'baz' }] } }
      });

      expect(
        payDistributionStore.stateValue[PayDistributionsStoreSlice.PAY_DISTRIBUTIONS].data.itemID
      ).toEqual('baz');
    });

    it('should call loadDistributionsMeta() when getting pay distributions', async () => {
      spyOn(payDistributionStoreActions, 'loadDistributionsMeta').and.callThrough();
      await makeHttpRequest({ matchUrl: 'foo/meta', getMeta: true });

      httpMock.expectOne('/wffoo?effectiveDate=2018-01-12').flush({});

      expect(payDistributionStoreActions.loadDistributionsMeta).toHaveBeenCalled();
    });

    it('should handle errors and updating the store when loading pay distributions', fakeAsync(async () => {
      makeHttpRequest({ error: true })
        .then()
        .finally(() => {
          expect(workerInfoStoreActions.getEffectiveDate).toHaveBeenCalledTimes(1);
          expect(payDistributionStore.stateValue).toEqual({
            [PayDistributionsStoreSlice.PAY_DISTRIBUTIONS]: {
              data: {
                distributions: null,
                itemID: null,
                hasChangePermission: false
              },
              loading: false,
              error: {
                distributionsError: true
              }
            },
            [PayDistributionsStoreSlice.PAY_DISTRIBUTIONS_META]: {
              data: {
                meta: null
              },
              loading: false,
              error: {}
            }
          });
        });

      flush();
    }));

    it('should not make call to get distributions if sffo not found', async () => {
      Mock.extend(findSffoService).with({
        findSffo: () => {
          return {
            sffo: undefined,
            href: undefined
          };
        }
      });

      await makeHttpRequest({ expectNone: true });
      httpMock.expectNone('/wffoo?effectiveDate=2018-01-12');
    });

    it('should not make call to get distributions if sffo found but href is undefined', async () => {
      Mock.extend(findSffoService).with({
        findSffo: () => {
          return {
            sffo: {
              sffo: [
                'payrollManagement',
                'payStatementManagement',
                'payStatementViewing',
                'payStatement.read'
              ]
            },
            href: undefined
          };
        }
      });

      await makeHttpRequest({ expectNone: true });
      httpMock.expectNone('/wffoo?effectiveDate=2018-01-12');

      expect(
        payDistributionStore.stateValue[PayDistributionsStoreSlice.PAY_DISTRIBUTIONS].loading
      ).toBeFalsy();
    });

    describe('loadDistributionsMeta()', () => {
      it('should an make API call to get pay distributions meta and codeList and update the store', fakeAsync(() => {
        payDistributionStoreActions.loadDistributionsMeta();
        payDistributionStoreActions.getPayDistributionsMeta('foo').catch(() => Mock.noop());

        const metaRequest = httpMock.match((req) => req.url === 'foo/meta');
        metaRequest.forEach((req) => req.flush(MOCK_PAY_DISTRIBUTIONS_META_RESPONSE));

        tick();

        httpMock.expectOne(`${CODE_LIST_URI}?$filter=paygroup+eq+'baz'`).flush({});
        expect(metaRequest[0].request.headers.get('roleCode')).toEqual('employee');

        tick();

        expect(findSffoService.findSffo).toHaveBeenCalledTimes(1);
        expect(workerInfoStoreActions.getPayrollGroupCode).toHaveBeenCalledTimes(1);
        expect(payDistributionStore.stateValue).toEqual({
          [PayDistributionsStoreSlice.PAY_DISTRIBUTIONS]: {
            data: {
              distributions: null,
              itemID: null,
              hasChangePermission: true
            },
            loading: false,
            error: {}
          },
          [PayDistributionsStoreSlice.PAY_DISTRIBUTIONS_META]: {
            data: {
              meta: transformedDistributionsMeta
            },
            loading: false,
            error: {}
          }
        });
      }));

      it('should use codeList provided in meta and not make codeList call', async () => {
        makeHttpRequest({
          methodName: 'loadDistributionsMeta',
          matchUrl: 'foo/meta',
          mockData: MOCK_META_CODELIST
        })
          .then()
          .catch()
          .finally(() => {
            expect(workerInfoStoreActions.getPayrollGroupCode).not.toHaveBeenCalled();
            expect(
              payDistributionStore.stateValue[PayDistributionsStoreSlice.PAY_DISTRIBUTIONS_META]
                .data.meta.accountTypeList
            ).toEqual(codeListItems);
            expect(
              payDistributionStore.stateValue[PayDistributionsStoreSlice.PAY_DISTRIBUTIONS_META]
                .loading
            ).toBe(false);
          });
      });

      it('should not set meta in store if meta call fails', fakeAsync(() => {
        payDistributionStoreActions.loadDistributionsMeta();
        payDistributionStoreActions.getPayDistributionsMeta('foo').catch(() => Mock.noop());

        const requests = httpMock.match((req) => req.method === 'GET');
        requests.forEach((req) => req.error(null, { status: 500, statusText: 'ServerError' }));

        tick();

        expect(
          payDistributionStore.stateValue[PayDistributionsStoreSlice.PAY_DISTRIBUTIONS_META]
        ).toEqual({
          data: {
            meta: null
          },
          loading: false,
          error: {
            distributionsMetaError: true
          }
        });
      }));

      it('should return meta from store if already cached', () => {
        payDistributionStore.update(PayDistributionsStoreSlice.PAY_DISTRIBUTIONS_META, {
          data: {
            meta: transformedDistributionsMeta
          }
        });

        payDistributionStoreActions.loadDistributionsMeta();
        expect(findSffoService.findSffo).not.toHaveBeenCalled();

        expect(payDistributionStore.stateValue).toEqual({
          [PayDistributionsStoreSlice.PAY_DISTRIBUTIONS]: {
            data: {
              distributions: null,
              itemID: null,
              hasChangePermission: false
            },
            loading: false,
            error: {}
          },
          [PayDistributionsStoreSlice.PAY_DISTRIBUTIONS_META]: {
            data: {
              meta: transformedDistributionsMeta
            },
            loading: false,
            error: {}
          }
        });
      });
    });

    describe('getCodeList()', () => {
      it('should make codeList call with payrollGroupCode and update store', fakeAsync(() => {
        payDistributionStore.update(PayDistributionsStoreSlice.PAY_DISTRIBUTIONS_META, {
          loading: true
        });

        payDistributionStoreActions.getCodeList();

        tick();

        httpMock
          .expectOne(req =>
            req.urlWithParams === `${CODE_LIST_URI}?$filter=paygroup+eq+'baz'`
            && req.headers.get('roleCode') === 'employee'
          )
          .flush({ codeLists: [{ listItems: codeListItems }] });

        tick();

        expect(workerInfoStoreActions.getPayrollGroupCode).toHaveBeenCalledTimes(1);
        expect(
          payDistributionStore.stateValue[PayDistributionsStoreSlice.PAY_DISTRIBUTIONS_META].data
            .meta.accountTypeList
        ).toEqual(codeListItems);
        expect(
          payDistributionStore.stateValue[PayDistributionsStoreSlice.PAY_DISTRIBUTIONS_META].loading
        ).toBe(false);
      }));

      it('should not make codeList call or update store because worker call failed', fakeAsync(() => {
        Mock.extend(workerInfoStoreActions).with({
          getPayrollGroupCode: () => Promise.reject()
        });

        payDistributionStore.update(PayDistributionsStoreSlice.PAY_DISTRIBUTIONS_META, {
          loading: true
        });

        payDistributionStoreActions.getCodeList();

        tick();

        httpMock.expectNone(`${CODE_LIST_URI}?$filter=paygroup+eq+'baz'`);

        tick();

        expect(
          payDistributionStore.stateValue[PayDistributionsStoreSlice.PAY_DISTRIBUTIONS_META]?.data
            ?.meta?.accountTypeList
        ).toBeUndefined();

        expect(
          payDistributionStore.stateValue[PayDistributionsStoreSlice.PAY_DISTRIBUTIONS_META]
            ?.loading
        ).toBeFalse();
      }));

      it('should not make codeList call or update store because we do not have a payrollGroupCode', fakeAsync(() => {
        Mock.extend(workerInfoStoreActions).with({
          getPayrollGroupCode: () => Promise.resolve({})
        });

        payDistributionStore.update(PayDistributionsStoreSlice.PAY_DISTRIBUTIONS_META, {
          loading: true
        });

        payDistributionStoreActions.getCodeList();

        tick();

        httpMock.expectNone(`${CODE_LIST_URI}?$filter=paygroup+eq+'baz'`);

        tick();

        expect(
          payDistributionStore.stateValue[PayDistributionsStoreSlice.PAY_DISTRIBUTIONS_META]?.data
            ?.meta?.accountTypeList
        ).toBeUndefined();

        expect(
          payDistributionStore.stateValue[PayDistributionsStoreSlice.PAY_DISTRIBUTIONS_META]
            ?.loading
        ).toBeFalse();
      }));

      describe('postDistributions', () => {
        it('should use workflow prefix', fakeAsync(() => {
          const postSpy = baseHttpClient.post as jasmine.Spy;

          payDistributionStore.update(PayDistributionsStoreSlice.PAY_DISTRIBUTIONS, {
            data: {
              hasChangePermission: true,
              distributions: [],
              country: COUNTRY_CONFIG[COUNTRY.US]
            }
          });

          payDistributionStoreActions.postDistributions([]);
          flush();

          expect(postSpy.calls.first().args[0].useWorkflow).toBe(true);
        }));
      });

      describe('getMetaPermission()', () => {
        it('should set hasChangePermission to true', () => {
          Mock.extend(findSffoService).with({
            findSffo: () => {
              return {
                sffo: {
                  sffo: [
                    'payrollManagement',
                    'payrollInstructionManagement',
                    'payDistributionManagement',
                    'worker.payDistribution.change'
                  ]
                },
                href: 'foo'
              };
            }
          });

          payDistributionStoreActions.loadDistributionsMeta();

          httpMock.expectOne('foo/meta').flush({});

          expect(
            payDistributionStore.stateValue[PayDistributionsStoreSlice.PAY_DISTRIBUTIONS].data
              .hasChangePermission
          ).toBeTrue();
        });

        it('should not set hasChangePermission to true', () => {
          Mock.extend(findSffoService).with({
            findSffo: () => {
              return {
                sffo: {
                  sffo: [
                    'payrollManagement',
                    'payrollInstructionManagement',
                    'payDistributionManagement',
                    'worker.payDistribution.change'
                  ]
                },
                href: null
              };
            }
          });

          payDistributionStoreActions.loadDistributionsMeta();

          expect(
            payDistributionStore.stateValue[PayDistributionsStoreSlice.PAY_DISTRIBUTIONS].data
              .hasChangePermission
          ).toBeFalse();
        });
      });

      describe('recallDistributionChanges', () => {
        it('should prefix the url with /wf/recall', () => {
          payDistributionStore.update(PayDistributionsStoreSlice.PAY_DISTRIBUTIONS, {
            data: {
              hasChangePermission: true,
              distributions: [],
              country: COUNTRY_CONFIG[COUNTRY.US]
            }
          });
          const recallSpy = baseHttpClient.post as jasmine.Spy;
          payDistributionStoreActions.recallDistributions();

          expect(
            recallSpy.calls
              .first()
              .args[0].urlTransform('/events/payroll/v1/worker.pay-distribution.change')
          ).toEqual('/wf/recall/events/payroll/v1/worker.pay-distribution.change');
        });
      });
    });
  });
});
