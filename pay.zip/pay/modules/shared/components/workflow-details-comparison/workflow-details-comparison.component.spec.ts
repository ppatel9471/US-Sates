import { Shallow } from 'shallow-render';

import { SharedModule } from '../../shared.module';
import { WorkflowDetailsComparisonComponent } from '../workflow-details-comparison/workflow-details-comparison.component';

type MockDataType = Record<string, any>;
type MockComparisonDetailsType = Record<string, any>;

describe('WorkflowDetailsComparisonComponent', () => {
  let shallow: Shallow<WorkflowDetailsComparisonComponent<MockDataType, MockComparisonDetailsType>>;

  beforeEach(() => {
    shallow = new Shallow<
    WorkflowDetailsComparisonComponent<MockDataType, MockComparisonDetailsType>
    >(WorkflowDetailsComparisonComponent, SharedModule);
  });

  it('should display generic compare details view', async () => {
    const { find } = await shallow.render({
      bind: {
        data: null
      }
    });

    expect(find('.current')).toHaveFound(1);
    expect(find('.pending')).toHaveFound(1);
    expect(find('task-compare-details').componentInstance.statusCodeLabel).toEqual('Pending');
  });
});
