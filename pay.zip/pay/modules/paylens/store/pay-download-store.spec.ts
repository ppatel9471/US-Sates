import { HttpClient } from '@angular/common/http';
import { TestBed } from '@angular/core/testing';
import { ClientDeviceService, LoggerFactory } from '@espresso/core';
import { of, throwError } from 'rxjs';
import { Mock } from 'ts-mockery';

import { UserIdentityService } from '@myadp/common';
import { FindSffoService } from '@myadp/pay-shared';
import { MockLoggerFactory } from '@specHelpers';

import {
  PayStatementsDownloadStore,
  PayStatementsDownloadStoreSlice,
  Statement
} from './pay-download-store';

const sffo = {
  sffo: {
    sffo: [
      'payrollManagement',
      'payStatementManagement',
      'payStatementImageViewing',
      'payStatementImages.download'
    ]
  },
  href: 'url'
};

describe('PayStatementsDownloadStore', () => {
  let payStatementDownloadStore: PayStatementsDownloadStore;
  let httpClient: HttpClient;
  let findSffoService: FindSffoService;
  let userIdentityService: UserIdentityService;
  let clientDeviceService: ClientDeviceService;

  const downloadStatements: Statement[] = [
    { id: 1, statementImageUri: 'foo' },
    { id: 2, statementImageUri: 'baz' }
  ];

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        PayStatementsDownloadStore,
        {
          provide: HttpClient,
          useValue: Mock.of<HttpClient>({
            post: () => of({})
          })
        },
        {
          provide: FindSffoService,
          useValue: Mock.of<FindSffoService>({
            findSffo: () => sffo
          })
        },
        {
          provide: UserIdentityService,
          useValue: Mock.of<UserIdentityService>({
            getAoid: () => Promise.resolve('abc')
          })
        },
        {
          provide: ClientDeviceService,
          useValue: Mock.of<ClientDeviceService>({
            isNative: () => false
          })
        },
        { provide: LoggerFactory, useClass: MockLoggerFactory }
      ]
    });

    payStatementDownloadStore = TestBed.inject(PayStatementsDownloadStore);
    httpClient = TestBed.inject(HttpClient);
    findSffoService = TestBed.inject(FindSffoService);
    userIdentityService = TestBed.inject(UserIdentityService);
    clientDeviceService = TestBed.inject(ClientDeviceService);
  });

  it('should create the store with an initial state', () => {
    expect(payStatementDownloadStore.stateValue).toEqual({
      [PayStatementsDownloadStoreSlice.PAY_STATEMENTS_DOWNLOAD]: {
        data: undefined,
        loading: false,
        error: {}
      }
    });
  });

  describe('canDownload()', () => {
    it('should return true if user has permission', () => {
      expect(payStatementDownloadStore.canDownload()).toBeTruthy();
    });

    it('should return false if user does not have permission', () => {
      Mock.extend(findSffoService).with({
        findSffo: () => {
          return {
            sffo: undefined,
            href: undefined
          };
        }
      });

      expect(payStatementDownloadStore.canDownload()).toBeFalsy();
    });

    // batch download is not supported on the native app
    it('should return false if is native', () => {
      Mock.extend(clientDeviceService).with({
        isNative: () => true
      });

      expect(payStatementDownloadStore.canDownload()).toBeFalsy();
    });
  });

  describe('updateSelected()', () => {
    it('should add statement to download list', () => {
      payStatementDownloadStore.updateSelected(true, downloadStatements[0]);
      expect(
        payStatementDownloadStore.stateValue[
          PayStatementsDownloadStoreSlice.PAY_STATEMENTS_DOWNLOAD
        ].data.statements
      ).toEqual([downloadStatements[0]]);
    });

    it('should add statement to download list', () => {
      // Add
      payStatementDownloadStore.updateSelected(true, downloadStatements[0]);
      payStatementDownloadStore.updateSelected(true, downloadStatements[1]);
      expect(
        payStatementDownloadStore.stateValue[
          PayStatementsDownloadStoreSlice.PAY_STATEMENTS_DOWNLOAD
        ].data.statements
      ).toEqual(downloadStatements);

      // Remove
      payStatementDownloadStore.updateSelected(false, downloadStatements[0]);
      expect(
        payStatementDownloadStore.stateValue[
          PayStatementsDownloadStoreSlice.PAY_STATEMENTS_DOWNLOAD
        ].data.statements
      ).toEqual([downloadStatements[1]]);
    });
  });

  describe('clear()', () => {
    it('should delete all items from store', () => {
      payStatementDownloadStore.updateSelected(true, downloadStatements[0]);

      payStatementDownloadStore.clear();
      expect(
        payStatementDownloadStore.stateValue[
          PayStatementsDownloadStoreSlice.PAY_STATEMENTS_DOWNLOAD
        ].data
      ).toBeNull();
    });
  });

  describe('state slices', () => {
    it('should return statements, loading and errors as individual slices from store', (done: DoneFn) => {
      payStatementDownloadStore.update(PayStatementsDownloadStoreSlice.PAY_STATEMENTS_DOWNLOAD, {
        data: {
          statements: downloadStatements
        },
        loading: false,
        error: {
          downloadError: false
        }
      });

      // statements$
      payStatementDownloadStore.statements$().subscribe((statements) => {
        expect(statements).toEqual(downloadStatements);
      });

      // loading$
      payStatementDownloadStore.loading$().subscribe((loading) => {
        expect(loading).toBe(false);
      });

      // errors$
      payStatementDownloadStore.errors$().subscribe((errors) => {
        expect(errors).toBe(false);
        done();
      });
    });

    it('should return true if there is an error', (done: DoneFn) => {
      payStatementDownloadStore.update(PayStatementsDownloadStoreSlice.PAY_STATEMENTS_DOWNLOAD, {
        error: {
          downloadError: true
        }
      });
      payStatementDownloadStore.errors$().subscribe((errors) => {
        expect(errors).toBe(true);
        done();
      });
    });
  });

  describe('download()', () => {
    it('should make API to download statements', (done: DoneFn) => {
      payStatementDownloadStore.update(PayStatementsDownloadStoreSlice.PAY_STATEMENTS_DOWNLOAD, {
        data: {
          statements: downloadStatements
        },
        loading: false,
        error: {
          downloadError: false
        }
      });

      payStatementDownloadStore.canDownload();
      payStatementDownloadStore.download();

      userIdentityService.getAoid().then((aoid) => {
        expect(httpClient.post).toHaveBeenCalledWith(
          'url',
          {
            events: [
              {
                originator: { associateOID: aoid },
                actor: { associateOID: aoid },
                data: {
                  eventContext: { associateOID: aoid },
                  transform: {
                    eventStatusCode: {
                      codeValue: 'submit'
                    },
                    payStatementImageIDs: ['foo', 'baz']
                  }
                }
              }
            ]
          },
          jasmine.objectContaining({ responseType: 'arraybuffer' })
        );
      });

      done();
    });

    it('should set store downloadError if API call fails', (done: DoneFn) => {
      Mock.extend(httpClient).with({
        post: () => throwError('error')
      });

      payStatementDownloadStore.download().catch(() => {
        expect(
          payStatementDownloadStore.stateValue[
            PayStatementsDownloadStoreSlice.PAY_STATEMENTS_DOWNLOAD
          ].error?.downloadError
        ).toBe(true);
      });
      done();
    });
  });
});
