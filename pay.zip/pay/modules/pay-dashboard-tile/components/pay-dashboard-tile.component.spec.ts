import { CurrencyPipe } from '@angular/common';
import { DebugElement } from '@angular/core';
import { ComponentFixture } from '@angular/core/testing';
import { ClientDeviceService } from '@espresso/core';
import { TileService } from '@synerg/components/tile';
import { cloneDeep } from 'lodash';
import { noop, of } from 'rxjs';
import { Shallow } from 'shallow-render';
import { QueryMatch } from 'shallow-render/dist/lib/models/query-match';
import { Mock } from 'ts-mockery';

import {
  BarbecueService,
  LanguagePipe,
  LanguageService,
  LocationService,
  MaskPipe
} from '@myadp/common';

import {
  MOCK_DONUT_CONFIG,
  MOCK_DONUT_CONFIG_FORMATTED,
  MOCK_PAY_STATEMENTS_RESPONSE
} from '../mocks/mock-data';
import { PayDashboardTileModule } from '../pay-dashboard-tile.module';
import { PayDashboardTileBaseService } from '../services/pay-dashboard-tile-base.service';
import { PayDashboardTileServiceFactory } from '../services/pay-dashboard-tile-service.factory';
import { PayDashboardTileComponent } from './pay-dashboard-tile.component';

describe('PayDashboardTileComponent', () => {
  let shallow: Shallow<PayDashboardTileComponent>;
  let mockPayDashboardTileService: PayDashboardTileBaseService;

  beforeEach(() => {
    mockPayDashboardTileService = Mock.of<PayDashboardTileBaseService>({
      loadPayStatements: () => noop,
      payStatementsIsLoading$: () => of(false),
      payStatements: MOCK_PAY_STATEMENTS_RESPONSE,
      payStatementsError: false,
      getPayDonutConfig: () => ({
        showTooltips: true,
        transparentBackground: true,
        size: 'fill',
        borderWidth: 2
      }),
      getPayDonutData: () => cloneDeep(MOCK_DONUT_CONFIG)
    });

    shallow = new Shallow(PayDashboardTileComponent, PayDashboardTileModule)
      .dontMock(CurrencyPipe)
      .dontMock(MaskPipe)
      .mockPipe(LanguagePipe, (key: string) => key)
      .mock(BarbecueService, {
        isBarbecue: () => false
      })
      .mock(ClientDeviceService, {
        isNative: () => false
      })
      .mock(PayDashboardTileServiceFactory, {
        getPayDashboardTileService: () => mockPayDashboardTileService
      })
      .mock(LanguageService, {
        get: (key) => key
      })
      .mock(LocationService, {
        navigateParam: () => noop,
        navigate: () => noop
      })
      .mock(TileService, {
        setIsLoading: () => noop,
        setHasError: () => noop,
        setCanOpen: () => noop
      });
  });

  it('should show full pay tile', async () => {
    const { find } = await shallow.render();
    const payTile = '#pay-tile-dashboard';

    expect(find(payTile)).toHaveFoundOne();
    expect(find('.pay-tile-date')).toHaveFoundOne();
    expect(find('.pay-tile-hours')).toHaveFoundOne();
    expect(find('.pay-tile-take-home')).toHaveFoundOne();
    expect(find('.pay-tile-gross')).toHaveFoundOne();
    expect(find('adp-donut')).toHaveFoundOne();

    expect(find(payTile).nativeElement.textContent).toContain('paytile.HOURS');
    expect(find(payTile).nativeElement.textContent).toContain('paytile.TAKE_HOME');
    expect(find(payTile).nativeElement.textContent).toContain('paytile.GROSS_PAY');
  });

  it('should format donutConfig with categories', async () => {
    const { instance } = await shallow.render();
    expect(instance.getState().payDonutData).toEqual(MOCK_DONUT_CONFIG_FORMATTED);
  });

  it('should suppress hours when missing', async () => {
    const mockPayStatementMissingData = cloneDeep(MOCK_PAY_STATEMENTS_RESPONSE);
    delete mockPayStatementMissingData.payStatements[0].totalHours;
    Mock.extend(mockPayDashboardTileService).with({
      payStatements: mockPayStatementMissingData
    });

    const { find } = await shallow.render();
    const payTile = '#pay-tile-dashboard';

    expect(find(payTile)).toHaveFoundOne();
    expect(find('.pay-tile-hours')).toHaveFound(0);
    expect(find('.pay-tile-total-hours')).toHaveFound(0);
  });

  it('should suppress date when missing', async () => {
    const mockPayStatementMissingData = cloneDeep(MOCK_PAY_STATEMENTS_RESPONSE);
    delete mockPayStatementMissingData.payStatements[0].payDate;
    Mock.extend(mockPayDashboardTileService).with({
      payStatements: mockPayStatementMissingData
    });

    const { find } = await shallow.render();
    const payTile = '#pay-tile-dashboard';

    expect(find(payTile)).toHaveFoundOne();
    expect(find('.pay-tile-date')).toHaveFound(0);
  });

  it('should show net pay when missing', async () => {
    const mockPayStatementMissingData = cloneDeep(MOCK_PAY_STATEMENTS_RESPONSE);
    delete mockPayStatementMissingData.payStatements[0].netPayAmount;
    Mock.extend(mockPayDashboardTileService).with({
      payStatements: mockPayStatementMissingData
    });

    const { find } = await shallow.render();
    const payTile = '#pay-tile-dashboard';

    expect(find(payTile)).toHaveFoundOne();
    expect(find('.pay-tile-take-home')).toHaveFoundOne();
    expect(find(payTile).nativeElement.textContent).toContain('paytile.TAKE_HOME');
  });

  it('should show gross pay when missing', async () => {
    const mockPayStatementMissingData = cloneDeep(MOCK_PAY_STATEMENTS_RESPONSE);
    delete mockPayStatementMissingData.payStatements[0].grossPayAmount;
    Mock.extend(mockPayDashboardTileService).with({
      payStatements: mockPayStatementMissingData
    });

    const { find } = await shallow.render();
    const payTile = '#pay-tile-dashboard';

    expect(find(payTile)).toHaveFoundOne();
    expect(find('.pay-tile-gross')).toHaveFoundOne();
    expect(find(payTile).nativeElement.textContent).toContain('paytile.GROSS_PAY');
  });

  it('should show error message', async () => {
    const alert = 'adp-alert';
    const { find, instance, fixture } = await shallow.render();
    instance.setState({ hasError: true });
    fixture.detectChanges();

    expect(find(alert)).toHaveFoundOne();
    expect(find(alert).nativeElement.textContent).toContain('common.GENERAL_ERROR');
  });

  it("should show no data message and set notification button if it's not bbq", async () => {
    const message = '.no-data-message';
    const button = '.pay-tile-notification-button';

    const { find, instance, fixture } = await shallow.render();
    instance.setState({ hasNoData: true });
    fixture.detectChanges();

    expect(find(message)).toHaveFoundOne();
    expect(find(message).nativeElement.textContent).toContain('paytile.NO_PAY_DATA_MSG');
    expect(find(message).nativeElement.textContent).toContain(
      'paytile.NO_PAY_DATA_NOTIFICATION_MSG'
    );

    expect(find(button)).toHaveFoundOne();
  });

  it("should only show no data message if it's bbq", async () => {
    const message = '.no-data-message';
    const button = '.pay-tile-notification-button';

    shallow.mock(BarbecueService, {
      isBarbecue: () => true
    });

    const { find, instance, fixture } = await shallow.render();
    instance.setState({ hasNoData: true });
    fixture.detectChanges();

    expect(find(message)).toHaveFoundOne();
    expect(find(message).nativeElement.textContent).toContain('paytile.NO_PAY_DATA_MSG');
    expect(find(message).nativeElement.textContent).not.toContain(
      'paytile.NO_PAY_DATA_NOTIFICATION_MSG'
    );

    expect(find(button)).toHaveFound(0);
  });

  describe('setIsLoading', () => {
    it('should set isLoading flag to true', async () => {
      Mock.extend(mockPayDashboardTileService).with({
        payStatementsIsLoading$: () => of(true)
      });

      const { instance, fixture } = await shallow.render();

      fixture.detectChanges();

      expect(instance.isLoading).toBe(true);
    });

    it('should set isLoading flag to false', async () => {
      const { instance, fixture } = await shallow.render();

      fixture.detectChanges();

      expect(instance.isLoading).toBe(false);
    });
  });

  describe('setNotifications', () => {
    it('should pass correct param for settings page on web', async () => {
      const { find, get, instance, fixture } = await shallow.render();

      shouldCallWithParams(['/settings'], find, get, instance, fixture);
    });

    it('should pass correct param for settings page on native mobile', async () => {
      shallow.mock(ClientDeviceService, {
        isNative: () => true
      });
      const params = [
        '/settings',
        {
          target:
            "?target=mobile-settings&ServeResourceAction.route=mobile-settings&componentRoute='notificationCenter'"
        }
      ];

      const { find, get, instance, fixture } = await shallow.render();
      shouldCallWithParams(params, find, get, instance, fixture);
    });
  });

  it('should mask/unmask currency values', async () => {
    const { find, instance, fixture } = await shallow.render();
    const takeHomeGross = '.pay-tile-amount-container';

    find(takeHomeGross).forEach((elm) => {
      expect(elm.nativeElement.textContent).toContain('XXXX.XX');
    });

    instance.setState({ unmask: true });
    fixture.detectChanges();

    find(takeHomeGross).forEach((elm) => {
      expect(elm.nativeElement.textContent).not.toContain('XXXX.XX');
    });
  });

  it('should unmask currency values by default if unmaskValues input is set to true', async () => {
    const { find, instance, fixture } = await shallow.render({ bind: { unmaskValues: true } });
    const takeHomeGross = '.pay-tile-amount-container';

    find(takeHomeGross).forEach((elm) => {
      expect(elm.nativeElement.textContent).not.toContain('XXXX.XX');
    });

    instance.setState({ unmask: false });
    fixture.detectChanges();

    find(takeHomeGross).forEach((elm) => {
      expect(elm.nativeElement.textContent).toContain('XXXX.XX');
    });
  });

  describe('setNavigation', () => {
    it('should set tile canOpen for navigation', async () => {
      const { get } = await shallow.render();
      const tileService = get(TileService);

      expect(tileService.setCanOpen).toHaveBeenCalledWith(true);
    });
  });

  type Find = (selector: string) => QueryMatch<DebugElement>;

  function shouldCallWithParams(
    params: Array<any>,
    find: Find,
    get: Function,
    instance: PayDashboardTileComponent,
    fixture: ComponentFixture<any>
  ) {
    instance.setState({ hasNoData: true });
    fixture.detectChanges();

    const buttonElement = find('adp-button');
    const locationService = get(LocationService);

    expect(buttonElement).toHaveFoundOne();

    buttonElement.nativeElement.click();
    fixture.detectChanges();

    expect(locationService.navigateParam).toHaveBeenCalledWith(params);
  }
});
