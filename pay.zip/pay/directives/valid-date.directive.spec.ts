import { Component, Input, NgModule, ViewChild } from '@angular/core';
import { Shallow } from 'shallow-render';
import { fakeAsync, tick } from '@angular/core/testing';

import { FormControl, FormsModule, NgForm } from '@angular/forms';
import { ValidDateDirective } from './valid-date.directive';

@NgModule({
  imports: [FormsModule],
  declarations: [ValidDateDirective]
})
class TestModule {}

describe('Directive: ValidDate', () => {
  let shallow: Shallow<ValidDateDirectiveTestComponent>;

  const render = fakeAsync(async () => {
    const rendering = await shallow.render();
    tick();
    rendering.fixture.detectChanges();
    return rendering;
  });

  beforeEach(() => {
    shallow = new Shallow(ValidDateDirectiveTestComponent, TestModule)
      .dontMock(FormsModule)
      .dontMock(ValidDateDirective);
  });

  it('should have error message', async () => {
    const { instance } = await render();
    expect(instance.f.valid).toBeFalsy();
    expect(instance.myControl.control.errors.validDate.message).toContain('VALIDATION_VALID_DATE');
  });

  it('should have valid date', async () => {
    const { instance, find } = await render();
    writeDate(find, '01/01/2019');
    expect(instance.f.valid).toBeTruthy();
    expect(instance.myControl.control.errors).toBe(null);
  });

  it('should be invalid with partial date', async () => {
    const { instance, find } = await render();
    writeDate(find, '01/0');
    expect(instance.f.valid).toBeFalsy();
    expect(instance.myControl.control.errors.validDate.message).toContain('VALIDATION_VALID_DATE');
  });

  it('should be invalid with incorrect number of days', async () => {
    const { instance, find } = await render();
    writeDate(find, '01/32/2010');
    expect(instance.f.valid).toBeFalsy();
    expect(instance.myControl.control.errors.validDate.message).toContain('VALIDATION_VALID_DATE');

    writeDate(find, '02/29/2010');
    expect(instance.f.valid).toBeFalsy();

    writeDate(find, '02/28/2010');
    expect(instance.f.valid).toBeTruthy();
  });

  it('should be invalid with incorrect format (DD/MM/YYYY)', async () => {
    const { instance, find } = await render();
    writeDate(find, '21-01-2010');
    expect(instance.f.valid).toBeFalsy();
    expect(instance.myControl.control.errors.validDate.message).toContain('VALIDATION_VALID_DATE');
  });

  function writeDate(find: Function, date: string) {
    const input = find(`input[name='date']`).nativeElement;
    input.value = date;
    input.dispatchEvent(new Event('input'));
  }
});

@Component({
  template: `
    <form #f="ngForm">
      <input type="text" validDate name="date" [(ngModel)]="date" #myControl="ngModel" />
    </form>
  `
})
class ValidDateDirectiveTestComponent {
  @Input() date = 'asdf';
  @Input() format: string = 'MM/DD/YYYY';
  @ViewChild('f', { static: true }) f: NgForm;
  @ViewChild('myControl', { static: true }) myControl: FormControl;
}
