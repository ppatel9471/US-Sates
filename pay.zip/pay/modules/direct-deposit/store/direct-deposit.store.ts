import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { SORS } from '@myadp/common';
import { BaseStore } from '@myadp/pay-shared';

import { WorkflowUI } from '../../shared/models/workflow-ui.model';
import { AccountDetailsControls } from '../models/account-details-form.model';
import {
  AccountType,
  MiscPermissions,
  ValidationStatus,
  ValidationStatusObj
} from '../models/deposit-account.model';
import { DirectDepositAccount } from '../models/direct-deposit-account.model';
import { FormDetails } from '../models/form-details.model';
import { WiselyTypes } from '../models/wisely.model';

import { CountryDetails, COUNTRY } from '../../pay-distributions-shared/models/country';

export { DirectDepositStoreActions } from './direct-deposit-store.actions';

interface DirectDepositStorePermissions {
  [WiselyTypes.WISELY_DIRECT]: boolean;
  [WiselyTypes.WISELY_PAY]: boolean;
  GIACT: boolean;
  canValidateBankInfo: boolean;
}

export enum DirectDepositStoreSlice {
  DIRECT_DEPOSIT_ACCOUNTS = 'DIRECT_DEPOSIT_ACCOUNTS',
  DIRECT_DEPOSIT_CONFIG = 'DIRECT_DEPOSIT_CONFIG',
  FORM_DETAILS = 'FORM_DETAILS',
  PERMISSIONS = 'PERMISSIONS',
  ACCOUNT_VERIFICATION = 'ACCOUNT_VERIFICATION',
  DIRECT_DEPOSIT_ACCOUNTS_INITIAL = 'DIRECT_DEPOSIT_ACCOUNTS_INITIAL',
  MODIFIED_ACCOUNTS = 'MODIFIED_ACCOUNTS',
  DIRECT_DEPOSIT_COUNTRY = 'DIRECT_DEPOSIT_COUNTRY'
}

export interface DirectDepositStoreState {
  [DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS]?: DirectDepositAccount[];
  [DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS_INITIAL]?: DirectDepositAccount[];
  [DirectDepositStoreSlice.DIRECT_DEPOSIT_CONFIG]?: ProviderConfigState;
  [DirectDepositStoreSlice.FORM_DETAILS]?: FormDetails;
  [DirectDepositStoreSlice.PERMISSIONS]?: DirectDepositStorePermissions;
  [DirectDepositStoreSlice.ACCOUNT_VERIFICATION]?: {
    [key: string]: ValidationStatusObj;
  };
  [DirectDepositStoreSlice.DIRECT_DEPOSIT_COUNTRY]?: CountryDetails;
  [DirectDepositStoreSlice.MODIFIED_ACCOUNTS]?: Record<
  WorkflowUI.ChangeType,
  DirectDepositAccount[]
  >;
}

interface ProviderConfigState {
  sorProvider: string;
}

@Injectable({
  providedIn: 'root'
})
export class DirectDepositStore extends BaseStore<DirectDepositStoreState> {
  constructor() {
    super({
      [DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS]: {
        data: null,
        loading: false,
        error: {}
      },
      [DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS_INITIAL]: {
        data: null
      },
      [DirectDepositStoreSlice.MODIFIED_ACCOUNTS]: {
        data: null
      },
      [DirectDepositStoreSlice.DIRECT_DEPOSIT_CONFIG]: {
        data: undefined,
        loading: false,
        error: {}
      },
      [DirectDepositStoreSlice.FORM_DETAILS]: {
        data: undefined
      },
      [DirectDepositStoreSlice.PERMISSIONS]: {
        data: undefined,
        loading: false,
        error: {}
      },
      [DirectDepositStoreSlice.ACCOUNT_VERIFICATION]: {
        data: undefined,
        loading: false,
        error: {}
      },
      [DirectDepositStoreSlice.DIRECT_DEPOSIT_COUNTRY]: {
        data: null
      }
    });
  }

  public get directDepositAccounts$(): Observable<DirectDepositAccount[]> {
    return this.getData$(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS, undefined, []).pipe(
      map((accounts) => accounts?.filter(this.filterDeleted))
    );
  }

  public getDDAccountsSnapshot(
    { filterDeleted = true }: { filterDeleted?: boolean } = {
      filterDeleted: true
    }
  ): DirectDepositAccount[] {
    const accounts = this.getData(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS, undefined, null);
    return filterDeleted && !!accounts ? accounts.filter(this.filterDeleted) : accounts;
  }

  public get ddAccountsInitialSnapshot(): DirectDepositAccount[] {
    return this.getData(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS_INITIAL, undefined, null);
  }

  public get formDetails(): FormDetails {
    return this.getData(DirectDepositStoreSlice.FORM_DETAILS);
  }

  public get currentWorkingVerificationStatus$(): Observable<ValidationStatus> {
    return this.getData$(
      DirectDepositStoreSlice.FORM_DETAILS,
      AccountDetailsControls.VALIDATION_STATUS,
      null
    );
  }

  public getValidationStatus(routingAccountKey: string): ValidationStatusObj {
    return this.getData(DirectDepositStoreSlice.ACCOUNT_VERIFICATION, routingAccountKey, null);
  }

  public get isLoading$(): Observable<boolean> {
    return this.isSliceLoading$(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS);
  }

  public hasChanges(): boolean {
    const currentSnapShot = this.getDDAccountsSnapshot();
    const initialSnapShot = this.ddAccountsInitialSnapshot;

    return JSON.stringify(currentSnapShot) !== JSON.stringify(initialSnapShot);
  }

  public get allModifications(): Record<WorkflowUI.ChangeType, DirectDepositAccount[]> {
    return this.getData(DirectDepositStoreSlice.MODIFIED_ACCOUNTS, undefined, null);
  }

  public getModifications(typeOfChange: WorkflowUI.ChangeType): DirectDepositAccount[] {
    return this.getData(DirectDepositStoreSlice.MODIFIED_ACCOUNTS, typeOfChange, []);
  }

  // Currently Enterprise (EV5) is the only major SOR that isn't using the compliant schema definitions on the POST
  public get usesNonCompliantSchema(): boolean {
    return this.isEnterprise;
  }

  public get hasStaticAccountTypes(): boolean {
    return this.isRun || this.isAvsddm || this.isPRWC;
  }

  public get isRun(): boolean {
    return this.sorProvider === SORS.US.RUN;
  }

  public get isWFN(): boolean {
    return this.sorProvider === SORS.US.WFN;
  }

  public get isAvsddm(): boolean {
    return this.sorProvider === SORS.US.AVSDDM;
  }

  public get isEnterprise(): boolean {
    return this.sorProvider === SORS.US.ENTERPRISE;
  }

  public get isEnterprisePortal(): boolean {
    return this.sorProvider === SORS.US.ENTERPRISE_PORTAL;
  }

  public get isPRWC(): boolean {
    return this.sorProvider === SORS.US.PRWC;
  }

  public get isCanadian(): boolean {
    return this.isFromCountry(COUNTRY.CA);
  }

  public isFromCountry(countryCode: COUNTRY): boolean {
    return (
      this.getData(DirectDepositStoreSlice.DIRECT_DEPOSIT_COUNTRY, 'shortName') === countryCode
    );
  }

  public get directDepositCountry(): CountryDetails {
    return this.getData(DirectDepositStoreSlice.DIRECT_DEPOSIT_COUNTRY);
  }

  public hasPermission(permission: MiscPermissions): boolean {
    return this.getData(DirectDepositStoreSlice.PERMISSIONS, permission, false);
  }

  public get hasPostError$(): Observable<boolean> {
    return this.hasError$(DirectDepositStoreSlice.DIRECT_DEPOSIT_ACCOUNTS, 'ddAccountsPostError');
  }

  public get sorProvider(): string {
    return this.getData(DirectDepositStoreSlice.DIRECT_DEPOSIT_CONFIG, 'sorProvider');
  }

  public getAvailableAccountTypes(accountTypes: AccountType[]): AccountType[] {
    const existingAccounts = this.getDDAccountsSnapshot().map(
      ({ currentData, pendingData }) => (pendingData ?? currentData)?.codeValueData?.accountCode
    );

    return accountTypes.filter((accountType) => {
      return existingAccounts.indexOf(accountType.value) === -1;
    });
  }

  private filterDeleted({
    currentData = null,
    pendingData = null,
    pendingEvent = null
  }: DirectDepositAccount): boolean {
    return (
      !!currentData || !!pendingData || (!!pendingEvent && pendingEvent?.changeType !== 'pruned')
    );
  }
}
