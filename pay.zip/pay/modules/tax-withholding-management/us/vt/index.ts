import { VtIntroComponent } from './steps/intro/vt-intro.component';
import { VtMaritalStatusComponent } from './steps/marital-status/vt-marital-status.component';
import { VtAllowancesComponent } from './steps/allowances/vt-allowances.component';
import { VtAdditionalWithholdingComponent } from './steps/additional-withholding/vt-additional-withholding.component';
import { VtExemptionComponent } from './steps/exemption/vt-exemption.component';

export { VtTWChangeEventService } from './services/vt-tw-change-event.service';
export { VtStepNavigationService } from './services/vt-step-navigation.service';
export { VtSummaryMetaDataService } from './services/vt-summary-meta-data.service';

export const VT_COMPONENTS = [
  VtIntroComponent,
  VtMaritalStatusComponent,
  VtExemptionComponent,
  VtAllowancesComponent,
  VtAdditionalWithholdingComponent
];

export { VTSTEP_COMPONENT } from './models/steps-component.model';

export { VtAttachmentCodes } from './models/vt-tw-change-event';
