import { CurrencyPipe } from '@angular/common';
import { TestBed } from '@angular/core/testing';
import { LoggerFactory } from '@espresso/core';
import * as moment from 'moment';
import { Mock } from 'ts-mockery';

import { LanguageService } from '@myadp/common';
import { PayPermissionService } from '@myadp/pay-shared';
import { MockLoggerFactory } from '@specHelpers';

import { getState } from '../../../models/states.model';
import { PendingEventType } from '../../../models/tax-withholding.model';
import { UsStateTaxWithholdingElections } from '../../../models/us-state-tax-withholding-election.model';
import { StateWithholdingTransformService } from '../../../modules/shared/services/state-withholding-transform.service';
import { TaxWithholdingStore } from '../../../services/tax-withholding.store';
import { FederalStateVersionService } from '../../shared/services/federal-state-version.service';
import { ValueFormatterService } from '../../shared/services/value-formatter.service';
import { WithholdingFormatterService } from '../../shared/services/withholding-formatter.service';
import { MaritalStatus, MaritalStatus2019 } from '../../tax-withholding-management/us/fed/models/fed-marital-status.enum';
import { FedWizard } from '../../tax-withholding-management/us/fed/models/fed-wizard.model';
import { StateWithholdingHelperService } from './state-withholding-helper.service';

describe('StateWithholdingHelperService', () => {
  let service: StateWithholdingHelperService;
  let mockWithholdingData: UsStateTaxWithholdingElections;
  const mockFederalData: Partial<FedWizard> = {
    nonresidentAlien: { nonresidentAlien: false },
    maritalStatus: { maritalStatus: MaritalStatus.HEAD_OF_HOUSEHOLD }
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        StateWithholdingHelperService,
        StateWithholdingTransformService,
        WithholdingFormatterService,
        ValueFormatterService,
        CurrencyPipe,
        {
          provide: LanguageService,
          useValue: Mock.of<LanguageService>({ get: (key) => key })
        },
        {
          provide: PayPermissionService,
          useValue: Mock.of<PayPermissionService>({
            hasStateTaxWithholdingChangePermission: () => true
          })
        },
        {
          provide: FederalStateVersionService,
          useValue: Mock.of<FederalStateVersionService>({ getYearState: (s) => getState(s) })
        },
        {
          provide: LoggerFactory,
          useClass: MockLoggerFactory
        },
        {
          provide: TaxWithholdingStore,
          useValue: Mock.of<TaxWithholdingStore>({
            getFederalWizard: () => mockFederalData
          })
        }
      ]
    });
  });

  beforeEach(() => {
    service = TestBed.inject(StateWithholdingHelperService);
  });

  describe('is state supported', () => {
    it('should return false if state is invalid or not included in StateModel', () => {
      const isSupported = service.isStateSupported('ABC123');
      expect(isSupported).toBeFalsy();
    });

    it('should return true if state is supported', () => {
      const isSupported = service.isStateSupported('Arizona');
      expect(isSupported).toBeTruthy();
    });
  });

  describe('does state have income tax', () => {
    it('should return false if state has income tax', () => {
      const hasNoIncomeTax = service.isNoIncomeState('Alabama');
      expect(hasNoIncomeTax).toBeFalsy();
    });

    it('should return true if state has no income tax', () => {
      const hasNoIncomeTax = service.isNoIncomeState('Alaska');
      expect(hasNoIncomeTax).toBeTruthy();
    });
  });

  describe('flat rate', () => {
    it('should return false if state has a flat rate', () => {
      const isFlatRateState = service.isFlatRateState('AL');
      expect(isFlatRateState).toBeFalsy();
    });

    it('should return true if state has a flat rate', () => {
      const isFlatRateState = service.isFlatRateState('PA2020');
      expect(isFlatRateState).toBeTruthy();
    });
  });

  describe('withholding model', () => {
    beforeEach(() => {
      mockWithholdingData = {
        usStateTaxWithholdingElections: [
          {
            stateIncomeTaxWithholdingElections: [
              {
                stateCode: { codeValue: 'GA', longName: 'Georgia' },
                taxWithholdingAllowanceQuantity: 1,
                taxFilingStatusCode: {
                  codeValue: 'X',
                  longName: 'Married Filing Jointly or Sep'
                }
              },
              {
                stateCode: { codeValue: 'AL', longName: 'Alabama' },
                taxWithholdingAllowanceQuantity: 1
              },
              {
                stateCode: { codeValue: 'XY', longName: 'XYZ' },
                taxWithholdingAllowanceQuantity: 1
              }
            ],
            workflowData: {
              pendingData: {
                usStateTaxWithholdingElections: [
                  {
                    stateIncomeTaxWithholdingElections: [
                      {
                        stateCode: { codeValue: 'GA', longName: 'Georgia' },
                        taxWithholdingAllowanceQuantity: 2,
                        taxFilingStatusCode: {
                          codeValue: 'X',
                          longName: 'Married Filing Jointly or Sep'
                        }
                      }
                    ]
                  }
                ]
              },
              pendingEvents: {
                eventTypeId: PendingEventType.EMPLOYEE_INITIATED,
                history: [
                  {
                    assignedTo: 'Smith, Bob',
                    actionTaken: 'None',
                    actionDate: 12345,
                    comments: 'comment',
                    processStepID: 6789
                  }
                ]
              }
            }
          }
        ]
      };
    });

    it('should populate current data', () => {
      const withholdingInfo = service.getWithholdingModel(mockWithholdingData);

      expect(withholdingInfo.hasElections).toBeTruthy();
      expect(withholdingInfo.withholdingItems[0].summaryItems).toBeDefined();
      expect(withholdingInfo.withholdingItems[1].summaryItems).toBeDefined();
    });

    it('should populate locked out info message', () => {
      mockWithholdingData.usStateTaxWithholdingElections[0].stateIncomeTaxWithholdingElections[0].actions =
        [
          {
            operationID: 'worker.usState.taxWithholding.election.read',
            attestation: {
              messageTxt: 'TWT_1001'
            }
          }
        ];
      const withholdingInfo = service.getWithholdingModel(mockWithholdingData);

      expect(withholdingInfo.hasElections).toBeTruthy();
      expect(withholdingInfo.withholdingItems[1].info).toEqual({
        type: 'info',
        title: 'myadp-pay.TAXWITHHOLDING_CARD_NOEDIT_TITLE',
        message: 'myadp-pay.TAXWITHHOLDING_CARD_NOEDIT_TWT_1001_MESSAGE'
      });
      expect(withholdingInfo.withholdingItems[1].summaryItems).toBeDefined();
    });

    it('should not populate current data when there is none', () => {
      delete mockWithholdingData.usStateTaxWithholdingElections[0]
        .stateIncomeTaxWithholdingElections;
      const withholdingInfo = service.getWithholdingModel(mockWithholdingData);

      expect(withholdingInfo.hasElections).toBeFalsy();
      expect(withholdingInfo.withholdingItems.length).toEqual(0);
    });

    it('should not populate pending data when there is none', () => {
      delete mockWithholdingData.usStateTaxWithholdingElections[0].workflowData;
      const withholdingInfo = service.getWithholdingModel(mockWithholdingData);

      expect(withholdingInfo.withholdingItems[0].pendingSummaryItems).toBeUndefined();
      expect(withholdingInfo.withholdingItems[1].pendingSummaryItems).toBeUndefined();
    });

    it('should populate pending data for only the item that is changed', () => {
      const withholdingInfo = service.getWithholdingModel(mockWithholdingData);

      expect(withholdingInfo.withholdingItems[0].pendingSummaryItems).toBeUndefined();
      expect(withholdingInfo.withholdingItems[1].pendingSummaryItems).toBeDefined();
    });

    it('should populate pending events', () => {
      const withholdingInfo = service.getWithholdingModel(mockWithholdingData);

      expect(withholdingInfo.pendingEvents).toEqual(
        mockWithholdingData.usStateTaxWithholdingElections[0].workflowData.pendingEvents
      );
    });

    it('should not populate pending events when there are none', () => {
      delete mockWithholdingData.usStateTaxWithholdingElections[0].workflowData;
      const withholdingInfo = service.getWithholdingModel(mockWithholdingData);

      expect(withholdingInfo.pendingEvents).not.toBeDefined();
    });
  });

  describe('showEffectiveDate logic', () => {
    beforeEach(() => {
      mockWithholdingData = {
        usStateTaxWithholdingElections: [
          {
            stateIncomeTaxWithholdingElections: [
              {
                stateCode: { codeValue: 'GA', longName: 'Georgia' },
                taxWithholdingStatus: {
                  effectiveDate: moment().add(1, 'day').format('YYYY-MM-DD')
                },
                taxWithholdingAllowanceQuantity: 1,
                taxFilingStatusCode: {
                  codeValue: 'MARRIED_FILING_JOINTLY',
                  longName: 'Married Filing Jointly or Sep'
                }
              },
              {
                stateCode: { codeValue: 'PA', longName: 'Pennsylvania', shortName: 'PA2020' },
                taxWithholdingStatus: {
                  effectiveDate: moment().add(1, 'month').format('YYYY-MM-DD')
                }
              },
              {
                stateCode: { codeValue: 'AK', longName: 'Alaska' },
                taxWithholdingStatus: {
                  effectiveDate: moment().add(1, 'year').format('YYYY-MM-DD')
                }
              }
            ],
            workflowData: {
              pendingData: {
                usStateTaxWithholdingElections: [
                  {
                    stateIncomeTaxWithholdingElections: [
                      {
                        stateCode: { codeValue: 'GA', longName: 'Georgia' },
                        taxWithholdingAllowanceQuantity: 2,
                        taxFilingStatusCode: {
                          codeValue: 'MARRIED_FILING_JOINTLY',
                          longName: 'Married Filing Jointly or Sep'
                        }
                      }
                    ]
                  }
                ]
              },
              pendingEvents: {
                eventTypeId: PendingEventType.EMPLOYEE_INITIATED,
                history: [
                  {
                    assignedTo: 'Smith, Bob',
                    actionTaken: 'None',
                    actionDate: 12345,
                    comments: 'comment',
                    processStepID: 6789
                  }
                ]
              }
            }
          }
        ]
      };
    });

    it('should not show when there are pending items present', async () => {
      const withholdingInfo = service.getWithholdingModel(mockWithholdingData);

      expect(withholdingInfo.withholdingItems[1].showEffectiveDate).toBeFalse();
    });

    it('should show when effective date is in the future', async () => {
      delete mockWithholdingData.usStateTaxWithholdingElections[0].workflowData;
      const withholdingInfo = service.getWithholdingModel(mockWithholdingData);

      expect(withholdingInfo.withholdingItems[1].showEffectiveDate).toBeTrue();
    });

    it('should not show when state is flat rate', async () => {
      const withholdingInfo = service.getWithholdingModel(mockWithholdingData);

      expect(withholdingInfo.withholdingItems[0].showEffectiveDate).toBeFalse();
    });

    it('should not show when state is no income tax state', async () => {
      const withholdingInfo = service.getWithholdingModel(mockWithholdingData);

      expect(withholdingInfo.withholdingItems[0].showEffectiveDate).toBeFalse();
    });

    it('should not show when effective date is not in the future', async () => {
      mockWithholdingData.usStateTaxWithholdingElections[0].stateIncomeTaxWithholdingElections[0].taxWithholdingStatus =
        {
          effectiveDate: moment().subtract(1, 'day').format('YYYY-MM-DD')
        };
      const withholdingInfo = service.getWithholdingModel(mockWithholdingData);
      expect(withholdingInfo.withholdingItems[1].showEffectiveDate).toBeFalse();
    });

    it('should not show when effective date is not valid', async () => {
      mockWithholdingData.usStateTaxWithholdingElections[0].stateIncomeTaxWithholdingElections[0].taxWithholdingStatus =
        {
          effectiveDate: 'invalid'
        };
      const withholdingInfo = service.getWithholdingModel(mockWithholdingData);

      expect(withholdingInfo.withholdingItems[1].showEffectiveDate).toBeFalse();
    });
  });

  describe('invalid federal dependency logic', () => {
    it('should return false if not federal-dependent state', () => {
      const invalidDep = service.hasInvalidFederalDependency('NY');
      expect(invalidDep).toBeFalsy();
    });

    it('should return false if federal-dependent state and has valid 2019 federal data', () => {
      mockFederalData.maritalStatus = { maritalStatus: MaritalStatus2019.SINGLE };
      const invalidDep = service.hasInvalidFederalDependency('CO2019');
      expect(invalidDep).toBeFalsy();
    });

    it('should return false if federal-dependent state and has valid current-year federal data', () => {
      mockFederalData.maritalStatus = {
        maritalStatus: MaritalStatus.SINGLE_OR_MARRIED_FILING_SEPARATELY
      };
      const invalidDep = service.hasInvalidFederalDependency('CO');
      expect(invalidDep).toBeFalsy();
    });

    it('should return true if federal-dependent state and has invalid 2019 federal data', () => {
      mockFederalData.maritalStatus = {
        maritalStatus: MaritalStatus.SINGLE_OR_MARRIED_FILING_SEPARATELY
      };
      const invalidDep = service.hasInvalidFederalDependency('CO2019');
      expect(invalidDep).toBeTruthy();
    });

    it('should return true if federal-dependent state and has invalid current-year federal data', () => {
      mockFederalData.maritalStatus = { maritalStatus: MaritalStatus2019.SINGLE };
      const invalidDep = service.hasInvalidFederalDependency('CO');
      expect(invalidDep).toBeTruthy();
    });
  });
});
