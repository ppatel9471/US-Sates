import { FormsModule, ControlContainer, NgForm } from '@angular/forms';
import { Shallow } from 'shallow-render';
import { TextboxModule } from '@synerg/components/textbox';

import {
  expectElementToBeDisabled,
  expectElementToNotBeDisabled,
  getInputValue,
  setInputValue
} from '@myadp/pay-shared/testing/spec-util.spec';
import { MetaModule } from '../../meta.module';
import { TwmCurrencyInputComponent } from './twm-currency-input.component';

describe('TwmCurrencyInputComponent', () => {
  let shallow: Shallow<TwmCurrencyInputComponent>;
  const currencyInputTemplate = `
  <form #form="ngForm">
    <twm-currency-input [name]="name" [model]="model" [disabled]="disabled"></twm-currency-input>
  </form>`;

  beforeEach(() => {
    shallow = new Shallow(TwmCurrencyInputComponent, MetaModule)
      .provide(NgForm)
      .dontMock(FormsModule, ControlContainer, TextboxModule);
  });

  it('should display values', async () => {
    const { find, fixture } = await shallow.render(currencyInputTemplate, {
      bind: {
        name: 'amount',
        model: {
          amount: ''
        }
      }
    });
    const input = find('adp-textbox .vdl-textbox');
    setInputValue(fixture, input, '71');
    fixture.detectChanges();

    expect(getInputValue(find, 'amount')).toEqual('71');
    expectElementToNotBeDisabled(input);
  });

  it('should display form values', async () => {
    const { find } = await shallow.render(currencyInputTemplate, {
      bind: {
        name: 'amount',
        model: {
          amount: '123'
        }
      }
    });

    expect(getInputValue(find, 'amount')).toEqual('123');
  });

  it('should only accept numbers as input', async () => {
    const { find, fixture } = await shallow.render(currencyInputTemplate, {
      bind: {
        name: 'amount',
        model: {
          amount: ''
        }
      }
    });
    const input = find('adp-textbox .vdl-textbox');
    setInputValue(fixture, input, 'abc.-$');
    fixture.detectChanges();

    expect(getInputValue(find, 'amount')).toEqual('');
  });

  it('should handle disabled', async () => {
    const { find } = await shallow.render(currencyInputTemplate, {
      bind: {
        name: 'amount',
        disabled: true,
        model: {
          amount: ''
        }
      }
    });
    const input = find('adp-textbox .vdl-textbox');

    expectElementToBeDisabled(input);
  });
});
