import {
  MOCK_TRANSFORMED_PAY_STATEMENT_DETAILS_RESPONSE
} from '../../../../../../src/spec-helpers/pay/pay-statement/pay-statement-details';
import { Insight } from '../../../models/payment-calculation-analysis.model';
import { transformInsights } from './deduction-insights.transform';

describe('transformInsights', () => {
  let transformedInsights: Record<string, Insight[]>;
  const insightTax: Insight = {
    text: 'message taxes',
    rank: 1000,
    tags: ['Deduction', 'Taxes']
  };
  const insightBenefits: Insight = {
    text: 'message benefits',
    rank: 1000,
    tags: ['Deduction', 'Benefits']
  };
  const insightEarnings: Insight = {
    text: 'message earnings',
    rank: 1000,
    tags: ['Earnings']
  };

  const insightsNoTag: Insight = {
    text: 'message no tag',
    rank: 1000
  };

  let insights = [insightTax, insightBenefits, insightEarnings, insightsNoTag];

  beforeEach(() => {
    transformedInsights = undefined;
  });

  it('should transform deduction categories', () => {
    transformedInsights = transformInsights(
      insights,
      MOCK_TRANSFORMED_PAY_STATEMENT_DETAILS_RESPONSE.deductionsCategories
    );

    expect(transformedInsights).toEqual({
      top: [insightsNoTag],
      Taxes: [insightTax],
      Benefits: [insightBenefits],
      Earnings: [insightEarnings]
    });
  });

  it('should put insights in the general catgory when there is no mapping', () => {
    const insightWithNoTag: Insight = {
      text: 'message earnings',
      rank: 1000,
      tags: []
    };
    insights = [insightTax, insightWithNoTag, insightEarnings];
    transformedInsights = transformInsights(
      insights,
      MOCK_TRANSFORMED_PAY_STATEMENT_DETAILS_RESPONSE.deductionsCategories
    );

    expect(transformedInsights).toEqual({
      top: [insightWithNoTag],
      Taxes: [insightTax],
      Earnings: [insightEarnings]
    });
  });

  it('should put insights with same tag in the same deduction category', () => {
    // three inisights for tax category
    insights = [
      insightTax,
      insightTax,
      insightTax,
      insightEarnings,
      insightBenefits,
      insightsNoTag
    ];
    transformedInsights = transformInsights(
      insights,
      MOCK_TRANSFORMED_PAY_STATEMENT_DETAILS_RESPONSE.deductionsCategories
    );

    expect(transformedInsights).toEqual({
      top: [insightsNoTag],
      Taxes: [insightTax, insightTax, insightTax],
      Benefits: [insightBenefits],
      Earnings: [insightEarnings]
    });
  });
});
