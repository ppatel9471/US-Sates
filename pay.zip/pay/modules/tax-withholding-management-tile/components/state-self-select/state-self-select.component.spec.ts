import { Shallow } from 'shallow-render';

import { LanguageService } from '@myadp/common';

import { WithholdingType } from '../../../../models/formatted-tax-withholding.model';
import { getState } from '../../../../models/states.model';
import { DownloadPdfDirective } from '../../../shared/directives/download-pdf.directive';
import { TaxWithholdingManagementTileModule } from '../../tax-withholding-management-tile.module';
import { StateSelfSelectComponent } from './state-self-select.component';

describe('StateSelfSelectComponent', () => {
  let shallow: Shallow<StateSelfSelectComponent>;
  const mockWithholdingItems = [
    {
      type: WithholdingType.STATE,
      title: 'Alabama',
      effectiveDate: 'mock date',
      state: { shortName: 'AL', longName: 'Alabama', countryCode: 'US' },
      summaryItems: [{ displayName: 'mock name', displayValue: 'mock value' }]
    },
    {
      type: WithholdingType.STATE,
      title: 'Utah',
      effectiveDate: '',
      invalidFederalDependency: true,
      state: { shortName: 'UT', longName: 'Utah', countryCode: 'US' },
      summaryItems: [{ displayName: 'mock name', displayValue: 'mock value' }]
    },
    {
      type: WithholdingType.STATE,
      title: 'Georgia',
      effectiveDate: 'mock date',
      state: { shortName: 'GA', longName: 'Georgia', countryCode: 'US' },
      summaryItems: [{ displayName: 'mock name', displayValue: 'mock value' }]
    },
    {
      type: WithholdingType.STATE,
      title: 'Ohio',
      effectiveDate: 'mock date',
      state: getState('OH2020'),
      summaryItems: [{ displayName: 'mock name', displayValue: 'mock value' }]
    },
    {
      type: WithholdingType.STATE,
      title: 'Oregon',
      effectiveDate: 'mock date',
      state: { shortName: 'OR', longName: 'Oregon', countryCode: 'US' },
      isUneditable: true,
      invalidFederalDependency: true,
      summaryItems: [{ displayName: 'mock name', displayValue: 'mock value' }]
    },
    {
      type: WithholdingType.STATE,
      title: 'Colorado',
      effectiveDate: '',
      isUneditable: true,
      invalidFederalDependency: true,
      state: { shortName: 'CO', longName: 'Colorado', countryCode: 'US' },
      summaryItems: [{ displayName: 'mock name', displayValue: 'mock value' }]
    }
  ];

  beforeEach(() => {
    shallow = new Shallow(StateSelfSelectComponent, TaxWithholdingManagementTileModule)
      .provide(LanguageService)
      .mock(LanguageService, { get: (key: string) => key });
  });

  it('should have items in dropdown', async () => {
    const { instance } = await shallow.render(
      '<pay-state-self-select [withholdingItems]="inactiveWithholdingItems"></pay-state-self-select>',
      {
        bind: {
          inactiveWithholdingItems: mockWithholdingItems
        }
      }
    );
    expect(instance.states.length).toBe(6);
    expect(instance.states).toEqual([
      { label: 'Alabama', value: 'Alabama', withholdingItem: mockWithholdingItems[0] },
      { label: 'Utah', value: 'Utah', withholdingItem: mockWithholdingItems[1] },
      { label: 'Georgia', value: 'Georgia', withholdingItem: mockWithholdingItems[2] },
      { label: 'Ohio', value: 'Ohio', withholdingItem: mockWithholdingItems[3] },
      { label: 'Oregon', value: 'Oregon', withholdingItem: mockWithholdingItems[4] },
      { label: 'Colorado', value: 'Colorado', withholdingItem: mockWithholdingItems[5] }
    ]);
  });

  it('should have disabled button if no form is selected', async () => {
    const { find } = await shallow.render(
      '<pay-state-self-select [withholdingItems]="inactiveWithholdingItems"></pay-state-self-select>',
      {
        bind: {
          inactiveWithholdingItems: mockWithholdingItems
        }
      }
    );
    expect(find('[data-e2e="start-form-button"]').componentInstance.disabled).toBeTruthy();
  });

  it('should show start button when editable form is selected', async () => {
    const { instance, fixture, find } = await shallow.render(
      '<pay-state-self-select [withholdingItems]="inactiveWithholdingItems"></pay-state-self-select>',
      {
        bind: {
          inactiveWithholdingItems: mockWithholdingItems
        }
      }
    );
    instance.selectedState = {
      label: 'Georgia',
      value: 'Georgia',
      withholdingItem: mockWithholdingItems[2]
    };
    instance.selectedStateChange();
    fixture.detectChanges();

    expect(find('[data-e2e="open-bank-form-button"]')).toHaveFound(0);
    expect(find('[data-e2e="start-form-button"]')).toHaveFound(1);
    expect(find('[data-e2e="start-form-button"]').componentInstance.disabled).toBeFalsy();
  });

  it('should show blank form button when uneditable form is selected', async () => {
    const { instance, fixture, find, findDirective } = await shallow.render(
      '<pay-state-self-select [withholdingItems]="inactiveWithholdingItems"></pay-state-self-select>',
      {
        bind: {
          inactiveWithholdingItems: mockWithholdingItems
        }
      }
    );
    instance.selectedState = {
      label: 'Oregon',
      value: 'Oregon',
      withholdingItem: mockWithholdingItems[4]
    };
    instance.selectedStateChange();
    fixture.detectChanges();

    expect(find('[data-e2e="start-form-button"]')).toHaveFound(0);
    expect(find('[data-e2e="open-bank-form-button"]')).toHaveFound(1);
    expect(find('[data-e2e="open-bank-form-button"]').componentInstance.disabled).toBeFalsy();
    expect(find('[data-e2e="fed-dep-warning"]')).toHaveFound(0);
    expect(findDirective(DownloadPdfDirective).useAudioEye).toBeFalse();
    expect(instance.statement).toEqual({
      title: 'myadp-pay.OR_TAX_WITHHOLDING',
      uri: `/api/tax/v1/tax-withholding/US/forms/OR-W-4?subdivisionCode=OR`
    });
  });

  it('should show blank form button when uneditable form is selected CO DR0004', async () => {
    const { instance, fixture, find, findDirective } = await shallow.render(
      '<pay-state-self-select [withholdingItems]="inactiveWithholdingItems"></pay-state-self-select>',
      {
        bind: {
          inactiveWithholdingItems: mockWithholdingItems
        }
      }
    );
    instance.selectedState = {
      label: 'Colorado',
      value: 'Colorado',
      withholdingItem: mockWithholdingItems[5]
    };
    instance.selectedStateChange();
    fixture.detectChanges();

    expect(find('[data-e2e="start-form-button"]')).toHaveFound(0);
    expect(find('[data-e2e="open-bank-form-button"]')).toHaveFound(1);
    expect(find('[data-e2e="open-bank-form-button"]').componentInstance.disabled).toBeFalsy();
    expect(find('[data-e2e="fed-dep-warning"]')).toHaveFound(0);
    expect(findDirective(DownloadPdfDirective).useAudioEye).toBeFalse();
    expect(instance.statement).toEqual({
      title: 'myadp-pay.CO2022_TAX_WITHHOLDING',
      uri: `/api/tax/v1/tax-withholding/US/forms/DR0004?subdivisionCode=CO`
    });
  });

  it('should emit a normal state object when the start button is clicked', async () => {
    const { instance, find, outputs } = await shallow.render(
      '<pay-state-self-select [withholdingItems]="inactiveWithholdingItems"></pay-state-self-select>',
      {
        bind: {
          inactiveWithholdingItems: mockWithholdingItems
        }
      }
    );
    instance.selectedState = {
      label: 'Alabama',
      value: 'Alabama',
      withholdingItem: mockWithholdingItems[0]
    };

    find('[data-e2e="start-form-button"]').nativeElement.click();
    expect(outputs.startStateWizard.emit).toHaveBeenCalledWith(getState('AL'));
  });

  it('should emit a deprecated state object when the start button is clicked', async () => {
    const { instance, find, outputs } = await shallow.render(
      '<pay-state-self-select [withholdingItems]="inactiveWithholdingItems"></pay-state-self-select>',
      {
        bind: {
          inactiveWithholdingItems: mockWithholdingItems
        }
      }
    );
    instance.selectedState = {
      label: 'Ohio',
      value: 'Ohio',
      withholdingItem: mockWithholdingItems[3]
    };

    find('[data-e2e="start-form-button"]').nativeElement.click();
    expect(outputs.startStateWizard.emit).toHaveBeenCalledWith(getState('OH2020'));
  });

  it('should show warning message and disable button when selected state is federal-like state and has invalid federal data', async () => {
    const { instance, fixture, find } = await shallow.render(
      '<pay-state-self-select [withholdingItems]="inactiveWithholdingItems"></pay-state-self-select>',
      {
        bind: {
          inactiveWithholdingItems: mockWithholdingItems
        }
      }
    );
    instance.selectedState = {
      label: 'Utah',
      value: 'Utah',
      withholdingItem: mockWithholdingItems[1]
    };
    instance.selectedStateChange();
    fixture.detectChanges();

    expect(find('[data-e2e="open-bank-form-button"]')).toHaveFound(0);
    expect(find('[data-e2e="start-form-button"]')).toHaveFound(1);
    expect(find('[data-e2e="fed-dep-warning"]')).toHaveFound(1);
    expect(find('[data-e2e="start-form-button"]').componentInstance.disabled).toBeTruthy();
  });
});
