import { DonutDataPoint } from '@synerg/components/donut';

import { Amount, PayStatementsDTO } from '@myadp/dto';

import {
  Insight,
  INSIGHTS_TAG,
  PaymentCalculationAnalysis
} from '../../../models/payment-calculation-analysis.model';
import { PdfStatement } from '../../shared/models/pdf-viewer.model';

export enum PayStatementsStoreSlice {
  PAY_STATEMENTS = 'payStatements',
  CURRENT_STATEMENT_DETAILS = 'currentStatementDetails',
  STATEMENT_DETAILS_CACHE = 'statementDetailsCache',
  WORKER_ASSIGNMENTS = 'workerAssignment',
  PAYMENT_CALCULATION_ANALYSIS_CACHE = 'paymentCalculationAnalysisCache',
  CURRENT_PAYMENT_CALCULATION_ANALYSIS = 'currentPaymentCalculationAnalysis'
}

export interface PayStatementsStoreState {
  [PayStatementsStoreSlice.PAY_STATEMENTS]?: PayStatementsUI.PayStatementState;
  [PayStatementsStoreSlice.CURRENT_STATEMENT_DETAILS]?: PayStatementsUI.PayStatementDetailsState;
  [PayStatementsStoreSlice.STATEMENT_DETAILS_CACHE]?: Record<
  string,
  PayStatementsUI.PayStatementDetailsState
  >;
  [PayStatementsStoreSlice.CURRENT_PAYMENT_CALCULATION_ANALYSIS]?: PayStatementsUI.PaymentCalculationAnalysisState;
  [PayStatementsStoreSlice.PAYMENT_CALCULATION_ANALYSIS_CACHE]?: Record<
  string,
  PayStatementsUI.PaymentCalculationAnalysisState
  >;
}

export namespace PayStatementsUI {
  export interface PayStatementState {
    statements: PayStatement[];
    statementsForPdfViewer?: PdfStatement[];
    workerPayInfo?: WorkerPayInfo;
    hasNotificationPermission?: boolean;
  }

  export interface PayStatement {
    id?: number;
    payDate?: string;
    netPay?: Amount;
    grossPay?: Amount;
    totalHours?: number;
    payDetailUri?: string;
    statementImageUri?: string;
    payAdjustment?: boolean;
    statementFiscalYear?: string;
    statementType?: string;
  }

  export interface PayStatementDetailsState {
    statement: PayStatement;
    statementDetails?: PayStatementDetails;
    paymentCalculationAnaylsis?: PaymentCalculationAnalysis;
    id?: number;
    payDetailUri?: string;
    statementImageUri?: string;
    statementFiscalYear?: string;
    statementType?: string;
  }

  export interface PaymentCalculationAnalysisState {
    paymentCalcAnalysis: PaymentCalculationAnalysis; // REVIEW: is this being used?
    categorizedInsights: Record<string, Insight[]>;
  }

  export interface PayStatementDetails {
    payDate?: string;
    netPay?: Amount;
    totalHours?: number;
    grossPay?: Amount;
    grossPayYTD?: Amount;
    earnings?: Earning[];
    deductionsCategories?: DeductionsCategory[];
    donutData?: PayDonutData;
    hasYearToDateData?: boolean;
    directDeposits?: PayStatementsDTO.DirectDeposit[];
    memos?: Memos;
  }

  export interface WorkerPayInfo {
    rate: Amount;
    frequency: string;
  }

  export interface PayDonutData {
    data?: PayDonutItem[];
    hasPositiveDeductions: boolean;
  }

  export interface PayDonutItem extends DonutDataPoint {
    id?: string;
    amount?: Amount;
    amountYTD?: Amount;
    valueYTD?: number;
  }

  export interface DeductionsCategory {
    id: string; // non-translated name
    name?: string;
    amount?: Amount;
    amountYTD?: Amount;
    deductions?: DeductionsCategoryItem[];
    directDeposits?: PayStatementsDTO.DirectDeposit[];
    displayConfig: {
      rank: number; // display order (1-n)
      color: string;
      calculatorLink?: CalculatorLink;
    };
    insightsTag?: INSIGHTS_TAG;
  }

  export interface DeductionsCategoryItem {
    name?: string;
    amount?: Amount;
    amountYTD?: Amount;
    preTax?: boolean;
  }

  export interface Earning {
    name: string;
    amount: Amount;
    rate?: Amount;
    payPeriodHours?: number;
    preTax: boolean;
  }

  export interface Memos {
    otherMemos?: Memo[];
    taxableBenefits?: Memo[];
  }

  export interface Memo {
    name?: string;
    categoryName?: string;
    amount?: number; // not currency due to EA schema
    amountYTD?: number;
  }

  export interface CalculatorLink {
    title: string;
    link: string;
  }
  export interface DeductionsCategoryCompare {
    id: string;
    name?: string;
    amount?: Amount[];
    deductions?: DeductionsCategoryCompareItem[];
    displayConfig: {
      rank: number;
      color: string;
      calculatorLink?: CalculatorLink;
    };
  }

  export interface DeductionsCategoryCompareItem {
    name?: string;
    amount?: Amount[];
  }
}
