import { DistributionType } from '../../pay-distributions-shared/models/pay-distributions-ui';

export enum DepositAmountControls {
  AMOUNT_TYPE = 'distributionType',
  PERCENTAGE_AMOUNT = 'percentageAmount',
  FLAT_AMOUNT = 'flatAmount',
  TERMS = 'terms'
}

// Transformed when POSTing
export interface DepositAmountForm {
  [DepositAmountControls.AMOUNT_TYPE]?: DistributionType;
  [DepositAmountControls.PERCENTAGE_AMOUNT]?: string;
  [DepositAmountControls.FLAT_AMOUNT]?: string;
  [DepositAmountControls.TERMS]?: boolean;
}
