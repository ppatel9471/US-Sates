import { TestBed } from '@angular/core/testing';
import { Mock } from 'ts-mockery';
import { LanguageService } from '@myadp/common';

import { StepsStoreActions } from '../store/steps/steps-store.actions';
import { DeductionsTermsService } from './deductions-terms-service';

describe('DeductionsTermsService', () => {
  let termsService: DeductionsTermsService;
  let languageService: LanguageService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        {
          provide: LanguageService,
          useValue: Mock.of<LanguageService>({ get: (key) => key })
        },
        {
          provide: StepsStoreActions,
          useValue: Mock.of<StepsStoreActions>({
            getWorker: () =>
              Promise.resolve({
                person: {
                  legalName: {
                    givenName: 'Francis',
                    familyName1: 'Fields'
                  }
                }
              })
          })
        }
      ]
    });

    termsService = TestBed.inject(DeductionsTermsService);
    languageService = TestBed.inject(LanguageService);
  });

  it('should give terms', async () => {
    await termsService.init();

    expect(termsService.consent).toContain('myadp-pay.DEDUCTIONS_AUTHORIZE');
  });

  it('should include the signature line when asked for the printed version of consent text', async () => {
    await termsService.init();

    expect(termsService.consent).toContain('myadp-pay.DEDUCTIONS_AUTHORIZE');

    expect(termsService.printedConsentText).toContain(
      'myadp-pay.TERMS_AND_CONDITIONS_SIGNATURE'
    );

    expect(languageService.get).toHaveBeenCalledWith(
      'myadp-pay.TERMS_AND_CONDITIONS_SIGNATURE',
      {
        workerName: 'Francis Fields'
      }
    );
  });
});
