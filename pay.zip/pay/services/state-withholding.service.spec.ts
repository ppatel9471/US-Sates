import { TestBed } from '@angular/core/testing';
import { Mock } from 'ts-mockery';

import { BaseHttpClient } from '@myadp/common';
import { PAY_SFFO } from '@myadp/pay-shared';

import { UsStateTaxWithholdingElections } from '../models/us-state-tax-withholding-election.model';
import { WorkerUSStateWithholdingElectionChangeEvent } from '../modules/tax-withholding-management/us/shared/models/state-income-tw-election-event';
import { StateWithholdingService } from './state-withholding.service';

describe('StateWithholdingService', () => {
  let service: StateWithholdingService;
  const mockResponse: UsStateTaxWithholdingElections = {
    usStateTaxWithholdingElections: [
      { stateIncomeTaxWithholdingElections: [{ additionalTaxPercentage: 0.2 }] }
    ]
  };
  const mockEvent: WorkerUSStateWithholdingElectionChangeEvent = {
    data: {
      eventContext: {
        worker: {
          associateOID: 'mockAOID'
        },
        stateCode: null
      },
      transform: {
        effectiveDateTime: '',
        stateIncomeTaxWithholdingElection: {
          taxWithholdingAllowanceQuantity: 10
        }
      }
    },
    actor: {
      associateOID: 'mockAOID'
    },
    serviceCategoryCode: null,
    eventNameCode: null
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        StateWithholdingService,
        {
          provide: BaseHttpClient,
          useValue: Mock.of<BaseHttpClient>({
            get: () => Promise.resolve<UsStateTaxWithholdingElections>(mockResponse),
            post: () =>
              Promise.resolve<{
                events: WorkerUSStateWithholdingElectionChangeEvent[];
              }>({ events: [mockEvent] })
          })
        }
      ]
    });
    service = TestBed.inject(StateWithholdingService);
  });

  it('should get state withholding', (done: DoneFn) => {
    service.getStateWithholding().then((res) => {
      expect(res).toEqual(mockResponse);
      done();
    });
  });

  it('should post state withholding', (done: DoneFn) => {
    const mockClient = TestBed.inject(BaseHttpClient);
    const postSpy = mockClient.post as jasmine.Spy;
    const mockBody: Object = { mockEvents: 'mockEvents' };
    service
      .saveWithholding(mockBody)
      .subscribe((res: { events: WorkerUSStateWithholdingElectionChangeEvent[] }) => {
        const actual = postSpy.calls.first().args[0];
        expect(actual.userPermission).toEqual(PAY_SFFO.TAX_WITHHOLDING_STATE_CHANGE);
        expect(actual.payload).toEqual(mockBody);
        expect(res).toEqual({ events: [mockEvent] });
        done();
      });
  });

  it('should recall state withholding', (done: DoneFn) => {
    const mockClient = TestBed.inject(BaseHttpClient);
    const postSpy = mockClient.post as jasmine.Spy;
    service.recallWithholding().subscribe(() => {
      const actual = postSpy.calls.first().args[0];
      expect(actual.userPermission).toEqual(PAY_SFFO.TAX_WITHHOLDING_STATE_CHANGE);
      expect(actual.urlTransform('/url')).toEqual('/recall/url');
      done();
    });
  });
});
