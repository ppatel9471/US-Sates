import { Component, OnInit, Optional, ViewChild } from '@angular/core';
import { SelectOption } from '@synerg/components/select';
import { TileService } from '@synerg/components/tile';
import { Observable } from 'rxjs';
import { filter, take, tap } from 'rxjs/operators';

import { QueryParamsService } from '@myadp/common';
import { WorkerTaxStatementsDTO } from '@myadp/dto';
import { PaperlessStore } from '@myadp/pay-paperless-shared';
import { PAY_DEEP_LINKS, PayPermissionService } from '@myadp/pay-shared';

import { PdfStatement, StatementType } from '../../../shared/models/pdf-viewer.model';
import { TaxStatementsStoreActions } from '../../store/tax-statements-store.actions';
import { TaxStatementsStore } from '../../store/tax-statements.store';
import { TaxStatementsModalComponent } from '../tax-statements-modal/tax-statements-modal.component';

@Component({
  selector: 'tax-statements-tile',
  templateUrl: 'tax-statements-tile.component.html'
})
export class TaxStatementsTileComponent implements OnInit {
  @ViewChild('moreTaxStatementsModal') moreTaxStatementsModal: TaxStatementsModalComponent;
  public statementType = StatementType;
  public canViewImportBanner: boolean;
  public taxStatementsError$: Observable<boolean>;
  public emptyTaxStatement$: Observable<boolean>;
  public mostRecentTaxYear$: Observable<string>;
  public taxStatementsIsLoading$: Observable<boolean>;
  public selectionYears$: Observable<SelectOption[]>;
  public selectedYear: string;
  public statementsFilteredByYear$: Observable<WorkerTaxStatementsDTO.WorkerTaxStatement[]>;
  public allTaxStatements$: Observable<PdfStatement[]>;
  public showAlert$: Observable<boolean>;

  constructor(
    private taxStatementsStoreActions: TaxStatementsStoreActions,
    private taxStatementsStore: TaxStatementsStore,
    private paperlessStore: PaperlessStore,
    private payPermissionService: PayPermissionService,
    private queryParamsService: QueryParamsService,
    @Optional() private tileService: TileService
  ) {}

  public ngOnInit() {
    this.tileService?.setIsLoading(false);
    this.taxStatementsStoreActions.getTaxStatements();
    this.canViewImportBanner = this.payPermissionService.canViewTaxStatementsImportBanner();
    this.emptyTaxStatement$ = this.taxStatementsStore.emptyTaxStatement$();
    this.taxStatementsError$ = this.taxStatementsStore.taxStatementsError$();
    this.mostRecentTaxYear$ = this.taxStatementsStore.mostRecentTaxYear$();
    this.taxStatementsIsLoading$ = this.taxStatementsStore.taxStatementsIsLoading$();
    this.selectionYears$ = this.taxStatementsStore.selectionYears$();
    this.allTaxStatements$ = this.taxStatementsStore.statementsForPdfViewer$();
    this.showAlert$ = this.paperlessStore.showForcedDialog$();
    this.taxStatementsStore
      .mostRecentTaxYear$()
      .pipe(
        filter((year) => year !== undefined),
        tap((year) => {
          this.selectedYear = year;
          this.updateStatements();
          this.autoOpenModalCheck();
        }),
        take(1)
      )
      .subscribe();
  }

  public openMoreTaxStatementsModal() {
    this.moreTaxStatementsModal.setShowTaxStatementsModal(true);
  }
  public updateStatements() {
    this.statementsFilteredByYear$ = this.taxStatementsStore.filterStatementsByYear$(
      this.selectedYear
    );
  }

  public getLabel() {
    return this.selectedYear === '0' ? 'common.OTHER' : this.selectedYear;
  }

  public autoOpenModalCheck(): void {
    const openVal = this.queryParamsService.getParameterValue('open');
    if (openVal === PAY_DEEP_LINKS.TaxStatements) {
      this.openMoreTaxStatementsModal();
    }
  }
}
