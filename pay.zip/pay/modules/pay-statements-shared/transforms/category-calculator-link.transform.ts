import { Amount } from '@myadp/dto';

import { PayStatementsUI } from '../models/pay-statement-ui';

const taxCalcLink: string = 'https://www.irs.gov/individuals/tax-withholding-estimator';
const retirement401kCalcLink: string =
  'https://www.adp.com/resources/tools/calculators/401k-planner-calculator.aspx';
const retirement403bCalcLink: string =
  'https://www.adp.com/resources/tools/calculators/403b-planner-calculator.aspx';
export const paycheckCalcLink: string = 'https://www.adp.com/resources/tools/calculators.aspx';

export function buildCalculatorLink(
  categoryId: string,
  categoryAmount: Amount,
  deductions: PayStatementsUI.DeductionsCategoryItem[]
): PayStatementsUI.CalculatorLink {
  // only these categories have links
  const handlerLookup = {
    tax: () => getTaxLink(),
    taxes: () => getTaxLink(),
    retirement: () => getRetirementLink(deductions),
    takeHome: () => paycheckCalcLink
  };
  const titleLookup = {
    tax: 'myadp-pay.PAY_CALCULATOR_TAXES_LINK_TITLE',
    taxes: 'myadp-pay.PAY_CALCULATOR_TAXES_LINK_TITLE',
    retirement: 'myadp-pay.PAY_CALCULATOR_RETIREMENT_LINK_TITLE',
    takeHome: 'myadp-pay.PAY_CALCULATOR_TAKE_HOME_LINK_TITLE'
  };
  const link: string = handlerLookup[categoryId] ? handlerLookup[categoryId]() : undefined;
  let calculatorLink: PayStatementsUI.CalculatorLink;

  if (!!link && categoryAmount?.currencyCode === 'USD' && hasValidAmount(categoryAmount)) {
    calculatorLink = {
      title: titleLookup[categoryId],
      link: link
    };
  }

  return calculatorLink;
}

function hasValidAmount(amount: Amount): boolean {
  return !(amount?.amountValue === 0);
}

function getTaxLink(): string {
  return taxCalcLink;
}

function getRetirementLink(deductions: PayStatementsUI.DeductionsCategoryItem[]): string {
  const regEx401k: RegExp = /401/gi;
  const regEx403b: RegExp = /403/gi;
  const has401k: boolean = findDeduction(deductions, regEx401k);
  const has403b: boolean = findDeduction(deductions, regEx403b);
  let link: string = null;

  if (has403b) {
    link = retirement403bCalcLink;
  }
  if (has401k) {
    link = retirement401kCalcLink;
  }

  return link;
}

function findDeduction(
  deductions: PayStatementsUI.DeductionsCategoryItem[],
  lookFor: RegExp
): boolean {
  return !!deductions.find((deduction) => lookFor.test(deduction?.name));
}
