import { BaseHttpClient } from '@myadp/common';
import { TestBed } from '@angular/core/testing';
import { Mock } from 'ts-mockery';
import { PAY_SFFO } from '@myadp/pay-shared';
import { LocalWithholdingService } from './local-withholding.service';
import { UsLocalTaxInstruction } from '../models/us-local-tax-instruction.model';

describe('LocalWithholdingService', () => {
  let service: LocalWithholdingService;
  let baseHttpClient: BaseHttpClient;
  const mockTW: UsLocalTaxInstruction[] = [{ additionalTaxPercentage: 10 }];
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        LocalWithholdingService,
        {
          provide: BaseHttpClient,
          useValue: Mock.of<BaseHttpClient>({
            get: () =>
              Promise.resolve<any>({
                usTaxProfiles: [{ usLocalTaxInstructions: mockTW }]
              })
          })
        }
      ]
    });
    service = TestBed.inject(LocalWithholdingService);
    baseHttpClient = TestBed.inject(BaseHttpClient);
  });

  it('should create service', () => {
    expect(service).toBeTruthy();
  });

  it('should get local withholding', () => {
    service.getLocalWithholding().then(res => {
      expect(baseHttpClient.get).toHaveBeenCalledWith({
        userPermission: PAY_SFFO.TAX_WITHHOLDING_LOCAL_READ
      });
      expect(res).toEqual(mockTW);
    });
  });
});
