import {
  PdfStatement,
  StatementDetailItemType
} from '../../shared/models/pdf-viewer.model';
import { PayStatementsUI } from '../models/pay-statement-ui';
import { transformPdf } from './statements-pdf-viewer.transform';

describe('transformPdf', () => {
  const statementImageUri1 =
    '/l2/v1_0/O/A/payStatement/1074162519264497000198001612729/images/CERooo008000620000r701AC7680FFC521.pdf';
  const statementImageUri2 =
    '/l2/v1_0/O/A/payStatement/1074162519254260000198001043941/images/CERooo008000520000r7013E3AE9EFC521.pdf';
  const payDate1 = 'Apr 6, 2019';
  const payDate2 = 'Apr 5, 2019';
  const transformedStatements: PayStatementsUI.PayStatement[] = [
    {
      id: 1,
      payDate: payDate1,
      netPay: { amountValue: 1001, currencyCode: 'USD' },
      grossPay: { amountValue: 2001, currencyCode: 'USD' },
      totalHours: 80,
      payDetailUri: undefined,
      statementImageUri: statementImageUri1,
      payAdjustment: true,
      statementFiscalYear: '2019',
      statementType: 'Adjustment'
    },
    {
      id: 2,
      payDate: payDate2,
      netPay: { amountValue: 1002, currencyCode: 'USD' },
      grossPay: { amountValue: 2002, currencyCode: 'USD' },
      totalHours: 80,
      payDetailUri: '/v1_0/O/A/payStatement/1074162519254260000198001043941',
      statementImageUri: statementImageUri2,
      payAdjustment: false,
      statementFiscalYear: '2019',
      statementType: undefined
    }
  ];

  let transformedPdfs: PdfStatement[];
  beforeEach(() => {
    transformedPdfs = transformPdf(transformedStatements);
  });

  it('should map uri', () => {
    expect(transformedPdfs[0].uri).toEqual(statementImageUri1);
    expect(transformedPdfs[1].uri).toEqual(statementImageUri2);
  });

  it('should map title', () => {
    expect(transformedPdfs[0].title).toEqual(payDate1);
    expect(transformedPdfs[1].title).toEqual(payDate2);
  });

  it('should map statementDetails', () => {
    expect(transformedPdfs[0].statementDetails).toContain({
      label: 'myadp-pay.PDF_VIEWER_SLIDEIN_PAY_DATE',
      value: payDate1
    });
    expect(transformedPdfs[1].statementDetails).toContain({
      label: 'myadp-pay.PDF_VIEWER_SLIDEIN_PAY_DATE',
      value: payDate2
    });

    expect(transformedPdfs[0].statementDetails).toContain({
      label: 'myadp-pay.PDF_VIEWER_SLIDEIN_GROSS_PAY',
      value: { amountValue: 2001, currencyCode: 'USD' },
      type: StatementDetailItemType.CURRENCY
    });
    expect(transformedPdfs[1].statementDetails).toContain({
      label: 'myadp-pay.PDF_VIEWER_SLIDEIN_GROSS_PAY',
      value: { amountValue: 2002, currencyCode: 'USD' },
      type: StatementDetailItemType.CURRENCY
    });

    expect(transformedPdfs[0].statementDetails).toContain({
      label: 'myadp-pay.PDF_VIEWER_SLIDEIN_NET_PAY',
      value: { amountValue: 1001, currencyCode: 'USD' },
      type: StatementDetailItemType.CURRENCY
    });
    expect(transformedPdfs[1].statementDetails).toContain({
      label: 'myadp-pay.PDF_VIEWER_SLIDEIN_NET_PAY',
      value: { amountValue: 1002, currencyCode: 'USD' },
      type: StatementDetailItemType.CURRENCY
    });
  });
});
