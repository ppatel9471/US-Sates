import { CurrencyPipe } from '@angular/common';
import { TestBed } from '@angular/core/testing';
import { Mock } from 'ts-mockery';

import { LanguageService } from '@myadp/common';
import { MOCK_TRANSFORMED_DIRECT_DEPOSIT_ACCOUNTS } from '@specHelpers/pay/direct-deposit/direct-deposit';

import {
  DistributionOptions,
  PayDistributionsUI
} from '../../pay-distributions-shared/models/pay-distributions-ui';
import { DirectDepositComparisonService } from './direct-deposit-comparison.service';
import { WorkflowComparisonService } from './workflow-comparison.service';

describe('DirectDepositComparisonService', () => {
  let service: DirectDepositComparisonService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        DirectDepositComparisonService,
        WorkflowComparisonService,
        CurrencyPipe,
        {
          provide: LanguageService,
          useValue: Mock.of<LanguageService>({ get: (key) => key })
        }
      ]
    });
    service = TestBed.inject(DirectDepositComparisonService);
  });

  it('should get comparison data for a pending new account', () => {
    const pendingData = MOCK_TRANSFORMED_DIRECT_DEPOSIT_ACCOUNTS[0].currentData;
    const [current, pending] = service.getComparisonData(
      {
        isWisely: false,
        currentData: null,
        pendingData: pendingData,
        pendingEvent: { changeType: 'add' }
      },
      false
    );

    expect(current).toEqual({ addOrDeleteMsg: 'myadp-pay.DD_WORKFLOW_COMPARISON_PENDING_ADD' });
    expect(pending).toEqual({
      ...pendingData,
      isWisely: false,
      displayAmount: '$123.00'
    });
  });

  it('should get comparison data for a pending account deletion', () => {
    const currentData: PayDistributionsUI.PayDistributionDetails = {
      ...MOCK_TRANSFORMED_DIRECT_DEPOSIT_ACCOUNTS[1].currentData,
      distributionType: DistributionOptions.REMAINING,
      flatAmount: { amountValue: 0, currencyCode: 'USD' },
      percentageAmount: null
    };
    const [current, pending] = service.getComparisonData(
      {
        isWisely: false,
        currentData: currentData,
        pendingData: null,
        pendingEvent: { changeType: 'delete' }
      },
      true
    );

    expect(current).toEqual({
      ...currentData,
      isWisely: false,
      displayAmount: 'myadp-pay.DD_REMAINING'
    });
    expect(pending).toEqual({ addOrDeleteMsg: 'myadp-pay.DD_WORKFLOW_COMPARISON_PENDING_DELETE' });
  });

  it('should get comparison data for a pending account edit when there are not other accounts', () => {
    const currentData: PayDistributionsUI.PayDistributionDetails = {
      ...MOCK_TRANSFORMED_DIRECT_DEPOSIT_ACCOUNTS[2].currentData,
      distributionType: DistributionOptions.PERCENTAGE,
      flatAmount: { amountValue: 0, currencyCode: 'USD' },
      percentageAmount: 12.46
    };
    const pendingData: PayDistributionsUI.PayDistributionDetails = {
      ...MOCK_TRANSFORMED_DIRECT_DEPOSIT_ACCOUNTS[2].currentData,
      distributionType: DistributionOptions.REMAINING,
      flatAmount: { amountValue: 0, currencyCode: 'USD' },
      percentageAmount: null
    };
    const [current, pending] = service.getComparisonData(
      {
        isWisely: false,
        currentData: currentData,
        pendingData: pendingData,
        pendingEvent: { changeType: 'edit' }
      },
      false
    );

    expect(current).toEqual({
      ...currentData,
      isWisely: false,
      displayAmount: '12.46%'
    });
    expect(pending).toEqual({
      distributionType: DistributionOptions.REMAINING,
      percentageAmount: null,
      isWisely: false,
      displayAmount: 'myadp-pay.DD_FULL'
    });
  });

  it('should get comparison data for a pending account edit when changing distributionType', () => {
    const currentData: PayDistributionsUI.PayDistributionDetails = {
      ...MOCK_TRANSFORMED_DIRECT_DEPOSIT_ACCOUNTS[2].currentData,
      distributionType: DistributionOptions.FLAT,
      flatAmount: { amountValue: 156, currencyCode: 'USD' },
      percentageAmount: null
    };
    const pendingData: PayDistributionsUI.PayDistributionDetails = {
      ...MOCK_TRANSFORMED_DIRECT_DEPOSIT_ACCOUNTS[2].currentData,
      distributionType: DistributionOptions.PERCENTAGE,
      flatAmount: { amountValue: 0, currencyCode: 'USD' },
      percentageAmount: 35.68
    };
    const [current, pending] = service.getComparisonData(
      {
        isWisely: false,
        currentData: currentData,
        pendingData: pendingData,
        pendingEvent: { changeType: 'edit' }
      },
      false
    );

    expect(current).toEqual({
      ...currentData,
      isWisely: false,
      displayAmount: '$156.00'
    });
    expect(pending).toEqual({
      distributionType: DistributionOptions.PERCENTAGE,
      percentageAmount: 35.68,
      flatAmount: { amountValue: 0, currencyCode: 'USD' },
      isWisely: false,
      displayAmount: '35.68%'
    });
  });

  it('should get comparison data for a pending account edit when keeping the same distributionType', () => {
    const currentData: PayDistributionsUI.PayDistributionDetails = {
      ...MOCK_TRANSFORMED_DIRECT_DEPOSIT_ACCOUNTS[2].currentData,
      distributionType: DistributionOptions.FLAT,
      flatAmount: { amountValue: 35.12, currencyCode: 'USD' },
      percentageAmount: null
    };
    const pendingData: PayDistributionsUI.PayDistributionDetails = {
      ...MOCK_TRANSFORMED_DIRECT_DEPOSIT_ACCOUNTS[2].currentData,
      distributionType: DistributionOptions.FLAT,
      flatAmount: { amountValue: 89.97, currencyCode: 'USD' },
      percentageAmount: null
    };
    const [current, pending] = service.getComparisonData(
      {
        isWisely: false,
        currentData: currentData,
        pendingData: pendingData,
        pendingEvent: { changeType: 'edit' }
      },
      false
    );

    expect(current).toEqual({
      ...currentData,
      isWisely: false,
      displayAmount: '$35.12'
    });
    expect(pending).toEqual({
      flatAmount: { amountValue: 89.97, currencyCode: 'USD' },
      isWisely: false,
      displayAmount: '$89.97'
    });
  });

  it('should get comparison data for a pending account edit when only accountNumber has changed', () => {
    const currentData: PayDistributionsUI.PayDistributionDetails = {
      ...MOCK_TRANSFORMED_DIRECT_DEPOSIT_ACCOUNTS[2].currentData,
      accountNumber: '00019',
      distributionType: DistributionOptions.REMAINING,
      flatAmount: null,
      percentageAmount: null
    };
    const pendingData: PayDistributionsUI.PayDistributionDetails = {
      ...MOCK_TRANSFORMED_DIRECT_DEPOSIT_ACCOUNTS[2].currentData,
      distributionType: DistributionOptions.REMAINING,
      accountNumber: '00015'
    };
    const [current, pending] = service.getComparisonData(
      {
        isWisely: false,
        currentData: currentData,
        pendingData: pendingData,
        pendingEvent: { changeType: 'edit' }
      },
      false
    );

    expect(current).toEqual({
      ...currentData,
      isWisely: false,
      displayAmount: 'myadp-pay.DD_FULL'
    });
    expect(pending).toEqual({
      accountNumber: '00015',
      isWisely: false,
      displayAmount: null
    });
  });
});
