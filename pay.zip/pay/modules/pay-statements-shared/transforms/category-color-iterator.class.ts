import { cloneDeep } from 'lodash';

import { categoryColors } from '../constants/category-colors.const';

export class CategoryColorIterator {
  private palette: string[];

  constructor(baseColorPalette: string[]) {
    this.palette = cloneDeep(baseColorPalette);
  }

  public nextColor(): string {
    const color: string = this.palette.shift();
    this.palette.push(color);
    return color;
  }
}

export function buildColorIterator(): CategoryColorIterator {
  return new CategoryColorIterator([
    categoryColors.primary,
    categoryColors.accent2,
    categoryColors.accent4
  ]);
}
