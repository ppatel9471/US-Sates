import { PayStatementsUI } from '../models/pay-statement-ui';
import { categoryColors } from './category-colors.const';
import { INSIGHTS_TAG } from '../../../models/payment-calculation-analysis.model';

export const TAKE_HOME_ID: string = 'takeHome';
export const DEDUCTIONS_ID: string = 'deductions';
export const ADJUSTMENTS_ID: string = 'adjustments';
export const DEDUCTIONS_CATEGORY_NAME: string = 'Deductions';
export const TAXABLE_BENEFIT_NAME: string = 'Taxable Benefit';
export const BANKING_NAME: string = 'Banking';

export const deductionCategoryMetadata: Record<
string,
Partial<PayStatementsUI.DeductionsCategory>
> = {
  grossPay: {
    name: 'myadp-pay.PAY_GROSS_PAY',
    displayConfig: {
      rank: 1,
      color: categoryColors.accent1
    }
  },
  [DEDUCTIONS_ID]: {
    name: 'myadp-pay.PAY_DEDUCTIONS',
    displayConfig: {
      rank: 2,
      color: categoryColors.accent3
    }
  },
  tax: {
    name: 'myadp-pay.PAY_TAXES',
    displayConfig: {
      rank: 3,
      color: categoryColors.accent3
    },
    insightsTag: INSIGHTS_TAG.TAXES
  },
  taxes: {
    name: 'myadp-pay.PAY_TAXES',
    displayConfig: {
      rank: 3,
      color: categoryColors.accent3
    },
    insightsTag: INSIGHTS_TAG.TAXES
  },
  benefit: {
    name: 'myadp-pay.PAY_BENEFITS',
    displayConfig: {
      rank: 4,
      color: categoryColors.primaryLight
    },
    insightsTag: INSIGHTS_TAG.BENEFITS
  },
  benefits: {
    name: 'myadp-pay.PAY_BENEFITS',
    displayConfig: {
      rank: 4,
      color: categoryColors.primaryLight
    },
    insightsTag: INSIGHTS_TAG.BENEFITS
  },
  retirement: {
    name: 'myadp-pay.PAY_RETIREMENT',
    displayConfig: {
      rank: 8,
      color: categoryColors.accent2
    },
    insightsTag: INSIGHTS_TAG.RETIREMENT
  },
  garnishment: {
    name: 'myadp-pay.PAY_GARNISHMENTS',
    displayConfig: {
      rank: 11,
      color: categoryColors.accent7
    }
  },
  garnishments: {
    name: 'myadp-pay.PAY_GARNISHMENTS',
    displayConfig: {
      rank: 11,
      color: categoryColors.accent7
    }
  },
  statutoryDeductions: {
    name: 'myadp-pay.PAY_STATUTORY_DEDUCTIONS',
    displayConfig: {
      rank: 12,
      color: categoryColors.accent6
    }
  },
  voluntaryDeductions: {
    name: 'myadp-pay.PAY_VOLUNTARY_DEDUCTIONS',
    displayConfig: {
      rank: 13,
      color: categoryColors.accent4Dark
    }
  },
  other: {
    name: 'myadp-pay.PAY_OTHER',
    displayConfig: {
      rank: 14,
      color: categoryColors.accent4
    }
  },
  taxableBenefits: {
    name: 'myadp-pay.PAY_TAXABLE_BENEFITS',
    displayConfig: {
      rank: 15,
      color: 'accent-5-dark'
    }
  },
  [ADJUSTMENTS_ID]: {
    id: ADJUSTMENTS_ID,
    name: 'myadp-pay.PAY_ADJUSTMENTS',
    displayConfig: {
      rank: 16,
      color: categoryColors.accent3Dark
    }
  },
  [TAKE_HOME_ID]: {
    id: TAKE_HOME_ID,
    name: 'myadp-pay.PAY_TAKE_HOME',
    displayConfig: {
      rank: 20,
      color: categoryColors.accent1
    }
  }
};
