import { PayStatementsDTO, Amount } from '@myadp/dto';
import { isEmpty } from 'lodash';

import { PayStatementsUI } from '../models/pay-statement-ui';
import {
  deductionCategoryMetadata,
  ADJUSTMENTS_ID
} from '../constants/deduction-category-metadata.const';

export function buildOtherPayCategory(
  statementDetails: PayStatementsDTO.PayStatementDetailRaw
): PayStatementsUI.DeductionsCategory {
  const donutMetadata = deductionCategoryMetadata[ADJUSTMENTS_ID];
  // look for sectionLabelName 'Adjustments'
  const otherPayDetails: PayStatementsDTO.OtherPayDetail[] = statementDetails?.otherPay?.filter(
    (detail) => detail.sectionLabelName.toLowerCase() === 'adjustments'
  )?.[0]?.otherPayDetail;
  if (!isEmpty(otherPayDetails)) {
    return {
      id: donutMetadata.id,
      amount: getAmount(otherPayDetails),
      amountYTD: {
        amountValue: null,
        currencyCode: null
      },
      name: donutMetadata.name,
      deductions: getDetail(otherPayDetails),
      displayConfig: {
        ...donutMetadata.displayConfig
      }
    };
  }
}

function getDetail(
  otherPayDetails: PayStatementsDTO.OtherPayDetail[] = []
): PayStatementsUI.DeductionsCategoryItem[] {
  return otherPayDetails.map((otherPayDetail) => {
    return {
      name: otherPayDetail?.labelName,
      amount: otherPayDetail?.payAmount,
      preTax: otherPayDetail?.preTaxIndicator
    };
  });
}

function getAmount(otherPayDetails: PayStatementsDTO.OtherPayDetail[] = []): Amount {
  const totalAmount =
    otherPayDetails.reduce((sum: number, detail) => {
      return sum + (detail?.payAmount?.amountValue ?? 0);
    }, 0) || null;

  return totalAmount
    ? {
      amountValue: totalAmount,
      currencyCode: getCurrencyCode(otherPayDetails)
    }
    : null;
}

function getCurrencyCode(otherPayDetails: PayStatementsDTO.OtherPayDetail[] = []): string {
  const firstOtherPay = otherPayDetails?.find(
    (otherPayDetail) => !!otherPayDetail?.payAmount?.currencyCode
  );
  return firstOtherPay?.payAmount?.currencyCode;
}
