import { Directive, Input, OnInit } from '@angular/core';
import { ListItem } from '../../models/form-item.model';
import { cloneDeep } from 'lodash';

@Directive()
// eslint-disable-next-line @angular-eslint/directive-class-suffix
export abstract class TwmAbstractFormGroup implements OnInit {
  @Input() options: ListItem[];
  @Input() public name: string;
  @Input() public inline: boolean = true;
  @Input() public required: boolean = true;
  public formOptions: ListItem[];
  public value: string | boolean;

  ngOnInit() {
    this.formOptions = cloneDeep(this.options);
  }
}
