import { Component, Input } from '@angular/core';

import { ContentItem, FormItem } from '../../models/form-item.model';

@Component({
  selector: 'twm-content-form-item',
  styleUrls: ['./content-form-item.component.scss'],
  templateUrl: './content-form-item.component.html'
})
export class ContentFormItemComponent {
  @Input() public formItem: FormItem;

  public isGrid(content: ContentItem): boolean {
    return !!content.textItem && !!content.linkItem;
  }
}
