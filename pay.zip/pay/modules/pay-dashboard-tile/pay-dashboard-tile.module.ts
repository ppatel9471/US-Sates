import { NgModule } from '@angular/core';
import { CurrencyPipe } from '@angular/common';

import { MyAdpCommonModule } from '@myadp/common';

import { AlertModule } from '@synerg/components/alert';
import { BusyIndicatorModule } from '@synerg/components/busy-indicator';
import { ButtonModule } from '@synerg/components/button';
import { DonutModule } from '@synerg/components/donut';
import { PayDashboardTileComponent } from './components/pay-dashboard-tile.component';
import { PayDashboardTileUnmaskComponent } from './components/pay-dashboard-tile-unmask.component';
import { TileModule } from '@synerg/components/tile';

@NgModule({
  imports: [MyAdpCommonModule, DonutModule, BusyIndicatorModule, ButtonModule, AlertModule, TileModule],
  declarations: [PayDashboardTileComponent, PayDashboardTileUnmaskComponent],
  providers: [
    CurrencyPipe
  ]
})
export class PayDashboardTileModule {
  static components = {
    default: PayDashboardTileComponent
  };
}
