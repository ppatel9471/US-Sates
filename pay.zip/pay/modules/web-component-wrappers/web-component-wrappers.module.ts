import { CommonModule } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { AlertModule } from '@synerg/components/alert';
import { TileModule } from '@synerg/components/tile';

import { MyAdpCommonModule } from '@myadp/common';

import { PwcWrapperComponent } from './components/shared/pwc-component-wrapper/pwc-wrapper.component';
import { TimeOffBalancesTileComponent } from './components/timeoff-balances-tile/timeoff-balances-tile.component';

@NgModule({
  imports: [CommonModule, TileModule, AlertModule, MyAdpCommonModule],
  declarations: [TimeOffBalancesTileComponent, PwcWrapperComponent],
  exports: [TimeOffBalancesTileComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class WebComponentWrappersModule {
  static components = {
    default: PwcWrapperComponent,
    timeoffBalancesTile: TimeOffBalancesTileComponent
  };
}
