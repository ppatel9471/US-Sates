import { Component } from '@angular/core';

@Component({
  templateUrl: 'direct-deposit-sandbox-wrapper.component.html'
})
export class DirectDepositSandboxWrapperComponent {

}
