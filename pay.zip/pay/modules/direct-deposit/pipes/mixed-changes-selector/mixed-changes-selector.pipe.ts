import { Pipe, PipeTransform } from '@angular/core';

import { WorkflowUI } from '../../../shared/models/workflow-ui.model';
import { DirectDepositAccount } from '../../models/direct-deposit-account.model';

type MixedChange = { account: DirectDepositAccount; changeMsg: string };

@Pipe({ name: 'mixedChangesSelector', pure: true })
export class MixedChangesSelectorPipe implements PipeTransform {
  public transform(
    modifications: Record<WorkflowUI.ChangeType, DirectDepositAccount[]>
  ): MixedChange[] {
    const changeMsgLookup: Record<WorkflowUI.ChangeType, string> = {
      add: 'myadp-pay.DD_DONE_ADDED_CHANGE',
      edit: 'myadp-pay.DD_DONE_EDITED_CHANGE',
      delete: 'myadp-pay.DD_DONE_DELETED_CHANGE'
    };

    return Object.entries(modifications).reduce(
      (changes: MixedChange[], [key, values]: [WorkflowUI.ChangeType, DirectDepositAccount[]]) => [
        ...changes,
        ...(values?.map((value) => ({ account: value, changeMsg: changeMsgLookup[key] })) ?? [])
      ],
      []
    );
  }
}
