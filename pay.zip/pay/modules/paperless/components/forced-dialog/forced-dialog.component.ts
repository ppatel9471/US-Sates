import { Component, OnInit } from '@angular/core';
import { ClientDeviceService } from '@espresso/core';
import { Observable } from 'rxjs';

import {
  ForcedDialogPageType,
  PaperlessStore,
  PaperlessStoreActions
} from '@myadp/pay-paperless-shared';
import { PayPermissionService } from '@myadp/pay-shared';

@Component({
  selector: 'forced-dialog',
  templateUrl: './forced-dialog.component.html',
  styleUrls: ['./forced-dialog.component.scss']
})
export class ForcedDialogComponent implements OnInit {
  public forcedDialogType = ForcedDialogPageType;
  public displayIntro = true;
  public displayConsent: boolean;
  public displayEmail: boolean;
  public displayDone: boolean;
  public displayClose: boolean;
  public displayLogout: boolean;
  public showForcedDialog$: Observable<boolean>;

  constructor(
    private payPermissionService: PayPermissionService,
    private paperlessStore: PaperlessStore,
    private paperlessStoreActions: PaperlessStoreActions,
    private clientDeviceService: ClientDeviceService
  ) {}

  public ngOnInit() {
    this.paperlessStoreActions.getAllPreferences();
    this.showForcedDialog$ = this.paperlessStore.showForcedDialog$();
  }

  public setDisplayScreen(screen: string, display: boolean): void {
    const lookUp = {
      [ForcedDialogPageType.INTRO]: () => (this.displayIntro = display),
      [ForcedDialogPageType.CONSENT]: () => (this.displayConsent = display),
      [ForcedDialogPageType.EMAIL]: () => (this.displayEmail = display),
      [ForcedDialogPageType.DONE]: () => (this.displayDone = display),
      [ForcedDialogPageType.CLOSE]: () => (this.displayClose = display)
    };
    lookUp[screen]();
  }

  public showScreen(screen?: string): void {
    // if no screen parameter, hide all screens
    const hideScreens = Object.keys(ForcedDialogPageType).filter((key) => key !== screen);
    if (screen) {
      this.setDisplayScreen(screen, true);
    }

    hideScreens.forEach((key) => this.setDisplayScreen(key, false));
  }

  public closeForcedDialog(): void {
    // if no permission and not native
    // show sorry to see you go sreen and log out
    if (
      !this.payPermissionService.canViewPayAndTaxStatements() &&
      !this.clientDeviceService.isNative()
    ) {
      this.displayLogout = true;
    }
    this.done();
  }

  public done(): void {
    this.showScreen();
    this.paperlessStore.forcedDialogClosed$.next(true);
  }

  public closeLogout(): void {
    this.displayLogout = false;
  }
}
