import { PayDeductionsUI } from '../../pay-deductions-shared/models/pay-deductions-ui';

export interface DeductionForm extends PayDeductionsUI.DeductionDetails {
  terms?: boolean;
  formValid?: boolean;
}
