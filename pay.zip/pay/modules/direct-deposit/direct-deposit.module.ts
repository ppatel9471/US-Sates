import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CoreModule } from '@synerg/angular-components';
import { AlertModule } from '@synerg/components/alert';
import { AvatarModule } from '@synerg/components/avatar';
import { BusyIndicatorModule } from '@synerg/components/busy-indicator';
import { ButtonModule } from '@synerg/components/button';
import { CheckboxModule } from '@synerg/components/checkbox';
import { FormGroupModule } from '@synerg/components/form-group';
import { FormattedFieldModule } from '@synerg/components/formatted-field';
import { IconModule } from '@synerg/components/icon';
import { ListViewModule } from '@synerg/components/list-view';
import { ModalModule } from '@synerg/components/modal';
import { ProgressBarModule } from '@synerg/components/progress-bar';
import { RadioGroupModule } from '@synerg/components/radio-group';
import { SelectModule } from '@synerg/components/select';
import { SlideinModule } from '@synerg/components/slidein';
import { SnackbarModule } from '@synerg/components/snackbar';
import { TextboxModule } from '@synerg/components/textbox';
import { TileModule } from '@synerg/components/tile';
import { WizardContainerModule } from '@synerg/components/wizard-container';
import { NgxMaskModule } from 'ngx-mask';

import { MyAdpCommonModule } from '@myadp/common';
import { SelfEnrollFlowModule } from '@myadp/paycard';

import { CustomContentSharedModule } from '../custom-content-shared/custom-content-shared.module';
import { SharedModule } from '../shared/shared.module';
import { WiselyEnrollmentComponent } from './account-types/paycards/wisely/wisely-enrollment/wisely-enrollment.component';
import { DirectDepositContainerComponent } from './components/direct-deposit-container/direct-deposit-container.component';
import { DirectDepositListComponent } from './components/direct-deposit-list/direct-deposit-list.component';
import { DirectDepositSlideinComponent } from './components/direct-deposit-slidein/direct-deposit-slidein.component';
import { DirectDepositCATileComponent } from './components/direct-deposit-tile/country/ca/direct-deposit-ca-tile.component';
import { DirectDepositUSTileComponent } from './components/direct-deposit-tile/country/us/direct-deposit-us-tile.component';
import { DirectDepositTileComponent } from './components/direct-deposit-tile/direct-deposit-tile.component';
import { DirectDepositNoDistributionsComponent } from './components/direct-deposit-tile/no-direct-deposits/no-direct-deposits.component';
import { OCRConfirmationStepComponent } from './components/ocr-component/components/ocr-confirmation-step/ocr-confirmation-step.component';
import { OCRTriggerButtonComponent } from './components/ocr-component/components/ocr-trigger-button/ocr-trigger-button.component';
import { AccountListComponent } from './components/shared/account-list/account-list.component';
import { DepositAmountFormatComponent } from './components/shared/deposit-amount-format/deposit-amount-format.component';
import { StepsNavigationComponent } from './components/steps-navigation/steps-navigation.component';
import { AccountDetailsComponent } from './components/steps/account-details/account-details.component';
import { AccountDetailsCAComponent } from './components/steps/account-details/country/ca/account-details-ca.component';
import { AccountDetailsModalComponent } from './components/steps/account-details/country/shared/account-details-modal.component';
import { AccountDetailsSharedComponent } from './components/steps/account-details/country/shared/account-details-shared.component';
import { AccountDetailsUSComponent } from './components/steps/account-details/country/us/account-details-us.component';
import { AccountReviewComponent } from './components/steps/account-review/account-review.component';
import { AccountTypeComponent } from './components/steps/account-type/account-type.component';
import { AccountVerificationComponent } from './components/steps/account-verification/account-verification.component';
import { DepositAmountComponent } from './components/steps/deposit-amount/deposit-amount.component';
import { DepositDoneComponent } from './components/steps/deposit-done/deposit-done.component';
import { AccountDetailsSelectorPipe } from './pipes/account-details-selector/account-details-selector.pipe';
import { MaskNumberPipe } from './pipes/mask-number/mask-number.pipe';
import { MixedChangesSelectorPipe } from './pipes/mixed-changes-selector/mixed-changes-selector.pipe';
import { WiselyNameDisplayPipe } from './pipes/wisely-name-display/wisely-name-display.pipe';

const DIRECT_DEPOSIT_COMPONENTS = [
  DirectDepositCATileComponent,
  DirectDepositUSTileComponent,
  AccountDetailsCAComponent,
  AccountDetailsUSComponent,
  AccountDetailsModalComponent,
  DirectDepositTileComponent,
  DirectDepositSlideinComponent,
  DirectDepositContainerComponent,
  DirectDepositListComponent,
  AccountListComponent,
  DepositAmountFormatComponent,
  AccountTypeComponent,
  AccountDetailsComponent,
  DepositAmountComponent,
  AccountReviewComponent,
  DepositDoneComponent,
  StepsNavigationComponent,
  WiselyEnrollmentComponent,
  DirectDepositNoDistributionsComponent,
  AccountVerificationComponent,
  MaskNumberPipe,
  AccountDetailsSelectorPipe,
  MixedChangesSelectorPipe,
  WiselyNameDisplayPipe,
  OCRTriggerButtonComponent,
  OCRConfirmationStepComponent,
  AccountDetailsSharedComponent
];

@NgModule({
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    FormGroupModule.forRoot(),
    RadioGroupModule,
    ButtonModule,
    ModalModule,
    SlideinModule,
    AlertModule,
    BusyIndicatorModule,
    SnackbarModule,
    ProgressBarModule,
    MyAdpCommonModule,
    SharedModule,
    ListViewModule,
    FormattedFieldModule,
    CustomContentSharedModule,
    TextboxModule,
    CheckboxModule,
    SelectModule,
    IconModule,
    FormGroupModule,
    AvatarModule,
    WizardContainerModule,
    TileModule,
    SelfEnrollFlowModule,
    CoreModule,
    NgxMaskModule.forRoot()
  ],
  declarations: DIRECT_DEPOSIT_COMPONENTS
})
export class MyADPDirectDepositModule {
  static components = {
    default: DirectDepositTileComponent
  };
}
