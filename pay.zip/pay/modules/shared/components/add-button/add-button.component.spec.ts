import { ButtonComponent } from '@synerg/components/button';
import { Shallow } from 'shallow-render';

import { LanguagePipe } from '@myadp/common';

import { SharedModule } from '../../shared.module';
import { AddButtonComponent } from './add-button.component';

describe('AddButtonComponent', () => {
  let shallow: Shallow<AddButtonComponent>;

  beforeEach(() => {
    shallow = new Shallow(AddButtonComponent, SharedModule).mockPipe(
      LanguagePipe,
      (key: string) => key
    );
  });

  describe('Button text', () => {
    it('should display given text', async () => {
      const { find } = await shallow.render({
        bind: {
          text: 'myadp-pay.DD_ADD_ACCOUNT'
        }
      });

      expect(find('adp-button').nativeElement.innerHTML).toContain('myadp-pay.DD_ADD_ACCOUNT');
    });
  });

  describe('Disable add button', () => {
    it('should not disable the button', async () => {
      const { findComponent } = await shallow.render({
        bind: {
          disableAdd: false
        }
      });

      expect(findComponent(ButtonComponent).disabled).toBeFalsy();
    });

    it('should disable the button', async () => {
      const { findComponent } = await shallow.render({
        bind: {
          disableAdd: true
        }
      });

      expect(findComponent(ButtonComponent).disabled).toBeTruthy();
    });
  });

  describe('Add button clicked', () => {
    it('should emit when clicked', async () => {
      const { find, outputs } = await shallow.render({
        bind: {
          text: 'Add something'
        }
      });
      find('adp-button').nativeElement.click();

      expect(outputs.added.emit).toHaveBeenCalledTimes(1);
    });
  });
});
