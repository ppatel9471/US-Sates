import { AbstractControl, FormControl, NG_VALIDATORS, Validator } from '@angular/forms';
import { Directive, Input } from '@angular/core';
import * as moment from 'moment';

// TODO: temp validator until synerg fixes date picker validation issues
// https://bitbucket.es.ad.adp.com/projects/AAC/repos/components/pull-requests/1403/overview
@Directive({
  selector: '[validDate][ngModel]',
  providers: [{ provide: NG_VALIDATORS, useExisting: ValidDateDirective, multi: true }]
})
export class ValidDateDirective implements Validator {
  @Input('dateFormat') format: string;

  validate(c: FormControl) {
    return validDate(this.format)(c);
  }
}

const validDate = (format: string = 'MM/DD/YYYY') => (control: AbstractControl) => {
  const date = control.value;
  const validPattern = /^(0[1-9]|1[012])\/(0[1-9]|[12][0-9]|3[01])\/(19|20)\d{2}$/.test(date);
  if (validPattern && moment(date, format).isValid()) {
    return null;
  }

  return {
    validDate: {
      message: 'myadp-pay.VALIDATION_VALID_DATE',
      placeholders: { date }
    }
  };
};
