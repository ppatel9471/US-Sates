import { camelCase, groupBy } from 'lodash';

import { Amount, PayStatementsDTO } from '@myadp/dto';

import {
  BANKING_NAME,
  deductionCategoryMetadata,
  DEDUCTIONS_CATEGORY_NAME,
  TAKE_HOME_ID
} from '../constants/deduction-category-metadata.const';
import { PayStatementsUI } from '../models/pay-statement-ui';
import { buildCalculatorLink } from './category-calculator-link.transform';
import { buildColorIterator, CategoryColorIterator } from './category-color-iterator.class';
import { buildOtherPayCategory } from './other-pay.transform';
import { buildCategory } from './take-home.transform';

export function transformDeductionsCategories(
  statementDetailsRaw: PayStatementsDTO.PayStatementDetailRaw
): PayStatementsUI.DeductionsCategory[] {
  let deductionCategoryDetails: PayStatementsDTO.DeductionCategoryDetails[] =
    statementDetailsRaw?.deductionCategoryDetails ?? [];
  const deductionsRaw: PayStatementsDTO.Deduction[] = statementDetailsRaw?.deductions ?? [];
  const groupedDeductions = groupDeductions(deductionsRaw);
  const colorIterator = buildColorIterator();

  if (!deductionCategoryDetails.length) {
    // 'deductionCategoryDetails' might come back missing if using
    // the legacy statement-details API
    deductionCategoryDetails = [{ deductionCategoryCodeName: DEDUCTIONS_CATEGORY_NAME }];
  }

  const categories: PayStatementsUI.DeductionsCategory[] = deductionCategoryDetails
    .filter((categoryRaw) => categoryRaw?.deductionCategoryCodeName?.trim() !== BANKING_NAME)
    .map((categoryRaw) => {
      const categoryCodeName: string = categoryRaw?.deductionCategoryCodeName;
      // Example: {id: 'Taxable Benefits' => 'taxableBenefits'}
      const categoryId: string = camelCase(categoryCodeName);
      const deductions = getDeductions(groupedDeductions[categoryId] ?? []);
      const amount =
        categoryRaw?.deductionCategoryTotalPeriodAmount ?? getCategoryTotal(deductions);
      const categoryMetadata = deductionCategoryMetadata[categoryId];
      const insightsTag = categoryMetadata.insightsTag;
      const category: PayStatementsUI.DeductionsCategory = {
        id: categoryId,
        name: categoryMetadata ? categoryMetadata.name : categoryCodeName,
        amount: amount,
        amountYTD:
          categoryRaw?.deductionCategoryTotalYTDAmount ?? getCategoryTotal(deductions, true),
        deductions: deductions,
        displayConfig: {
          ...getDisplayConfig(categoryMetadata, colorIterator),
          calculatorLink: buildCalculatorLink(categoryId, amount, deductions)
        }
      };
      if (insightsTag) {
        category.insightsTag = insightsTag;
      }

      return category;
    });
  return buildTakeHomeOtherCategory(categories, statementDetailsRaw);
}

export function buildTakeHomeOtherCategory(
  categories: PayStatementsUI.DeductionsCategory[],
  statementDetailsRaw: PayStatementsDTO.PayStatementDetailRaw
): PayStatementsUI.DeductionsCategory[] {
  categories.push(buildCategory(TAKE_HOME_ID, statementDetailsRaw));
  const otherPay = buildOtherPayCategory(statementDetailsRaw);
  if (otherPay) {
    categories.push(otherPay);
  }
  return sortCategories(categories);
}

function groupDeductions(
  deductions: PayStatementsDTO.Deduction[]
): Record<string, PayStatementsDTO.Deduction[]> {
  return groupBy(deductions, (deduction: PayStatementsDTO.Deduction) =>
    // If the deduction doesn't have a category, default to "Deductions".
    // This can happen when using the legacy statement-details API
    camelCase(deduction.deductionCategoryCodeName || DEDUCTIONS_CATEGORY_NAME)
  );
}

function getDeductions(
  deductions: PayStatementsDTO.Deduction[] = []
): PayStatementsUI.DeductionsCategoryItem[] {
  return (
    deductions
      .map((deduction) => {
        // Legacy statement-details API uses 'codeName' instead of 'CodeName'.
        // Since the store should reflect the data as accurately as possible,
        // 'null' and 'undefined' values shouldn't be lost
        const codeNameLegacy: string = deduction?.codeName;
        const name: string =
          codeNameLegacy === null || codeNameLegacy !== undefined
            ? codeNameLegacy
            : deduction?.CodeName;

        return {
          name: name?.trim() ?? name,
          amount: deduction?.deductionAmount,
          amountYTD: deduction?.deductionYTDAmount,
          preTax: deduction?.preTaxIndicator
        };
      })
      // filter "Bnkg" deductions because it's accounted for in payDistributions
      .filter((deduction) => deduction?.name !== 'Bnkg')
  );
}

export function sortCategories(
  categories: PayStatementsUI.DeductionsCategory[]
): PayStatementsUI.DeductionsCategory[] {
  return categories.sort(
    (d1: PayStatementsUI.DeductionsCategory, d2: PayStatementsUI.DeductionsCategory) => {
      // Make sure Take Home is last in the list
      if (!d1.displayConfig.rank || d1.id === TAKE_HOME_ID) {
        return 1;
      } else if (!d2.displayConfig.rank || d2.id === TAKE_HOME_ID) {
        return -1;
      } else {
        return d1.displayConfig.rank - d2.displayConfig.rank;
      }
    }
  );
}

function getDisplayConfig(
  metadata: Partial<PayStatementsUI.DeductionsCategory>,
  colorIterator: CategoryColorIterator
): { rank: number; color: string } {
  return {
    rank: metadata ? metadata.displayConfig.rank : undefined,
    color: metadata ? metadata.displayConfig.color : colorIterator.nextColor()
  };
}

// Manually calculate the category total if necessary
function getCategoryTotal(
  deductions: PayStatementsUI.DeductionsCategoryItem[],
  useYTD: boolean = false
): Amount {
  const categoryTotal: number =
    deductions.reduce((totalAmount: number, deduction: PayStatementsUI.DeductionsCategoryItem) => {
      const amount = deduction?.amount?.amountValue || 0;
      const amountYTD = deduction?.amountYTD?.amountValue || 0;

      return totalAmount + (useYTD ? amountYTD : amount);
    }, 0) || null;

  // Find the first deduction with a valid currencyCode
  const deductionWithCC = deductions?.find(
    (deduction) => !!(useYTD ? deduction?.amountYTD?.currencyCode : deduction?.amount?.currencyCode)
  );
  const currencyCode = useYTD
    ? deductionWithCC?.amountYTD?.currencyCode
    : deductionWithCC?.amount?.currencyCode;

  return {
    amountValue: categoryTotal,
    currencyCode: currencyCode
  };
}
