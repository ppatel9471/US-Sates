import { Component } from '@angular/core';

import { DirectDepositAccount } from '../../models/direct-deposit-account.model';
import { BaseStepComponent } from '../base-step/base-step.component';

@Component({
  selector: 'dd-direct-deposit-list',
  templateUrl: './direct-deposit-list.component.html'
})
export class DirectDepositListComponent extends BaseStepComponent {
  public canceledRequest(account: DirectDepositAccount): void {
    this.stepsStoreActions.cancelPendingRequest(account, true);
  }
}
