import {
  PdfStatement,
  StatementDetailItemType
} from '../../shared/models/pdf-viewer.model';
import { PayStatementsUI } from '../models/pay-statement-ui';

export function transformPdf(statements: PayStatementsUI.PayStatement[]): PdfStatement[] {
  return statements.map((statement) => {
    return {
      uri: statement?.statementImageUri,
      title: statement?.payDate,
      statementDetails: [
        {
          label: 'myadp-pay.PDF_VIEWER_SLIDEIN_PAY_DATE',
          value: statement?.payDate
        },
        {
          label: 'myadp-pay.PDF_VIEWER_SLIDEIN_GROSS_PAY',
          value: statement?.grossPay,
          type: StatementDetailItemType.CURRENCY
        },
        {
          label: 'myadp-pay.PDF_VIEWER_SLIDEIN_NET_PAY',
          value: statement?.netPay,
          type: StatementDetailItemType.CURRENCY
        }
      ]
    };
  });
}
