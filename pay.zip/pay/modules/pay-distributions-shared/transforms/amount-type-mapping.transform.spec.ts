import { Amount } from '@myadp/dto';

import { DistributionOptions } from '../models/pay-distributions-ui';
import { mapAmountType } from './amount-type-mapping.transform';

describe('mapAmountType', () => {
  it('should map remaining type', () => {
    const amountInfo = {
      type: DistributionOptions.REMAINING,
      percentage: 15,
      amount: { amountValue: 145, currencyCode: 'USD' }
    };

    expect(mapAmountType(amountInfo)).toEqual({
      distributionType: DistributionOptions.REMAINING,
      percentageAmount: null,
      flatAmount: null
    });
  });

  it('should map percentage type', () => {
    const amountInfo = {
      type: DistributionOptions.PERCENTAGE,
      percentage: 15,
      amount: { amountValue: null, currencyCode: 'USD' } as Amount
    };

    expect(mapAmountType(amountInfo)).toEqual({
      distributionType: DistributionOptions.PERCENTAGE,
      percentageAmount: 15,
      flatAmount: null
    });
  });

  it('should map flat type', () => {
    const amountInfo = {
      type: DistributionOptions.FLAT,
      percentage: 15,
      amount: { amountValue: 194.28, currencyCode: 'USD' }
    };

    expect(mapAmountType(amountInfo)).toEqual({
      distributionType: DistributionOptions.FLAT,
      percentageAmount: null,
      flatAmount: { amountValue: 194.28, currencyCode: 'USD' }
    });
  });
});
