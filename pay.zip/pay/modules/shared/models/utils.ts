import * as moment from 'moment';

export function formatDate(dateStr: string, format: string = 'll') {
  const date = moment(dateStr, 'YYYY-MM-DD', true);
  return date.isValid() ? date.format(format) : null;
}
