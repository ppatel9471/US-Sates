import { Amount, LegacyCodeType, PayDistributionsDTO } from '@myadp/dto';

import { WorkflowUI } from '../../shared/models/workflow-ui.model';
import { CountryDetails } from './country';

export const mk = PayDistributionsDTO.metaKey;

export enum PayDistributionsStoreSlice {
  PAY_DISTRIBUTIONS = 'payDistributions',
  PAY_DISTRIBUTIONS_META = 'payDistributionsMeta'
}

export enum DistributionOptions {
  FLAT = 'flat',
  PERCENTAGE = 'percentage',
  REMAINING = 'remaining'
}

export type DistributionType =
  | DistributionOptions.FLAT
  | DistributionOptions.PERCENTAGE
  | DistributionOptions.REMAINING;

export interface PayDistributionsStoreState {
  [PayDistributionsStoreSlice.PAY_DISTRIBUTIONS]?: PayDistributionsUI.PayDistributionState;
  [PayDistributionsStoreSlice.PAY_DISTRIBUTIONS_META]?: PayDistributionsUI.PayDistributionStateMeta;
}

export namespace PayDistributionsUI {
  export interface PayDistributionState {
    hasChangePermission: boolean;
    distributions: PayDistribution[];
    itemID?: string;
    country?: CountryDetails;
  }

  export interface PayDistributionStateMeta {
    meta: PayDistributionMeta;
  }

  export type PayDistribution = WorkflowUI.WorkflowData<PayDistributionDetails, PendingEvent>;

  export interface PayDistributionDetails {
    readonly id?: string;
    codeValueData?: CodeValueData;
    accountNumber?: string;
    routingNumber?: string;
    transitNumber?: string;
    distributionType?: DistributionType;
    percentageAmount?: number;
    precedence?: string;
    precedenceCode?: string;
    flatAmount?: Amount;
    accountName?: string;
    accountTypeName?: string;
    bankName?: string;
    institution?: string;
    prenoteIndicator?: boolean;
  }

  export interface CodeValueData {
    itemID?: string;
    shortName?: string;
    longName?: string;
    accountCode?: string;
  }

  export type PendingEvent = WorkflowUI.PendingEvent<WorkflowUI.ChangeType | 'pruned'> & {
    altWorkflowMessage?: string; // WFN-style workflow message
  };

  export interface PayDistributionMeta {
    // start from `distributionInstructions` in the meta response
    maxAccounts?: number; // maxItems
    minAccounts?: number; // minItems
    termsAgreementMsg?: string; // helperMessage.messageTxt
    showDistributionPercentage?: boolean; // distributionPercentage
    canValidateBankInfo?: boolean; // prenoteBypassIndicator
    forceRemaining?: {
      enabled?: boolean;
      msg?: string; // remainingBalanceIndicator.helperMessage.messageTxt
    };
    distributionAmount?: {
      min?: number; // distributionAmount.amountValue.minAmountValue
    };
    accountName?: {
      enabled?: boolean; // depositAccount.financialAccount.accountName
      maxLength?: number; // depositAccount.financialAccount.accountName.maxLength
    };
    accountTypeList?: LegacyCodeType[]; // depositAccount.financialAccount.typeCode.codeList
    codeListHref?: string;
    isEmailConfigured?: boolean; // data.eventContext.worker.associateOID.helperMessage.messageTxt
    paymentMethodCodes?: {
      // paymentMethodCode; used for DailyPay / EWA
      codeList?: LegacyCodeType[];
      readOnly?: boolean;
    };
    banks?: LegacyCodeType[];
  }
}
