import { Component, Input } from '@angular/core';

@Component({
  selector: 'paylens-statement-details-tabs',
  styleUrls: ['./statement-details-tabs.component.scss'],
  templateUrl: './statement-details-tabs.component.html'
})
export class PaylensStatementDetailsTabsComponent {
  @Input() public isMobileView: boolean = false;
  public onInsightsTab: boolean = false;

  public clickInsightsTab(clicked: boolean) {
    this.onInsightsTab = clicked;
  }
}
