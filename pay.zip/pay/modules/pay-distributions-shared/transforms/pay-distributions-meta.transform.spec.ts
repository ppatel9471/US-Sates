import { PayDistributionsDTO } from '@myadp/dto';
import { MOCK_PAY_DISTRIBUTIONS_META_RESPONSE } from '@specHelpers/pay/pay-distributions/pay-distributions-meta';

import { PayDistributionsUI } from '../models/pay-distributions-ui';
import { transformDistributionsMeta } from './pay-distributions-meta.transform';

const transformedDistributionsMeta: PayDistributionsUI.PayDistributionMeta = {
  maxAccounts: 4,
  minAccounts: 0,
  termsAgreementMsg: 'terms message',
  showDistributionPercentage: true,
  canValidateBankInfo: true,
  forceRemaining: {
    enabled: true,
    msg: 'force remaining balance msg'
  },
  distributionAmount: {
    min: 0
  },
  accountName: {
    enabled: true,
    maxLength: 30
  },
  accountTypeList: null,
  codeListHref:
    '/codelists/payroll/v3/payroll-instruction-management/directdepositdeductioncodevalues?$filter=paygroup eq %27foo%27',
  isEmailConfigured: true,
  paymentMethodCodes: {
    codeList: [{ shortName: 'DailyPay', codeValue: 'DP2' }],
    readOnly: false
  }
};

const codeListItems = [
  {
    codeValue: 'C',
    shortName: 'Checking',
    longName: 'Checking'
  },
  {
    codeValue: 'S',
    shortName: 'Savings',
    longName: 'Savings'
  }
];

const MOCK_META_CODELIST: PayDistributionsDTO.MetaResponse = {
  meta: {
    '/data/transforms': [
      {
        '/payDistribution/distributionInstructions/depositAccount/financialAccount/typeCode': {
          codeList: {
            links: [
              {
                href: '/codelists/payroll/v3/payroll-instruction-management/directdepositdeductioncodevalues?$filter=paygroup eq %27foo%27'
              }
            ],
            listItems: codeListItems
          }
        }
      }
    ]
  }
};

describe('transformDistributionsMeta', () => {
  let metaFields: PayDistributionsUI.PayDistributionMeta;
  const emptyMetaRes = {
    meta: {
      '/data/transforms': [{}]
    }
  };

  beforeEach(() => {
    metaFields = transformDistributionsMeta(MOCK_PAY_DISTRIBUTIONS_META_RESPONSE);
  });

  it('should have a list of banks when country is canada', () => {
    const bankMeta = {
      meta: {
        '/data/transforms': [
          {
            '/payDistributions/distributionInstructions/depositAccount/financialParty/nameCode': {
              codeList: {
                listItems: [
                  {
                    codeValue: '0001',
                    shortName: 'Testbank'
                  }
                ]
              }
            }
          }
        ]
      }
    };

    expect(transformDistributionsMeta(bankMeta, 'CA')).toEqual(
      jasmine.objectContaining({
        banks: [
          {
            codeValue: '0001',
            shortName: 'Testbank'
          }
        ]
      })
    );
  });

  describe('showDistributionPercentage', () => {
    it('should set showDistributionPercentage to true', () => {
      const percentageMeta = {
        meta: {
          '/data/transforms': [
            {
              '/payDistribution/distributionInstructions/distributionPercentage': {}
            }
          ]
        }
      };

      expect(transformDistributionsMeta(percentageMeta)).toEqual(
        jasmine.objectContaining({
          showDistributionPercentage: true
        })
      );
    });

    it('should set showDistributionPercentage to false', () => {
      expect(transformDistributionsMeta(emptyMetaRes)).toHaveProperty(
        'showDistributionPercentage',
        false
      );
    });
  });

  describe('accountName', () => {
    it('should default to maxLength of 30', () => {
      expect(transformDistributionsMeta(emptyMetaRes)).toHaveProperty('accountName.maxLength', 30);
    });
  });

  it('should transform distributions meta', () => {
    expect(metaFields).toEqual(transformedDistributionsMeta);
  });

  it('should assign accountTypeList from distributions meta', () => {
    const metaFieldsCodeList = transformDistributionsMeta(MOCK_META_CODELIST);
    expect(metaFieldsCodeList.accountTypeList).toEqual(codeListItems);
  });
});
