import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { CoreModule } from '@synerg/angular-components';
import { AlertModule } from '@synerg/components/alert';
import { CarouselModule } from '@synerg/components/carousel';

import { MyAdpCommonModule } from '@myadp/common';
import {
  NOTIFICATION_EVENT_NAME_CODES,
  NotificationsService,
  ThingsToDoSharedModule
} from '@myadp/thingstodo-shared';
import { TaskModule } from '@myadp/thingstodo-shared/modules/task/task.module';

import { SharedModule } from '../../shared/shared.module';
import { DeductionDetailsAccountComponent } from './components/deduction-tasks-details-account/deduction-tasks-details-account.component';
import { DeductionDetailsComponent } from './components/deduction-tasks-details/deduction-tasks-details.component';

@NgModule({
  imports: [
    CommonModule,
    MyAdpCommonModule,
    ThingsToDoSharedModule,
    TaskModule,
    CarouselModule,
    AlertModule,
    SharedModule,
    CoreModule
  ],
  declarations: [DeductionDetailsComponent, DeductionDetailsAccountComponent]
})
export class DeductionTasksModule {
  constructor(private notificationsService: NotificationsService) {
    [
      NOTIFICATION_EVENT_NAME_CODES.pay.worker_general_deduction_instruction_start,
      NOTIFICATION_EVENT_NAME_CODES.pay.worker_general_deduction_instruction_change,
      NOTIFICATION_EVENT_NAME_CODES.pay.worker_general_deduction_instruction_stop
    ].forEach((event) =>
      this.notificationsService.setTaskDetailsRoute(event, DeductionDetailsComponent)
    );
  }
}
