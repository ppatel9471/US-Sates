import { Shallow } from 'shallow-render';

import { LanguagePipe } from '@myadp/common';
import { PayPermissionService } from '@myadp/pay-shared';

import { TaxWithholdingManagementTileModule } from '../../tax-withholding-management-tile.module';
import { TaxWithholdingManagementTileComponent } from './tax-withholding-management-tile.component';


describe('TaxWithholdingManagementTileComponent', () => {
  let shallow: Shallow<TaxWithholdingManagementTileComponent>;

  beforeAll(() => {
    shallow = new Shallow(TaxWithholdingManagementTileComponent, TaxWithholdingManagementTileModule)
      .mockPipe(LanguagePipe, (key) => key)
      .mock(PayPermissionService, {
        getTaxWithholdingVersion: () => 'v2'
      });
  });

  it('should display the summary view for V2', async () => {
    const { find } = await shallow.render();

    expect(find('pay-summary-view')).toHaveFound(1);
    expect(find('.tile-content').nativeElement.innerHTML).not.toContain('myadp-pay.TWM_UNSUPPORTED_VERSION');
  });

  it('should display an error for V1', async () => {
    shallow.mock(PayPermissionService, {
      getTaxWithholdingVersion: () => 'v1'
    });
    const { find } = await shallow.render();

    expect(find('pay-summary-view')).toHaveFound(0);
    expect(find('.tile-content').nativeElement.innerHTML).toContain('myadp-pay.TWM_UNSUPPORTED_VERSION');
  });

});
