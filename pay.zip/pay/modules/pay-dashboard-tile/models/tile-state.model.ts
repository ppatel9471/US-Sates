import { PayStatementModel } from './pay-statement.model';
import { DeductionCategoryItem } from './pay-category-constants';

export interface TileState {
  hasError: boolean;
  unmask: boolean ;
  payDonutData: Array<DeductionCategoryItem>;
  payDetailsObj: PayStatementModel;
  hasNoData: boolean;
  netPay?: string;
  grossPay?: string;
}
