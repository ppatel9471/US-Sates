export enum COUNTRY {
  US = 'US',
  CA = 'CA'
}
export interface CountryDetails {
  shortName: COUNTRY;
  currencyCode: string;
}

export type CountryConfig = Record<COUNTRY, CountryDetails>;

export const COUNTRY_CONFIG: CountryConfig = {
  [COUNTRY.US]: {
    shortName: COUNTRY.US,
    currencyCode: 'USD'
  },
  [COUNTRY.CA]: {
    shortName: COUNTRY.CA,
    currencyCode: 'CAD'
  }
};
