import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ClientDeviceService, LoggerFactory } from '@espresso/core';
import { saveAs } from 'file-saver';
import * as log4javascript from 'log4javascript';
import { Observable } from 'rxjs';

import { ROLE, UserIdentityService } from '@myadp/common';
import { BaseStore, FindSffoService, PAY_SFFO } from '@myadp/pay-shared';

import { PayStatementsUI } from '../../pay-statements-shared/models/pay-statement-ui';

export enum PayStatementsDownloadStoreSlice {
  PAY_STATEMENTS_DOWNLOAD = 'payStatementsDownload'
}

export interface Statement {
  id: number;
  statementImageUri: string;
}

export interface PayStatementsDownloadStoreState {
  [PayStatementsDownloadStoreSlice.PAY_STATEMENTS_DOWNLOAD]?: StatementState;
}

interface StatementState {
  statements: Statement[];
}

export const MAX_NUM_DOWNLOAD = 10;
const PAY_STATEMENT_ZIP_FILE_NAME = 'pay_statements.zip';

@Injectable({
  providedIn: 'root'
})
export class PayStatementsDownloadStore extends BaseStore<PayStatementsDownloadStoreState> {
  private hasDownloadPermission: boolean;
  private downloadApi: string;
  private logger: log4javascript.Logger;

  constructor(
    private findSffoService: FindSffoService,
    private httpClient: HttpClient,
    private loggerFactory: LoggerFactory,
    private userIdentityService: UserIdentityService,
    private clientDeviceService: ClientDeviceService
  ) {
    super({
      [PayStatementsDownloadStoreSlice.PAY_STATEMENTS_DOWNLOAD]: {
        data: undefined,
        loading: false,
        error: {}
      }
    });
    this.logger = this.loggerFactory.getLogger(
      'myadp.pay.pay-download-store.PayStatementsDownloadStore'
    );
  }

  public canDownload(): boolean {
    if (this.clientDeviceService.isNative()) {
      return false;
    }

    if (this.hasDownloadPermission !== undefined) {
      return this.hasDownloadPermission;
    }
    const { sffo, href } = this.findSffoService.findSffo([
      { sffo: PAY_SFFO.PAY_STATEMENT_MULTIPLE_DOWNLOAD.sffo },
      { sffo: PAY_SFFO.PAY_STATEMENT_MULTIPLE_DOWNLOAD_LEGACY.sffo }
    ]);

    this.downloadApi = href;

    this.hasDownloadPermission = !!sffo;
    return this.hasDownloadPermission;
  }

  public updateSelected(checked: boolean, selectedStatement: PayStatementsUI.PayStatement): void {
    const { id, statementImageUri } = selectedStatement;
    const currentState = this.statements;

    // if statement already exist we need to remove it
    const statementExist = currentState.find((statement) => statement.id === id);
    const updatedStateValue = checked
      ? currentState
      : currentState.filter((statement) => statement.id !== statementExist.id);

    const nextState = checked
      ? [...updatedStateValue, { id, statementImageUri }]
      : updatedStateValue;
    this.update(PayStatementsDownloadStoreSlice.PAY_STATEMENTS_DOWNLOAD, {
      data: {
        statements: nextState
      }
    });
  }

  public clear(): void {
    this.update(PayStatementsDownloadStoreSlice.PAY_STATEMENTS_DOWNLOAD, {
      data: null
    });
  }

  public statements$(): Observable<Statement[]> {
    return this.getData$(PayStatementsDownloadStoreSlice.PAY_STATEMENTS_DOWNLOAD, 'statements', []);
  }

  public loading$(): Observable<boolean> {
    return this.isSliceLoading$(PayStatementsDownloadStoreSlice.PAY_STATEMENTS_DOWNLOAD);
  }

  public errors$(): Observable<boolean> {
    return this.hasError$(
      PayStatementsDownloadStoreSlice.PAY_STATEMENTS_DOWNLOAD,
      'downloadError'
    );
  }

  public async download(): Promise<void> {
    const statements: Statement[] = this.statements;
    const statementImageURIs = statements.map((statement) => statement.statementImageUri);

    this.update(PayStatementsDownloadStoreSlice.PAY_STATEMENTS_DOWNLOAD, {
      error: {
        downloadError: false
      },
      loading: true
    });

    const headers = new HttpHeaders({
      'Content-Type': 'application/json;charset=UTF-8',
      'roleCode': ROLE.EMPLOYEE
    });

    return this.userIdentityService.getAoid().then((aoid: string) => {
      return this.httpClient
        .post(this.downloadApi, this.getRequestPayload(aoid, statementImageURIs), {
          responseType: 'arraybuffer',
          headers
        })
        .toPromise()
        .then((response: ArrayBuffer) => this.forceDownload(response))
        .catch((error) => {
          this.logger.error(`Error downloading statements: ${error}`);

          this.update(PayStatementsDownloadStoreSlice.PAY_STATEMENTS_DOWNLOAD, {
            error: {
              downloadError: true
            }
          });
        })
        .finally(() => {
          this.update(PayStatementsDownloadStoreSlice.PAY_STATEMENTS_DOWNLOAD, {
            loading: false
          });
        });
    });
  }

  private getRequestPayload(aoid: string, statementUris: string[]) {
    const associateOID = { associateOID: aoid };
    return {
      events: [
        {
          originator: associateOID,
          actor: associateOID,
          data: {
            eventContext: associateOID,
            transform: {
              eventStatusCode: {
                codeValue: 'submit'
              },
              payStatementImageIDs: statementUris
            }
          }
        }
      ]
    };
  }

  private forceDownload(response: ArrayBuffer) {
    const blob = new Blob([response], { type: 'application/zip' });
    saveAs(blob, PAY_STATEMENT_ZIP_FILE_NAME);
  }

  private get statements(): Statement[] {
    return this.getData(PayStatementsDownloadStoreSlice.PAY_STATEMENTS_DOWNLOAD, 'statements', []);
  }
}
