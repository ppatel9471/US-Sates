import { Injectable } from '@angular/core';
import { WindowImplService as WindowService } from '@myadp/common/services/window-impl.service';

import { CustomElementsTags } from '../model/web-components.model';

@Injectable({
  providedIn: 'root'
})
export class WebComponentsService {
  constructor(private windowService: WindowService) {}

  // returns true if constructor for the named custom element is returned
  // or false if there is no custom element definition
  public hasRegistryDefinition(customElement: CustomElementsTags): boolean {
    return !!(this.windowService.getWindow().customElements as CustomElementRegistry).get(
      customElement
    );
  }
}
