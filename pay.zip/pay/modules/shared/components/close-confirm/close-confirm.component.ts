import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'close-confirm',
  templateUrl: './close-confirm.component.html'
})
export class CloseConfirmComponent {
  @Input() public size: string = 'lg';
  @Input() public title?: string = 'myadp-pay.SHARED_EXIT_TITLE';
  @Input() public content: string;
  @Input() public cancelText?: string = 'common.CANCEL';
  @Input() public confirmText?: string = 'common.EXIT';
  @Input() public closeable?: boolean = true;

  @Output() public cancel = new EventEmitter<void>();
  @Output() public confirm = new EventEmitter<void>();

  public cancelButton(): void {
    this.cancel.emit();
  }

  public confirmButton(): void {
    this.confirm.emit();
  }
}
