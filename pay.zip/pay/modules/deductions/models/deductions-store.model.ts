import { PayDeductionsUI } from '../../pay-deductions-shared/models/pay-deductions-ui';
import { WorkflowUI } from '../../shared/models/workflow-ui.model';
import { DeductionForm } from './deduction-form.model';

export interface DeductionsStoreState {
  formData?: DeductionForm;
  changedDeductionDetails?: PayDeductionsUI.DeductionDetails;
  changes?: DeductionChanges;
  permissions?: Record<WorkflowUI.ChangeType, boolean>;
}

export interface DeductionChanges {
  changeType?: WorkflowUI.ChangeType;
  deductionDetails?: PayDeductionsUI.DeductionDetails;
}
