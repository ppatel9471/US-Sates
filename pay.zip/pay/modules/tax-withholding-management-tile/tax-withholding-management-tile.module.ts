import { NgModule } from '@angular/core';
import { CoreModule } from '@synerg/angular-components';
import { AlertModule } from '@synerg/components/alert';
import { BusyIndicatorModule } from '@synerg/components/busy-indicator';
import { ButtonModule } from '@synerg/components/button';
import { ListViewModule } from '@synerg/components/list-view';
import { ModalModule } from '@synerg/components/modal';
import { PopoverModule } from '@synerg/components/popover';
import { SelectModule } from '@synerg/components/select';

import { MyAdpCommonModule } from '@myadp/common';

import { CustomContentSharedModule } from '../custom-content-shared/custom-content-shared.module';
import { SharedModule } from '../shared/shared.module';
import { TaxWithholdingManagementModule } from '../tax-withholding-management/tax-withholding-management.module';
import { StartButtonComponent } from './components/start-button/start-button.component';
import { StateSelfSelectComponent } from './components/state-self-select/state-self-select.component';
import { SummaryViewComponent } from './components/summary-view/summary-view.component';
import { TaxWithholdingManagementTileComponent } from './components/tax-withholding-management-tile/tax-withholding-management-tile.component';

@NgModule({
  imports: [
    MyAdpCommonModule,
    BusyIndicatorModule,
    ButtonModule,
    SelectModule,
    ModalModule,
    PopoverModule,
    SharedModule,
    AlertModule,
    TaxWithholdingManagementModule,
    ListViewModule,
    CustomContentSharedModule,
    CoreModule
  ],
  declarations: [
    TaxWithholdingManagementTileComponent,
    SummaryViewComponent,
    StartButtonComponent,
    StateSelfSelectComponent
  ],
  exports: [TaxWithholdingManagementTileComponent]
})
export class TaxWithholdingManagementTileModule {
  static components = {
    default: TaxWithholdingManagementTileComponent
  };
}
