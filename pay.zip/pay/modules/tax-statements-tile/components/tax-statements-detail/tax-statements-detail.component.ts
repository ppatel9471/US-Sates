import { Component, Input, OnInit } from '@angular/core';

import { LanguageService } from '@myadp/common';
import { WorkerTaxStatementsDTO } from '@myadp/dto';

import { StatementType } from '../../../shared/models/pdf-viewer.model';
import { TaxStatementsType } from '../../models/tax-statements.model';
import { showEmployerName } from '../../store/tax-statements.store';

@Component({
  selector: 'tax-statements-detail',
  templateUrl: 'tax-statements-detail.component.html'
})
export class TaxStatementsDetailComponent implements OnInit {
  public statementType = StatementType;
  public ariaLabelForViewStatement: string;
  public useAudioEye: boolean;
  @Input() statement: WorkerTaxStatementsDTO.WorkerTaxStatement;
  showEmployerName = showEmployerName;

  constructor(private languageService: LanguageService) {}

  ngOnInit(): void {
    const { employerName, form, statementYear } = this.statement;
    const unknownText = this.languageService.get('common.UNKNOWN');

    this.useAudioEye = [TaxStatementsType.W2, TaxStatementsType.W2_ALT].includes(
      this.statement?.form?.code
    );
    this.ariaLabelForViewStatement = this.languageService.get('myadp-pay.PAY_VIEW_STATEMENT_ARIA', {
      form: form?.code || unknownText,
      employerName: employerName || unknownText,
      year: statementYear?.year || unknownText
    });
  }
}
