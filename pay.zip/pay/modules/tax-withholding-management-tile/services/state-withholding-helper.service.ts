import { Injectable } from '@angular/core';
import { LoggerFactory } from '@espresso/core';
import { get } from 'lodash';
import * as log4javascript from 'log4javascript';
import * as moment from 'moment';

import { PayPermissionService } from '@myadp/pay-shared';

import { Info, WithholdingInfo, WithholdingItem, WithholdingType } from '../../../models/formatted-tax-withholding.model';
import { FEDERAL_STATES, getState, StateModel, STATES } from '../../../models/states.model';
import { PendingEvent } from '../../../models/tax-withholding.model';
import { UsStateTaxWithholdingElections } from '../../../models/us-state-tax-withholding-election.model';
import { StateWithholdingTransformService } from '../../../modules/shared/services/state-withholding-transform.service';
import { TaxWithholdingStore } from '../../../services/tax-withholding.store';
import { MaritalStatus, MaritalStatus2019 } from '../../tax-withholding-management/us/fed/models/fed-marital-status.enum';
import { FedMaritalStatusControl } from '../../tax-withholding-management/us/fed/models/fed-wizard.model';
import { JurisdictionFactoryService } from './jurisdiction-factory.service';

@Injectable({
  providedIn: 'root'
})
export class StateWithholdingHelperService {
  private logger: log4javascript.Logger;

  constructor(
    private payPermissionService: PayPermissionService,
    private stateWithholdingTransformService: StateWithholdingTransformService,
    private taxWithholdingStore: TaxWithholdingStore,
    private jurisdictionFactory: JurisdictionFactoryService,
    loggerFactory: LoggerFactory
  ) {
    this.logger = loggerFactory.getLogger(
      'myadp.pay.tax-withholding-management-tile.state-withholding-helper.service'
    );
  }

  public getWithholdingModel(withholdingData: UsStateTaxWithholdingElections): WithholdingInfo {
    const withholdingItems = this.getWithholdingItems(withholdingData);
    const hasElections = withholdingItems.length > 0;
    const pendingEvents = this.getPendingEvents(withholdingData);

    return {
      withholdingItems,
      type: WithholdingType.STATE,
      hasElections,
      pendingEvents
    };
  }

  public showNotice(item: WithholdingItem): boolean {
    return (
      !item.pendingEvents &&
      !item.isFlatRate &&
      !item.isNoIncomeTax &&
      moment(item.effectiveDate).isAfter(moment(), 'day')
    );
  }

  public getWithholdingItems(withholdingData: UsStateTaxWithholdingElections): WithholdingItem[] {
    const withholdingItems: WithholdingItem[] =
      this.stateWithholdingTransformService.getWithholdingItems(withholdingData);

    withholdingItems.forEach((withholding) => {
      const state: StateModel = get(withholding, 'state');
      const { longName, shortName } = { ...state };
      withholding.isNoIncomeTax = this.isNoIncomeState(longName);
      withholding.isFlatRate = this.isFlatRateState(shortName);
      // state is uneditable if state is locked or user has no change permission
      withholding.isUneditable =
        withholding.isLocked || !this.payPermissionService.hasStateTaxWithholdingChangePermission();
      withholding.isUnsupported = !this.isStateSupported(longName);
      withholding.invalidFederalDependency = this.hasInvalidFederalDependency(shortName);
      withholding.allowEdit = this.isStateEditable(withholding);
      withholding.showEffectiveDate = this.showNotice(withholding);

      withholding.info = this.getInfo(withholding);
    });

    return withholdingItems;
  }

  public isNoIncomeState(longName: string): boolean {
    return get(
      STATES.find((state) => state.longName === longName),
      'noIncomeState'
    );
  }

  public isFlatRateState(shortName: string): boolean {
    return get(
      STATES.find((state) => state.shortName === shortName),
      'flatRateState'
    );
  }

  public isStateSupported(longName: string): boolean {
    const state = getState(longName) ?? '';
    if (!state) {
      this.logger.warn(
        'isStateSupported',
        `Tax withholding wizard experience is not supported for "${longName}".`
      );
      return false;
    }
    return this.jurisdictionFactory.getStepComponents(state) !== undefined;
  }

  public hasInvalidFederalDependency(shortName: string): boolean {
    const fedMaritalStatus =
      this.taxWithholdingStore.getFederalWizard()?.maritalStatus?.[
        FedMaritalStatusControl.MARITAL_STATUS
      ];
    if (['CO2019', 'ND2019', 'NM2019', 'UT2019'].includes(shortName)) {
      return !Object.values(MaritalStatus2019).includes(fedMaritalStatus as MaritalStatus2019);
    } else if (FEDERAL_STATES.includes(shortName)) {
      return !Object.values(MaritalStatus).includes(fedMaritalStatus as MaritalStatus);
    } else {
      return false;
    }
  }

  public isStateEditable(withholdingItem: WithholdingItem): boolean {
    return !(
      withholdingItem.isUnsupported ||
      withholdingItem.isNoIncomeTax ||
      withholdingItem.isUneditable ||
      withholdingItem.lockedOutMessage ||
      withholdingItem.isFlatRate ||
      withholdingItem.invalidFederalDependency
    );
  }

  private getPendingEvents(withholdingData: UsStateTaxWithholdingElections): PendingEvent {
    return get(withholdingData, 'usStateTaxWithholdingElections[0].workflowData.pendingEvents');
  }

  private getInfo(withholdingItem: WithholdingItem): Info {
    if (withholdingItem.isNoIncomeTax) {
      return {
        type: 'success',
        title: 'myadp-pay.TAXWITHHOLDING_CARD_NO_INCOME_TAX_TITLE',
        message: 'myadp-pay.TAXWITHHOLDING_CARD_NO_INCOME_TAX_MESSAGE'
      };
    } else if (withholdingItem.isUnsupported) {
      return {
        type: 'info',
        title: 'myadp-pay.TAXWITHHOLDING_CARD_UNSUPPORTED_TITLE',
        message: 'myadp-pay.TAXWITHHOLDING_CARD_UNSUPPORTED_MESSAGE'
      };
    } else if (withholdingItem.isFlatRate) {
      return {
        type: 'info',
        message: 'myadp-pay.TAXWITHHOLDING_CARD_FLAT_RATE_MESSAGE'
      };
    } else if (withholdingItem.lockedOutMessage) {
      return {
        type: 'info',
        title: 'myadp-pay.TAXWITHHOLDING_CARD_NOEDIT_TITLE',
        message: `myadp-pay.TAXWITHHOLDING_CARD_NOEDIT_${withholdingItem.lockedOutMessage}_MESSAGE`
      };
    } else if (withholdingItem.isUneditable) {
      return {
        type: 'info',
        title: 'myadp-pay.TAXWITHHOLDING_CARD_NOEDIT_TITLE',
        message: 'myadp-pay.TAXWITHHOLDING_CARD_NOEDIT_MESSAGE'
      };
    } else if (withholdingItem.invalidFederalDependency) {
      return {
        type: 'warning',
        message: 'myadp-pay.TAXWITHHOLDING_CARD_INVALID_FEDERAL_DEPENDENCY'
      };
    }
    return null;
  }
}
