import { TestBed } from '@angular/core/testing';
import { Mock } from 'ts-mockery';
import { CurrencyPipe } from '@angular/common';
import { LanguageService } from '@myadp/common';

import { LocalWithholdingHelperService } from './local-withholding-helper.service';
import { UsLocalTaxInstruction } from '../../../models/us-local-tax-instruction.model';
import { WithholdingFormatterService } from '../../shared/services/withholding-formatter.service';
import { ValueFormatterService } from '../../shared/services/value-formatter.service';

describe('LocalWithholdingHelperService', () => {
  let service: LocalWithholdingHelperService;
  let mockLocal: UsLocalTaxInstruction;
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        LocalWithholdingHelperService,
        WithholdingFormatterService,
        ValueFormatterService,
        CurrencyPipe,
        {
          provide: LanguageService,
          useValue: Mock.of<LanguageService>({ get: () => '' })
        }
      ]
    });
  });

  beforeEach(() => {
    service = TestBed.inject(LocalWithholdingHelperService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should show allowances when it is >=0', () => {
    mockLocal = createMockLocal({
      taxAllowanceQuantity: 0
    });
    const summaryItems = service.formatLocalWithholding([mockLocal]).withholdingItems[0]
      .summaryItems;
    expect(summaryItems).toEqual(
      jasmine.arrayContaining([
        {
          displayName: 'TOTAL_ALLOWANCES',
          displayValue: 0
        }
      ])
    );
  });

  it('should hide allowances when it is not in the response or it is <0', () => {
    mockLocal = createMockLocal({
      taxAllowanceQuantity: -1
    });
    let summaryItems = service.formatLocalWithholding([mockLocal]).withholdingItems[0].summaryItems;
    expect(summaryItems).toEqual([]);
    mockLocal = createMockLocal({});
    summaryItems = service.formatLocalWithholding([mockLocal]).withholdingItems[0].summaryItems;
    expect(summaryItems).toEqual([]);
  });

  function createMockLocal(data: any) {
    return {
      localCode: { codeValue: 1, longName: 'GA' },
      ...data
    };
  }
});
