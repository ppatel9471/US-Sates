import { Pipe, PipeTransform } from '@angular/core';

import {
  ADJUSTMENTS_ID,
  TAKE_HOME_ID
} from '../../pay-statements-shared/constants/deduction-category-metadata.const';
import { PayStatementsUI } from '../../pay-statements-shared/models/pay-statement-ui';

@Pipe({ name: 'deductionsDataSelector', pure: true })
export class DeductionsDataSelectorPipe implements PipeTransform {
  public transform(
    deductionCategories: PayStatementsUI.DeductionsCategory[],
    useYTD: boolean
  ): PayStatementsUI.DeductionsCategory[] {
    // remove adjustments and Take Home category and breakdown when on YTD
    return useYTD
      ? deductionCategories
        .map((category) => ({
          ...category,
          deductions: category?.id === TAKE_HOME_ID ? [] : category?.deductions
        }))
        .filter((category) => category.id !== ADJUSTMENTS_ID && category.id !== TAKE_HOME_ID)
      : deductionCategories;
  }
}
