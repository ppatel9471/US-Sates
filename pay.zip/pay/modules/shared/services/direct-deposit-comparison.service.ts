import { Injectable } from '@angular/core';
import { isEqual } from 'lodash';

import { DirectDepositAccount } from '../../direct-deposit/models/direct-deposit-account.model';
import {
  DistributionOptions,
  PayDistributionsUI
} from '../../pay-distributions-shared/models/pay-distributions-ui';
import { DirectDepositComparisonDetails } from '../models/workflow-comparison-details.model';
import { WorkflowUI } from '../models/workflow-ui.model';
import { WorkflowComparisonService } from './workflow-comparison.service';

@Injectable({
  providedIn: 'root'
})
export class DirectDepositComparisonService extends WorkflowComparisonService<
DirectDepositAccount,
DirectDepositComparisonDetails
> {
  public getComparisonData(
    account: DirectDepositAccount,
    hasMultipleAccounts?: boolean
  ): [DirectDepositComparisonDetails, DirectDepositComparisonDetails] {
    const isWisely = account?.isWisely;
    const currentData = this.mapToComparisonDetails(
      account?.currentData,
      hasMultipleAccounts,
      isWisely
    );
    const pendingData = this.mapToComparisonDetails(
      account?.pendingData,
      hasMultipleAccounts,
      isWisely
    );

    const actionTypeLookup: Record<
    WorkflowUI.ChangeType,
    () => [DirectDepositComparisonDetails, DirectDepositComparisonDetails]
    > = {
      add: () => [{ addOrDeleteMsg: 'myadp-pay.DD_WORKFLOW_COMPARISON_PENDING_ADD' }, pendingData],
      delete: () => [
        currentData,
        { addOrDeleteMsg: 'myadp-pay.DD_WORKFLOW_COMPARISON_PENDING_DELETE' }
      ],
      edit: () => [
        currentData,
        this.getDifferences([currentData, pendingData], hasMultipleAccounts)
      ]
    };

    return actionTypeLookup?.[account?.pendingEvent?.changeType]?.();
  }

  private mapToComparisonDetails(
    data: PayDistributionsUI.PayDistributionDetails,
    hasMultipleAccounts: boolean,
    isWisely: boolean,
    displayAmount?: string
  ): Partial<DirectDepositComparisonDetails> {
    return {
      ...data,
      displayAmount: displayAmount ?? this.getDisplayAmount(data, hasMultipleAccounts) ?? null,
      isWisely: isWisely
    };
  }

  private getDifferences(
    [currentData, pendingData]: [DirectDepositComparisonDetails, DirectDepositComparisonDetails],
    hasMultipleAccounts: boolean
  ): Partial<DirectDepositComparisonDetails> {
    const comparisonFields = [
      'routingNumber',
      'accountNumber',
      'distributionType',
      'percentageAmount',
      'flatAmount'
    ];
    const differences: Partial<PayDistributionsUI.PayDistributionDetails> = {};
    let displayAmount: string;

    Object.keys(pendingData)
      .filter((key) => comparisonFields.includes(key))
      .forEach((key) => {
        if (!isEqual(currentData?.[key], pendingData?.[key])) {
          differences[key] = pendingData?.[key];
        }
      });

    if (differences?.flatAmount && pendingData?.distributionType === DistributionOptions.FLAT) {
      displayAmount = this.formatCurrency(differences?.flatAmount);
    } else if (
      differences?.percentageAmount &&
      pendingData?.distributionType === DistributionOptions.PERCENTAGE
    ) {
      displayAmount = this.formatPercentage(differences.percentageAmount);
    }

    return this.mapToComparisonDetails(
      differences,
      hasMultipleAccounts,
      pendingData?.isWisely,
      displayAmount
    );
  }

  private getDisplayAmount(
    data: PayDistributionsUI.PayDistributionDetails,
    hasMultipleAccounts: boolean
  ): string | null {
    return (
      {
        [DistributionOptions.REMAINING]: () =>
          hasMultipleAccounts ? 'myadp-pay.DD_REMAINING' : 'myadp-pay.DD_FULL',
        [DistributionOptions.PERCENTAGE]: () => this.formatPercentage(data?.percentageAmount),
        [DistributionOptions.FLAT]: () => this.formatCurrency(data?.flatAmount)
      }[data?.distributionType]?.() ?? null
    );
  }
}
