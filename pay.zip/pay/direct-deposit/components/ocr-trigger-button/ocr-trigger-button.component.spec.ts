import { OCRData, OCRTriggerButtonComponent } from './ocr-trigger-button.component';
import { waitForAsync, ComponentFixture, fakeAsync, TestBed, tick } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { ClientDeviceService, NativeResourceService } from '@espresso/core';
import { NativeOCRService } from '@myadp/common';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement } from '@angular/core';
import { MockLanguagePipe, SetUpTestBed } from '@specHelpers';
import { Mock } from 'ts-mockery';

class OCRTriggerComponentEl {
  constructor(private debugElement: DebugElement) {}
  get trigger() {
    return this.debugElement.query(By.css('button'));
  }
}

describe('OCRTriggerButtonComponent', () => {
  let fixture: ComponentFixture<OCRTriggerButtonComponent>;
  let ocrTriggerButton: OCRTriggerButtonComponent;
  let ocrTriggerButtonEl: OCRTriggerComponentEl;

  const ocrResult: OCRData = {
    accountNumber: '0000000016',
    routingNumber: '2125678'
  };

  const beforeAllHook = () => {
    return {
      declarations: [OCRTriggerButtonComponent, MockLanguagePipe],
      providers: getMockProviders(),
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    };
  };

  SetUpTestBed(beforeAllHook);

  beforeEach(fakeAsync(() => {
    fixture = TestBed.createComponent(OCRTriggerButtonComponent);
    ocrTriggerButton = fixture.componentInstance;
    ocrTriggerButtonEl = new OCRTriggerComponentEl(fixture.debugElement);
    fixture.detectChanges();
    tick();
  }));

  it('should display OCR trigger element when supported', waitForAsync(() => {
    expect(ocrTriggerButton.isOCRFeatureSupported).toBe(true);
    fixture.detectChanges();
    const { nativeElement } = ocrTriggerButtonEl.trigger;
    expect(nativeElement.textContent).toContain('myadp-pay.TAKE_A_PICTURE');
  }));

  it('should set OCR flag to false when not supported', waitForAsync(() => {
    Mock.extend<NativeResourceService>(TestBed.inject(NativeResourceService)).with({
      getAppContext: () => Promise.resolve({ ocrServices: { bankRoutingServiceEnabled: false } })
    });

    expect(ocrTriggerButton.isOCRFeatureSupported).toBe(false);
    fixture.detectChanges();
    expect(ocrTriggerButtonEl.trigger).toBeNull();
  }));

  it('should not display the component when not native', waitForAsync(() => {
    Mock.of<ClientDeviceService>({ isNative: () => false });

    expect(ocrTriggerButton.isOCRFeatureSupported).toBe(false);
    fixture.detectChanges();
    expect(ocrTriggerButtonEl.trigger).toBeNull();
  }));

  it('should notify with capture initiation event', waitForAsync(() => {
    let called = false;
    ocrTriggerButton.captureInitiated.subscribe(() => (called = true));
    ocrTriggerButton.captureImage();
    expect(called).toBe(true);
  }));

  it('should notify with successful completion of check capture', waitForAsync(() => {
    ocrTriggerButton.captureCompleted.subscribe((result: OCRData) => {
      expect(result).toEqual(ocrResult);
    });
    ocrTriggerButton.captureImage();
  }));

  it('should notify with error status of check capture', waitForAsync(() => {
    const error = {
      status: '009',
      description: 'Camera Unauthorized'
    };

    ocrTriggerButton.captureFailed.subscribe((result: any) => {
      expect(result).toEqual(error);
    });
    Mock.extend<NativeOCRService>(TestBed.inject(NativeOCRService)).with({
      getBankAccountInformation: () => Promise.reject(error)
    });
    ocrTriggerButton.captureImage();
  }));

  it('should notify with camera cancelled status', fakeAsync(() => {
    const error = {
      status: {
        code: '005',
        description: 'Camera cancelled'
      }
    };

    const captureFailedListener = jasmine.createSpy('captureFailed');
    const captureCancelledListener = jasmine.createSpy('captureCancelled');

    ocrTriggerButton.captureFailed.subscribe(captureFailedListener);
    ocrTriggerButton.captureCancelled.subscribe(captureCancelledListener);
    Mock.extend<NativeOCRService>(TestBed.inject(NativeOCRService)).with({
      getBankAccountInformation: () => Promise.reject(error)
    });

    ocrTriggerButton.captureImage();
    fixture.detectChanges();
    tick();
    expect(captureFailedListener).not.toHaveBeenCalled();
    expect(captureCancelledListener).toHaveBeenCalled();
  }));

  it('should notify with camera not authorized status', fakeAsync(() => {
    const error = {
      status: {
        code: '003',
        description: 'Camera Not Authorized'
      }
    };

    const captureFailedListener = jasmine.createSpy('captureFailed');
    const captureCancelledListener = jasmine.createSpy('captureCancelled');

    ocrTriggerButton.captureFailed.subscribe(captureFailedListener);
    ocrTriggerButton.captureCancelled.subscribe(captureCancelledListener);
    Mock.extend<NativeOCRService>(TestBed.inject(NativeOCRService)).with({
      getBankAccountInformation: () => Promise.reject(error)
    });

    ocrTriggerButton.captureImage();
    fixture.detectChanges();
    tick();
    expect(captureFailedListener).not.toHaveBeenCalled();
    expect(captureCancelledListener).toHaveBeenCalled();
  }));

  function getMockProviders() {
    return [
      {
        provide: NativeResourceService,
        useValue: Mock.of<NativeResourceService>({
          getAppContext: () => Promise.resolve({ ocrServices: { bankRoutingServiceEnabled: true } })
        })
      },
      {
        provide: ClientDeviceService,
        useValue: Mock.of<ClientDeviceService>({ isNative: () => true })
      },
      {
        provide: NativeOCRService,
        useValue: Mock.of<NativeOCRService>({
          getBankAccountInformation: () => Promise.resolve({ result: ocrResult } as any)
        })
      }
    ];
  }
});
