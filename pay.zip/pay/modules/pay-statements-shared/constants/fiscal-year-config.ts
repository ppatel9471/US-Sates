export const FISCAL_YEAR_CONFIG = {
  FREEDOM: {
    start: {
      day: '06',
      month: '04'
    }
  }
};
