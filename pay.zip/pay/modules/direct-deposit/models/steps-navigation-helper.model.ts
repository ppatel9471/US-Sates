import { STEPS } from './steps.enum';
export { STEPS } from './steps.enum';

export interface ProgressProperties {
  hidden?: boolean;
  disabled?: boolean;
}

export type StepNavigationActions =
  | 'add'
  | 'edit'
  | 'delete'
  | 'add-wisely'
  | 'edit-wisely'
  | 'root';

export interface StepStateProps {
  prev?: ProgressProperties;
  next?: ProgressProperties;
  cancel?: ProgressProperties;
  isWisely?: boolean;
  isEditing?: boolean;
  showProgress?: boolean;
  showTerms?: boolean;
  showHeader?: boolean;
  hideNavigation?: boolean;
  isLastStep?: boolean;
  isFirstStep?: boolean;
  isSubmitStep?: boolean;
}

export interface StepNavigationDetails {
  stepComponent: STEPS;
  tag?: StepNavigationActions;
  stepProps?: StepStateProps;
  current?: number;
  outOf?: number;
}
