import { Component, EventEmitter, Input, OnChanges, Output } from '@angular/core';
import { SelectOption } from '@synerg/components/select';

import { LanguageService } from '@myadp/common';

import { WithholdingItem } from '../../../../models/formatted-tax-withholding.model';
import { StateModel } from '../../../../models/states.model';
import { PdfStatement, StatementType } from '../../../shared/models/pdf-viewer.model';
import { JurisdictionFactoryService } from '../../services/jurisdiction-factory.service';

@Component({
  selector: 'pay-state-self-select',
  templateUrl: 'state-self-select.component.html'
})
export class StateSelfSelectComponent implements OnChanges {
  @Output() public startStateWizard: EventEmitter<StateModel> = new EventEmitter();
  @Input() public withholdingItems: WithholdingItem[];
  public selectedState: SelectOption;
  public states: SelectOption[];
  public statement: PdfStatement;
  public statementType = StatementType;

  constructor(
    private languageService: LanguageService,
    private jurisdictionFactory: JurisdictionFactoryService
  ) {}

  public ngOnChanges() {
    this.states = this.withholdingItems.map((item: WithholdingItem) => {
      return {
        label: item.state.longName,
        value: item.state.longName,
        withholdingItem: item
      };
    });
  }

  public startForm() {
    this.startStateWizard.emit(this.selectedState.withholdingItem.state);
    this.selectedState = null;
  }

  public selectedStateChange() {
    this.setBlankForm(this.selectedState);
  }

  private setBlankForm(selectedState: SelectOption) {
    if (selectedState) {
      const stateShortName = selectedState.withholdingItem.state.shortName;
      const formType = stateShortName === 'CO' ? 'not-exempt' : 'primary';
      const attachment = this.jurisdictionFactory.getAttachmentNameCode(
        selectedState.withholdingItem.state,
        formType
      );
      const countryCode = selectedState.withholdingItem.state.countryCode;
      const titleShortName = stateShortName === 'CO' ? 'CO2022' : stateShortName;
      this.statement = {
        title: this.languageService.get(`myadp-pay.${titleShortName}_TAX_WITHHOLDING`),
        uri: `/api/tax/v1/tax-withholding/${countryCode}/forms/${attachment.shortName}?subdivisionCode=${stateShortName}`
      };
    }
  }
}
