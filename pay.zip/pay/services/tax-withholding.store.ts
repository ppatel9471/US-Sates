import { Injectable } from '@angular/core';

import { LanguageService } from '@myadp/common';

import { WithholdingInfo, WithholdingItem } from '../models/formatted-tax-withholding.model';
import { FEDERAL, StateUtil } from '../models/states.model';
import { PdfStatement } from '../modules/shared/models/pdf-viewer.model';
import { FedWizard } from '../modules/tax-withholding-management/us/fed/models/fed-wizard.model';
import { TWElectionToFedService } from '../modules/tax-withholding-management/us/fed/services/tw-election-to-fed.service';

@Injectable({
  providedIn: 'root'
})
export class TaxWithholdingStore {
  public federalWithholding: WithholdingInfo = { withholdingItems: [] };
  public stateWithholding: WithholdingInfo = { withholdingItems: [] };

  constructor(
    private readonly twElectionToFedService: TWElectionToFedService,
    private languageService: LanguageService
  ) {}

  public getFederalWizard(): Partial<FedWizard> {
    return this.twElectionToFedService.translate(
      this.findWithholdingItem(FEDERAL.shortName)?.rawData
    );
  }

  public findWithholdingItem(name: string): WithholdingItem {
    const withholdingItems: WithholdingItem[] = this.getAllWithholdingItems();

    return withholdingItems.find((state) => {
      return state.state.longName === name || state.state.shortName === name;
    });
  }

  public getAllWithholdingItems(): WithholdingItem[] {
    return [
      ...this.federalWithholding.withholdingItems,
      ...this.stateWithholding.withholdingItems
    ].filter((state) => {
      return state.state !== undefined;
    });
  }

  // Filter out states with no effectiveDate (PIMYPI-8954)
  public getActiveWithholdingItems(): WithholdingItem[] {
    return [
      ...this.federalWithholding.withholdingItems,
      ...this.stateWithholding.withholdingItems.filter((item: WithholdingItem) => {
        return !this.isInactive(item) && item.state !== undefined;
      })
    ];
  }

  public getWithholdingForms(): PdfStatement[] {
    return this.getActiveWithholdingItems()
      .map((item: WithholdingItem) => {
        if (item.attachments && item.attachments.length) {
          const formShortName = item.attachments[0].shortName ? item.attachments[0].shortName : '';
          const type = StateUtil.isFederal(item.state.shortName)
            ? this.languageService.get('myadp-pay.FEDERAL')
            : this.languageService.get('myadp-pay.STATE');
          return {
            title: this.languageService.get('myadp-pay.PDF_VIEWER_SLIDEIN_HEADER_TAX_WITHHOLDING', {
              state: item.state.longName,
              form: formShortName
            }),
            uri: item.attachments[0].gssUrl,
            statementDetails: [
              { label: 'myadp-pay.PDF_VIEWER_SLIDEIN_TYPE', value: type },
              {
                label: 'myadp-pay.PDF_VIEWER_SLIDEIN_FORM',
                value: item.attachments[0].shortName
              }
            ]
          };
        }
      })
      .filter((item) => !!item);
  }

  public getInactiveWithholdingItems(): WithholdingItem[] {
    return this.stateWithholding.withholdingItems.filter((item: WithholdingItem) => {
      return this.isInactive(item) && item.state !== undefined;
    });
  }

  public getLivedInState(): string {
    const stateObject: WithholdingItem = this.stateWithholding.withholdingItems.find(
      (item: WithholdingItem) => item.livedIn
    );
    if (stateObject) {
      return stateObject.state.longName;
    }

    return null;
  }

  public hasCompletedStateForm(states: string[]): boolean {
    const withholdingItems: WithholdingItem[] = this.getActiveWithholdingItems();
    const matchingStates: WithholdingItem[] = withholdingItems.filter((state) =>
      states.includes(state.state.shortName)
    );

    return matchingStates.length > 0;
  }

  private isInactive(item: WithholdingItem): boolean {
    return (
      !item.isNoIncomeTax &&
      !item.isFlatRate &&
      !item.isUnsupported &&
      !item.pendingSummaryItems?.length &&
      !item.effectiveDate
    );
  }
}
