import { TileService } from '@synerg/components/tile';
import { PageType } from '@myadp/pay-paperless-shared/models/page-type.enum';
import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { MockLanguagePipe } from '@specHelpers';
import { RetirementPaperlessTileComponent } from './retirement-paperless-tile.component';

describe('LoanOutstandingPopupComponent', () => {
  let component: RetirementPaperlessTileComponent;
  let fixture: ComponentFixture<RetirementPaperlessTileComponent>;
  let service: TileService;
  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ RetirementPaperlessTileComponent, MockLanguagePipe],
      providers: [TileService]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RetirementPaperlessTileComponent);
    component = fixture.componentInstance;
    service = TestBed.inject(TileService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should onInit be called', () => {
    const ngOnInit = spyOn(component, 'ngOnInit').and.callThrough();
    component.ngOnInit();
    fixture.whenStable().then(() => {
      expect(ngOnInit).toHaveBeenCalled();
      expect(component.pageType).toBe(PageType.RETIREMENT);
    });
  });

  it('should onInit call the tile service setIsLoadin method', () => {
    const ngOnInit = spyOn(component, 'ngOnInit').and.callThrough();
    const setIsLoading = spyOn(service, 'setIsLoading').and.returnValue(null);
    component.ngOnInit();
    fixture.whenStable().then(() => {
      expect(ngOnInit).toHaveBeenCalled();
      expect(component.pageType).toBe(PageType.RETIREMENT);
      expect(setIsLoading).toHaveBeenCalled();
      expect(setIsLoading).toHaveBeenCalledWith(false);
    });
  });

});
