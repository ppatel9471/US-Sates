import { PayDistributionsUI } from '../../pay-distributions-shared/models/pay-distributions-ui';
import { AccountDetailsForm } from './account-details-form.model';
import { DepositAmountForm } from './deposit-amount-form.model';

export type FormDetails = FormData & PayDistributionDetails;

type FormData = Partial<AccountDetailsForm> & Partial<DepositAmountForm>;
// omitted properties are of different types in FormDetails
type PayDistributionDetails = Partial<
Omit<PayDistributionsUI.PayDistributionDetails, 'flatAmount' | 'percentageAmount'>
>;
