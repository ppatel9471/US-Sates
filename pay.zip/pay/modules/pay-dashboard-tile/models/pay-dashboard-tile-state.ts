import { PayStatementsDTO } from './pay-statement.model';

export enum PayDashboardTileStoreSlice {
  PAY_STATEMENTS = 'payStatements'
}

export interface PayDashboardTileStoreState {
  [PayDashboardTileStoreSlice.PAY_STATEMENTS]?: PayDashboardTile.PayStatementsState;
}

export namespace PayDashboardTile {
  export interface PayStatementsState {
    payStatements?: PayStatementsDTO;
  }
}
