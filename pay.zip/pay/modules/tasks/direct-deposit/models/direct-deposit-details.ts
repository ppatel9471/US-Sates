import { chain, find, get, isEqual, isNull, map, union } from 'lodash';

import {
  CodeListItem,
  DirectDepositAccountNewSchema,
  DirectDepositAccountOldSchema,
  DirectDepositTasksDetails,
  PendingEventsHistoryDetails
} from '@myadp/dto';

import {
  loadRequesterAndLatestComments,
  NotificationComments,
  NotificationCodeType
} from '@myadp/thingstodo-shared';

import { PayTasksService } from '../../shared/services/pay-tasks.service';
import {
  ALINE_CODE,
  DIRECT_DEPOSIT_EVENT_TYPE,
  DirectDepositAccountType,
  DirectDepositComparisonData,
  DirectDepositFormattedAccount,
  METADATA_PATH
} from './direct-deposit-tasks-details.model';

export class DirectDepositDetails {
  public notificationCodeType: NotificationCodeType;
  public currentData: DirectDepositAccountNewSchema[] | DirectDepositAccountOldSchema[];
  public pendingData: DirectDepositAccountNewSchema[] | DirectDepositAccountOldSchema[];
  public payrollGroupCode: CodeListItem;
  public statusCode: string;
  public comments: NotificationComments;
  public comparisonData: DirectDepositComparisonData[] = [];
  public pendingEventsHistory: PendingEventsHistoryDetails[];

  constructor(data: DirectDepositTasksDetails,notificationCodeType: NotificationCodeType) {
    this.notificationCodeType = notificationCodeType;
    this.currentData = <DirectDepositAccountNewSchema[] | DirectDepositAccountOldSchema[]>(
      (get(data, 'currentData.payDistributions[0].distributionInstructions') ||
        get(data, 'oldData.payDistributions[0].distributionInstructions', {}))
    );
    this.pendingData = <DirectDepositAccountNewSchema[] | DirectDepositAccountOldSchema[]>(
      (get(data, 'pendingData.payDistributions[0].distributionInstructions') ||
        get(data, 'newData.payDistributions[0].distributionInstructions', {}))
    );
    this.comparisonData = this.getComparisonData();
    this.statusCode = PayTasksService.getStatusCodeLabel(data);
    this.comments = loadRequesterAndLatestComments(data, null);
    this.payrollGroupCode = get(data, 'currentData.payDistributions[0].payrollGroupCode');
    this.pendingEventsHistory = data.history ? data.history : get(data, 'pendingEvents[0].history');
  }
  private getComparisonData(): DirectDepositComparisonData[] {
    return map(this.extractAccounts(), (account: DirectDepositComparisonData) => {
      account.type = this.eventTypeLookup(!!account.currentData, !!account.pendingData);
      if (account.type === DIRECT_DEPOSIT_EVENT_TYPE.CHANGE) {
        const comparisonData = {};
        map(Object.keys(account.pendingData), (key: string) => {
          if (
            key !== 'totalAccount' &&
            !isEqual(account.currentData[key], account.pendingData[key])
          ) {
            comparisonData[key] = account.pendingData[key];
          }
        });
        account.comparisonData = comparisonData;
      } else if (account.type === DIRECT_DEPOSIT_EVENT_TYPE.ADD) {
        account.comparisonData = account.pendingData;
      }
      if (!!account.comparisonData && Object.keys(account.comparisonData).length > 0) {
        // add total account number to change account
        account.comparisonData['totalAccount'] = account.pendingData.totalAccount;
      }
      return account;
    });
  }

  private extractAccounts(): DirectDepositComparisonData[] {
    const currentFormattedAccounts = this.formatAccounts(this.currentData);
    const pendingFormattedAccounts = this.formatAccounts(this.pendingData);
    return map(
      this.getUniqueItemIDs(currentFormattedAccounts, pendingFormattedAccounts),
      (accountType: DirectDepositAccountType) => {
        return {
          accountType,
          currentData: find(currentFormattedAccounts, { accountType }),
          pendingData: find(pendingFormattedAccounts, { accountType })
        };
      }
    );
  }

  private formatAccounts(
    data: DirectDepositAccountNewSchema[] | DirectDepositAccountOldSchema[]
  ): DirectDepositFormattedAccount[] {
    return map(data, (account: DirectDepositAccountNewSchema | DirectDepositAccountOldSchema) => {
      const formattedAccount: DirectDepositFormattedAccount = {};
      const distributionAmount: number = get(account, 'distributionAmount.amountValue');

      if (get(account, METADATA_PATH.OLD_SCHEMA.ACCOUNT_NUMBER)) {
        formattedAccount.routingNumber = get(account, METADATA_PATH.OLD_SCHEMA.ROUTING_NUMBER);
        formattedAccount.accountNumber = get(account, METADATA_PATH.OLD_SCHEMA.ACCOUNT_NUMBER);
        formattedAccount.accountType = get(account, METADATA_PATH.OLD_SCHEMA.ACCOUNT_TYPE);
      } else {
        const distributionPercentage: number = get(
          account,
          METADATA_PATH.NEW_SCHEMA.DISTRIBUTION_PERCENTAGE
        );
        formattedAccount.routingNumber = get(account, METADATA_PATH.NEW_SCHEMA.ROUTING_NUMBER);
        formattedAccount.accountNumber = get(account, METADATA_PATH.NEW_SCHEMA.ACCOUNT_NUMBER);
        formattedAccount.accountType = get(account, METADATA_PATH.NEW_SCHEMA.ACCOUNT_TYPE);
        formattedAccount.distributionPercentage = isNull(distributionPercentage)
          ? undefined
          : distributionPercentage;
      }
      formattedAccount.distributionAmount = isNull(distributionAmount)
        ? undefined
        : get(account, 'distributionAmount');
      formattedAccount.remainingBalanceIndicator = get(account, 'remainingBalanceIndicator');
      formattedAccount.totalAccount = data.length;
      formattedAccount.isPayCard = this.isPayCard(
        formattedAccount.accountType.codeValue,
        get(account, METADATA_PATH.NEW_SCHEMA.ACCOUNT_NAME, null)
      );
      return formattedAccount;
    });
  }

  private isPayCard(accountType: string, accountName: string): boolean {
    return (
      [ALINE_CODE].includes(accountType) ||
      !!(
        accountType?.toLowerCase().indexOf('wis') > -1 ||
        accountName?.toLowerCase().indexOf('wisely') > -1
      )
    );
  }

  private getUniqueItemIDs(
    currentFormattedAccounts: DirectDepositFormattedAccount[],
    pendingFormattedAccounts: DirectDepositFormattedAccount[]
  ): DirectDepositAccountType[] {
    return <DirectDepositAccountType[]>chain(
      union(currentFormattedAccounts, pendingFormattedAccounts)
    )
      .map((account: any) => {
        return get(account, 'accountType');
      })
      .uniq('codeValue')
      .valueOf();
  }

  private eventTypeLookup(current: boolean, pending: boolean) {
    let event = DIRECT_DEPOSIT_EVENT_TYPE.ADD;
    if (current) {
      event = pending ? DIRECT_DEPOSIT_EVENT_TYPE.CHANGE : DIRECT_DEPOSIT_EVENT_TYPE.DELETE;
    }
    return event;
  }
}
