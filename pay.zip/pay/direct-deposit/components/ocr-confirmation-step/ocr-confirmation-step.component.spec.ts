import { OCRData } from '../ocr-trigger-button/ocr-trigger-button.component';
import { waitForAsync, ComponentFixture, fakeAsync, TestBed, tick } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement } from '@angular/core';
import { MockLanguagePipe, SetUpTestBed } from '@specHelpers';
import { NativeOCRService } from '@myadp/common';
import { Mock } from 'ts-mockery';
import { OCRConfirmationStepComponent } from './ocr-confirmation-step.component';

describe('OCRConfirmationStepComponent', () => {
  let fixture: ComponentFixture<OCRConfirmationStepComponent>;
  let OCRConfirmationStep: OCRConfirmationStepComponent;
  let OCRConfirmationStepEl: OCRConfirmationStepComponentEl;

  const accountInfo: OCRData = {
    accountNumber: '0000000016',
    routingNumber: '2125678'
  };

  const beforeAllHook = () => {
    return {
      declarations: [OCRConfirmationStepComponent, MockLanguagePipe],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers: [
        {
          provide: NativeOCRService,
          useValue: Mock.of<NativeOCRService>({
            getBankAccountInformation: () => Promise.resolve({ result: accountInfo } as any)
          })
        }
      ]
    };
  };

  SetUpTestBed(beforeAllHook);

  beforeEach(fakeAsync(() => {
    fixture = TestBed.createComponent(OCRConfirmationStepComponent);
    OCRConfirmationStep = fixture.componentInstance;
    OCRConfirmationStepEl = getStepElement(fixture.debugElement);
    OCRConfirmationStep.ocrData = accountInfo;
    fixture.detectChanges();
    tick();
  }));

  it('should take account info as input', waitForAsync(() => {
    expect(OCRConfirmationStep.accountInfo).toEqual(accountInfo);
  }));

  it('should get correct language keys', waitForAsync(() => {
    const { nativeElement } = OCRConfirmationStepEl.confirmationStepBody;
    expect(nativeElement.textContent).toContain('myadp-pay.ACCOUNT_INFO_TITLE');
    expect(nativeElement.textContent).toContain('myadp-pay.OCR_CONFIRM_INFO_MESSAGE');
    expect(OCRConfirmationStepEl.confirm.nativeElement.textContent).toContain('common.CONFIRM');
    expect(OCRConfirmationStepEl.retake.nativeElement.textContent).toContain(
      'myadp-pay.RETAKE_PHOTO'
    );
    expect(OCRConfirmationStepEl.cancel.nativeElement.textContent).toContain('common.CANCEL');
  }));

  it('should display routing number information', () => {
    const { label, value } = OCRConfirmationStepEl.routingNumberSection;
    expect(label.nativeElement.textContent).toEqual('myadp-pay.ROUTING_NUMBER');
    expect(value.nativeElement.textContent).toEqual(accountInfo.routingNumber);
  });

  it('should display account number information', () => {
    const { label, value } = OCRConfirmationStepEl.accountNumberSection;
    expect(label.nativeElement.textContent).toEqual('myadp-pay.ACCOUNT_NUMBER');
    expect(value.nativeElement.textContent).toEqual(accountInfo.accountNumber);
  });

  it('should notify with confirm account info click event', waitForAsync(() => {
    OCRConfirmationStep.confirmClick.subscribe((confirmedInfo: OCRData) => {
      expect(confirmedInfo).toEqual(accountInfo);
    });
    OCRConfirmationStep.handleConfirmClick();
  }));

  it('should notify with cancel OCR use event', waitForAsync(() => {
    let called = false;
    OCRConfirmationStep.cancelClick.subscribe(() => (called = true));
    OCRConfirmationStep.handleCancelClick();
    expect(called).toBe(true);
  }));

  it('should update account info on successful recapture', waitForAsync(() => {
    expect(OCRConfirmationStep.accountInfo).toEqual(accountInfo);
    const newAccInfo = {
      accountNumber: '25617',
      routingNumber: '78954321'
    };
    Mock.extend<NativeOCRService>(TestBed.inject(NativeOCRService)).with({
      getBankAccountInformation: () => Promise.resolve({ result: newAccInfo } as any)
    });

    OCRConfirmationStepEl.retake.triggerEventHandler('click', null);
    expect(OCRConfirmationStep.isProcessing).toBe(true);
    fixture.whenStable().then(() => {
      fixture.detectChanges();
      const { value } = OCRConfirmationStepEl.routingNumberSection;
      expect(value.nativeElement.textContent).toEqual(newAccInfo.routingNumber);
      expect(OCRConfirmationStep.accountInfo).toEqual(newAccInfo);
      expect(OCRConfirmationStep.isProcessing).toBe(false);
    });
  }));

  it('should send capture failed event on failure', fakeAsync(() => {
    const captureFailedListener = jasmine.createSpy('captureFailed');
    OCRConfirmationStep.captureFailed.subscribe(captureFailedListener);
    Mock.extend<NativeOCRService>(TestBed.inject(NativeOCRService)).with({
      getBankAccountInformation: () => Promise.reject('failed')
    });

    OCRConfirmationStepEl.retake.triggerEventHandler('click', null);
    expect(OCRConfirmationStep.isProcessing).toBe(true);
    fixture.detectChanges();
    tick();
    expect(captureFailedListener).toHaveBeenCalled();
    expect(OCRConfirmationStep.isProcessing).toBe(false);
  }));

  it('should not send capture cancelled event', fakeAsync(() => {
    const captureFailedListener = jasmine.createSpy('captureFailed');
    OCRConfirmationStep.captureFailed.subscribe(captureFailedListener);
    Mock.extend<NativeOCRService>(TestBed.inject(NativeOCRService)).with({
      getBankAccountInformation: () => Promise.reject({ status: { code: '005' } })
    });

    OCRConfirmationStepEl.retake.triggerEventHandler('click', null);
    expect(OCRConfirmationStep.isProcessing).toBe(true);
    fixture.detectChanges();
    tick();
    expect(captureFailedListener).not.toHaveBeenCalled();
    expect(OCRConfirmationStep.isProcessing).toBe(false);
  }));
});

class OCRConfirmationStepComponentEl {
  constructor(private debugElement: DebugElement) {}
  get confirmationStepBody() {
    return this.debugElement.query(By.css('.ocr-confirmation'));
  }

  get routingNumberSection() {
    const elm = this.debugElement.query(By.css('[e2e*="routing-number"]'));
    const labelValuePair = this.getLabelValuePair(elm);
    return {
      ...elm,
      ...labelValuePair
    };
  }

  get accountNumberSection() {
    const elm = this.debugElement.query(By.css('[e2e*="account-number"]'));
    const labelValuePair = this.getLabelValuePair(elm);
    return {
      ...elm,
      ...labelValuePair
    };
  }

  get confirm() {
    return this.debugElement.query(By.css('[e2e*="confirm-btn"]'));
  }

  get retake() {
    return this.debugElement.query(By.css('[e2e*="retake-btn"]'));
  }

  get cancel() {
    return this.debugElement.query(By.css('[e2e*="cancel-btn"]'));
  }

  private getLabelValuePair(debugElm: DebugElement) {
    return {
      label: debugElm.query(By.css('.label')),
      value: debugElm.query(By.css('.value'))
    };
  }
}

function getStepElement(debugEl: DebugElement) {
  return new OCRConfirmationStepComponentEl(debugEl);
}
