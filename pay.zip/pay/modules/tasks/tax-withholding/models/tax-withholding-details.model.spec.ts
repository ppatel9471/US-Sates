import { UsFederalTaxWithholdingElections } from '../../../..//models/us-federal-tax-withholding-election.model';
import { UsStateTaxWithholdingElections } from '../../../..//models/us-state-tax-withholding-election.model';
import { TaxWithholdingDetails } from './tax-withholding-details.model';
import { STATUS_CODE } from '@myadp/thingstodo-shared';

describe('TaxWithholdingDetails', () => {
  let taxWithholdingDetails: TaxWithholdingDetails;
  const mockFedElection: UsFederalTaxWithholdingElections = {
    usFederalTaxWithholdingElections: [
      {
        workflowData: {
          pendingEvents: {
            eventName: 'Federal Event',
            history: [
              {
                actionDate: 123345,
                actionTaken: STATUS_CODE.approval,
                assignedTo: 'Smith, Bob',
                comments: 'comment',
                processStepID: 9876
              }
            ]
          }
        }
      }
    ]
  };
  const mockStateElection: UsStateTaxWithholdingElections = {
    usStateTaxWithholdingElections: [
      {
        workflowData: {
          pendingEvents: {
            eventName: 'State Event',
            history: [
              {
                actionDate: 123345,
                actionTaken: STATUS_CODE.approval,
                assignedTo: 'Smith, Bob',
                comments: 'comment',
                processStepID: 9876
              }
            ]
          }
        }
      }
    ]
  };

  describe('federal', () => {
    beforeEach(() => {
      taxWithholdingDetails = new TaxWithholdingDetails(mockFedElection);
    });

    it('should set pendingEvents', () => {
      expect(taxWithholdingDetails.pendingEvents).toEqual(
        mockFedElection.usFederalTaxWithholdingElections[0].workflowData.pendingEvents
      );
      expect(taxWithholdingDetails.comments.latestComment).toEqual('comment');
      expect(taxWithholdingDetails.comments.requesterComment).toBe(null);
    });

    it('should return isFederal true', () => {
      expect(taxWithholdingDetails.isFederal()).toBeTruthy();
    });
  });

  describe('state', () => {
    beforeEach(() => {
      taxWithholdingDetails = new TaxWithholdingDetails(mockStateElection);
    });

    it('should set pendingEvents', () => {
      expect(taxWithholdingDetails.pendingEvents).toEqual(
        mockStateElection.usStateTaxWithholdingElections[0].workflowData.pendingEvents
      );
      expect(taxWithholdingDetails.comments.latestComment).toEqual('comment');
      expect(taxWithholdingDetails.comments.requesterComment).toBe(null);
    });

    it('should return isFederal false', () => {
      expect(taxWithholdingDetails.isFederal()).toBeFalsy();
    });
  });
});
