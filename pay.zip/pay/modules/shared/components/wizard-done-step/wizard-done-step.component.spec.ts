import { Shallow } from 'shallow-render';

import { LanguagePipe } from '@myadp/common';

import { SharedModule } from '../../shared.module';
import { WizardDoneStepComponent } from './wizard-done-step.component';

describe('WorkflowDetailsComparisonComponent', () => {
  let shallow: Shallow<WizardDoneStepComponent>;

  const mockRestartText = 'myadp-pay.MANAGE_SOMETHING';
  const mockTemplate = `<pay-wizard-done-step [restartText]="restartText">
  <span>Some content</span>
  </pay-wizard-done-step>`;

  beforeEach(() => {
    shallow = new Shallow(WizardDoneStepComponent, SharedModule).mockPipe(
      LanguagePipe,
      (key) => key
    );
  });

  it('should display the done step with content', async () => {
    const { find } = await shallow.render(mockTemplate, {
      bind: {
        restartText: mockRestartText
      }
    });

    const [closeBtn, restartBtn] = find('adp-button');
    expect(find('h3').nativeElement.innerHTML).toContain('myadp-pay.DONE_STEP_TITLE');
    expect(find('span').nativeElement.innerHTML).toContain('Some content');
    expect(closeBtn.nativeElement.innerHTML).toContain('common.CLOSE');
    expect(restartBtn.nativeElement.innerHTML).toContain(mockRestartText);
  });

  it('should emit when the close button is clicked', async () => {
    const { find, outputs } = await shallow.render(mockTemplate, {
      bind: {
        restartText: mockRestartText
      }
    });
    const [closeBtn] = find('adp-button');
    closeBtn.nativeElement.click();

    expect(outputs.closed.emit).toHaveBeenCalledTimes(1);
  });

  it('should emit when the restart button is clicked', async () => {
    const { find, outputs } = await shallow.render(mockTemplate, {
      bind: {
        restartText: mockRestartText
      }
    });
    const [, restartBtn] = find('adp-button');
    restartBtn.nativeElement.click();

    expect(outputs.restarted.emit).toHaveBeenCalledTimes(1);
  });
});
