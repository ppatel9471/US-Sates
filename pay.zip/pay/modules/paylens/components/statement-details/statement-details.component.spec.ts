import { SdfShimmer } from '@synerg/angular-components';
import { of } from 'rxjs';
import { Shallow } from 'shallow-render';

import { LanguagePipe } from '@myadp/common';

import { PayStatementsUI } from '../../../pay-statements-shared/models/pay-statement-ui';
import { PayStatementStore } from '../../../pay-statements-shared/store/pay-statement.store';
import { PaylensModule } from '../../paylens.module';
import { InsightsAlertComponent } from '../statement-details/insights-alert/insights-alert.component';
import { PaylensNoStatementDetailsComponent } from './no-statement-details/no-statement-details.component';
import { PaylensPayDonutComponent } from './pay-donut/pay-donut.component';
import { PaylensStatementDetailsSummaryComponent } from './statement-details-summary/statement-details-summary.component';
import { PaylensStatementDetailsComponent } from './statement-details.component';

describe('PaylensStatementDetailsComponent', () => {
  let shallow: Shallow<PaylensStatementDetailsComponent>;

  const statement: PayStatementsUI.PayStatement = {
    id: 1,
    payDate: 'Apr 14, 2019',
    netPay: undefined,
    grossPay: { amountValue: 1732.1, currencyCode: 'USD' },
    totalHours: 80,
    payDetailUri: '/v1_0/O/A/payStatement/1074162519254260000198001043940',
    statementImageUri:
      '/l2/v1_0/O/A/payStatement/1074162519264497000198001612729/images/CERooo008000620000r701AC7680FFC521.pdf',
    payAdjustment: true,
    statementFiscalYear: '2019',
    statementType: undefined
  };

  const state = {
    payStatements: {
      data: {
        statements: [statement]
      }
    },
    currentStatementDetails: {
      data: {
        statement: {
          ...statement
        },
        statementDetails: {
          hasYearToDateData: true,
          earnings: [{}]
        }
      }
    }
  };

  const categorizedInsights = {
    top: [
      {
        text: 'You received a new earning "RegularPay" of $10,000.00 this pay period.',
        rank: 100,
        tags: ['EARNINGS']
      }
    ],
    retirement: [
      {
        text: 'Your deduction increased from $100 to $200',
        rank: 100,
        tags: ['Retirement']
      }
    ]
  };

  beforeEach(() => {
    shallow = new Shallow(PaylensStatementDetailsComponent, PaylensModule)
      .dontMock(PaylensNoStatementDetailsComponent)
      .mock(PayStatementStore, {
        statementDetails$: (slice) => {
          if (!slice) {
            return of(state.currentStatementDetails.data.statementDetails);
          }
        },
        currentStatement$: of(state.currentStatementDetails.data.statement)
      })
      .mockPipe(LanguagePipe, (key) => key);
  });

  describe('statement details', () => {
    it('should show the statement details view', async () => {
      const { find, findComponent } = await shallow.render();

      expect(find('paylens-summary-header')).toHaveFound(1);
      expect(findComponent(PaylensNoStatementDetailsComponent)).toHaveFound(0);
      expect(findComponent(PaylensStatementDetailsSummaryComponent)).toHaveFoundOne();
      expect(findComponent(SdfShimmer)).toHaveFound(0);
    });

    it('should show the paylens donut', async () => {
      const { findComponent } = await shallow
        .mock(PayStatementStore, {
          statementDetails$: (slice) => {
            if (!slice) {
              return of(state.currentStatementDetails.data.statementDetails);
            } else if (slice === 'donutData') {
              return of({
                data: []
              });
            }
          }
        })
        .render();

      expect(findComponent(PaylensPayDonutComponent)).toHaveFound(1);
    });

    it('should show the no pay statement details view', async () => {
      const { findComponent } = await shallow
        .mock(PayStatementStore, {
          statementDetails$: () => of(null)
        })
        .render();

      expect(findComponent(PaylensStatementDetailsSummaryComponent)).toHaveFound(0);
      expect(findComponent(PaylensNoStatementDetailsComponent)).toHaveFoundOne();
    });

    it('should show info text if positive deductions are present', async () => {
      const { find } = await shallow
        .mock(PayStatementStore, {
          statementDetails$: (slice) => {
            if (!slice) {
              return of(state.currentStatementDetails.data.statementDetails);
            } else if (slice === 'donutData') {
              return of({
                hasPositiveDeductions: true,
                data: []
              });
            }
          }
        })
        .render();

      expect(find('.donut-positive-deductions-alert').nativeElement.innerHTML).toContain(
        'myadp-pay.PAY_DONUT_POSITIVE_DEDUCTIONS_ALERT'
      );
    });

    it('should not show earnings or the paylens donut when viewing YTD', async () => {
      const { find, findComponent } = await shallow
        .mock(PayStatementStore, {
          statementDetails$: (slice) => {
            if (!slice) {
              return of(state.currentStatementDetails.data.statementDetails);
            } else if (slice === 'donutData') {
              return of({
                data: []
              });
            }
          }
        })
        .render({
          bind: {
            yearToDate: true
          }
        });

      expect(find('paylens-summary-header')).toHaveFound(1);
      expect(find('paylens-statement-details-earnings')).toHaveFound(0);
      expect(findComponent(PaylensPayDonutComponent)).toHaveFound(0);
    });
  });

  describe('loading shimmer', () => {
    it('should show a loading shimmer when loading statement details', async () => {
      const { findComponent } = await shallow
        .mock(PayStatementStore, {
          isStatementDetailsLoading$: of(true)
        })
        .render();

      expect(findComponent(SdfShimmer)).toHaveFoundOne();
    });
  });

  describe('No statement details', () => {
    it('should display no-statement-details when viewing YTD and there is no YTD data', async () => {
      const { findComponent } = await shallow
        .mock(PayStatementStore, {
          statementDetails$: (slice) => {
            if (!slice) {
              return of({ hasYearToDateData: false });
            }
          }
        })
        .render({
          bind: {
            yearToDate: true
          }
        });

      expect(findComponent(PaylensNoStatementDetailsComponent)).toHaveFoundOne();
      expect(findComponent(PaylensStatementDetailsSummaryComponent)).toHaveFound(0);
      expect(findComponent(InsightsAlertComponent)).toHaveFound(0);
    });

    it('should display no-statement-details when there is an error', async () => {
      const { findComponent } = await shallow
        .mock(PayStatementStore, {
          hasStatementDetailsError$: of(true)
        })
        .render();

      expect(findComponent(PaylensNoStatementDetailsComponent)).toHaveFoundOne();
    });
  });

  describe('Insights Alert', () => {
    it('should show the insights alert', async () => {
      const { findComponent } = await shallow
        .mock(PayStatementStore, {
          categorizedInsights$: of(categorizedInsights)
        })
        .render();

      expect(findComponent(InsightsAlertComponent)).toHaveFoundOne();
    });
  });

  describe('Insights', () => {
    it('should display insights when viewing insights tab', async () => {
      const { find } = await shallow
        .mock(PayStatementStore, {
          currentDetailsData$: of({
            statement: {},
            statementDetails: {
              totalHours: 80
            }
          })
        })
        .render({
          bind: {
            onInsightsTab: true
          }
        });

      expect(find('paylens-statement-insights')).toHaveFoundOne();
    });

    it('should still display insights when there is an error', async () => {
      const { find } = await shallow
        .mock(PayStatementStore, {
          hasStatementDetailsError$: of(true)
        })
        .render({
          bind: {
            onInsightsTab: true
          }
        });

      expect(find('paylens-statement-insights')).toHaveFoundOne();
    });

    it('should display no-statement-details when there is no statementDetail', async () => {
      const { find, findComponent } = await shallow
        .mock(PayStatementStore, {
          currentDetailsData$: of({
            statement: {}
          }),
          statementDetails$: () => of(null)
        })
        .render({
          bind: {
            onInsightsTab: true
          }
        });

      expect(find('paylens-statement-insights')).toHaveFound(0);
      expect(findComponent(PaylensNoStatementDetailsComponent)).toHaveFoundOne();
    });
  });
});
