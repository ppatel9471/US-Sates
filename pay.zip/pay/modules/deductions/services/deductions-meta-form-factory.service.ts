import { Injectable } from '@angular/core';
import { combineLatest, from, Observable } from 'rxjs';
import { filter, map, skipWhile, switchMap } from 'rxjs/operators';

import { CodeListService, Meta, RawMetaObject } from '@myadp/forms';

import { PayDeductionsStore } from '../../pay-deductions-shared/store/pay-deductions.store';
import { DeductionsAddEditMetaForm } from '../models/deductions-add-edit-meta-form.model';
import { DeductionsSelectMetaForm } from '../models/deductions-select-meta-form.model';
import { DeductionsStoreActions } from '../store/deductions-store.actions';

@Injectable({
  providedIn: 'root'
})
export class DeductionsMetaFormFactory {
  constructor(
    private codeListService: CodeListService,
    private payDeductionsStore: PayDeductionsStore,
    private deductionsStoreActions: DeductionsStoreActions
  ) {}

  public buildDeductionsSelectMetaForm(): Observable<DeductionsSelectMetaForm> {
    this.deductionsStoreActions.loadStartMeta();

    return this.payDeductionsStore.payDeductionsStartMeta$.pipe(
      filter((metaObj) => !!metaObj),
      map((metaObj: RawMetaObject) => {
        const metaInstance = new Meta(metaObj);
        const metaForm = new DeductionsSelectMetaForm(
          metaInstance,
          this.codeListService
        ).initialize();

        return from(metaForm);
      }),
      switchMap((form) => form)
    );
  }

  public buildDeductionsAddEditMetaForm(
    codeValue: string,
    isEdit: boolean = false
  ): Observable<DeductionsAddEditMetaForm> {
    const deductionMetaSnapshot: RawMetaObject =
      this.payDeductionsStore.payDeductionMetaItemSnapshot(codeValue, isEdit);
    const hasMetaError: boolean = this.payDeductionsStore.hasDeductionMetaError;

    if (!deductionMetaSnapshot || hasMetaError) {
      this.deductionsStoreActions.loadDeductionMeta(codeValue, isEdit);
    }

    const observables: Observable<[RawMetaObject, boolean, boolean]> = !isEdit
      ? combineLatest([
        this.payDeductionsStore.payDeductionAddFormMeta$(codeValue),
        this.payDeductionsStore.hasDeductionMetaError$,
        this.payDeductionsStore.isPayDeductionsMetaLoading$
      ])
      : combineLatest([
        this.payDeductionsStore.payDeductionEditFormMeta$(codeValue),
        this.payDeductionsStore.hasDeductionMetaError$,
        this.payDeductionsStore.isPayDeductionsMetaLoading$
      ]);

    return observables.pipe(
      skipWhile(([, , load]: [RawMetaObject, boolean, boolean]) => load),
      filter(([metaObj, error]: [RawMetaObject, boolean, boolean]) => {
        if (error) {
          throw new Error();
        }
        return !!metaObj;
      }),
      map(([metaObj]: [RawMetaObject, boolean, boolean]) => {
        const metaInstance = new Meta(metaObj, false);
        const metaForm = new DeductionsAddEditMetaForm(
          metaInstance,
          this.codeListService
        ).initialize();

        return from(metaForm);
      }),
      switchMap((metaForm) => metaForm)
    );
  }
}
