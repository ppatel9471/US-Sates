import { Component, Input, OnInit } from '@angular/core';

import { DirectDepositAccount } from '../../../direct-deposit/models/direct-deposit-account.model';
import { DirectDepositComparisonDetails } from '../../models/workflow-comparison-details.model';
import { DirectDepositComparisonService } from '../../services/direct-deposit-comparison.service';
import { WorkflowDetailsComparisonComponent } from '../workflow-details-comparison/workflow-details-comparison.component';

@Component({
  selector: 'dd-details-comparison',
  templateUrl: './direct-deposit-details-comparison.component.html'
})
export class DirectDepositDetailsComparisonComponent
  extends WorkflowDetailsComparisonComponent<DirectDepositAccount, DirectDepositComparisonDetails>
  implements OnInit {
  @Input() hasMultipleAccounts?: boolean;

  constructor(private comparisonService: DirectDepositComparisonService) {
    super();
  }

  public ngOnInit() {
    [this.currentComparisonData, this.pendingComparisonData] =
      this.comparisonService.getComparisonData(this.data, this.hasMultipleAccounts);
  }
}
