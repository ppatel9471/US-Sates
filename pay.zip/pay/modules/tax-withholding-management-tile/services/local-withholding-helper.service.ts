import { Injectable } from '@angular/core';
import { get } from 'lodash';

import { LanguageService } from '@myadp/common';

import { UsLocalTaxInstruction } from '../../../models/us-local-tax-instruction.model';
import { AdditionalTaxAmount } from '../../../models/tax-withholding.model';
import {
  SummaryItem,
  WithholdingInfo,
  WithholdingItem,
  WithholdingType
} from '../../../models/formatted-tax-withholding.model';
import { WithholdingFormatterService } from '../../shared/services/withholding-formatter.service';
import { ValueFormatterType } from '../../shared/services/value-formatter.service';

@Injectable({
  providedIn: 'root'
})
export class LocalWithholdingHelperService {
  constructor(
    private withholdingFormatterService: WithholdingFormatterService,
    private languageService: LanguageService
  ) {}
  public formatLocalWithholding(withholdings: UsLocalTaxInstruction[]): WithholdingInfo {
    const response: WithholdingInfo = {
      type: WithholdingType.LOCAL,
      hasError: false
    };

    if (withholdings) {
      let withholdingItems = [];
      for (const withholding of withholdings) {
        const summaryItems: SummaryItem[] = [];
        if (get(withholding, 'taxAllowanceQuantity') >= 0) {
          this.withholdingFormatterService.summaryItemHelper(
            summaryItems,
            withholding,
            'taxAllowanceQuantity',
            'TOTAL_ALLOWANCES'
          );
        }

        const additionalAmount: AdditionalTaxAmount = get(withholding, 'additionalTaxAmount');
        const additionalPercent: number = get(withholding, 'additionalTaxPercentage');
        if (
          this.withholdingFormatterService.showAdditionalTaxAmount(
            additionalAmount,
            additionalPercent
          )
        ) {
          this.withholdingFormatterService.summaryItemHelper(
            summaryItems,
            withholding,
            'additionalTaxAmount',
            'ADDITIONAL_WITHHOLDING_AMOUNT',
            ValueFormatterType.Currency
          );
        }

        if (
          this.withholdingFormatterService.showAdditionalTaxPercentage(
            additionalAmount,
            additionalPercent
          )
        ) {
          this.withholdingFormatterService.summaryItemHelper(
            summaryItems,
            withholding,
            'additionalTaxPercentage',
            'ADDITIONAL_PERCENT_WITHHELD',
            ValueFormatterType.Percentage
          );
        }
        const title = this.withholdingFormatterService.getTitleName(get(withholding, 'localCode'));
        const withholdingItem: WithholdingItem = {
          state: null,
          title,
          summaryItems: summaryItems,
          info: {
            type: 'info',
            title: this.languageService.get('myadp-pay.TAXWITHHOLDING_CARD_NOEDIT_TITLE'),
            message: this.languageService.get('myadp-pay.TAXWITHHOLDING_CARD_NOEDIT_MESSAGE')
          }
        };
        withholdingItems.push(withholdingItem);
      }
      withholdingItems = this.withholdingFormatterService.sortWithholdingInfo(withholdingItems);
      response.withholdingItems = withholdingItems;
    } else {
      response.hasElections = false;
    }
    return response;
  }
}
