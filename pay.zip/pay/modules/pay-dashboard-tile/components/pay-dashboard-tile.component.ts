import { CurrencyPipe } from '@angular/common';
import { Component, Input, OnDestroy, OnInit, Optional } from '@angular/core';
import { ClientDeviceService, LoggerFactory } from '@espresso/core';
import { DonutConfig } from '@synerg/components/donut';
import { TileComponent, TileService } from '@synerg/components/tile';
import * as log4javascript from 'log4javascript';
import moment from 'moment';
import { BehaviorSubject, Observable, Subscription } from 'rxjs';
import { filter, take } from 'rxjs/operators';
import * as Highcharts from 'highcharts';
import Accessibility from 'highcharts/modules/accessibility';

import { BarbecueService, LanguageService, LocationService } from '@myadp/common';
import { Amount } from '@myadp/dto';

import { DeductionCategoryItem } from '../models/pay-category-constants';
import { TileState } from '../models/tile-state.model';
import { PayDashboardTileBaseService } from '../services/pay-dashboard-tile-base.service';
import { PayDashboardTileServiceFactory } from '../services/pay-dashboard-tile-service.factory';

Accessibility(Highcharts);

declare const require: any;
const PAY_CARD_IMAGE = require('../../../assets/paylens-no-statements.png').default;

@Component({
  selector: 'pay-dashboard-tile',
  templateUrl: 'pay-dashboard-tile.component.html',
  styleUrls: ['pay-dashboard-tile.component.scss']
})
export class PayDashboardTileComponent implements OnInit, OnDestroy {
  @Input() unmaskValues: boolean = false;
  public prefix = 'pay-tile-';
  public PAY_CARD_IMAGE = PAY_CARD_IMAGE;
  public donutConfig: DonutConfig;

  public _state$ = new BehaviorSubject<TileState>({
    hasError: false,
    unmask: false,
    payDonutData: [],
    hasNoData: false,
    payDetailsObj: {
      netPay: null,
      payDate: '',
      totalHours: null,
      grossPay: null
    }
  });

  public uiState$ = this._state$.asObservable();
  public isLoading$: Observable<boolean>;

  public isLoading: boolean; // isLoading prop is needed for the MyADP dashboard component

  public isBbq: boolean;

  private logger: log4javascript.Logger;

  public isLoadingSubscription: Subscription;
  private payDashboardTileService: PayDashboardTileBaseService;
  constructor(
    loggerFactory: LoggerFactory,
    private payDashboardTileServiceFactory: PayDashboardTileServiceFactory,
    private currencyPipe: CurrencyPipe,
    private locationService: LocationService,
    private clientDeviceService: ClientDeviceService,
    private bbqService: BarbecueService,
    private languageService: LanguageService,
    @Optional() public tileService: TileService,
    @Optional() private tile: TileComponent = null
  ) {
    this.logger = loggerFactory.getLogger(
      'myadp.modules.pay-dashboard-tile.components.pay.PayDashboardTileComponent'
    );
  }

  public ngOnInit(): void {
    this.payDashboardTileService = this.payDashboardTileServiceFactory.getPayDashboardTileService();
    this.setState({ unmask: this.unmaskValues });
    this.payDashboardTileService.loadPayStatements();
    this.isLoading$ = this.payDashboardTileService.payStatementsIsLoading$();
    this.setIsLoading();
    this.setNavigation();

    this.isBbq = this.bbqService.isBarbecue();

    this.isLoading$
      .pipe(
        filter((value) => value === false),
        take(1)
      )
      .subscribe(() => {
        const response = this.payDashboardTileService.payStatements;
        const payDetails = response?.payStatements?.[0];

        if (payDetails) {
          const netPayObj: Amount = payDetails?.netPayAmount || {
            amountValue: null,
            currencyCode: null
          };
          const grossPayObj: Amount = payDetails?.grossPayAmount || {
            amountValue: null,
            currencyCode: null
          };
          const payDate = payDetails?.payDate ? moment(payDetails?.payDate).format('ll') : null;

          this.setState({
            netPay: this.getAmount(netPayObj),
            grossPay: this.getAmount(grossPayObj),
            payDetailsObj: {
              payDate: payDate,
              totalHours: payDetails?.totalHours,
              netPay: netPayObj,
              grossPay: grossPayObj
            }
          });

          this.loadDonutData();
        } else {
          this.setState({ hasNoData: true });
        }
        if (this.payDashboardTileService.payStatementsError) {
          this.logger.error('Error loading pay details');
          this.setState({ hasError: true });
        }
      });
  }

  ngOnDestroy() {
    if (this.isLoadingSubscription) {
      this.isLoadingSubscription.unsubscribe();
    }
  }

  public setIsLoading() {
    this.isLoadingSubscription = this.isLoading$.subscribe((isLoading: boolean) => {
      if (this.tileService) {
        this.tileService.setIsLoading(isLoading);
      }

      this.isLoading = isLoading;
    });
  }

  public setNavigation() {
    if (this.tileService) {
      this.tileService.setCanOpen(true);
    }

    if (this.tile) {
      this.tile.open.subscribe(() => {
        this.locationService.navigate('/pay');
      });
    }
  }

  public unmaskValue(show: boolean): void {
    this.setState({ unmask: !show });
  }

  public setNotifications(): void {
    const isNative = this.clientDeviceService.isNative();
    const params: [string, any] = [
      '/settings',
      {
        target:
          "?target=mobile-settings&ServeResourceAction.route=mobile-settings&componentRoute='notificationCenter'"
      }
    ];
    if (!isNative) {
      params.pop();
    }
    this.locationService.navigateParam(params);
  }

  public getState(): TileState {
    return this._state$.getValue();
  }

  public setState(partialState: Partial<TileState>): void {
    const currentState = this._state$.getValue();
    const nextState = Object.assign({}, currentState, partialState);

    this._state$.next(nextState);
  }

  private loadDonutData(): void {
    const { netPay, grossPay } = this.getState().payDetailsObj;

    this.donutConfig = this.payDashboardTileService.getPayDonutConfig(grossPay, netPay);
    const payDonutData = this.payDashboardTileService.getPayDonutData(grossPay, netPay);

    this.setState({
      payDonutData: this.formatValues(payDonutData)
    });
  }

  private formatValues(deductionCategory: DeductionCategoryItem[]): DeductionCategoryItem[] {
    deductionCategory.map((category) => {
      category.key = this.languageService.get(category.key);
      category.value = Math.abs(category.amount.amountValue);
      category.formatted = this.getAmount(category.amount);
    });
    return deductionCategory;
  }

  private getAmount({ amountValue, currencyCode }: Amount): string {
    return amountValue ? this.currencyFormat(amountValue, currencyCode) : '--';
  }

  private currencyFormat(amountValue: number, currencyCode: string): string {
    return this.currencyPipe.transform(amountValue, currencyCode);
  }
}
