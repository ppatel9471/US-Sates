import { Amount, PayStatementsDTO } from '@myadp/dto';

import { formatDate } from '../../shared/models/utils';
import { PayStatementsUI } from '../models/pay-statement-ui';
import { TAKE_HOME_ID, TAXABLE_BENEFIT_NAME } from '../constants/deduction-category-metadata.const';
import { transformDeductionsCategories } from './deduction-category.transform';
import { transformDonut } from './donut.transform';

export function transformStatementDetails(
  response: PayStatementsDTO.PayStatementDetailsRaw
): PayStatementsUI.PayStatementDetails {
  const statementDetailsRaw = response?.payStatement;
  const statementDetail = statementDetailsRaw;
  const grossPay = statementDetail?.grossPayAmount;
  let statementDetails: PayStatementsUI.PayStatementDetails = {};

  if (statementDetailsRaw) {
    const deductionCategories: PayStatementsUI.DeductionsCategory[] = transformDeductionsCategories(
      statementDetail
    );
    const grossPayYTD = statementDetail?.grossPayYTDAmount;

    statementDetails = {
      payDate: formatDate(statementDetail?.payDate),
      netPay: statementDetail?.netPayAmount,
      totalHours: statementDetail?.totalHours,
      grossPay: grossPay,
      grossPayYTD: grossPayYTD,
      earnings: getEarnings(statementDetail?.earnings),
      deductionsCategories: deductionCategories,
      donutData: transformDonut(deductionCategories, grossPay),
      hasYearToDateData: hasYearToDateData(deductionCategories, grossPayYTD),
      directDeposits: statementDetail?.directDeposits,
      memos: getMemos(statementDetail?.memos ?? [])
    };
  } else {
    const deductionCategories = transformDeductionsCategories(statementDetail);
    statementDetails = {
      donutData: transformDonut(deductionCategories, grossPay)
    };
  }

  return statementDetails;
}

function hasYearToDateData(
  deductionCategories: PayStatementsUI.DeductionsCategory[],
  grossPayYTD: Amount
): boolean {
  // filter out take home
  const hasYtdValues = deductionCategories
    .filter((category) => category.id !== TAKE_HOME_ID)
    .some((category) => !!category?.amountYTD?.amountValue);

  return hasYtdValues || !!grossPayYTD?.amountValue;
}

function getEarnings(earningsRaw: PayStatementsDTO.Earning[] = []): PayStatementsUI.Earning[] {
  const REGULAR_EARNING_NAME = 'Regular';
  earningsRaw = earningsRaw || [];

  if (earningsRaw === null) {
    earningsRaw = [];
  }
  return (
    earningsRaw
      .map((earning) => ({
        name: earning?.earningCodeName?.trim(),
        amount: earning?.earningAmount,
        rate: earning?.payRate,
        payPeriodHours: earning?.payPeriodHours,
        preTax: earning?.preTaxIndicator
      }))
      .filter(
        (earning: PayStatementsUI.Earning) =>
          // keep only earnings that have something capable of being used
          !!earning?.amount?.amountValue || !!earning?.rate || !!earning?.payPeriodHours
      )
      .sort((e1: PayStatementsUI.Earning, e2: PayStatementsUI.Earning) => {
        const e1Name = e1?.name;
        const e2Name = e2?.name;

        // if both earnings are "Regular" earnings, sort them by amount
        if (e1Name === REGULAR_EARNING_NAME && e2Name === REGULAR_EARNING_NAME) {
          return e2?.amount?.amountValue - e1?.amount?.amountValue;
        } else {
          // sort alphabetically
          return e1Name.localeCompare(e2Name, undefined, { numeric: true });
        }
      })
      .reduce(
        (earningBuckets: PayStatementsUI.Earning[][], earning: PayStatementsUI.Earning) => {
          /**
           * Sort into buckets using the below criteria:
           * Bucket #0: is a "Regular" earning
           * Bucket #1: the earning has valid payPeriodHours
           * Bucket #2: everything else
           */
          let bucket: number;

          if (earning?.name === REGULAR_EARNING_NAME) {
            bucket = 0;
          } else if (earning?.payPeriodHours) {
            bucket = 1;
          } else {
            bucket = 2;
          }

          earningBuckets[bucket].push(earning);
          return earningBuckets;
        },
        [[], [], []]
      )
      // flatten the buckets
      .reduce((sortedEarnings, earningBucket) => sortedEarnings.concat(earningBucket), [])
  );
}

function getMemos(memos: PayStatementsDTO.Memo[]): PayStatementsUI.Memos {
  const _memos: PayStatementsUI.Memo[] = memos.map((memo) => ({
    name: memo?.nameCode?.shortName?.trim(),
    categoryName: memo?.memoCategoryCode?.shortName,
    amount: memo?.memoAmount?.amountValue,
    amountYTD: memo?.memoYTDAmount?.amountValue
  }));
  const otherMemos = _memos.filter((memo) => memo?.categoryName !== TAXABLE_BENEFIT_NAME);
  const taxableBenefits = _memos.filter((memo) => memo?.categoryName === TAXABLE_BENEFIT_NAME);

  return {
    otherMemos: otherMemos?.length ? otherMemos : null,
    taxableBenefits: taxableBenefits?.length ? taxableBenefits : null
  };
}
