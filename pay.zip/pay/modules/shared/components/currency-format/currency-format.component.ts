import {
  ChangeDetectionStrategy,
  Component,
  HostBinding,
  Input,
  OnDestroy,
  OnChanges,
  OnInit
} from '@angular/core';
import { Observable, Subscription } from 'rxjs';
import { map } from 'rxjs/operators';

import { Amount } from '@myadp/dto';

import { PrivacyModeStore } from '../../../privacy-mode-shared/store/privacy-mode.store';
import {
  ValueFormatterService,
  ValueFormatterType
} from '../../../shared/services/value-formatter.service';

@Component({
  selector: 'pay-currency-format',
  template: '{{displayValue$ | async}}',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class CurrencyFormatComponent implements OnInit, OnChanges, OnDestroy {
  @Input() public enablePrivacy: boolean = true;
  @Input() public value: Amount & { amount: number; currencyCode: string } & {
    rateValue: number;
    currencyCode: string;
  };
  /**
   * Angular's CurrencyPipe digitsInfo format:
   * `{minIntegerDigits}.{minFractionDigits}-{maxFractionDigits}`
   */
  @Input() public digitsInfo?: string;
  @HostBinding('attr.aria-label') ariaLabel: string;
  public formattedAmount: string;
  public maskedAmount: string;
  public displayValue$: Observable<string>;
  public isNativeMobile: boolean = false;
  public displaySub: Subscription;

  constructor(
    private valueFormatterService: ValueFormatterService,
    private privacyModeStore: PrivacyModeStore
  ) {}

  public ngOnInit() {
    this.maskedAmount = this.getMaskedAmount();

    this.displayValue$ = this.privacyModeStore.showMaskedValue$.pipe(
      map(privacyModeEnabled => this.getDisplayValue(privacyModeEnabled))
    );

    // Screen readers wont read negative symbol when amounts have commas
    this.displaySub = this.displayValue$
      .subscribe({
        next: displayValue => this.ariaLabel = displayValue.replace(',', '')
      });
  }

  public ngOnChanges() {
    this.formattedAmount = this.getFormattedAmount();
  }

  public ngOnDestroy() {
    this.displaySub.unsubscribe();
  }

  private getFormattedAmount(): string {
    // TEMP: normalize from AngularJS objects
    const amount: Amount = {
      amountValue: this.value?.amountValue ?? this.value?.amount ?? this.value?.rateValue,
      currencyCode: this.value?.currencyCode
    };

    return this.valueFormatterService.format(
      amount || {},
      ValueFormatterType.Currency,
      this.digitsInfo
    );
  }

  private getMaskedAmount(): string {
    const formattedMaskedAmount: string = this.valueFormatterService.format(
      { amountValue: '1111.11', currencyCode: this.value?.currencyCode },
      ValueFormatterType.Currency,
      this.digitsInfo
    );
    return formattedMaskedAmount.replace(/[0-9]/g, 'X');
  }

  private getDisplayValue(privacyModeEnabled: boolean): string {
    return this.enablePrivacy && privacyModeEnabled
      ? this.maskedAmount
      : this.formattedAmount || '--';
  }
}
