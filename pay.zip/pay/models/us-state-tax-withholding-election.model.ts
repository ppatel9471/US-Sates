import {
  Action,
  AdditionalStatutoryInput,
  AdditionalTaxAmount,
  AttachmentType,
  CodeType,
  PendingEvent,
  TaxWithholdingStatus
} from './tax-withholding.model';

export interface UsStateTaxWithholdingElections {
  usStateTaxWithholdingElections?: UsStateTaxWithholdingElection[];
}

export interface UsStateTaxWithholdingElection {
  links?: string[];
  payrollGroupCode?: CodeType;
  payrollRegionCode?: CodeType;
  stateIncomeTaxWithholdingElections?: StateIncomeTaxWithholdingElection[];
  workflowData?: UsStateTaxWithholdingElectionsWorkflowData;
}

export interface StateIncomeTaxWithholdingElection {
  actions?: Action[];
  livedInJurisdictionIndicator?: boolean;
  workedInJurisdictionIndicator?: boolean;
  taxWithholdingStatus?: TaxWithholdingStatus;
  additionalTaxAmount?: AdditionalTaxAmount;
  stateCode?: CodeType;
  taxFilingStatusCode?: CodeType;
  additionalTaxPercentage?: number;
  reducedTaxAmount?: number;
  taxWithholdingAllowanceQuantity?: number;
  additionalStatutoryInputs?: AdditionalStatutoryInput[];
  attachments?: AttachmentType[];
}

export interface UsStateTaxWithholdingElectionsWorkflowData {
  pendingData?: UsStateTaxWithholdingElections;
  pendingEvents?: PendingEvent;
}
