import { TestBed } from '@angular/core/testing';

import { INSIGHTS_TAG } from '../../../models/payment-calculation-analysis.model';
import { deductionCategoryMetadata } from '../../pay-statements-shared/constants/deduction-category-metadata.const';
import { PayStatementsUI } from '../../pay-statements-shared/models/pay-statement-ui';
import { DeductionsDataSelectorPipe } from './deductions-data-selector.pipe';

describe('DeductionsDataSelectorPipe', () => {
  let pipe: DeductionsDataSelectorPipe;
  const mockDeductions: PayStatementsUI.DeductionsCategory[] = [
    {
      id: 'taxes',
      name: deductionCategoryMetadata['taxes'].name,
      amount: { amountValue: -123.45, currencyCode: 'USD' },
      amountYTD: { amountValue: -987.65, currencyCode: 'USD' },
      displayConfig: {
        ...deductionCategoryMetadata['taxes'].displayConfig,
        calculatorLink: {
          title: 'Tax Withholding Calculator',
          link: 'www.tax-calculator.com'
        }
      },
      deductions: [
        {
          name: 'Federal Income Tax',
          amount: { amountValue: -123.45, currencyCode: 'USD' },
          amountYTD: { amountValue: -678.9, currencyCode: 'USD' },
          preTax: true
        }
      ],
      insightsTag: INSIGHTS_TAG.TAXES
    },
    {
      id: 'benefits',
      name: deductionCategoryMetadata['benefits'].name,
      amount: { amountValue: -23.45, currencyCode: 'USD' },
      amountYTD: { amountValue: -87.65, currencyCode: 'USD' },
      displayConfig: {
        ...deductionCategoryMetadata['benefits'].displayConfig,
        calculatorLink: null
      },
      deductions: [
        {
          name: 'Something beneficial',
          amount: { amountValue: -23.45, currencyCode: 'USD' },
          amountYTD: { amountValue: -78.9, currencyCode: 'USD' },
          preTax: false
        }
      ],
      insightsTag: INSIGHTS_TAG.BENEFITS
    },
    {
      id: 'retirement',
      name: deductionCategoryMetadata['retirement'].name,
      amount: { amountValue: -23.45, currencyCode: 'USD' },
      amountYTD: { amountValue: -87.65, currencyCode: 'USD' },
      displayConfig: {
        ...deductionCategoryMetadata['retirement'].displayConfig,
        calculatorLink: {
          title: 'Retirement Calculator',
          link: 'www.retirement-calculator.com'
        }
      },
      deductions: [
        {
          name: 'Retirement 401k',
          amount: { amountValue: -23.45, currencyCode: 'USD' },
          amountYTD: { amountValue: -78.9, currencyCode: 'USD' },
          preTax: true
        }
      ],
      insightsTag: INSIGHTS_TAG.RETIREMENT
    },
    {
      id: 'adjustments',
      name: 'myadp-pay.PAY_ADJUSTMENTS',
      amount: { amountValue: -250, currencyCode: 'USD' },
      amountYTD: { amountValue: null, currencyCode: null },
      deductions: [
        {
          name: 'Net Pay Recovery',
          amount: { amountValue: -250, currencyCode: 'USD' },
          preTax: false
        }
      ],
      displayConfig: { rank: 16, color: 'accent-3-dark' }
    },
    {
      id: 'takeHome',
      name: deductionCategoryMetadata['takeHome'].name,
      amount: { amountValue: 523.45, currencyCode: 'USD' },
      amountYTD: { amountValue: 987.95, currencyCode: 'USD' },
      displayConfig: {
        ...deductionCategoryMetadata['takeHome'].displayConfig,
        calculatorLink: {
          title: 'Paycheck Calculator',
          link: 'www.paycheck-calculator.com'
        }
      },
      deductions: [
        {
          name: 'Check',
          amount: { amountValue: 771.95, currencyCode: 'USD' },
          amountYTD: undefined
        }
      ]
    }
  ];

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DeductionsDataSelectorPipe]
    });

    pipe = new DeductionsDataSelectorPipe();
  });

  it('should return deduction categories w/o changes when not on YTD', () => {
    const transformedDeductions = pipe.transform(mockDeductions, false);

    expect(transformedDeductions.length).toBe(5);
    expect(transformedDeductions).toEqual(mockDeductions);
  });

  it('should remove Take Home category and breakdown and Adjustments when on YTD', () => {
    const transformedDeductions = pipe.transform(mockDeductions, true);

    expect(transformedDeductions.length).toBe(3);
    expect(transformedDeductions).toEqual([
      mockDeductions[0],
      mockDeductions[1],
      mockDeductions[2]
    ]);
  });
});
