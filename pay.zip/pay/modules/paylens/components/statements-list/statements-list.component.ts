import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  OnChanges,
  Output,
  OnInit
} from '@angular/core';

import { PayStatementsUI } from '../../../pay-statements-shared/models/pay-statement-ui';
import { BehaviorSubject, combineLatest, Observable, of } from 'rxjs';
import { ClientDeviceService, StackService } from '@synerg/components/shared';
import { map, startWith } from 'rxjs/operators';

@Component({
  selector: 'paylens-statements-list',
  templateUrl: './statements-list.component.html',
  styleUrls: ['./statements-list.component.scss', 'statements-list.component-alt.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class PaylensStatementsListComponent implements OnInit, OnChanges {
  @Input() autoSelectAfterFilter: boolean = true;
  @Input() showFilter: boolean = true;
  @Input() showBatchDownload: boolean = true;
  @Input() limit: number;
  @Input() statements: PayStatementsUI.PayStatement[];
  @Input() disableClick: boolean;
  @Input() currentStatementData: PayStatementsUI.PayStatementDetailsState;
  @Input() autoFilterStatementList: boolean = true;
  @Output() loadedDetails = new EventEmitter<PayStatementsUI.PayStatement>();
  public filteredStatements = new BehaviorSubject<PayStatementsUI.PayStatement[]>([]);
  public isDialogOpen$: Observable<boolean>;
  private currentFilteredDate: string;

  constructor(
    private stackService: StackService,
    private clientDeviceService: ClientDeviceService
  ) {}

  public ngOnInit() {
    if (this.clientDeviceService.isIE()) {
      this.isDialogOpen$ = combineLatest([
        this.stackService.modalStack$.pipe(startWith([])),
        this.stackService.slideinStack$.pipe(startWith([]))
      ]).pipe(map(([modal, slideIn]) => modal.length + slideIn.length > 0));
    } else {
      this.isDialogOpen$ = of(false);
    }
  }

  public ngOnChanges(): void {
    if (this.autoFilterStatementList) {
      this.filterByYear(this.currentStatementData?.statementFiscalYear);
    } else {
      // mobile statements & activity (static list) shouldn't be filtered by date
      this.filteredStatements.next(this.statements);
    }
  }

  public loadDetails(statement: PayStatementsUI.PayStatement): void {
    this.loadedDetails.emit(statement);
  }

  public onStatementsFiltered(year: string): void {
    if (this.currentFilteredDate !== year) {
      const filteredStatements = this.filterByYear(year);
      if (this.autoSelectAfterFilter) {
        this.loadDetails(filteredStatements[0]);
      }
    }
  }

  public filterByYear(year: string): PayStatementsUI.PayStatement[] {
    this.currentFilteredDate = year;
    const nextFilteredStatements = this.statements.filter(
      (statement) => statement?.statementFiscalYear === year
    );
    this.filteredStatements.next(nextFilteredStatements);
    return nextFilteredStatements;
  }
}
