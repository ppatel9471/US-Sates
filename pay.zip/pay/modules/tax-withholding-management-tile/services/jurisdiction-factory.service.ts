import { Injectable, Injector } from '@angular/core';
import { capitalize, find } from 'lodash';

import { StateModel } from '../../../models/states.model';
import { CodeType } from '../../../models/tax-withholding.model';
import * as StateComponentsServices from '../../tax-withholding-management/all-wizard-components-services';
import * as AllWizardSteps from '../../tax-withholding-management/all-wizard-steps';
import { MetaDataDecorator } from '../../tax-withholding-management/shared/models/meta-data-decorator';
import { STEPSTYPE } from '../../tax-withholding-management/shared/models/steps-type.model';
import { DoneMetaDataService } from '../../tax-withholding-management/shared/services/done-meta-data.service';
import { ESignMetaDataService } from '../../tax-withholding-management/shared/services/esign-meta-data.service';
import { StateSecondaryFormService } from '../../tax-withholding-management/shared/services/state-secondary-form.service';
import { StepNavigationBaseService } from '../../tax-withholding-management/shared/services/step-navigation-base.service';
import { SummaryMetaDataService } from '../../tax-withholding-management/shared/services/summary-meta-data.service';
import { StatutoryFormObject } from '../../tax-withholding-management/us/shared/models/statutory-forms.model';
import { SHARED_STEPS } from '../../tax-withholding-management/us/shared/models/steps.enum';
import { WizardDataModel } from '../../tax-withholding-management/us/shared/models/wizard-data.model';
import { StateTWChangeEventService } from '../../tax-withholding-management/us/shared/services/state-tw-change-event.service';

@Injectable({
  providedIn: 'root'
})
export class JurisdictionFactoryService {
  constructor(private injector: Injector) {}

  public getDoneMetaDataService(state: StateModel): DoneMetaDataService {
    return this.injector.get<DoneMetaDataService>(
      StateComponentsServices[
        `${this.convertStateShortName(state.shortName)}DoneMetaDataService`
      ] || DoneMetaDataService
    );
  }

  public getESignMetaDataService(state: StateModel): ESignMetaDataService {
    return this.injector.get<ESignMetaDataService>(
      StateComponentsServices[
        `${this.convertStateShortName(state.shortName)}ESignMetaDataService`
      ] || ESignMetaDataService
    );
  }

  public getTwChangeEventService(state: StateModel): StateTWChangeEventService {
    const serviceToken =
      StateComponentsServices[`${this.convertStateShortName(state.shortName)}TWChangeEventService`];
    if (serviceToken) {
      return this.injector.get<StateTWChangeEventService>(serviceToken);
    }
  }

  public getStepComponents(state: StateModel): { [step: string]: object } {
    const stepComponents = StateComponentsServices[`${state.shortName}STEP_COMPONENT`];

    if (stepComponents instanceof Function) {
      const secondaryFormServiceToken =
        StateComponentsServices[
          `${this.convertStateShortName(state.shortName)}SecondaryFormService`
        ];
      const secondaryFormService =
        this.injector.get<StateSecondaryFormService>(secondaryFormServiceToken);

      return StateComponentsServices[`${state.shortName}STEP_COMPONENT`]?.(
        secondaryFormService?.isAllowlisted()
      );
    } else {
      return StateComponentsServices[`${state.shortName}STEP_COMPONENT`];
    }
  }

  public getStepsMetaData(state: StateModel): STEPSTYPE {
    let steps = { ...AllWizardSteps[`${state.shortName}STEPS`], ...SHARED_STEPS };
    const decoratorToken =
      StateComponentsServices[
        `${this.convertStateShortName(state.shortName)}MetaDataDecoratorService`
      ];
    if (decoratorToken) {
      steps = this.injector.get<MetaDataDecorator>(decoratorToken).decorate(steps);
    }
    return steps;
  }

  public getStepNavigationService(state: StateModel): StepNavigationBaseService {
    return this.injector.get<StepNavigationBaseService>(
      StateComponentsServices[
        `${this.convertStateShortName(state.shortName)}StepNavigationService`
      ] || StepNavigationBaseService
    );
  }

  public getSummaryMetaDataService(state: StateModel): SummaryMetaDataService<WizardDataModel> {
    const serviceToken =
      StateComponentsServices[
        `${this.convertStateShortName(state.shortName)}SummaryMetaDataService`
      ];
    if (serviceToken) {
      return this.injector.get<SummaryMetaDataService<WizardDataModel>>(serviceToken);
    }
  }

  public getAttachmentNameCode(state: StateModel, type: string = 'primary'): CodeType {
    return find<{ type: string }, StatutoryFormObject>(
      StateComponentsServices[`${this.convertStateShortName(state.shortName)}AttachmentCodes`],
      { type }
    )?.data;
  }

  private convertStateShortName(stateShortName: string) {
    return capitalize(stateShortName.toLowerCase());
  }
}
