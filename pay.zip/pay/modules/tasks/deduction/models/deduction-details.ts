import { clone, find, get } from 'lodash';
import { CodeListItem, DeductionsDTO, PendingEventsHistoryDetails } from '@myadp/dto';
import {
  loadRequesterAndLatestComments,
  NotificationComments,
  NotificationCodeType
} from '@myadp/thingstodo-shared';

import { DEDUCTION_EVENT_TYPE, DEDUCTION_PATH, DeductionComparisonData } from './deduction-tasks-details.model';
import { PayTasksService } from '../../shared/services/pay-tasks.service';

export class DeductionDetails {
  public notificationCodeType: NotificationCodeType;
  public comparisonData: DeductionComparisonData;
  public pendingEvent: string;
  public itemID: string;
  public comments: NotificationComments;
  public statusCode: string;

  public currentData: DeductionsDTO.GeneralDeductionInstruction[];
  public pendingData: DeductionsDTO.GeneralDeductionInstruction;

  public payrollGroupCode: CodeListItem;
  public pendingEventsHistory: PendingEventsHistoryDetails[];

  constructor(
    data: DeductionsDTO.DeductionTasksDetails,
    notificationCodeType: NotificationCodeType
  ) {
    this.notificationCodeType = notificationCodeType;
    this.currentData = <DeductionsDTO.GeneralDeductionInstruction[]>(
      (get(data, DEDUCTION_PATH.TASK_CURRENT_DATA) ||
        get(data, DEDUCTION_PATH.NOTIFICATION_CURRENT_DATA, {}))
    );
    this.pendingData = <DeductionsDTO.GeneralDeductionInstruction>(
      (get(data, DEDUCTION_PATH.TASK_PENDING_DATA) ||
        get(data, DEDUCTION_PATH.NOTIFICATION_PENDING_DATA, {}))
    );
    this.pendingEvent =
      get(data, DEDUCTION_PATH.TASK_RESOURCE_PATH) ||
      get(data, DEDUCTION_PATH.NOTIFICATION_RESOURCE_PATH);
    this.pendingEvent = this.pendingEvent
      .split('/')
      .pop()
      .split('.')
      .pop();

    this.itemID =
      get(data, DEDUCTION_PATH.TASK_ITEM_ID) || get(data, DEDUCTION_PATH.NOTIFICATION_ITEM_ID);
    this.comparisonData = this.getComparisonData();
    this.statusCode = PayTasksService.getStatusCodeLabel(data);
    this.comments = loadRequesterAndLatestComments(data, null);
    this.payrollGroupCode = get(data, 'currentData.workerGeneralDeductionInstructions[0].payrollGroupCode');
    this.pendingEventsHistory = data.history ? data.history : get(data, 'pendingEvents[0].history');
  }

  private getComparisonData(): DeductionComparisonData {
    const pendingObj: DeductionsDTO.GeneralDeductionInstruction = clone(
      find(this.currentData, (obj) => {
        return obj.itemID === this.itemID;
      }),
      true
    );
    const lookUp = {
      [DEDUCTION_EVENT_TYPE.CHANGE]: () => {
        const comparison: DeductionsDTO.GeneralDeductionInstruction = {};
        // compare numeric values for rateValue & goalLimitAmount, default to 0 if falsy values
        if (pendingObj?.deductionRate?.rateValue !== this.pendingData?.deductionRate?.rateValue) {
          this.normalizeRate(comparison);
        }

        if (
          pendingObj?.deductionGoal?.goalLimitAmount?.amountValue !==
          this.pendingData?.deductionGoal?.goalLimitAmount?.amountValue
        ) {
          this.normalizeGoal(comparison);
        }

        return { currentData: pendingObj, pendingData: comparison };
      },
      [DEDUCTION_EVENT_TYPE.START]: () => {
        this.normalizeRate(this.pendingData);
        this.normalizeGoal(this.pendingData);

        return {
          pendingData: this.pendingData
        };
      },
      [DEDUCTION_EVENT_TYPE.STOP]: () => {
        this.normalizeRate(pendingObj, true);
        this.normalizeGoal(pendingObj, true);

        return { currentData: pendingObj };
      }
    };

    const comparisonData = lookUp[this.pendingEvent]();
    comparisonData.itemID = this.itemID;
    comparisonData.type = this.pendingEvent;
    return comparisonData;
  }

  private normalizeRate(
    deduction: DeductionsDTO.GeneralDeductionInstruction,
    isStopEvent: boolean = false
  ) {
    if (!isStopEvent) {
      deduction.deductionRate = {
        ...this.pendingData?.deductionRate,
        rateValue: this.pendingData?.deductionRate?.rateValue ?? 0
      };
    } else {
      deduction.deductionRate = {
        ...deduction?.deductionRate,
        rateValue: deduction?.deductionRate?.rateValue ?? 0
      };
    }
  }

  private normalizeGoal(
    deduction: DeductionsDTO.GeneralDeductionInstruction,
    isStopEvent: boolean = false
  ) {
    if (!isStopEvent) {
      deduction.deductionGoal = {
        ...this.pendingData?.deductionGoal,
        goalLimitAmount: {
          ...this.pendingData?.deductionGoal?.goalLimitAmount,
          amountValue: this.pendingData?.deductionGoal?.goalLimitAmount?.amountValue ?? 0
        }
      };
    } else {
      deduction.deductionGoal = {
        ...deduction?.deductionGoal,
        goalLimitAmount: {
          ...deduction?.deductionGoal?.goalLimitAmount,
          amountValue: deduction?.deductionGoal?.goalLimitAmount?.amountValue ?? 0
        }
      };
    }
  }
}
