import { TestBed } from '@angular/core/testing';

import { PayStatementsUI } from '../../pay-statements-shared/models/pay-statement-ui';
import { MemosDataSelectorPipe } from './memos-data-selector.pipe';

describe('MemosDataSelectorPipe', () => {
  let pipe: MemosDataSelectorPipe;
  const mockMemos: PayStatementsUI.Memos = {
    otherMemos: [
      {
        name: 'EFG',
        categoryName: 'not Taxable',
        amount: 6.12,
        amountYTD: 1456.03
      },
      {
        name: 'L337',
        categoryName: undefined,
        amount: null,
        amountYTD: 392.68
      }
    ],
    taxableBenefits: [
      {
        name: 'Incentive',
        categoryName: 'Taxable Benefit',
        amount: 8.63,
        amountYTD: 156.63
      },
      {
        name: 'SomethingTaxable',
        categoryName: 'Taxable Benefit',
        amount: 15.56,
        amountYTD: undefined
      }
    ]
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [MemosDataSelectorPipe]
    });

    pipe = new MemosDataSelectorPipe();
  });

  it('should return memos with amounts when not on YTD', () => {
    const transformedMemos = pipe.transform(mockMemos, false);

    expect(transformedMemos).toEqual({
      otherMemos: [mockMemos.otherMemos[0]],
      taxableBenefits: mockMemos.taxableBenefits
    });
  });

  it('should return memos with YTD amounts when on YTD', () => {
    const transformedMemos = pipe.transform(mockMemos, true);

    expect(transformedMemos).toEqual({
      otherMemos: mockMemos.otherMemos,
      taxableBenefits: [mockMemos.taxableBenefits[0]]
    });
  });
});
