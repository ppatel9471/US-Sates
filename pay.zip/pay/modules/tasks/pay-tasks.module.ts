import { NgModule } from '@angular/core';

import { DirectDepositTasksModule } from './direct-deposit/direct-deposit-tasks.module';
import { TaxWithholdingTasksModule } from './tax-withholding/tax-withholding-tasks.module';
import { DeductionTasksModule } from './deduction/deduction-tasks.module';

@NgModule({
  imports: [DirectDepositTasksModule, TaxWithholdingTasksModule, DeductionTasksModule],
  exports: [DirectDepositTasksModule, TaxWithholdingTasksModule, DeductionTasksModule],
})
export class PayTasksModule {}
