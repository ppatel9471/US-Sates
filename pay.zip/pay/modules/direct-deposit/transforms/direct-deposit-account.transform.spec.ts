import { SORS } from '@myadp/common';
import { mockClockAfterEach, mockClockBeforeEach } from '@myadp/pay-shared/testing/spec-util.spec';
import {
  MOCK_FORM_DETAILS,
  MOCK_TRANSFORMED_DIRECT_DEPOSIT_ACCOUNTS
} from '@specHelpers/pay/direct-deposit/direct-deposit';

import {
  DistributionOptions,
  PayDistributionsUI
} from '../../pay-distributions-shared/models/pay-distributions-ui';
import { AccountDetailsControls } from '../models/account-details-form.model';
import { DepositAmountControls } from '../models/deposit-amount-form.model';
import { DirectDepositAccount } from '../models/direct-deposit-account.model';
import {
  transformDirectDepositAccounts,
  transformFormDetails
} from './direct-deposit-account.transform';

describe('transformDirectDepositAccounts', () => {
  const mockMeta = {
    paymentMethodCodes: {
      codeList: [{ shortName: 'DailyPay', codeValue: 'DP2' }],
      readOnly: true
    }
  };

  const mockAccounts: DirectDepositAccount[] = [
    {
      currentData: {
        id: 'sDED31032',
        codeValueData: {
          itemID: '103',
          longName: 'DED3',
          shortName: undefined,
          accountCode: '103'
        },
        precedence: '2',
        precedenceCode: '2',
        accountTypeName: 'DED3',
        accountNumber: '0000000015',
        routingNumber: '021200025',
        accountName: undefined,
        distributionType: DistributionOptions.FLAT,
        flatAmount: { amountValue: 50, currencyCode: 'USD' }
      },
      pendingData: {
        id: 'sDED31032',
        codeValueData: {
          itemID: '103',
          longName: 'DED3',
          shortName: undefined,
          accountCode: '103'
        },
        precedence: '2',
        accountTypeName: 'DED3',
        accountNumber: '0000000015',
        routingNumber: '021200025',
        accountName: undefined,
        distributionType: DistributionOptions.FLAT,
        flatAmount: { amountValue: 45, currencyCode: 'USD' }
      },
      pendingEvent: {
        approver: 'Practitioner, Divya',
        changeType: 'edit'
      }
    }
  ];

  describe('Wisely', () => {
    it('should transform PayDistributions to DirectDepositAccounts with Wisely using Account Name', () => {
      const mockAccount = {
        ...mockAccounts[0],
        currentData: {
          ...mockAccounts[0].currentData,
          accountName: 'WISELY DIRECT'
        }
      };

      expect(transformDirectDepositAccounts([mockAccount], mockMeta, 'FOO', true)).toEqual([
        {
          isReadOnly: false,
          isWisely: true,
          isDailyPay: false,
          hasAltWorkflow: false,
          ...mockAccount
        }
      ]);
    });

    it('should transform PayDistributions to DirectDepositAccounts with Wisely using accountTypeName', () => {
      const mockAccount = {
        ...mockAccounts[0],
        currentData: {
          ...mockAccounts[0].currentData,
          accountTypeName: 'WIS'
        }
      };

      expect(transformDirectDepositAccounts([mockAccount], mockMeta, 'FOO', true)).toEqual([
        {
          isReadOnly: false,
          isWisely: true,
          isDailyPay: false,
          hasAltWorkflow: false,
          ...mockAccount
        }
      ]);
    });
  });

  it('should transform PayDistributions to DirectDepositAccounts', () => {
    expect(transformDirectDepositAccounts(mockAccounts, mockMeta, 'FOO', true)).toEqual([
      {
        isReadOnly: false,
        isWisely: false,
        isDailyPay: false,
        hasAltWorkflow: false,
        ...mockAccounts[0]
      }
    ]);
  });

  it('should set isReadyOnly to true user does not have change permissions', () => {
    expect(transformDirectDepositAccounts(mockAccounts, mockMeta, SORS.US.RUN, false)).toEqual([
      {
        isReadOnly: true,
        isWisely: false,
        isDailyPay: false,
        hasAltWorkflow: false,
        ...mockAccounts[0]
      }
    ]);
  });

  it('should set isReadyOnly to true if SOR is AVS and email is not configured', () => {
    expect(
      transformDirectDepositAccounts(
        mockAccounts,
        { isEmailConfigured: false },
        SORS.US.AVSDDM,
        true
      )
    ).toEqual([
      {
        isReadOnly: true,
        isWisely: false,
        isDailyPay: false,
        hasAltWorkflow: false,
        ...mockAccounts[0]
      }
    ]);
  });

  it('should set isDailyPay', () => {
    const mockDailyPayDists: PayDistributionsUI.PayDistribution[] = [
      {
        currentData: {
          id: 'sEarnedWageAccessDP2',
          codeValueData: {
            itemID: '103',
            longName: 'EarnedWageAccess',
            shortName: null,
            accountCode: 'DP2'
          },
          precedence: '1',
          accountTypeName: 'DP2',
          accountNumber: '0000000015',
          routingNumber: '021200025',
          accountName: undefined,
          distributionType: DistributionOptions.FLAT,
          flatAmount: { amountValue: 50, currencyCode: 'USD' }
        },
        pendingData: null,
        pendingEvent: null
      }
    ];

    expect(transformDirectDepositAccounts(mockDailyPayDists, mockMeta, 'FOO', true)).toEqual([
      {
        isReadOnly: true,
        isWisely: false,
        isDailyPay: true,
        hasAltWorkflow: false,
        ...mockDailyPayDists[0]
      }
    ]);
  });

  it('should set hasAltWorkflow', () => {
    const mockAltWfDists: PayDistributionsUI.PayDistribution[] = [
      {
        currentData: null,
        pendingData: {
          id: 'XX1',
          codeValueData: {
            itemID: 'X1',
            longName: 'Checking',
            shortName: null,
            accountCode: 'X'
          },
          precedence: undefined,
          accountTypeName: 'X1',
          accountNumber: '0000000015',
          routingNumber: '021200025',
          accountName: undefined,
          distributionType: DistributionOptions.FLAT,
          flatAmount: { amountValue: 50, currencyCode: 'USD' }
        },
        pendingEvent: { altWorkflowMessage: 'Waiting for approval' }
      }
    ];

    expect(transformDirectDepositAccounts(mockAltWfDists, mockMeta, 'FOO', true)).toEqual([
      {
        isReadOnly: false,
        isWisely: false,
        isDailyPay: false,
        hasAltWorkflow: true,
        ...mockAltWfDists[0]
      }
    ]);
  });

  describe('transformFormDetails', () => {
    beforeEach(() => {
      mockClockBeforeEach();
    });

    afterEach(() => {
      mockClockAfterEach();
    });

    it('should include institution and transit number if available', () => {
      const transformedDetails = transformFormDetails(
        true,
        {
          [AccountDetailsControls.ACCOUNT_TYPE_CODE]: {
            label: 'Checking',
            shortName: ''
          },
          codeValueData: {
            accountCode: 'C2',
            shortName: ''
          },
          [AccountDetailsControls.ACCOUNT_NAME]: '',
          [AccountDetailsControls.ACCOUNT_NUMBER]: 'X123456P7',
          [AccountDetailsControls.TRANSIT_NUMBER]: '021000021',
          [AccountDetailsControls.INSTITUTION]: {
            value: '999',
            label: 'Canada Bank'
          } as any, // vs code complains that this is not an AccountType
          [DepositAmountControls.AMOUNT_TYPE]: DistributionOptions.PERCENTAGE,
          [DepositAmountControls.PERCENTAGE_AMOUNT]: '5.75',
          [DepositAmountControls.FLAT_AMOUNT]: '45.12'
        },
        []
      );

      expect(transformedDetails.pendingData.transitNumber).toBe('021000021');
      expect(transformedDetails.pendingData.institution).toBe('999');
    });

    it('should transform a new account with accountCode coming from codeValueData', () => {
      const transformedDetails = transformFormDetails(
        true,
        {
          [AccountDetailsControls.ACCOUNT_TYPE_CODE]: {
            label: 'Checking',
            shortName: ''
          },
          codeValueData: {
            accountCode: 'C2',
            shortName: ''
          },
          [AccountDetailsControls.ACCOUNT_NAME]: '',
          [AccountDetailsControls.ACCOUNT_NUMBER]: 'X123456P7',
          [AccountDetailsControls.ROUTING_NUMBER]: '021000021',
          [DepositAmountControls.AMOUNT_TYPE]: DistributionOptions.PERCENTAGE,
          [DepositAmountControls.PERCENTAGE_AMOUNT]: '5.75',
          [DepositAmountControls.FLAT_AMOUNT]: '45.12'
        },
        []
      );

      expect(transformedDetails.pendingData.codeValueData.accountCode).toBe('C2');
    });

    it('should transform a new account', () => {
      const [mockFormDetails, transformedForm] = MOCK_FORM_DETAILS.flatNew;

      const transformedDetails = transformFormDetails(
        true,
        mockFormDetails,
        MOCK_TRANSFORMED_DIRECT_DEPOSIT_ACCOUNTS
      );
      const transformedFormWithId = Object.assign(transformedForm, {
        id: transformedDetails.pendingData.id
      });

      expect(
        transformFormDetails(true, mockFormDetails, MOCK_TRANSFORMED_DIRECT_DEPOSIT_ACCOUNTS)
      ).toEqual({
        isWisely: false,
        currentData: null,
        pendingData: transformedFormWithId,
        pendingEvent: null
      });
    });

    it('should transform using codeValue if longName or shortName not provided', () => {
      const transformedDetails = transformFormDetails(
        true,
        {
          [AccountDetailsControls.ACCOUNT_TYPE_CODE]: {
            label: 'Checking',
            value: 'DED3',
            shortName: ''
          },
          codeValueData: {
            accountCode: 'C2',
            shortName: ''
          },
          [AccountDetailsControls.ACCOUNT_NAME]: '',
          [AccountDetailsControls.ACCOUNT_NUMBER]: 'X123456P7',
          [AccountDetailsControls.ROUTING_NUMBER]: '021000021',
          [DepositAmountControls.AMOUNT_TYPE]: DistributionOptions.PERCENTAGE,
          [DepositAmountControls.PERCENTAGE_AMOUNT]: '5.75',
          [DepositAmountControls.FLAT_AMOUNT]: '45.12'
        },
        []
      );

      expect(transformedDetails.pendingData.accountTypeName).toBe('DED3');
    });

    it('should transform an existing account', () => {
      const [mockFormDetails, transformedForm] = MOCK_FORM_DETAILS.percentageEdit;

      expect(
        transformFormDetails(false, mockFormDetails, MOCK_TRANSFORMED_DIRECT_DEPOSIT_ACCOUNTS)
      ).toEqual({
        isReadOnly: false,
        isWisely: false,
        isDailyPay: false,
        hasAltWorkflow: false,
        currentData: MOCK_TRANSFORMED_DIRECT_DEPOSIT_ACCOUNTS[1].currentData,
        pendingData: transformedForm,
        pendingEvent: null
      });
    });

    it('should transform an account with max flat amount', () => {
      const [mockFormDetails] = MOCK_FORM_DETAILS.flatNew;
      const maxAmountFormDetails = { ...mockFormDetails, flatAmount: '99,999,999.99' };

      expect(
        transformFormDetails(false, maxAmountFormDetails, MOCK_TRANSFORMED_DIRECT_DEPOSIT_ACCOUNTS)
      ).toHaveProperty('pendingData.flatAmount.amountValue', 99999999.99);
    });

    it('should make pendingEvent an empty object when transforming an edited pending WF event', () => {
      expect(
        transformFormDetails(
          false,
          {
            id: 'CheckingDED3',
            [AccountDetailsControls.ACCOUNT_TYPE_CODE]: {
              label: 'Checking',
              value: 'DED3',
              shortName: '',
              longName: 'Checking'
            },
            codeValueData: {
              accountCode: 'C2',
              shortName: '',
              longName: 'Checking 2'
            },
            [AccountDetailsControls.ACCOUNT_NAME]: '',
            [AccountDetailsControls.ACCOUNT_NUMBER]: 'X123456P7',
            [AccountDetailsControls.ROUTING_NUMBER]: '021000021',
            [DepositAmountControls.AMOUNT_TYPE]: DistributionOptions.PERCENTAGE,
            [DepositAmountControls.PERCENTAGE_AMOUNT]: '5.75',
            [DepositAmountControls.FLAT_AMOUNT]: '45.12'
          },
          [
            {
              isReadOnly: false,
              isWisely: false,
              isDailyPay: false,
              hasAltWorkflow: false,
              currentData: MOCK_TRANSFORMED_DIRECT_DEPOSIT_ACCOUNTS[1].currentData,
              pendingData: {
                id: 'CheckingDED3',
                accountName: '',
                accountTypeName: 'Checking',
                accountNumber: 'X123456P7',
                routingNumber: '021000021',
                distributionType: DistributionOptions.PERCENTAGE,
                percentageAmount: 5.75,
                flatAmount: null,
                prenoteIndicator: false
              },
              pendingEvent: { approver: 'Richard Sanchez', changeType: 'add' }
            }
          ]
        )
      ).toHaveProperty('pendingEvent', {});
    });
  });
});
