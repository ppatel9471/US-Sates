export const METADATA_PATH = {
  NEW_SCHEMA: {
    ACCOUNT_NAME: 'depositAccount.financialAccount.accountName',
    ROUTING_NUMBER: 'depositAccount.financialParty.routingTransitID.idValue',
    ACCOUNT_NUMBER: 'depositAccount.financialAccount.accountNumber',
    ACCOUNT_TYPE: 'depositAccount.financialAccount.typeCode',
    DISTRIBUTION_PERCENTAGE: 'distributionPercentage'
  },
  OLD_SCHEMA: {
    ROUTING_NUMBER: 'depositAccount.financialParty.routingTransitID.schemeCode.codeValue',
    ACCOUNT_NUMBER: 'depositAccount.BBAN',
    ACCOUNT_TYPE: 'precedenceCode'
  }
};

export const ALINE_CODE = 'ALN';
export const WISELY_CODE = 'WIS';

export enum DIRECT_DEPOSIT_EVENT_TYPE {
  CHANGE = 'change',
  ADD = 'add',
  DELETE = 'delete'
}

export interface DirectDepositFormattedAccount {
  distributionAmount?: { amountValue: number; currencyCode: string };
  remainingBalanceIndicator?: boolean;
  accountNumber?: string;
  routingNumber?: string;
  totalAccount?: number;
  accountType?: DirectDepositAccountType;
  isPayCard?: boolean;
  distributionPercentage?: number;
}

export interface DirectDepositComparisonData {
  accountType?: DirectDepositAccountType;
  currentData?: DirectDepositFormattedAccount;
  pendingData?: DirectDepositFormattedAccount;
  comparisonData?: DirectDepositFormattedAccount;
  type?: DIRECT_DEPOSIT_EVENT_TYPE;
}

export interface DirectDepositAccountType {
  codeValue: string;
  longName?: string;
  shortName?: string;
}
