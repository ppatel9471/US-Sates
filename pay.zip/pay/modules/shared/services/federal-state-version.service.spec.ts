import { TestBed } from '@angular/core/testing';
import { Mock } from 'ts-mockery';

import { MyAdpToggles, UserProfileService } from '@myadp/common';

import { getState } from '../../../models/states.model';
import { StepsService } from '../../tax-withholding-management/shared/services/steps.service';
import { FederalStateVersionService } from './federal-state-version.service';

describe('FederalStateVersionService', () => {
  let userProfileService: UserProfileService;
  let federalStateVersionService: FederalStateVersionService;
  let stepsService: StepsService;
  let myAdpToggles: MyAdpToggles;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        FederalStateVersionService,
        {
          provide: UserProfileService,
          useValue: Mock.of<UserProfileService>({
            hasFeaturedForSOR: () => false
          })
        },
        {
          provide: StepsService,
          useValue: Mock.of<StepsService>({
            isFederalData2019: () => true
          })
        },
        {
          provide: MyAdpToggles,
          useValue: Mock.of<MyAdpToggles>({
            payPA2021: false,
            payNE2022: false
          })
        }
      ]
    });

    userProfileService = TestBed.get(UserProfileService);
    myAdpToggles = TestBed.get(MyAdpToggles);
    stepsService = TestBed.get(StepsService);
    federalStateVersionService = TestBed.get(FederalStateVersionService);
  });

  describe('DEPRECATED MAP', () => {
    it('should return default state model when not in the deprecated map', () => {
      expect(federalStateVersionService.getYearState('DE')).toEqual(getState('DE'));
    });

    it('should NOT return deprecated state model when user does not meet whitelist criteria', () => {
      expect(federalStateVersionService.getYearState('Ohio')).toEqual(getState('OH'));
    });

    it('should return Pennsylvania model when feature toggle is enabled and SOR is blocklisted', () => {
      Mock.extend(myAdpToggles).with({
        payPA2021: true
      });
      Mock.extend(userProfileService).with({
        hasFeaturedForSOR: () => true
      });

      expect(federalStateVersionService.getYearState('Pennsylvania')).toEqual(getState('PA'));
    });

    it('should return Pennsylvania 2020 when SOR is blocklisted', () => {
      Mock.extend(userProfileService).with({
        hasFeaturedForSOR: () => true
      });
      expect(federalStateVersionService.getYearState('Pennsylvania')).toEqual(getState('PA2020'));
    });

    it('should return Ohio state model when SOR is allowlisted', () => {
      Mock.extend(userProfileService).with({
        hasFeaturedForSOR: () => false
      });
      expect(federalStateVersionService.getYearState('Ohio')).toEqual(getState('OH'));
    });

    it('should return Ohio 2020 state model when SOR is blocklisted', () => {
      Mock.extend(userProfileService).with({
        hasFeaturedForSOR: () => true
      });
      expect(federalStateVersionService.getYearState('Ohio')).toEqual(getState('OH2020'));
    });

    it('should return Nebraska 2019 state model when SOR is blocklisted', () => {
      expect(federalStateVersionService.getYearState('Nebraska')).toEqual(getState('NE2019'));
    });

    it('should return Nebraska 2019 state model when SOR is blocklisted', () => {
      Mock.extend(userProfileService).with({
        hasFeaturedForSOR: () => true
      });
      expect(federalStateVersionService.getYearState('Nebraska')).toEqual(getState('NE2019'));
    });

    it('should return Nebraska state model when NE feature toggle is enabled and SOR is blocklisted', () => {
      Mock.extend(userProfileService).with({
        hasFeaturedForSOR: () => true
      });
      Mock.extend(myAdpToggles).with({
        payNE2022: true
      });

      expect(federalStateVersionService.getYearState('Nebraska')).toEqual(getState('NE'));
    });

    it('should return Nebraska state model when NE feature toggle is enabled and SOR is allowlisted', () => {
      Mock.extend(userProfileService).with({
        hasFeaturedForSOR: () => false
      });
      Mock.extend(myAdpToggles).with({
        payNE2022: true
      });

      expect(federalStateVersionService.getYearState('Nebraska')).toEqual(getState('NE'));
    });
  });

  describe('FEDERAL STATES', () => {
    it('should NOT return 2019 state model when user does not meet whitelist criteria', () => {
      expect(federalStateVersionService.getYearState('Colorado')).toEqual(getState('CO'));
    });

    it('should NOT return 2019 state model when federal data is not 2019-format', () => {
      Mock.extend(stepsService).with({
        isFederalData2019: () => false
      });
      expect(federalStateVersionService.getYearState('Colorado')).toEqual(getState('CO'));
    });

    it('should return 2022 state model when user meets whitelist criteria', () => {
      Mock.extend(userProfileService).with({
        hasFeaturedForSOR: () => true
      });
      expect(federalStateVersionService.getYearState('Colorado')).toEqual(getState('CO2022'));
    });

    it('should return 2022 state model when CO feature toggle is enabled', () => {
      Mock.extend(userProfileService).with({
        hasFeaturedForSOR: () => false
      });
      Mock.extend(myAdpToggles).with({
        payCO2022: true
      });
      expect(federalStateVersionService.getYearState('Colorado')).toEqual(getState('CO2022'));
    });

    it('should return default state model when not in federal states map', () => {
      expect(federalStateVersionService.getYearState('New York')).toEqual(getState('NY'));
    });
  });
});
