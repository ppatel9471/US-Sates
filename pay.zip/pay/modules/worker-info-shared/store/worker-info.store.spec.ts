import { DatePipe } from '@angular/common';

import { PayrollWorker, Worker, WorkLocation } from '@myadp/dto';

import { MOCK_PAYROLL_WORKER_WORK_ASSIGNMENTS } from '../../../../../../src/spec-helpers/pay/pay-statement/pay-statement-details';
import { EMPTY_WORKER_INFO_STORE, WorkerInfoStoreSlice } from '../models/worker-info-state.model';
import { WorkerInfo, WorkerSsn } from '../models/worker-info.model';
import { WorkerInfoStore } from './worker-info.store';

describe('Worker Info Store', () => {
  let workerInfoStore: WorkerInfoStore;

  const mockSsn = '123456789';
  const mockFormattedSsn = '123-45-6789';
  const mockBirthDate = '1980-12-01';
  const mockGovernmentIds = [
    {
      idValue: mockSsn,
      itemID: 'SSN',
      nameCode: {
        codeValue: 'SSN',
        shortName: 'SSN',
        longName: 'Social Security Number'
      }
    }
  ];

  const mockWorkerInfo: WorkerInfo = {
    associateOID: '1',
    legalName: {
      givenName: 'Rachel',
      familyName1: 'Melony',
      middleName: 'Lisa',
      generationAffixCode: { longName: 'Jr', codeValue: '1' }
    },
    birthDate: 'xxxx-12-01',
    legalAddress: {
      lineOne: '123 Westside Pkwy',
      lineTwo: 'Apt E',
      lineThree: 'Address Line 3',
      cityName: 'Atlanta',
      countryCode: 'US',
      countrySubdivisionLevel1: {
        subdivisionType: 'State',
        codeValue: 'GA',
        longName: 'Georgia'
      },
      postalCode: '34243'
    }
  };

  const mockWorkerSsn: WorkerSsn = {
    formattedSSN: '123-45-6789',
    ssn: '123456789',
    isValid: true
  };

  const mockWorker: Worker = {
    associateOID: '1',
    person: {
      communication: {
        mobiles: [{ formattedNumber: '1234567890' }],
        landlines: [{ formattedNumber: '9876543210' }]
      },
      legalName: {
        givenName: 'Rachel',
        familyName1: 'Melony',
        middleName: 'Lisa',
        generationAffixCode: { longName: 'Jr', codeValue: '1' }
      },
      legalAddress: {
        lineOne: '123 Westside Pkwy'
      },
      governmentIDs: mockGovernmentIds,
      birthDate: 'xxxx-12-01'
    },
    workAssignments: [
      {
        assignedWorkLocations: [
          {
            nameCode: {
              codeValue: 'CA002',
              shortName: 'LosAngeles',
              longName: 'CA - Los Angeles'
            },
            address: {
              cityName: 'La Palma',
              countryCode: 'US',
              countrySubdivisionLevel1: {
                subdivisionType: 'State',
                codeValue: 'CA',
                longName: 'California'
              },
              lineOne: '5355 Orangethorpe',
              postalCode: '90623'
            }
          }
        ]
      }
    ],
    workerDates: {
      originalHireDate: '11/11/2011',
      rehireDate: null
    }
  };

  const mockWorkerProfile: PayrollWorker = {
    associateOID: '2',
    person: {
      governmentIDs: [
        {
          itemID: 'SSN',
          idValue: 'XXXXX1234',
          nameCode: { codeValue: 'SSN', shortName: 'SSN', longName: 'Social Security Number' },
          statusCode: { codeValue: 'VALID', longName: 'Valid' }
        }
      ],
      legalName: { givenName: 'Jasmine', familyName1: 'Wilson', formattedName: 'Wilson,Jasmine' },
      legalAddress: {
        lineOne: '2816 Woodstock Drive',
        cityName: 'Arcadia',
        countrySubdivisionLevel1: {
          subdivisionType: 'State',
          codeValue: 'CA',
          longName: 'California'
        },
        countryCode: 'US',
        postalCode: '91006'
      }
    },
    workerDates: { originalHireDate: '2014-11-11', adjustedServiceDate: null },
    workAssignment: MOCK_PAYROLL_WORKER_WORK_ASSIGNMENTS
  };

  const workLocation: WorkLocation = {
    nameCode: {
      codeValue: 'CA002',
      shortName: 'LosAngeles',
      longName: 'CA - Los Angeles'
    },
    address: {
      cityName: 'La Palma',
      countryCode: 'US',
      countrySubdivisionLevel1: {
        subdivisionType: 'State',
        codeValue: 'CA',
        longName: 'California'
      },
      lineOne: '5355 Orangethorpe',
      postalCode: '90623'
    }
  };

  beforeEach(() => {
    workerInfoStore = new WorkerInfoStore('en-US');
  });

  it('should create the store with an initial state', () => {
    expect(workerInfoStore).toBeTruthy();
    expect(workerInfoStore.stateValue).toEqual(EMPTY_WORKER_INFO_STORE);
  });

  describe('worker', () => {
    it('should have worker', async (done: DoneFn) => {
      workerInfoStore.update(WorkerInfoStoreSlice.WORKER, {
        data: mockWorker
      });
      workerInfoStore.worker$().subscribe((worker) => {
        expect(worker).toEqual(mockWorker);
        done();
      });
    });

    it('should have workerIsLoading', async (done: DoneFn) => {
      workerInfoStore.update(WorkerInfoStoreSlice.WORKER, {
        loading: true
      });
      workerInfoStore.workerIsLoading$().subscribe((loading) => {
        expect(loading).toBeTruthy();
        done();
      });
    });

    it('should have workerError', async (done: DoneFn) => {
      workerInfoStore.update(WorkerInfoStoreSlice.WORKER, {
        error: { loadWorkerError: true }
      });
      workerInfoStore.workerError$().subscribe((error) => {
        expect(error).toBeTruthy();
        done();
      });
    });
  });

  describe('workerInfo', () => {
    it('should have workerInfo', async (done: DoneFn) => {
      workerInfoStore.update(WorkerInfoStoreSlice.WORKER_INFO, {
        data: mockWorkerInfo
      });
      workerInfoStore.workerInfo$().subscribe((workerInfo) => {
        expect(workerInfo).toEqual(mockWorkerInfo);
        done();
      });
    });
  });

  describe('workerSsn', () => {
    it('should have ssn', async (done: DoneFn) => {
      workerInfoStore.update(WorkerInfoStoreSlice.WORKER_SSN, {
        data: mockWorkerSsn
      });
      workerInfoStore.formattedSsn$().subscribe((ssn) => {
        expect(ssn).toEqual(mockFormattedSsn);
        done();
      });
    });

    it('should have workerSsnIsLoading', async (done: DoneFn) => {
      workerInfoStore.update(WorkerInfoStoreSlice.WORKER_SSN, {
        loading: true
      });
      expect(workerInfoStore.stateValue[WorkerInfoStoreSlice.WORKER_SSN].loading);
      workerInfoStore.workerSsnOrBirthDateIsLoadingOrHasError$().subscribe((loading) => {
        expect(loading).toBeTruthy();
        done();
      });
    });

    it('should have isValid value', async (done: DoneFn) => {
      workerInfoStore.update(WorkerInfoStoreSlice.WORKER_SSN, {
        data: mockWorkerSsn
      });
      workerInfoStore.ssnValidateError$().subscribe((valid) => {
        expect(valid).toEqual(mockWorkerSsn.isValid);
        done();
      });
    });

    it('should get isValid true when SSN is in the correct format', async (done: DoneFn) => {
      mockWorkerSsn.ssn = '123456789';
      mockWorkerSsn.isValid = true;
      workerInfoStore.update(WorkerInfoStoreSlice.WORKER_SSN, {
        data: mockWorkerSsn
      });
      workerInfoStore.ssnValidateError$().subscribe((valid) => {
        expect(valid).toEqual(mockWorkerSsn.isValid);
        done();
      });
    });

    it('should get isValid false and get format as the validate reason when SSN is in the wrong format', async (done: DoneFn) => {
      mockWorkerSsn.ssn = '12345678';
      mockWorkerSsn.isValid = false;
      mockWorkerSsn.validateReason = 'format';
      workerInfoStore.update(WorkerInfoStoreSlice.WORKER_SSN, {
        data: mockWorkerSsn
      });
      workerInfoStore.ssnValidateError$().subscribe((valid) => {
        expect(valid).toEqual(mockWorkerSsn.isValid);
        done();
      });
      expect(workerInfoStore.getData(WorkerInfoStoreSlice.WORKER_SSN, 'validateReason')).toEqual(
        mockWorkerSsn.validateReason
      );
    });

    it('should get isValid false and get unmask as the validate reason when SSN is unmasked by X', async (done: DoneFn) => {
      mockWorkerSsn.ssn = 'XXXXX6789';
      mockWorkerSsn.isValid = false;
      mockWorkerSsn.validateReason = 'unmask';
      workerInfoStore.update(WorkerInfoStoreSlice.WORKER_SSN, {
        data: mockWorkerSsn
      });
      workerInfoStore.ssnValidateError$().subscribe((valid) => {
        expect(valid).toEqual(mockWorkerSsn.isValid);
        done();
      });
      expect(workerInfoStore.getData(WorkerInfoStoreSlice.WORKER_SSN, 'validateReason')).toEqual(
        mockWorkerSsn.validateReason
      );
    });

    it('should get isValid false and get unmask as the validate reason when SSN is unmasked by *', async (done: DoneFn) => {
      mockWorkerSsn.ssn = '*****6789';
      mockWorkerSsn.isValid = false;
      mockWorkerSsn.validateReason = 'unmask';
      workerInfoStore.update(WorkerInfoStoreSlice.WORKER_SSN, {
        data: mockWorkerSsn
      });
      expect(workerInfoStore.getData(WorkerInfoStoreSlice.WORKER_SSN, 'validateReason')).toEqual(
        mockWorkerSsn.validateReason
      );
      workerInfoStore.ssnValidateError$().subscribe((valid) => {
        expect(valid).toEqual(mockWorkerSsn.isValid);
        done();
      });
    });

    it('should get isValid false and get empty as the validate reason when SSN is empty', async (done: DoneFn) => {
      mockWorkerSsn.ssn = '';
      mockWorkerSsn.isValid = false;
      mockWorkerSsn.validateReason = 'empty';
      workerInfoStore.update(WorkerInfoStoreSlice.WORKER_SSN, {
        data: mockWorkerSsn
      });
      workerInfoStore.ssnValidateError$().subscribe((valid) => {
        expect(valid).toEqual(mockWorkerSsn.isValid);
        done();
      });
      expect(workerInfoStore.getData(WorkerInfoStoreSlice.WORKER_SSN, 'validateReason')).toEqual(
        mockWorkerSsn.validateReason
      );
    });

    it('should have workerSsnError', async (done: DoneFn) => {
      workerInfoStore.update(WorkerInfoStoreSlice.WORKER_SSN, {
        loading: false,
        error: { loadWorkerSsnError: true }
      });
      expect(workerInfoStore.stateValue[WorkerInfoStoreSlice.WORKER_SSN].error);
      workerInfoStore.workerSsnOrBirthDateIsLoadingOrHasError$().subscribe((loading) => {
        expect(loading).toBeTruthy();
        done();
      });
    });
  });

  describe('worker birth date', () => {
    it('should have birthDate', async (done: DoneFn) => {
      workerInfoStore.update(WorkerInfoStoreSlice.WORKER_BIRTHDATE, {
        data: mockBirthDate
      });
      workerInfoStore.workerBirthDate$().subscribe((birthDate) => {
        expect(birthDate).toEqual(mockBirthDate);
        done();
      });
    });

    it('should have workerBirthDateIsLoading', async (done: DoneFn) => {
      workerInfoStore.update(WorkerInfoStoreSlice.WORKER_BIRTHDATE, {
        loading: true
      });
      expect(workerInfoStore.stateValue[WorkerInfoStoreSlice.WORKER_BIRTHDATE].loading);
      workerInfoStore.workerSsnOrBirthDateIsLoadingOrHasError$().subscribe((loading) => {
        expect(loading).toBeTruthy();
        done();
      });
    });

    it('should have workerBirthDateError', async (done: DoneFn) => {
      workerInfoStore.update(WorkerInfoStoreSlice.WORKER_BIRTHDATE, {
        loading: false,
        error: { loadWorkerBirthDateError: true }
      });
      workerInfoStore.workerBirthDateError$().subscribe((error) => {
        expect(error).toBeTruthy();
        done();
      });
    });

    it('should have workerFormattedBirthDate', async (done: DoneFn) => {
      workerInfoStore.update(WorkerInfoStoreSlice.WORKER_BIRTHDATE, {
        loading: false,
        data: mockBirthDate
      });
      workerInfoStore.workerFormattedBirthDate$().subscribe((birthDate) => {
        const datePipe = new DatePipe('en-US');
        expect(birthDate).toEqual(datePipe.transform(birthDate, 'longDate'));
        done();
      });
    });
  });

  it('should have legalName', async (done: DoneFn) => {
    workerInfoStore.update(WorkerInfoStoreSlice.WORKER_INFO, {
      data: mockWorkerInfo
    });
    workerInfoStore.legalName$().subscribe((name) => {
      expect(name).toEqual(mockWorkerInfo.legalName);
      done();
    });
  });

  it('should have workAdress', async (done: DoneFn) => {
    workerInfoStore.update(WorkerInfoStoreSlice.WORKER_WORK_ASSIGNMENTS, {
      data: mockWorker.workAssignments
    });
    workerInfoStore.workLocation$().subscribe((address) => {
      expect(address).toEqual(workLocation.address);
      done();
    });
  });

  it('should have workAdress from worker-profile', async (done: DoneFn) => {
    workerInfoStore.update(WorkerInfoStoreSlice.WORKER_WORK_ASSIGNMENTS, {
      data: mockWorkerProfile.workAssignment
    });
    workerInfoStore.workLocation$().subscribe((address) => {
      expect(address).toEqual(mockWorkerProfile.workAssignment.assignedWorkLocations[0].address);
      done();
    });
  });

  it('should have employmentDate', () => {
    workerInfoStore.update(WorkerInfoStoreSlice.WORKER, {
      data: mockWorker
    });
    expect(workerInfoStore.employmentDate()).toEqual('11/11/2011');
    expect(workerInfoStore.determineEmploymentDate('01/01/2011')).toEqual('01/01/2011');
    expect(workerInfoStore.determineEmploymentDate(null)).toEqual('11/11/2011');
  });

  it('should have defaultPhone', () => {
    workerInfoStore.update(WorkerInfoStoreSlice.WORKER, {
      data: mockWorker
    });
    expect(workerInfoStore.defaultPhone()).toEqual('1234567890');
  });
});
