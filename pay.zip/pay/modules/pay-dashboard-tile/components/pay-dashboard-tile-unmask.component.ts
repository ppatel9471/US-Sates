import { Component } from '@angular/core';
@Component({
  selector: 'pay-dashboard-tile-unmask',
  template: '<pay-dashboard-tile [unmaskValues]="true"></pay-dashboard-tile>'
})
export class PayDashboardTileUnmaskComponent {}
