import { TestBed } from '@angular/core/testing';

import { WiselyNameDisplayPipe } from './wisely-name-display.pipe';

describe('WiselyNameDisplayPipe', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [WiselyNameDisplayPipe]
    });
  });

  it('should display a wisely name if they have wisely properties in said name', async () => {
    const pipe: WiselyNameDisplayPipe = new WiselyNameDisplayPipe();
    expect(pipe.transform('asdf')).toBe('asdf');
    expect(pipe.transform('wisely paaaay')).toBe('Wisely® by ADP');
    expect(pipe.transform('WISELY DIRECT')).toBe('Wisely® by ADP');
    expect(pipe.transform('wisElY pppp')).toBe('Wisely® by ADP');
    expect(pipe.transform('c2')).toBe('c2');
    expect(pipe.transform(undefined)).toBe('');
    expect(pipe.transform(null)).toBe('');
  });
});
