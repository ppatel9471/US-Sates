import { Shallow } from 'shallow-render';
import { LanguagePipe } from '@myadp/common';
import { ClientDeviceService, StackService } from '@synerg/components/shared';

import { PaylensModule } from '../../paylens.module';
import { PaylensStatementsListComponent } from './statements-list.component';
import { PayStatementsUI } from '../../../pay-statements-shared/models/pay-statement-ui';
import { PayStatementsDownloadCheckboxComponent } from '../statements-batch-download/download-checkbox/download-checkbox.component';
import { PaylensStatementsFilterComponent } from './statements-filter/statements-filter.component';
import { of } from 'rxjs';

const statements: PayStatementsUI.PayStatement[] = [
  {
    id: 1,
    payDate: 'Apr 14, 2019',
    netPay: undefined,
    grossPay: { amountValue: 1732.1, currencyCode: 'USD' },
    totalHours: 80,
    payDetailUri: '/v1_0/O/A/payStatement/1074162519254260000198001043940',
    statementImageUri:
      '/l2/v1_0/O/A/payStatement/1074162519264497000198001612729/images/CERooo008000620000r701AC7680FFC521.pdf',
    payAdjustment: true,
    statementFiscalYear: '2019',
    statementType: undefined
  },
  {
    id: 2,
    payDate: 'Apr 6, 2019',
    netPay: undefined,
    grossPay: { amountValue: 1732.1, currencyCode: 'USD' },
    totalHours: 80,
    payDetailUri: '/v1_0/O/A/payStatement/1074162519254260000198001043940',
    statementImageUri:
      '/l2/v1_0/O/A/payStatement/1074162519264497000198001612729/images/CERooo008000620000r701AC7680FFC521.pdf',
    payAdjustment: true,
    statementFiscalYear: '2019',
    statementType: undefined
  },
  {
    id: 3,
    payDate: 'Mar 1, 2018',
    netPay: undefined,
    grossPay: { amountValue: 1732.1, currencyCode: 'USD' },
    totalHours: 80,
    payDetailUri: '/v1_0/O/A/payStatement/1074162519254260000198001043941',
    statementImageUri:
      '/l2/v1_0/O/A/payStatement/1074162519264497000198001612730/images/CERooo008000620000r701AC7680FFC521.pdf',
    payAdjustment: true,
    statementFiscalYear: '2018',
    statementType: undefined
  }
];

const currentStatementData: PayStatementsUI.PayStatementDetailsState = {
  id: 1,
  payDetailUri: '/v1_0/O/A/payStatement/1074162519254260000198001043940',
  statementImageUri:
    '/l2/v1_0/O/A/payStatement/1074162519264497000198001612729/images/CERooo008000620000r701AC7680FFC521.pdf',
  statementFiscalYear: '2019',
  statementType: undefined,
  statement: {
    payDate: 'Apr 6, 2019'
  },
  statementDetails: {
    payDate: 'Apr 6, 2019'
  }
};

describe('PaylensStatementsListComponent', () => {
  let shallow: Shallow<PaylensStatementsListComponent>;

  beforeEach(() => {
    shallow = new Shallow(PaylensStatementsListComponent, PaylensModule)
      .mock(ClientDeviceService, {
        isIE: () => false
      })
      .mock(StackService, {
        modalStack$: of([]),
        slideinStack$: of([])
      })
      .mockPipe(LanguagePipe, (key) => key);
  });

  it('should emit the "statement" to get details for after selecting', async () => {
    const { find, outputs, instance } = await shallow.render({
      bind: { statements, currentStatementData }
    });
    spyOn(instance, 'loadDetails').and.callThrough();

    find('.statement-item-id-1 .statement-item-values-container').nativeElement.click();
    expect(outputs.loadedDetails.emit).toHaveBeenCalledWith(statements[0]);
    expect(instance.loadDetails).toHaveBeenCalledWith(statements[0]);
  });

  it('should emit the "statement" to get details for after clicking chevron', async () => {
    const { find, outputs, instance } = await shallow.render({
      bind: { statements, currentStatementData }
    });
    spyOn(instance, 'loadDetails').and.callThrough();

    find('.statement-item-id-1 .statement-item-icon').nativeElement.click();
    expect(outputs.loadedDetails.emit).toHaveBeenCalledWith(statements[0]);
    expect(instance.loadDetails).toHaveBeenCalledWith(statements[0]);
  });

  it('should filter statements based on current statement data', async () => {
    const { instance } = await shallow.render({ bind: { statements, currentStatementData } });
    const currentValues = instance.filteredStatements.getValue();
    expect(instance.currentStatementData.statementFiscalYear).toBe('2019');
    expect(currentValues.length).toBe(2);
    expect(currentValues[0].payDate).toBe('Apr 14, 2019');
    expect(currentValues[1].payDate).toBe('Apr 6, 2019');
  });

  it('should select first statement after filtering', async () => {
    const { instance } = await shallow.render({ bind: { statements, currentStatementData } });
    const currentValues = instance.filteredStatements.getValue();
    spyOn(instance, 'filterByYear').and.callThrough();
    spyOn(instance, 'loadDetails').and.callThrough();

    expect(currentValues.length).toBe(2);
    expect(currentValues[0].payDate).toBe('Apr 14, 2019');
    expect(currentValues[1].payDate).toBe('Apr 6, 2019');

    instance.onStatementsFiltered('2018');

    const newValues = instance.filteredStatements.getValue();
    expect(newValues.length).toBe(1);
    expect(newValues[0].payDate).toBe('Mar 1, 2018');
    expect(instance.filterByYear).toHaveBeenCalledWith('2018');
    expect(instance.loadDetails).toHaveBeenCalledWith(newValues[0]);
  });

  describe('autoSelectAfterFilter', () => {
    it('should show batch download checkboxes', async () => {
      const { findComponent } = await shallow.render({
        bind: { statements, currentStatementData }
      });
      expect(findComponent(PayStatementsDownloadCheckboxComponent)).toHaveFoundMoreThan(0);
    });

    it('should not show batch download checkboxes (native mobile)', async () => {
      const { findComponent } = await shallow.render({
        bind: { statements, currentStatementData, showBatchDownload: false }
      });
      expect(findComponent(PayStatementsDownloadCheckboxComponent)).toHaveFound(0);
    });
  });

  describe('showFilter', () => {
    it('should show year filter', async () => {
      const { findComponent } = await shallow.render({
        bind: { statements, currentStatementData }
      });
      expect(findComponent(PaylensStatementsFilterComponent)).toHaveFoundOne();
    });

    it('should NOT show year filter (mobile list views)', async () => {
      const { findComponent } = await shallow.render({
        bind: { statements, currentStatementData, showFilter: false }
      });
      expect(findComponent(PaylensStatementsFilterComponent)).toHaveFound(0);
    });
  });

  describe('autoSelectAfterFilter', () => {
    it('should trigger loading first statement after filtering (desktop view)', async () => {
      const { instance } = await shallow.render({
        bind: { statements, currentStatementData, autoSelectAfterFilter: true }
      });
      spyOn(instance, 'loadDetails').and.callThrough();
      instance.onStatementsFiltered('2018');
      expect(instance.loadDetails).toHaveBeenCalled();
    });

    it('should NOT trigger loading first statement after filtering (mobile list views)', async () => {
      const { instance } = await shallow.render({
        bind: { statements, currentStatementData, autoSelectAfterFilter: false }
      });
      spyOn(instance, 'loadDetails').and.callThrough();
      instance.onStatementsFiltered('2018');
      expect(instance.loadDetails).not.toHaveBeenCalled();
    });
  });

  describe('limit list', () => {
    it('should limit number of items in list (mobile statements & activities)', async () => {
      const { find } = await shallow.render({
        bind: { statements, currentStatementData, limit: 1 }
      });
      expect(find('.statement-item').length).toBe(1);
    });

    it('should NOT limit number of items in list', async () => {
      const { find } = await shallow.render({
        bind: { statements, currentStatementData, limit: null }
      });
      // filtered by year first
      expect(find('.statement-item').length).toBe(2);
    });
  });

  describe('autoFilterStatementList', () => {
    it('should call filterByYear on input change)', async () => {
      const { instance } = await shallow.render({
        bind: { statements, currentStatementData, limit: 1 }
      });
      spyOn(instance, 'filterByYear').and.callThrough();

      instance.ngOnChanges();
      expect(instance.filteredStatements.getValue().length).toBe(2);
      expect(instance.filterByYear).toHaveBeenCalled();
    });

    it('should not call filterByYear on input change)', async () => {
      const { instance } = await shallow.render({
        bind: { statements, currentStatementData, limit: 1, autoFilterStatementList: false }
      });
      spyOn(instance, 'filterByYear').and.callThrough();

      instance.ngOnChanges();
      expect(instance.filteredStatements.getValue().length).toBe(3);
      expect(instance.filterByYear).not.toHaveBeenCalled();
    });
  });

  describe('isDialogOpen$', () => {
    it('should set overflow to scroll by default', async () => {
      const { find } = await shallow.render();

      expect(find('.statement-items').length).toBe(1);
      expect(find('.statement-items.items-no-overflow').length).toBe(0);
    });

    it('should set overflow to scroll when browser is not IE and modal is open', async () => {
      const { find } = await shallow
        .mock(StackService, {
          modalStack$: of(['modalOne']),
          slideinStack$: of([])
        })
        .mock(ClientDeviceService, {
          isIE: () => false
        })
        .render();

      expect(find('.statement-items').length).toBe(1);
      expect(find('.statement-items.items-no-overflow').length).toBe(0);
    });

    it('should set overflow to hidden when browser is IE and modal is open', async () => {
      const { find } = await shallow
        .mock(StackService, {
          modalStack$: of(['modalOne']),
          slideinStack$: of([])
        })
        .mock(ClientDeviceService, {
          isIE: () => true
        })
        .render();

      expect(find('.statement-items.items-no-overflow').length).toBe(1);
    });

    it('should set overflow to hidden when browser is IE and slideIn is open', async () => {
      const { find } = await shallow
        .mock(StackService, {
          modalStack$: of([]),
          slideinStack$: of(['slideInOne'])
        })
        .mock(ClientDeviceService, {
          isIE: () => true
        })
        .render();

      expect(find('.statement-items.items-no-overflow').length).toBe(1);
    });
  });
});
