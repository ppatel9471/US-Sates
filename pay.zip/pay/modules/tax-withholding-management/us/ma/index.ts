import { MaIntroComponent } from './steps/intro/ma-intro.component';
import { MaDeprecatedIntroComponent } from './steps/intro/ma-deprecated-intro.component';
import { MaExemptionComponent } from './steps/exemption/ma-exemption.component';
import { MaDeprecatedExemptionComponent } from './steps/exemption/ma-deprecated-exemption.component';
import { MaAllowancesComponent } from './steps/allowances/ma-allowances.component';
import { MaAdditionalOptionsComponent } from './steps/additional-options/ma-additional-options.component';
import { MaAdditionalAllowancesComponent } from './steps/additional-allowances/ma-additional-allowances.component';

export { MaStepNavigationService } from './services/ma-step-navigation.service';
export { MaTWChangeEventService } from './services/ma-tw-change-event.service';
export { MaSummaryMetaDataService } from './services/ma-summary-meta-data.service';
export { MaDoneMetaDataService } from './services/ma-done-meta-data.service';
export { MaESignMetaDataService } from './services/ma-esign-meta-data.service';
export { MaSecondaryFormService } from './services/ma-secondary-form.service';

export const MA_COMPONENTS = [
  MaIntroComponent,
  MaDeprecatedIntroComponent,
  MaExemptionComponent,
  MaDeprecatedExemptionComponent,
  MaAllowancesComponent,
  MaAdditionalOptionsComponent,
  MaAdditionalAllowancesComponent
];

export { MASTEP_COMPONENT } from './models/steps-component.model';

export { MaAttachmentCodes } from './models/ma-tw-change-event';
