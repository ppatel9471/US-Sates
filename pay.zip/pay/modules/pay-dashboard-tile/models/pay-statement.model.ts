import { Amount } from '@myadp/dto';

export interface PayStatementsDTO {
  payStatements?: Array<PayStatementDTO>;
}

interface PayStatementDTO {
  payDate: string;
  netPayAmount?: Amount;
  grossPayAmount?: Amount;
  totalHours: number;
}

export interface PayStatementModel {
  payDate: string;
  netPay: Amount;
  grossPay: Amount;
  totalHours: number;
}
